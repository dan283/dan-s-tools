"""Non-destructive volume reconstruction and independent scanline fallback."""
import numpy as np


def scanline_axis(vertices,triangles,axis,resolution=128,merge=1e-5):
    """Integrate paired, unoriented mesh intersections on a projected grid.

    Duplicate hits merge geometrically; incomplete columns are discarded.
    A second axis is required by scanline_volume to confirm a solid.
    """
    order=[i for i in range(3) if i!=axis]+[axis]
    v=np.asarray(vertices)[:,order]; p=v[np.asarray(triangles)]
    low=v.min(axis=0); span=np.ptp(v,axis=0)
    if np.any(span<=1e-12): return dict(volume=0.,odd_fraction=1.,columns=0)
    sizes=np.maximum(12,np.ceil(resolution*span[:2]/span.max()).astype(int))
    step=span[:2]/sizes; rows=[]; depths=[]
    for tri in p:
        a,b,c=tri
        e1,e2=b[:2]-a[:2],c[:2]-a[:2]
        den=e1[0]*e2[1]-e1[1]*e2[0]
        if abs(den)<1e-15: continue
        start=np.maximum(0,np.ceil((tri[:,:2].min(axis=0)-low[:2])/step-.5).astype(int))
        end=np.minimum(sizes-1,np.floor((tri[:,:2].max(axis=0)-low[:2])/step-.5).astype(int))
        if np.any(end<start): continue
        xx,yy=np.meshgrid(np.arange(start[0],end[0]+1),np.arange(start[1],end[1]+1),indexing='ij')
        delta=np.column_stack((low[0]+(xx.ravel()+.5)*step[0],low[1]+(yy.ravel()+.5)*step[1]))-a[:2]
        u=(delta[:,0]*e2[1]-delta[:,1]*e2[0])/den
        w=(e1[0]*delta[:,1]-e1[1]*delta[:,0])/den
        valid=(u>=-1e-9)&(w>=-1e-9)&(u+w<=1+1e-9)
        if not valid.any(): continue
        rows.append((xx.ravel()*sizes[1]+yy.ravel())[valid])
        depths.append(a[2]+u[valid]*(b[2]-a[2])+w[valid]*(c[2]-a[2]))
    if not rows: return dict(volume=0.,odd_fraction=1.,columns=0)
    row=np.concatenate(rows); z=np.concatenate(depths); sort=np.lexsort((z,row)); row,z=row[sort],z[sort]
    keep=np.r_[True,(row[1:]!=row[:-1])|(np.diff(z)>merge)]
    row,z=row[keep],z[keep]
    starts=np.r_[0,np.flatnonzero(np.diff(row))+1]; ends=np.r_[starts[1:],len(row)]
    count=ends-starts; complete=(count%2==0)
    # Ignore columns with a single hit. Never cap a missing surface to the box.
    group=np.repeat(np.arange(len(starts)),count)
    rank=np.arange(len(z))-np.repeat(starts,count)
    contributions=np.where(rank%2==0,-z,z)
    lengths=np.bincount(group,weights=contributions)
    return dict(volume=float(lengths[complete].sum()*np.prod(step)),
                odd_fraction=float((~complete).mean()),columns=int(len(starts)))


def scanline_volume(vertices,triangles,resolution=128):
    span=float(np.max(np.ptp(vertices,axis=0)))
    axes=[scanline_axis(vertices,triangles,i,resolution,max(span*1e-6,1e-7)) for i in range(3)]
    usable=[a['volume'] for a in axes if a['columns']>=8 and a['odd_fraction']<=.08 and a['volume']>0]
    if len(usable)<2: raise ValueError('Not enough independent solid sections to estimate volume')
    volume=float(np.median(usable)); disagreement=float((max(usable)-min(usable))/volume*100)
    return dict(volume_mm3=volume,axis_disagreement_percent=disagreement,
                odd_columns_percent=[float(a['odd_fraction']*100) for a in axes])


def resolve(metrics,reconstruct,vertices,triangles,resolution=192,force=False):
    """Keep exact single-shell integration; otherwise reconstruct at two scales."""
    if np.linalg.matrix_rank(np.cov(np.asarray(vertices).T))<3:
        raise ValueError('A planar surface has no supported solid volume')
    if metrics['valid_volume'] and metrics['shells']==1 and not force:
        return dict(volume_mm3=metrics['volume_mm3'],volume_estimated=False,
                    volume_method='Closed mesh integration',volume_available=True)
    coarse=max(48,resolution//2); backend_error=None
    try:
        first=reconstruct(coarse); second=reconstruct(resolution)
        method='Voxel solid reconstruction'
    except Exception as error:
        backend_error=str(error)
        first=scanline_volume(vertices,triangles,coarse); second=scanline_volume(vertices,triangles,resolution)
        method='Multi-axis paired-section estimate'
    a,b=float(first['volume_mm3']),float(second['volume_mm3'])
    if not np.isfinite(b) or b<=0: raise ValueError('Reconstruction did not produce a measurable solid')
    variation=abs(a-b)/b*100
    disagreement=second.get('axis_disagreement_percent',0.)
    return dict(volume_mm3=b,volume_estimated=True,volume_available=True,volume_method=method,
                volume_resolution=int(resolution),volume_voxel_mm=float(np.max(np.ptp(vertices,axis=0))/resolution),
                volume_coarse_mm3=a,volume_refinement_change_percent=variation,
                volume_axis_disagreement_percent=disagreement,
                volume_confidence='Stable estimate' if max(variation,disagreement)<3 else 'Needs finer resolution / inspection',
                volume_backend_note=backend_error)


def verify_bore_void(vertices,triangles,section,spacing):
    """Refuse a reconstructed solid that fills the measured finger opening."""
    from . import bore
    u,w,n,o=section['basis']; c=section['ring']['center']
    origin=o+c[0]*u+c[1]*w
    occupied=0
    for direction in (u,w,n):
        hits=bore.line_hits(vertices,triangles,origin,direction,max(spacing*.01,1e-8))
        positive=hits[hits>max(spacing*.001,1e-9)]
        occupied+=int(len(positive)%2==1)
    if occupied>=2:
        raise ValueError('Voxel reconstruction filled the finger bore; use the source-section estimate instead')


def blender_voxel(context,vertices,triangles,resolution,bore_check=None):
    """Evaluate OpenVDB on a temporary normalized copy and clean it on every path."""
    import bpy
    from . import core
    scale=float(np.max(np.ptp(vertices,axis=0)))
    if scale<=1e-12: raise ValueError('Object has no solid dimensions')
    normalized=(np.asarray(vertices)-(np.min(vertices,axis=0)+np.max(vertices,axis=0))*.5)/scale
    # Duplicate triangles and zero-area faces can interfere with reconstruction.
    faces=np.asarray(triangles); keys=np.sort(faces,axis=1)
    _,ids=np.unique(keys,axis=0,return_index=True); faces=faces[np.sort(ids)]
    tri=normalized[faces]; area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)
    faces=faces[area>1e-14]
    mesh=None; obj=None; evaluated=None
    try:
        mesh=bpy.data.meshes.new('__JG_volume_mesh')
        mesh.from_pydata(normalized.tolist(),[],faces.tolist()); mesh.update()
        obj=bpy.data.objects.new('__JG_volume_copy',mesh)
        context.scene.collection.objects.link(obj)
        obj.hide_render=True
        # Reorient only inconsistent surface soups. Well-oriented cavity shells
        # keep their original orientation for signed solid reconstruction.
        audit=core.mesh_metrics(normalized,faces)
        if audit['winding_edges']:
            import bmesh
            bm=bmesh.new()
            try:
                bm.from_mesh(mesh); bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces)); bm.to_mesh(mesh)
            finally: bm.free()
        modifier=obj.modifiers.new('Measurement only','REMESH')
        modifier.mode='VOXEL'; modifier.voxel_size=1./resolution
        modifier.use_remove_disconnected=False
        modifier.use_smooth_shade=False
        evaluated=obj.evaluated_get(context.evaluated_depsgraph_get()); result=evaluated.to_mesh()
        if result is None: raise ValueError('Voxel reconstruction returned no mesh')
        result.calc_loop_triangles()
        raw=np.empty(len(result.vertices)*3,dtype=float); result.vertices.foreach_get('co',raw)
        tt=np.empty(len(result.loop_triangles)*3,dtype=np.int32); result.loop_triangles.foreach_get('vertices',tt)
        rebuilt=core.mesh_metrics(raw.reshape((-1,3))*scale,tt.reshape((-1,3)))
        if not rebuilt['valid_volume']: raise ValueError('Voxel reconstruction did not close the solid')
        if bore_check is not None:
            verify_bore_void(raw.reshape((-1,3))*scale,tt.reshape((-1,3)),bore_check,scale/resolution)
        return dict(volume_mm3=rebuilt['volume_mm3'])
    finally:
        try:
            if evaluated is not None: evaluated.to_mesh_clear()
        finally:
            try:
                if obj is not None: bpy.data.objects.remove(obj,do_unlink=True)
            finally:
                if mesh is not None: bpy.data.meshes.remove(mesh)

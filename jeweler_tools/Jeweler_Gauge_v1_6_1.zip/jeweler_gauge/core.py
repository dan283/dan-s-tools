"""Double-precision mesh measurements in millimetres; no Blender dependency."""
import math
from collections import defaultdict
import numpy as np

# Alloy entries are representative planning densities, NOT alloy specifications.
# Pure precious metal values: Heraeus melting-temperatures-en.pdf.
# 18k yellow reference composition: LBMA Density of Gold (equal Ag/Cu remainder).
MATERIALS = [
    ('AU24', 'Gold 24k / fine', 19.32, 1.0),
    ('AU22', 'Gold 22k yellow (approx.)', 17.70, 22/24),
    ('AU18Y', 'Gold 18k yellow (approx.)', 15.40, .750),
    ('AU18R', 'Gold 18k rose (approx.)', 15.10, .750),
    ('AU18W', 'Gold 18k white (approx.)', 15.70, .750),
    ('AU14Y', 'Gold 14k yellow / 585 (approx.)', 13.10, .585),
    ('AU14R', 'Gold 14k rose / 585 (approx.)', 13.00, .585),
    ('AU14W', 'Gold 14k white / 585 (approx.)', 12.70, .585),
    ('AU9', 'Gold 9k / 375 (approx.)', 11.20, .375),
    ('AG999', 'Fine silver 999', 10.49, .999),
    ('AG925', 'Sterling silver 925 (approx.)', 10.36, .925),
    ('AG935', 'Silver 935 (approx.)', 10.40, .935),
    ('PT999', 'Fine platinum', 21.45, 1.0),
    ('PT950', 'Platinum 950 (approx.)', 20.70, .950),
    ('PD', 'Palladium', 12.02, 1.0),
    ('TI', 'Titanium (approx.)', 4.51, 1.0),
    ('STEEL', 'Stainless steel (approx.)', 7.90, 1.0),
    ('BRASS', 'Brass (approx.)', 8.50, 1.0),
    ('COPPER', 'Copper (approx.)', 8.96, 1.0),
    ('WAX', 'Casting wax (approx.)', 0.95, 0.0),
    ('RESIN', 'Printing resin (approx.)', 1.10, 0.0),
    ('DIAMOND', 'Diamond (approx.)', 3.52, 0.0),
    ('CUSTOM', 'Custom density', 10.0, 0.0),
]
MATERIAL_MAP = {m[0]: m for m in MATERIALS}


def weld_exact(vertices, triangles):
    """Join identical coordinates for measurement only; preserve every position.

    STL-style face-local vertices otherwise falsely appear as open boundaries.
    No distance threshold, smoothing, geometric repair or face removal is used.
    """
    v = np.asarray(vertices, dtype=np.float64)
    t = np.asarray(triangles, dtype=np.int64)
    unique, inverse = np.unique(v, axis=0, return_inverse=True)
    return unique, inverse[t], len(v)-len(unique)


def mesh_metrics(vertices, triangles):
    v = np.asarray(vertices, dtype=np.float64)
    t = np.asarray(triangles, dtype=np.int64)
    if len(v) < 3 or len(t) == 0:
        raise ValueError('No evaluated mesh faces. Realize Geometry Nodes instances first.')
    p = v[t]
    cross = np.cross(p[:, 1] - p[:, 0], p[:, 2] - p[:, 0])
    areas = np.linalg.norm(cross, axis=1) * .5
    span = np.ptp(v, axis=0)
    tol = max(float(np.max(span)), 1.) * 1e-10
    degenerate = int(np.count_nonzero(areas < tol*tol))
    # Translation to nearby reference keeps large world coordinates stable.
    q = p - (v.min(axis=0) + v.max(axis=0)) * .5
    signed = float(np.einsum('ij,ij->i', q[:, 0], np.cross(q[:, 1], q[:, 2])).sum()/6.)
    edges = np.concatenate((t[:, [0, 1]], t[:, [1, 2]], t[:, [2, 0]]))
    canonical = np.sort(edges, axis=1)
    unique, inv, counts = np.unique(canonical, axis=0, return_inverse=True, return_counts=True)
    orientation = np.bincount(inv, weights=np.where(edges[:, 0] < edges[:, 1], 1., -1.))
    boundary = int(np.count_nonzero(counts == 1))
    nonmanifold = int(np.count_nonzero(counts > 2))
    inconsistent = int(np.count_nonzero((counts == 2) & (orientation != 0)))
    # Count connected surface components via edges (triangle-generated diagonals included).
    parent = np.arange(len(v))
    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for a, b in unique:
        a, b = root(a), root(b)
        if a != b:
            parent[b] = a
    shells = len({root(int(a)) for a in np.unique(t)})
    valid = not (boundary or nonmanifold or inconsistent or degenerate) and abs(signed) > tol**3
    normals = cross / np.maximum(np.linalg.norm(cross, axis=1)[:, None], 1e-30)
    warnings = []
    if boundary: warnings.append(f'{boundary} open boundary edges: volume/weight unavailable')
    if nonmanifold: warnings.append(f'{nonmanifold} non-manifold edges: volume/weight unavailable')
    if inconsistent: warnings.append(f'{inconsistent} inconsistent winding edges: volume/weight unavailable')
    if degenerate: warnings.append(f'{degenerate} degenerate triangles: volume/weight unavailable')
    if shells > 1: warnings.append(f'{shells} connected shells: verify overlaps and cavity orientation')
    return dict(volume_mm3=abs(signed) if valid else None, signed_volume=signed,
                area_mm2=float(areas.sum()), dimensions_mm=span.tolist(), valid_volume=valid,
                boundary_edges=boundary, nonmanifold_edges=nonmanifold, winding_edges=inconsistent,
                degenerate_triangles=degenerate, shells=shells, triangles=len(t), warnings=warnings,
                normals=normals, triangle_areas=areas)


def frame(normal):
    n = np.asarray(normal, dtype=float)
    n /= np.linalg.norm(n)
    helper = np.eye(3)[np.argmin(np.abs(n))]
    u = helper - n*np.dot(helper, n)
    u /= np.linalg.norm(u)
    return u, np.cross(n, u), n


def polygon_info(points):
    a = np.asarray(points, dtype=float)
    b = np.roll(a, -1, axis=0)
    cross = a[:, 0]*b[:, 1] - b[:, 0]*a[:, 1]
    area = cross.sum()*.5
    center = ((a+b)*cross[:, None]).sum(axis=0)/(6*area) if abs(area) > 1e-16 else a.mean(axis=0)
    return dict(perimeter=float(np.linalg.norm(b-a, axis=1).sum()), area=abs(float(area)),
                center=center, points=a)


def inside(point, polygon):
    a = np.asarray(polygon)
    b = np.roll(a, -1, axis=0)
    x, y = point
    mask = (a[:, 1] > y) != (b[:, 1] > y)
    aa, bb = a[mask], b[mask]
    if not len(aa): return False
    xx = aa[:, 0]+(y-aa[:, 1])*(bb[:, 0]-aa[:, 0])/(bb[:, 1]-aa[:, 1])
    return bool(np.count_nonzero(xx > x) % 2)


def section_loops(vertices, triangles, origin, normal, tolerance=1e-5):
    """Intersect triangles and stitch true contours, rejecting open/branched contours.

    Coplanar ambiguities are avoided with a tiny reproducible plane perturbation.
    Returned origin includes that shift so overlays match the measured plane.
    """
    v, t = np.asarray(vertices), np.asarray(triangles)
    u, w, n = frame(normal)
    o = np.asarray(origin, dtype=float)
    distances = (v-o) @ n
    if np.any(np.abs(distances) < tolerance*.05):
        o = o + n*tolerance*.173
        distances = (v-o) @ n
    d = distances[t]
    crossing = (np.min(d, axis=1) < 0) & (np.max(d, axis=1) > 0)
    ct, cd = t[crossing], d[crossing]
    cuts = []
    for i, j in ((0, 1), (1, 2), (2, 0)):
        mask = (cd[:, i] < 0) != (cd[:, j] < 0)
        ids = np.flatnonzero(mask)
        f = cd[mask, i] / (cd[mask, i]-cd[mask, j])
        p = v[ct[mask, i]] + f[:, None]*(v[ct[mask, j]]-v[ct[mask, i]])
        edge_ids = np.sort(ct[mask][:, [i,j]],axis=1)
        cuts.append((ids, p, edge_ids))
    segment_points = defaultdict(list)
    for ids, pp, ee in cuts:
        for k, p, edge in zip(ids, pp, ee): segment_points[int(k)].append((tuple(edge),p))
    nodes, positions, graph, segments = {}, [], defaultdict(set), set()
    def node(key,p):
        # Shared edge IDs join intersections exactly even on extremely dense
        # triangles, without rounding neighboring cuts into unrelated bins.
        if key not in nodes:
            nodes[key] = len(positions)
            positions.append(p)
        return nodes[key]
    for pp in segment_points.values():
        if len(pp) != 2: continue
        a, b = node(*pp[0]), node(*pp[1])
        if a == b: continue
        edge = tuple(sorted((a, b)))
        segments.add(edge)
        graph[a].add(b); graph[b].add(a)
    visited, loops, rejected = set(), [], 0
    for start in graph:
        if start in visited: continue
        component, stack = set(), [start]
        while stack:
            a = stack.pop()
            if a in component: continue
            component.add(a); stack.extend(graph[a]-component)
        visited.update(component)
        if any(len(graph[a]) != 2 for a in component):
            rejected += 1; continue
        order, previous, current = [], None, start
        while True:
            order.append(current)
            nxt = next(a for a in graph[current] if a != previous)
            previous, current = current, nxt
            if current == start: break
            if len(order) > len(component): break
        if len(order) < 3: continue
        p = np.asarray([positions[i] for i in order]) - o
        xy = np.column_stack((p@u, p@w))
        info = polygon_info(xy)
        if info['area'] > tolerance*tolerance: loops.append(info)
    return loops, (u, w, n, o), rejected


def select_ring(loops, preferred_center=None):
    """Largest nested opening; an arbitrary disjoint gemstone isn't the ring bore."""
    pairs = []
    for hole in loops:
        for outer in loops:
            if outer['area'] <= hole['area']*1.001: continue
            # Test several contour points, not centroid alone (both ring contours
            # and a disconnected setting can have overlapping centroids).
            samples = hole['points'][::max(1, len(hole['points'])//16)]
            if all(inside(p, outer['points']) for p in samples):
                if preferred_center is not None and not inside(preferred_center, hole['points']): continue
                pairs.append((hole, outer))
    if not pairs: return None
    hole = max((h for h, _ in pairs), key=lambda h: h['area'])
    outer = min((o for h, o in pairs if h is hole), key=lambda o: o['area'])
    return hole, outer


def ray_polygon(center, direction, points):
    a = points-center
    e = np.roll(points, -1, axis=0)-points
    def cross2(x, y): return x[..., 0]*y[..., 1]-x[..., 1]*y[..., 0]
    den = cross2(direction, e)
    valid = np.abs(den) > 1e-12
    r = np.full(len(a), np.inf); s = np.full(len(a), np.inf)
    r[valid] = cross2(a[valid], e[valid])/den[valid]
    s[valid] = cross2(a[valid], direction)/den[valid]
    hits = np.sort(r[valid & (r > 1e-8) & (s >= -1e-8) & (s < 1.-1e-8)])
    if not len(hits): return []
    return [float(h) for i, h in enumerate(hits) if i == 0 or h-hits[i-1] > 1e-7]


def ring_metrics(hole, outer, samples=360, center=None, boundaries=None):
    c = np.asarray(center) if center is not None else hole['center']
    if not inside(c, hole['points']): raise ValueError('Ring center is outside the opening. Use cursor center.')
    theta = np.arange(samples)*2*math.pi/samples
    directions = np.column_stack((np.cos(theta), np.sin(theta)))
    inner, outer_r, thickness, endpoints, ambiguous = [], [], [], [], 0
    for d in directions:
        ri, ro = ray_polygon(c, d, hole['points']), ray_polygon(c, d, outer['points'])
        if len(ri) != 1 or len(ro) != 1 or ro[0] <= ri[0]:
            inner.append(np.nan); outer_r.append(np.nan); thickness.append(np.nan)
            endpoints.append(None); ambiguous += 1
        else:
            exit_radius = ro[0]
            # Stop at intervening cutouts rather than counting voids as metal.
            if boundaries:
                for contour in boundaries:
                    if contour is hole or contour is outer: continue
                    beyond = [h for h in ray_polygon(c, d, contour['points']) if h > ri[0]+1e-5]
                    if beyond: exit_radius = min(exit_radius, min(beyond))
            inner.append(ri[0]); outer_r.append(ro[0]); thickness.append(exit_radius-ri[0])
            endpoints.append((c+d*ri[0], c+d*exit_radius))
    inner, thickness = np.asarray(inner), np.asarray(thickness)
    if samples % 2 == 0:
        diameters = inner + np.roll(inner, samples//2)
    else:
        opposite = []
        for d in directions:
            hits = ray_polygon(c, -d, hole['points'])
            opposite.append(hits[0] if len(hits) == 1 else np.nan)
        diameters = inner + np.asarray(opposite)
    finite = thickness[np.isfinite(thickness)]
    if not len(finite): raise ValueError('No unambiguous radial thickness. Try another slice/center.')
    ci, co = hole['perimeter'], outer['perimeter']
    return dict(inner_circumference_mm=ci, outer_circumference_mm=co,
                equivalent_inner_diameter_mm=ci/math.pi,
                inner_diameter_min_mm=float(np.nanmin(diameters)),
                inner_diameter_max_mm=float(np.nanmax(diameters)),
                ovality_mm=float(np.nanmax(diameters)-np.nanmin(diameters)),
                radial_thickness_min_mm=float(np.min(finite)),
                radial_thickness_max_mm=float(np.max(finite)),
                radial_thickness_mean_mm=float(np.mean(finite)),
                circularity=4*math.pi*hole['area']/(ci*ci),
                center=c, radial_thickness=thickness, endpoints=endpoints,
                ambiguous_rays=ambiguous,
                us_size_estimate=(ci-36.5367)/2.5535)


def detect_axis(vertices, triangles, local_axes, tolerance=1e-5):
    v = np.asarray(vertices)
    origin = (v.min(axis=0)+v.max(axis=0))*.5
    # Includes PCA for arbitrary applied rotation, and object axes for signets
    # whose heavier top biases PCA. Explicit axis remains available.
    _, eig = np.linalg.eigh(np.cov((v-origin).T))
    candidates = list(local_axes)+[eig[:, i] for i in range(3)]
    seen, best = [], None
    for axis in candidates:
        n = np.asarray(axis, dtype=float); n /= np.linalg.norm(n)
        if any(abs(n@other) > .9999 for other in seen): continue
        seen.append(n)
        axial = v@n
        pair = None
        for fraction in (.5,.35,.65,.2,.8,.1,.9):
            plane = n*(axial.min()+np.ptp(axial)*fraction)
            loops, basis, rejected = section_loops(v, triangles, plane, n, tolerance)
            pair = select_ring(loops)
            if pair: break
        if not pair: continue
        h, out = pair
        circularity = 4*math.pi*h['area']/(h['perimeter']**2)
        equivalent_diameter = h['perimeter']/math.pi
        # Favor a bore-aligned plane over an oblique section whose ellipse has
        # a larger perimeter/area. Applied rotation remains handled by PCA.
        aspect = float(np.ptp(axial))/max(equivalent_diameter,1e-9)
        score = h['area']*circularity**4/(1+aspect*aspect*4)
        if best is None or score > best[0]: best = (score, n)
    if best is None: raise ValueError('No closed ring opening detected. Choose axis and slice manually.')
    return best[1]


def calibration_factor(current_factor,measured_diameter,known_diameter):
    values=np.asarray([current_factor,measured_diameter,known_diameter],dtype=float)
    if not np.all(np.isfinite(values)) or np.any(values<=0):
        raise ValueError('Calibration requires positive physical and measured diameters')
    return float(current_factor*known_diameter/measured_diameter)


def casting_plan(volume_mm3, density, shrink_percent, allowance_percent, price_per_gram):
    mass = volume_mm3*density/1000
    factor = 1/(1-shrink_percent/100)
    charge = mass*(1+allowance_percent/100)
    return dict(weight_g=mass, compensation_scale=factor,
                compensated_pattern_volume_mm3=volume_mm3*factor**3,
                casting_charge_estimate_g=charge, metal_cost=mass*price_per_gram)

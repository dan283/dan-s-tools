bl_info = {
    'name': 'Jeweler Gauge', 'author': 'Dan / Codex', 'version': (1, 6, 1),
    'blender': (4, 2, 0), 'location': 'View3D > Sidebar > Jeweler',
    'description': 'Mesh ring contours, wall probes, alloy weights and casting reports',
    'category': '3D View',
}

import bpy
import math
import json
import csv
import time
import numpy as np
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty,
                       IntProperty, PointerProperty, StringProperty, CollectionProperty)
from bpy.types import Operator, Panel, PropertyGroup
from bpy.app.handlers import persistent
from bpy_extras import view3d_utils
from bpy_extras.io_utils import ExportHelper
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from . import core, bore, guides, solid, profile, silhouette, visibility
# Legacy add-on reinstall can reload only the package while leaving its pure
# helper modules cached. Refresh those helpers so measurements use this version.
import importlib
core = importlib.reload(core)
bore = importlib.reload(bore)
guides = importlib.reload(guides)
solid = importlib.reload(solid)
profile = importlib.reload(profile)
silhouette = importlib.reload(silhouette)
visibility = importlib.reload(visibility)

_CACHE = {}
_DIRTY = {}
_HANDLES = []
_HOVER = None
_MODAL = None
_SHADERS = {}
_LIVE_FACE_LIMIT = 250000
_VOLUME_BUSY = False
MATERIAL_ITEMS = [(m[0], m[1], f'{m[2]:g} g/cm³; use your supplier density for alloy accuracy') for m in core.MATERIALS]


def redraw():
    for wm in getattr(bpy.data, 'window_managers', ()):
        for win in wm.windows:
            for area in win.screen.areas:
                if area.type == 'VIEW_3D': area.tag_redraw()


def dirty(self, context):
    if context and context.scene:
        _DIRTY[context.scene.as_pointer()] = time.monotonic()
        redraw()


def overlay_update(self, context):
    redraw()


def category_update(self,context):
    self.overlay=any(visibility.enabled(self,p) for p,_,_ in visibility.CATEGORIES)
    if self.show_comparisons or self.show_casting: self.hud_detail=True
    redraw()


def slice_changed(self, context):
    self.auto_slice = False
    dirty(self,context)


def material_changed(self, context):
    if self.material != 'CUSTOM': self.density = core.MATERIAL_MAP[self.material][2]
    redraw()


def object_material_changed(self, context):
    if self.material != 'CUSTOM': self.density = core.MATERIAL_MAP[self.material][2]
    redraw()


def object_filter(self, obj):
    return obj.type in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'}


def target_changed(self,context):
    if getattr(self,'lock_object',None)!=self.target:
        self.bore_locked=False; self.lock_object=None
    dirty(self,context)


class JG_ObjectSettings(PropertyGroup):
    use_override: BoolProperty(name='Use object alloy', default=False)
    material: EnumProperty(name='Alloy', items=MATERIAL_ITEMS, default='AG925', update=object_material_changed)
    density: FloatProperty(name='Density g/cm³', default=10.36, min=.001, max=100., precision=4)
    exclude: BoolProperty(name='Exclude from batch metal weight', description='Exclude stones, display helpers or non-metal parts', default=False)


class JG_Probe(PropertyGroup):
    kind: StringProperty(default='WALL')
    label: StringProperty(default='Wall')
    a: FloatVectorProperty(size=3)
    b: FloatVectorProperty(size=3)
    value_mm: FloatProperty()
    source: StringProperty()


class JG_Settings(PropertyGroup):
    target: PointerProperty(name='Measure object', type=bpy.types.Object, poll=object_filter, update=target_changed)
    mode: EnumProperty(name='Mode', items=[('RING', 'Ring', 'Measure nested cross-section contours'), ('OBJECT', 'Object', 'Volume, dimensions and weight')], default='RING', update=dirty)
    units: EnumProperty(name='Scale convention', items=[('SCENE', 'Scene units', '1 Blender unit = scene scale × 1000 mm'), ('MM', '1 Blender unit = 1 mm', 'Useful for jewelry meshes modeled directly in millimetres'), ('CUSTOM', 'Custom calibration', 'Specify physical millimetres per Blender unit')], default='SCENE', update=dirty)
    mm_per_unit: FloatProperty(name='mm per Blender unit', default=1., min=.000001, precision=6, update=dirty)
    live: BoolProperty(name='Live measurements', description='Debounced refresh; heavy meshes refresh manually', default=True, update=dirty)
    overlay: BoolProperty(name='Viewport overlay', default=True, update=overlay_update)
    xray: BoolProperty(name='Show through mesh', default=True, update=overlay_update)
    show_hud: BoolProperty(name='Viewport dashboard', default=False, update=overlay_update)
    hud_detail: BoolProperty(name='Full dashboard / all readouts', description='Show all material comparisons, casting values and inspection data; compact mode leaves more room for on-object guides', default=False, update=overlay_update)
    show_labels: BoolProperty(name='On-object labels', default=True, update=overlay_update)
    show_bbox: BoolProperty(name='Bounding box / XYZ dimensions', default=False, update=category_update)
    show_inside: BoolProperty(name='Inside circumference',default=True,update=category_update)
    show_outside: BoolProperty(name='Outside circumference',default=True,update=category_update)
    show_shank_thickness: BoolProperty(name='Shank thickness',default=True,update=category_update)
    show_shank_depth: BoolProperty(name='Shank maximum depth',default=True,update=category_update)
    show_body_dimensions: BoolProperty(name='Whole ring body dimensions',default=False,update=category_update)
    show_volume: BoolProperty(name='Volume / material weight',default=True,update=category_update)
    show_surface: BoolProperty(name='Surface / mesh information',default=False,update=category_update)
    show_probes: BoolProperty(name='Pinned calipers / wall probes',default=True,update=category_update)
    show_diagnostics: BoolProperty(name='Advanced section diagnostics',default=False,update=category_update)
    show_quality: BoolProperty(name='Measurement notes',default=False,update=category_update)
    ring_focus: BoolProperty(name='Focus guides on bore and shank', description='Show local shank dimensions instead of radial extrema; body/top heights and XYZ dimensions have independent toggles', default=True, update=overlay_update)
    show_custom_gauge: BoolProperty(name='Custom angle guide', default=False, update=category_update)
    show_height_guides: BoolProperty(name='Crown: three heights',default=True,update=category_update)
    show_top_depth: BoolProperty(name='Top / crown depth',default=True,update=category_update)
    visibility_details: BoolProperty(name='Customize categories',default=False,update=overlay_update)
    ui_revision: IntProperty(default=0,options={'HIDDEN'})
    show_top_tiers: BoolProperty(name='Separate top-tier height guides',default=True,update=overlay_update)
    seam_tolerance: FloatProperty(name='Surface merge tolerance mm', description='Treat nearly coincident section/ray hits as one surface; for messy/overlapping triangles, not a source mesh edit', default=.005, min=.00001, max=.5, precision=4, update=dirty)
    show_ring_guides: BoolProperty(name='Ring contour / wall guides', default=True, update=overlay_update)
    show_diameters: BoolProperty(name='Bore diameter guides', default=True, update=category_update)
    show_plane: BoolProperty(name='Slice plane guide', default=True, update=overlay_update)
    show_extremes: BoolProperty(name='Thickness extrema guides', default=True, update=overlay_update)
    show_comparisons: BoolProperty(name='Other material weights in dashboard', default=False, update=category_update)
    show_casting: BoolProperty(name='Casting / sizing dashboard', default=False, update=category_update)
    font_size: IntProperty(name='Label size', default=20, min=10, max=48, soft_max=32, update=overlay_update)
    decimals: IntProperty(name='Display decimals', default=2, min=1, max=6, update=overlay_update)
    guide_offset: FloatProperty(name='Guide spacing', default=.12, min=.02, max=.6, subtype='FACTOR', update=overlay_update)
    label_limit: IntProperty(name='Pinned labels shown', default=30, min=1, max=200, update=overlay_update)
    axis: EnumProperty(name='Ring axis', items=[('AUTO', 'Find main finger bore', 'Circular evidence from geometric cuts and surface-normal directions; ignores small decorative loops'), ('X', 'Object X', 'Cross-section perpendicular to local X'), ('Y', 'Object Y', 'Cross-section perpendicular to local Y'), ('Z', 'Object Z', 'Cross-section perpendicular to local Z'), ('CURSOR', '3D cursor Z', 'Use the rotated 3D cursor orientation')], default='AUTO', update=dirty)
    auto_slice: BoolProperty(name='Auto-center slice in shank', description='Find a supported bore slice, then center it using local side-shank widths rather than the decorative head; dragging slice switches this off', default=True, update=dirty)
    slice: FloatProperty(name='Slice through width', description='Fraction of axial bounding span: 0 = one edge; 1 = the other', default=.5, min=.001, max=.999, subtype='FACTOR', update=slice_changed)
    slice_offset: FloatProperty(name='Slice offset mm', description='Extra axial offset from the fractional slice', default=0., precision=3, update=dirty)
    center_mode: EnumProperty(name='Opening center', items=[('AUTO', 'Contour centroid', 'Use the area centroid of the detected opening'), ('CURSOR', '3D cursor', 'Use cursor position projected into the slice; helps asymmetric/openings with multiple holes')], default='AUTO', update=dirty)
    bore_locked: BoolProperty(name='Lock bore axis / center',default=False,update=dirty)
    lock_object: PointerProperty(type=bpy.types.Object)
    lock_normal: FloatVectorProperty(size=3,default=(0,0,1))
    lock_center: FloatVectorProperty(size=3)
    known_bore: FloatProperty(name='Known inner diameter mm',description='For a round bore: set physical scale from its measured equivalent diameter and your known diameter. Do not guess a desired size',default=18.,min=6.,max=50.,precision=3)
    ring_style: EnumProperty(name='Ring / top type',items=[('AUTO','Detect raised top','Inspect the complete mesh, including a setting outside the main ring section'),('PLAIN','Plain ring','The complete ring outline is the body; no top separation'),('RAISED','Signet / raised setting','Separate a raised top from the shank envelope')],default='AUTO',update=dirty)
    ring_view: EnumProperty(name='Ring measurement view',items=[('FRONT','Front silhouette','Union of all projected surfaces, including off-center crowns; sampled outline'),('SECTION','Central section (diagnostic)','Traditional cut through the selected shank slice')],default='FRONT',update=dirty)
    silhouette_resolution: IntProperty(name='Silhouette resolution',description='Samples across the largest front dimension; increase for small outline details. Circumferences are approximate',default=1024,min=256,max=2048,update=dirty)
    custom_top_direction: BoolProperty(name='Set crown direction manually',default=False,update=dirty)
    crown_angle: FloatProperty(name='Crown direction',description='Angle in the detected bore plane; points from the finger opening toward the setting',default=math.pi*.5,subtype='ANGLE',update=dirty)
    height_base_mode: EnumProperty(name='Body / top split',items=[('AUTO','Automatic shank reference','Use a crown exit surface when supported, otherwise estimate from side/lower shank'),('MANUAL','Manual reference plane','Set the body-top height above the bore center')],default='AUTO',update=dirty)
    body_top_reference: FloatProperty(name='Body top above bore center mm',description='Physical distance along crown direction from bore center to the body/top reference plane',default=11.,min=.000001,precision=3,update=dirty)
    angle: FloatProperty(name='Gauge angle', description='Radial wall measurement at this angle in the section frame', default=0., min=-math.pi*2, max=math.pi*2, subtype='ANGLE', update=overlay_update)
    samples: IntProperty(name='Radial samples', default=360, min=36, max=1440, step=36, update=dirty)
    material: EnumProperty(name='Default alloy', items=MATERIAL_ITEMS, default='AG925', update=material_changed)
    density: FloatProperty(name='Density g/cm³', description='Editable: supplier alloy density takes precedence over estimates', default=10.36, min=.001, max=100., precision=4, update=overlay_update)
    volume_mode: EnumProperty(name='Volume method', items=[('AUTO','Smart automatic','Exact integration for a closed single shell; reconstruct damaged or multiple shells'),('SOLID','Reconstruct solid','Voxel reconstruction, including overlaps; does not edit your object'),('EXACT','Strict mesh only','Require closed edges and consistent winding')],default='AUTO',update=dirty)
    volume_resolution: IntProperty(name='Volume resolution',description='Voxels across the longest physical dimension; compares half-resolution with this resolution. Higher values preserve finer detail',default=192,min=64,max=512,step=32,update=dirty)
    minimum_wall: FloatProperty(name='Minimum wall mm', description='Your design threshold; no universal casting minimum is assumed', default=.8, min=.001, precision=3, update=overlay_update)
    scan_samples: IntProperty(name='Wall scan samples', description='Deterministic area-weighted face samples; results are sampled, not a guaranteed global minimum', default=2000, min=100, max=20000)
    width_slices: IntProperty(name='Width scan slices', default=11, min=3, max=51)
    price: FloatProperty(name='Alloy price / g', description='Manual price in your chosen currency per gram of this alloy', default=0., min=0., precision=2, update=overlay_update)
    currency: StringProperty(name='Currency', default='HUF')
    shrink: FloatProperty(name='Linear shrinkage %', description='Combined process shrinkage assumption; oversize factor = 1/(1-s)', default=1.5, min=0., max=15., precision=2, update=overlay_update)
    allowance: FloatProperty(name='Charge allowance %', description='Extra charge for sprues/buttons/process reserve; estimate only', default=20., min=0., max=1000., precision=1, update=overlay_update)
    target_circ: FloatProperty(name='Desired inner circumference mm', default=56., min=1., max=200., precision=3, update=overlay_update)
    probes: CollectionProperty(type=JG_Probe)


def mm_factor(scene):
    s = scene.jeweler_gauge
    if s.units == 'MM': return 1.
    if s.units == 'CUSTOM': return s.mm_per_unit
    return scene.unit_settings.scale_length*1000.


def snapshot(context, obj):
    if obj.mode == 'EDIT': obj.update_from_editmode()
    eval_obj = obj.evaluated_get(context.evaluated_depsgraph_get())
    mesh = eval_obj.to_mesh()
    if mesh is None: raise ValueError('Target has no evaluated mesh')
    try:
        mesh.calc_loop_triangles()
        raw = np.empty(len(mesh.vertices)*3, dtype=np.float64)
        mesh.vertices.foreach_get('co', raw)
        local = raw.reshape((-1, 3))
        tr = np.empty(len(mesh.loop_triangles)*3, dtype=np.int32)
        mesh.loop_triangles.foreach_get('vertices', tr)
        triangles = tr.reshape((-1, 3)).copy()
        if not len(local) or not len(triangles): raise ValueError('No mesh faces. Realize Geometry Nodes instances before measuring.')
        matrix = np.asarray(eval_obj.matrix_world, dtype=np.float64)
        world = local@matrix[:3, :3].T+matrix[:3, 3]
        reference = (world.min(axis=0)+world.max(axis=0))*.5
        factor = mm_factor(context.scene)
        vertices,triangles,joined = core.weld_exact((world-reference)*factor,triangles)
        axes = [matrix[:3, i]/max(np.linalg.norm(matrix[:3, i]), 1e-30) for i in range(3)]
        return dict(v=vertices, t=triangles, reference=reference, factor=factor,
                    axes=axes, object_name=obj.name, object_pointer=obj.as_pointer(),duplicate_vertices_joined=joined)
    finally:
        eval_obj.to_mesh_clear()


def to_world(data, point):
    return Vector(tuple(np.asarray(point)/data['factor']+data['reference']))


def to_mm(data, point):
    return (np.asarray(point)-data['reference'])*data['factor']


def contour_section(data, s, scene, fraction=None, normal=None):
    n = normal
    if n is None:
        if s.axis == 'AUTO': n = core.detect_axis(data['v'], data['t'], data['axes'])
        elif s.axis == 'CURSOR': n = tuple(scene.cursor.matrix.to_3x3().col[2].normalized())
        else: n = data['axes']['XYZ'.index(s.axis)]
    n = np.asarray(n); n = n/np.linalg.norm(n)
    coords = data['v']@n
    f = s.slice if fraction is None else fraction
    height = float(coords.min()+(coords.max()-coords.min())*f+s.slice_offset)
    origin = n*height
    fractions = [f]
    if fraction is None and s.auto_slice:
        fractions += [ff for ff in (.5,.35,.65,.2,.8,.1,.9) if abs(ff-f) > 1e-8]
    pair = None
    for actual_fraction in fractions:
        height = float(coords.min()+(coords.max()-coords.min())*actual_fraction+s.slice_offset)
        origin = n*height
        loops,basis,rejected = core.section_loops(data['v'],data['t'],origin,n)
        u,w,_,o = basis
        preferred = None
        if s.center_mode == 'CURSOR':
            cursor = to_mm(data,scene.cursor.location)-o
            preferred = np.array([cursor@u,cursor@w])
        pair = core.select_ring(loops,preferred)
        if pair and pair[0]['perimeter']/math.pi < np.max(np.ptp(data['v'],axis=0))*.18:
            pair = None
        if pair: break
    if pair is None:
        raise ValueError(f'No nested closed contours at this slice ({len(loops)} closed, {rejected} open/branched). Choose axis/slice/center.')
    h, out = pair
    ring = core.ring_metrics(h, out, s.samples, preferred, loops)
    ring['axial_span_mm'] = float(coords.max()-coords.min())
    ring['slice_position_mm'] = height
    ring['actual_slice_fraction'] = float(actual_fraction)
    ring['open_contours'] = rejected
    ring['extra_contours'] = max(0, len(loops)-2)
    ring.update(estimated=False,measurement_method='Exact mesh contour',bore_coverage_percent=100.)
    return dict(ring=ring, hole=h, outer=out, contours=loops, basis=basis)


def section_at(data,s,scene,fraction=None,normal=None):
    fixed_normal = normal
    if fixed_normal is None and s.axis != 'AUTO':
        fixed_normal = (tuple(scene.cursor.matrix.to_3x3().col[2].normalized()) if s.axis == 'CURSOR'
                        else data['axes']['XYZ'.index(s.axis)])
    preferred = to_mm(data,scene.cursor.location) if s.center_mode=='CURSOR' else None
    locked=bool(getattr(s,'bore_locked',False) and getattr(s,'lock_object',None)==s.target)
    locked_fraction=None
    if locked:
        matrix=np.asarray(s.target.matrix_world,dtype=float)
        fixed_normal=np.linalg.inv(matrix[:3,:3]).T@np.asarray(s.lock_normal)
        fixed_normal/=np.linalg.norm(fixed_normal)
        local=np.r_[np.asarray(s.lock_center),1.]
        preferred=to_mm(data,(matrix@local)[:3])
        axial=data['v']@fixed_normal
        locked_fraction=float((preferred@fixed_normal-axial.min())/max(np.ptp(axial),1e-12))
    tolerance = min(getattr(s,'seam_tolerance',.005),float(np.max(np.ptp(data['v'],axis=0)))*.0002)
    chosen_fraction=(locked_fraction if locked and fraction is None else s.slice if fraction is None else fraction)
    try:
        result = bore.find(data['v'],data['t'],data['axes'],
                           chosen_fraction,fixed_normal,
                           s.auto_slice and fraction is None and not locked,preferred,s.slice_offset)
        sec = bore.section(result,s.samples,tolerance)
        bore.exact_contours(data['v'],data['t'],sec)
    except ValueError:
        # A valid, large oval bore still has useful exact contours even when
        # a circular fit is unsuitable. Decorative pinholes are rejected here.
        sec = contour_section(data,s,scene,chosen_fraction if locked else fraction,fixed_normal)
    sec['ring']['axial_span_mm'] = float(np.ptp(data['v']@sec['basis'][2]))
    sec['ring']['bore_axis_world']=sec['basis'][2].tolist()
    sec['ring']['bore_locked']=locked
    sec['ring']['scale_warning']=bore.scale_hint(sec['ring']['equivalent_inner_diameter_mm'])
    if fraction is None:
        stations = bore.stations(data['v'],data['t'],sec,tolerance)
        # Place the automatic measuring plane at the shank's own width center,
        # not at the whole-object center biased by a broad signet head.
        if s.auto_slice and not locked and abs(s.slice_offset)<1e-9 and sec.get('bore_fit'):
            centers = [(p['width_a']+p['width_b'])*.5 for p in stations[:2] if p['width_mm'] is not None]
            if centers:
                n = sec['basis'][2]; axial = data['v']@n
                height = float(np.median([p@n for p in centers]))
                if abs(height-sec['basis'][3]@n)>.005:
                    f = float((height-axial.min())/max(np.ptp(axial),1e-9))
                    try:
                        res = bore.find(data['v'],data['t'],data['axes'],f,n,False,preferred)
                        sec = bore.section(res,s.samples,tolerance)
                        bore.exact_contours(data['v'],data['t'],sec)
                        sec['ring']['axial_span_mm'] = float(np.ptp(axial))
                        bore.stations(data['v'],data['t'],sec,tolerance)
                    except ValueError: pass
    sec['ring'].update(bore_axis_world=sec['basis'][2].tolist(),bore_locked=locked,
                       scale_warning=bore.scale_hint(sec['ring']['equivalent_inner_diameter_mm']))
    if sec['ring']['scale_warning']: sec['ring']['us_size_estimate']=None
    if fraction is None:
        if getattr(s,'ring_view','SECTION')=='FRONT':
            try:
                sec['silhouette']=silhouette.ring(data['v'],data['t'],sec,getattr(s,'silhouette_resolution',1024))
                front=sec['silhouette']
                front['ring']=dict(sec['ring'])
                front['ring'].update(core.ring_metrics(front['hole'],front['outer'],s.samples,sec['ring']['center']))
                front['ring'].update({key:value for key,value in sec['ring'].items() if key in
                    {'actual_slice_fraction','axial_span_mm','scale_warning','bore_locked','bore_axis_world'}})
                front['ring'].update(estimated=True,inner_estimated=True,outer_estimated=True,
                    measurement_method=front['method'],outer_measurement_method=front['method'])
            except ValueError as error: sec['silhouette_error']=str(error)
        try:
            sec['height_profile']=profile.analyze(data['v'],data['t'],sec,
                style=getattr(s,'ring_style','AUTO'),
                direction=getattr(s,'crown_angle',math.pi*.5) if getattr(s,'custom_top_direction',False) else None,
                manual_base=getattr(s,'body_top_reference',11.) if getattr(s,'height_base_mode','AUTO')=='MANUAL' else None)
            if sec.get('silhouette') and getattr(s,'ring_style','AUTO')!='PLAIN':
                sec['height_profile']=profile.front_crown(data['v'],sec,sec['height_profile'],
                    getattr(s,'body_top_reference',11.) if getattr(s,'height_base_mode','AUTO')=='MANUAL' else None)
            crown=sec['height_profile']['top_direction_degrees']*np.pi/180.
            if abs(np.arctan2(np.sin(crown-sec.get('top_angle',crown)),np.cos(crown-sec.get('top_angle',crown))))>np.pi/360:
                bore.stations(data['v'],data['t'],sec,tolerance,crown_angle=crown)
            for key in ('body_height_mm','total_height_mm','top_height_mm','crown_band_thickness_mm',
                        'top_width_mm','top_depth_mm','body_reference_estimated','has_raised_top'):
                sec['ring'][key]=sec['height_profile'][key]
        except ValueError as error: sec['height_error']=str(error)
    return sec


def measure(context, obj, ring=True):
    global _VOLUME_BUSY
    data = snapshot(context, obj)
    data['metrics'] = core.mesh_metrics(data['v'], data['t'])
    m=data['metrics']; s=context.scene.jeweler_gauge
    data['section']=None; data['ring_error']=''
    if ring:
        try: data['section']=section_at(data,s,context.scene)
        except ValueError as error: data['ring_error']=str(error)
    m.update(volume_available=m['volume_mm3'] is not None,volume_estimated=False,volume_method='Strict mesh integration')
    if s.volume_mode!='EXACT':
        previous=_CACHE.get(context.scene.as_pointer(),{})
        same=(previous.get('object_pointer')==data['object_pointer'] and 'v' in previous and
              previous.get('volume_settings')==(s.volume_mode,s.volume_resolution) and
              np.array_equal(previous['v'],data['v']) and np.array_equal(previous['t'],data['t']))
        try:
            _VOLUME_BUSY=True
            if same:
                estimate={key:value for key,value in previous['metrics'].items() if key.startswith('volume_')}
            else:
                def reconstruct(resolution):
                    if data['section']:
                        return solid.blender_voxel(context,data['v'],data['t'],resolution,bore_check=data['section'])
                    return solid.blender_voxel(context,data['v'],data['t'],resolution)
                estimate=solid.resolve(m,reconstruct,
                                       data['v'],data['t'],s.volume_resolution,force=s.volume_mode=='SOLID')
            m.update(estimate)
            if m.get('volume_estimated'):
                m['warnings']=[warning.replace(': volume/weight unavailable',': source mesh defect') for warning in m['warnings']]
                m['warnings'].append('Volume/weight use a reconstructed solid estimate; refinement change is not a guaranteed error bound')
                if m.get('volume_backend_note'):
                    m['warnings'].append('Voxel estimate rejected: '+m['volume_backend_note'])
                    m['warnings'].append('Voxel reconstruction unavailable; paired-section fallback may misread overlapping shells')
        except Exception as error:
            # An uncertain strict sum of overlapping shells is not a fallback.
            m.update(volume_mm3=None,volume_available=False,volume_estimated=True,volume_method='Reconstruction unavailable')
            m['warnings'].append('Solid volume could not be reconstructed: '+str(error))
        finally: _VOLUME_BUSY=False
    data['volume_settings']=(s.volume_mode,s.volume_resolution)
    if data['duplicate_vertices_joined']:
        data['metrics']['warnings'].append(f'{data["duplicate_vertices_joined"]:,} identical seam vertices joined for measurement only')
    if any(mod.type == 'NODES' and mod.show_viewport for mod in obj.modifiers):
        data['metrics']['warnings'].append('Geometry Nodes: ensure instances are realized; only evaluated mesh faces are measured')
    if ring:
        if data['section'] and data['section']['ring'].get('scale_warning'):
            m['warnings'].append(data['section']['ring']['scale_warning'])
    data['time'] = time.strftime('%Y-%m-%d %H:%M:%S')
    return data


def refresh(context, force=True):
    s = context.scene.jeweler_gauge
    key = context.scene.as_pointer()
    if not s.target:
        _CACHE.pop(key, None); _DIRTY.pop(key, None); return None
    try:
        previous = _CACHE.get(key)
        data = measure(context, s.target, s.mode == 'RING')
        data['settings_signature'] = settings_signature(context.scene)
        if previous and 'metrics' in previous and previous.get('object_pointer') == data['object_pointer']:
            same_geometry = (previous['factor'] == data['factor'] and
                             np.array_equal(previous['v'], data['v']) and
                             np.array_equal(previous['t'], data['t']))
            if same_geometry:
                if 'wall_scan' in previous: data['wall_scan'] = previous['wall_scan']
                if 'width_scan' in previous and previous.get('settings_signature') == data['settings_signature']:
                    data['width_scan'] = previous['width_scan']
        _CACHE[key] = data
        _DIRTY.pop(key, None)
        redraw()
        return data
    except Exception as e:
        _CACHE[key] = {'error': str(e), 'object_name': s.target.name, 'object_pointer': s.target.as_pointer()}
        _DIRTY.pop(key, None)
        redraw()
        return None


def settings_signature(scene):
    s = scene.jeweler_gauge
    return (mm_factor(scene), s.mode, s.axis, s.slice, s.slice_offset,
            s.center_mode, s.samples, s.auto_slice, s.seam_tolerance,s.volume_mode,s.volume_resolution,
            getattr(s,'bore_locked',False),tuple(getattr(s,'lock_normal',(0,0,1))),tuple(getattr(s,'lock_center',(0,0,0))),
            getattr(s,'ring_style','AUTO'),getattr(s,'custom_top_direction',False),getattr(s,'crown_angle',math.pi*.5),
            getattr(s,'height_base_mode','AUTO'),getattr(s,'body_top_reference',11.),
            getattr(s,'ring_view','SECTION'),getattr(s,'silhouette_resolution',1024),
            tuple(scene.cursor.location), tuple(scene.cursor.rotation_euler))


def current(context):
    s = context.scene.jeweler_gauge
    if not s.target: return None
    d = _CACHE.get(context.scene.as_pointer())
    if d and s.target and d.get('object_pointer') != s.target.as_pointer(): return None
    return d


def get_bvh(data):
    if 'bvh' not in data:
        data['bvh'] = BVHTree.FromPolygons([Vector(p) for p in data['v']], data['t'].tolist(), all_triangles=True)
    return data['bvh']


def radial_gauge(data, angle):
    sec = data.get('section')
    if not sec: return None
    center = sec['ring']['center']
    direction = np.array([math.cos(angle), math.sin(angle)])
    if 'segments' in sec:
        radius = sec['bore_fit']['radius']
        hits = bore.segment_hits(sec['segments'],center,direction,sec.get('merge_tolerance',.005))
        after = hits[hits>=radius*.6]
        if len(after)<2: return None
        return center+direction*after[0],center+direction*after[1],after[1]-after[0]
    ri = core.ray_polygon(center, direction, sec['hole']['points'])
    ro = core.ray_polygon(center, direction, sec['outer']['points'])
    if len(ri) != 1 or len(ro) != 1 or ro[0] <= ri[0]: return None
    exit_radius = ro[0]
    for contour in sec['contours']:
        if contour is sec['hole'] or contour is sec['outer']: continue
        beyond = [h for h in core.ray_polygon(center, direction, contour['points']) if h > ri[0]+1e-5]
        if beyond: exit_radius = min(exit_radius, min(beyond))
    return center+direction*ri[0], center+direction*exit_radius, exit_radius-ri[0]


def wall_ray(data, point, normal):
    """First material chord from entry point in inward face-normal direction."""
    m = data['metrics']
    if not m['valid_volume']: return None
    tree = get_bvh(data)
    sign = 1. if m['signed_volume'] >= 0 else -1.
    direction = -Vector(normal).normalized()*sign
    span = max(m['dimensions_mm'])
    epsilon = max(span*1e-7, 1e-6)
    hit, exit_normal, index, distance = tree.ray_cast(Vector(point)+direction*epsilon, direction, span*2)
    if hit is None or distance <= epsilon or exit_normal.dot(direction)*sign <= .05: return None
    return (Vector(point), hit, (hit-Vector(point)).length)


def alloy(scene, obj):
    settings = obj.jg_alloy if obj.jg_alloy.use_override else scene.jeweler_gauge
    return settings.material, settings.density


def add_probe(context, data, a_mm, b_mm, value, kind='WALL'):
    s = context.scene.jeweler_gauge
    p = s.probes.add()
    p.kind = kind; p.label = f'{"Wall" if kind == "WALL" else "Caliper"} {len(s.probes)}'
    p.a = to_world(data, a_mm); p.b = to_world(data, b_mm)
    p.value_mm = value; p.source = data['object_name']
    redraw()


class JG_OT_target(Operator):
    bl_idname = 'jg.use_active'
    bl_label = 'Measure Active Object'
    bl_description = 'Set active object as measurement target; does not modify the mesh'
    @classmethod
    def poll(cls, context): return context.object and object_filter(None, context.object)
    def execute(self, context):
        s = context.scene.jeweler_gauge
        if s.target != context.object and s.mode == 'RING':
            s.axis = 'AUTO'; s.slice = .5; s.slice_offset = 0.; s.center_mode = 'AUTO'; s.auto_slice = True
            s.bore_locked=False; s.lock_object=None
        s.target = context.object
        refresh(context)
        return {'FINISHED'}


class JG_OT_refresh(Operator):
    bl_idname = 'jg.refresh'
    bl_label = 'Refresh Measurements'
    def execute(self, context):
        d = refresh(context)
        if d is None:
            self.report({'WARNING'}, 'Choose an object, or check the measurement error in the panel')
            return {'CANCELLED'}
        return {'FINISHED'}


class JG_OT_visibility(Operator):
    bl_idname='jg.visibility'; bl_label='Measurement Visibility'
    preset: EnumProperty(items=[('ALL','Show all','Show all meaningful measurement categories'),
        ('NONE','Hide all','Hide guides, HUD values and probes'),('RING','Ring essentials','Clean ring measurements'),
        ('CROWN','Crown only','Show just the three crown height measurements')],default='RING')
    def execute(self,context):
        visibility.preset(context.scene.jeweler_gauge,self.preset)
        redraw(); return {'FINISHED'}


class JG_OT_visibility_group(Operator):
    bl_idname='jg.visibility_group'; bl_label='Toggle Measurement Group'
    bl_description='Show or hide this group in guides and measurement readouts'
    group: EnumProperty(items=[(key,label,'Toggle '+label) for key,label,_ in visibility.GROUPS])
    def execute(self,context):
        visibility.toggle_group(context.scene.jeweler_gauge,self.group)
        redraw(); return {'FINISHED'}


class JG_OT_refine_volume(Operator):
    bl_idname='jg.refine_volume'
    bl_label='Refine Volume / Weight'
    bl_description='Reconstruct at finer voxel resolution and update all material weights'
    def execute(self,context):
        s=context.scene.jeweler_gauge
        s.volume_mode='SOLID'; s.volume_resolution=min(512,s.volume_resolution*2)
        # At maximum resolution still allow an explicit recomputation.
        previous=_CACHE.get(context.scene.as_pointer(),{})
        previous.pop('volume_settings',None)
        d=refresh(context)
        if not d or d['metrics']['volume_mm3'] is None:
            self.report({'WARNING'},'No measurable solid; see the mesh notes'); return {'CANCELLED'}
        self.report({'INFO'},'Updated reconstructed volume and alloy weights'); return {'FINISHED'}


class JG_OT_detect_bore(Operator):
    bl_idname = 'jg.detect_bore'
    bl_label = 'Re-detect Main Bore'
    bl_description = 'Reset old ring axis/slice choices and find the main finger opening and shank center again'
    @classmethod
    def poll(cls,context): return context.scene.jeweler_gauge.target is not None
    def execute(self,context):
        s = context.scene.jeweler_gauge
        s.bore_locked=False; s.lock_object=None
        s.mode = 'RING'; s.axis = 'AUTO'; s.center_mode = 'AUTO'
        s.slice = .5; s.slice_offset = 0.; s.auto_slice = True; s.ring_focus = True
        data = refresh(context)
        if not data or not data.get('section'):
            self.report({'WARNING'},'No supported main bore; see ring detection details in the panel')
            return {'CANCELLED'}
        return {'FINISHED'}


def save_bore_lock(context,data,sec):
    s=context.scene.jeweler_gauge; obj=s.target
    matrix=np.asarray(obj.matrix_world,dtype=float)
    u,w,n,o=sec['basis']; center=sec['ring']['center']
    world=(o+center[0]*u+center[1]*w)/data['factor']+data['reference']
    local_normal=matrix[:3,:3].T@n
    s.lock_normal=tuple(local_normal/np.linalg.norm(local_normal))
    s.lock_center=tuple((np.linalg.inv(matrix)@np.r_[world,1.])[:3])
    s.lock_object=obj; s.bore_locked=True
    s.auto_slice=False; s.slice_offset=0.


class JG_OT_lock_bore(Operator):
    bl_idname='jg.lock_bore'
    bl_label='Lock Current Bore'
    bl_description='Keep this bore axis, center and section in object coordinates during refreshes'
    def execute(self,context):
        d=refresh(context)
        if not d or not d.get('section'):
            self.report({'WARNING'},'Detect a valid finger bore first'); return {'CANCELLED'}
        save_bore_lock(context,d,d['section']); refresh(context)
        return {'FINISHED'}


class JG_OT_unlock_bore(Operator):
    bl_idname='jg.unlock_bore'
    bl_label='Unlock Bore'
    def execute(self,context):
        s=context.scene.jeweler_gauge
        s.bore_locked=False; s.lock_object=None; s.auto_slice=True
        refresh(context); return {'FINISHED'}


class JG_OT_selected_bore(Operator):
    bl_idname='jg.selected_bore'
    bl_label='Use Selected Bore / Inner Wall'
    bl_description='In Edit Mode select a bore rim or inner-wall faces; infer and lock the real finger axis'
    @classmethod
    def poll(cls,context): return context.object and context.object.type=='MESH' and context.object.mode=='EDIT'
    def execute(self,context):
        import bmesh
        obj=context.object; s=context.scene.jeweler_gauge
        try:
            data=snapshot(context,obj); bm=bmesh.from_edit_mesh(obj.data)
            faces=[face for face in bm.faces if face.select]
            vertices=list({vertex for face in faces for vertex in face.verts}) if faces else [vertex for vertex in bm.verts if vertex.select]
            matrix=np.asarray(obj.matrix_world,dtype=float)
            points=np.asarray([tuple(vertex.co) for vertex in vertices],dtype=float)
            if len(points)<8: raise ValueError('Select vertices around the bore rim or its inner-wall faces')
            points=(points@matrix[:3,:3].T+matrix[:3,3]-data['reference'])*data['factor']
            normals=None
            if faces:
                normals=np.asarray([tuple(face.normal) for face in faces])@np.linalg.inv(matrix[:3,:3])
                normals/=np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-12)
            fit=bore.selected_bore(points,normals)
            result=bore.find(data['v'],data['t'],data['axes'],normal=fit['normal'],preferred_world=fit['center'])
            tolerance=min(s.seam_tolerance,float(np.max(np.ptp(data['v'],axis=0)))*.0002)
            sec=bore.section(result,s.samples,tolerance); bore.exact_contours(data['v'],data['t'],sec)
            # Selection defines the bore axis; place the cut at local side-shank
            # mid-width rather than at a rim face or a broad decorative head.
            stations=bore.stations(data['v'],data['t'],sec,tolerance)
            middles=[(p['width_a']+p['width_b'])*.5 for p in stations[:2] if p['width_mm'] is not None]
            if middles:
                n=sec['basis'][2]; axial=data['v']@n
                height=float(np.median([point@n for point in middles]))
                fraction=float((height-axial.min())/max(np.ptp(axial),1e-12))
                result=bore.find(data['v'],data['t'],data['axes'],fraction,n,False,fit['center'])
                sec=bore.section(result,s.samples,tolerance); bore.exact_contours(data['v'],data['t'],sec)
            s.target=obj; s.mode='RING'; save_bore_lock(context,data,sec)
            refresh(context)
            self.report({'INFO'},'Finger bore locked from selection'); return {'FINISHED'}
        except (ValueError,np.linalg.LinAlgError) as error:
            self.report({'WARNING'},str(error)); return {'CANCELLED'}


class JG_OT_calibrate_bore(Operator):
    bl_idname='jg.calibrate_bore'
    bl_label='Calibrate Scale From Known Bore'
    bl_description='Set physical mm per unit using the measured bore and your known inner diameter; does not resize the mesh'
    def execute(self,context):
        d=refresh(context); s=context.scene.jeweler_gauge
        if not d or not d.get('section'):
            self.report({'WARNING'},'Measure or select the correct bore before calibration'); return {'CANCELLED'}
        try:
            r=d['section']['ring']; measured=r['equivalent_inner_diameter_mm']
            if r['circularity']<.9 or r['ovality_mm']/max(measured,1e-12)>.15:
                raise ValueError('Bore is not sufficiently round. Verify the axis; use custom scale calibration for an oval bore')
            factor=core.calibration_factor(d['factor'],measured,s.known_bore)
        except ValueError as error:
            self.report({'WARNING'},str(error)); return {'CANCELLED'}
        save_bore_lock(context,d,d['section'])
        s.mm_per_unit=factor; s.units='CUSTOM'
        refresh(context)
        self.report({'INFO'},f'Calibrated: 1 BU = {factor:g} mm; bore axis locked')
        return {'FINISHED'}


class JG_OT_pick(Operator):
    bl_idname = 'jg.pick'
    bl_label = 'Click Wall Probe'
    bl_description = 'Hover/click the target surface to measure a normal-direction wall chord; Esc finishes'
    kind: EnumProperty(items=[('WALL', 'Wall', ''), ('CALIPER', 'Caliper', '')], default='WALL')

    @classmethod
    def poll(cls, context): return context.scene.jeweler_gauge.target is not None and _MODAL is None

    def invoke(self, context, event):
        global _MODAL, _HOVER
        # Sidebar invocation arrives in a UI region: find the actual viewport.
        if context.area.type != 'VIEW_3D': return {'CANCELLED'}
        self._area = context.area
        self._region = next((r for r in context.area.regions if r.type == 'WINDOW'), None)
        self._rv3d = context.space_data.region_3d
        if self._region is None: return {'CANCELLED'}
        self._data = refresh(context)
        if not self._data: return {'CANCELLED'}
        if self.kind == 'WALL' and not self._data['metrics']['valid_volume']:
            self.report({'WARNING'}, 'Wall probe requires a closed mesh with consistent winding')
            return {'CANCELLED'}
        get_bvh(self._data)
        self._first = None
        self._scene_key = context.scene.as_pointer()
        self._start_signature = settings_signature(context.scene)
        self._start_target = context.scene.jeweler_gauge.target.as_pointer()
        _MODAL = self
        _HOVER = None
        context.window_manager.modal_handler_add(self)
        self._area.header_text_set('Jeweler Gauge: click target to pin. Middle mouse/wheel orbit. Esc/right click finish.')
        return {'RUNNING_MODAL'}

    def finish(self):
        global _MODAL, _HOVER
        _MODAL = None; _HOVER = None
        try: self._area.header_text_set(None)
        except ReferenceError: pass
        redraw()

    def cancel(self, context): self.finish()

    def modal(self, context, event):
        global _HOVER
        s = context.scene.jeweler_gauge
        if event.type in {'ESC', 'RIGHTMOUSE'}:
            self.finish(); return {'CANCELLED'}
        if not s.target or s.target.as_pointer() != self._start_target or settings_signature(context.scene) != self._start_signature:
            self.finish(); return {'CANCELLED'}
        if self._scene_key in _DIRTY:
            self.report({'INFO'}, 'Geometry changed; restart probe to use current mesh')
            self.finish(); return {'CANCELLED'}
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'NDOF_MOTION'}:
            return {'PASS_THROUGH'}
        if event.type not in {'MOUSEMOVE', 'LEFTMOUSE'}: return {'PASS_THROUGH'}
        xy = (event.mouse_x-self._region.x, event.mouse_y-self._region.y)
        if not (0 <= xy[0] < self._region.width and 0 <= xy[1] < self._region.height):
            _HOVER = None; redraw(); return {'PASS_THROUGH'}
        origin = view3d_utils.region_2d_to_origin_3d(self._region, self._rv3d, xy,
                     clamp=max(self._data['metrics']['dimensions_mm'])/self._data['factor']*100)
        direction = view3d_utils.region_2d_to_vector_3d(self._region, self._rv3d, xy)
        hit, normal, index, distance = get_bvh(self._data).ray_cast(Vector(to_mm(self._data, origin)), direction)
        _HOVER = None
        if hit is not None:
            if self.kind == 'WALL': chord = wall_ray(self._data, hit, normal)
            elif self._first is not None: chord = (self._first, hit, (hit-self._first).length)
            else: chord = (hit, hit, 0.)
            if chord:
                a, b, value = chord
                _HOVER = (to_world(self._data, a), to_world(self._data, b), value, self._scene_key)
                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    if self.kind == 'CALIPER' and self._first is None:
                        self._first = hit.copy()
                        self._area.header_text_set('Jeweler Gauge: choose second point on the target. Esc finishes.')
                    else:
                        add_probe(context, self._data, a, b, value, self.kind)
                        self._first = None
                        self.report({'INFO'}, f'{value:.3f} mm pinned')
        redraw()
        return {'RUNNING_MODAL'}


class JG_OT_clear_probes(Operator):
    bl_idname = 'jg.clear_probes'
    bl_label = 'Clear Probes'
    bl_options = {'UNDO'}
    def execute(self, context):
        context.scene.jeweler_gauge.probes.clear(); redraw(); return {'FINISHED'}


class JG_OT_calibration(Operator):
    bl_idname = 'jg.calibration'
    bl_label = 'Create 18 mm Calibration Band'
    bl_description = 'Add a known 18 mm bore, 22 mm outside, 4 mm wide calibration mesh using current physical scale'
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        count = 256; f = mm_factor(context.scene)
        vertices, faces = [], []
        for z in (-2., 2.):
            for radius in (9., 11.):
                for i in range(count):
                    a = i*2*math.pi/count
                    vertices.append((radius*math.cos(a)/f, radius*math.sin(a)/f, z/f))
        for i in range(count):
            j = (i+1)%count
            faces.extend(((j, i, i+2*count, j+2*count),
                          (i+count, j+count, j+3*count, i+3*count),
                          (i, j, j+count, i+count),
                          (j+2*count, i+2*count, i+3*count, j+3*count)))
        mesh = bpy.data.meshes.new('JG Calibration 18-22-4mm')
        mesh.from_pydata(vertices, [], faces); mesh.update()
        obj = bpy.data.objects.new('JG Calibration Band — 18 mm bore', mesh)
        context.collection.objects.link(obj)
        obj.location = context.scene.cursor.location
        if context.object and context.object.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
        for old in context.selected_objects: old.select_set(False)
        obj.select_set(True); context.view_layer.objects.active = obj
        s = context.scene.jeweler_gauge
        s.target = obj; s.mode = 'RING'; s.axis = 'Z'; s.center_mode = 'AUTO'; s.slice = .5; s.slice_offset = 0.; s.auto_slice = True
        refresh(context)
        self.report({'INFO'}, 'Calibration band: expected bore circumference 56.547 mm; volume 502.604 mm³')
        return {'FINISHED'}


class JG_OT_wall_scan(Operator):
    bl_idname = 'jg.wall_scan'
    bl_label = 'Scan Wall Thickness'
    bl_description = 'Area-weighted face-normal chord samples; highlights thin samples in red'
    def execute(self, context):
        d = refresh(context)
        if not d or not d['metrics']['valid_volume']:
            self.report({'WARNING'}, 'Choose a closed mesh with consistent winding'); return {'CANCELLED'}
        m = d['metrics']; tree = get_bvh(d)
        count = context.scene.jeweler_gauge.scan_samples
        # Deterministic stratified surface-area sampling rather than vertex density bias.
        areas = m['triangle_areas']; cumulative = np.cumsum(areas)
        ids = np.searchsorted(cumulative, (np.arange(count)+.5)*cumulative[-1]/count)
        rng = np.random.default_rng(1967)
        uv = rng.random((count, 2)); uv[uv.sum(axis=1)>1] = 1-uv[uv.sum(axis=1)>1]
        tris = d['v'][d['t'][ids]]
        points = tris[:, 0]+uv[:, :1]*(tris[:, 1]-tris[:, 0])+uv[:, 1:]*(tris[:, 2]-tris[:, 0])
        chords = []
        for i, point in zip(ids, points):
            chord = wall_ray(d, point, m['normals'][i])
            if chord: chords.append((tuple(chord[0]), tuple(chord[1]), chord[2]))
        if not chords:
            self.report({'WARNING'}, 'No valid inward wall samples'); return {'CANCELLED'}
        values = np.array([c[2] for c in chords])
        d['wall_scan'] = dict(chords=chords, min_mm=float(values.min()), max_mm=float(values.max()),
                              mean_mm=float(values.mean()), attempted=count, measured=len(chords))
        redraw()
        self.report({'INFO'}, f'{len(chords)}/{count} sampled chords; minimum {values.min():.3f} mm')
        return {'FINISHED'}


class JG_OT_width_scan(Operator):
    bl_idname = 'jg.width_scan'
    bl_label = 'Scan Ring Across Width'
    bl_description = 'Find the tightest measured opening across the band; useful for comfort-fit rings'
    def execute(self, context):
        d = refresh(context)
        if not d or not d.get('section'):
            self.report({'WARNING'}, 'Set a valid ring axis and slice first'); return {'CANCELLED'}
        s = context.scene.jeweler_gauge
        n = d['section']['basis'][2]
        rows = []
        for f in np.linspace(.02, .98, s.width_slices):
            try:
                result = section_at(d, s, context.scene, float(f), n)['ring']
                rows.append(dict(slice_fraction=float(f),
                    circumference_mm=result['inner_circumference_mm'],
                    diameter_min_mm=result['inner_diameter_min_mm'],
                    radial_min_mm=result['radial_thickness_min_mm']))
            except ValueError: pass
        if not rows:
            self.report({'WARNING'}, 'No complete closed openings across width'); return {'CANCELLED'}
        d['width_scan'] = dict(rows=rows, attempted=s.width_slices,
                              tightest=min(rows, key=lambda row: row['circumference_mm']))
        redraw()
        return {'FINISHED'}


def public_metrics(d):
    m = d['metrics']
    keys = ('volume_mm3', 'area_mm2', 'dimensions_mm', 'valid_volume', 'boundary_edges',
            'nonmanifold_edges', 'winding_edges', 'degenerate_triangles', 'shells', 'triangles', 'warnings')
    result={k: m[k] for k in keys}
    result.update({key:value for key,value in m.items() if key.startswith('volume_')})
    return result


def public_ring(d):
    if not d.get('section'): return None
    r = d['section']['ring']
    return {k: v for k, v in r.items() if k not in {'center', 'radial_thickness', 'endpoints'}}


def report_object(context, obj, d):
    s = context.scene.jeweler_gauge
    material, density = alloy(context.scene, obj)
    volume = d['metrics']['volume_mm3']
    plan = core.casting_plan(volume, density, s.shrink, s.allowance, s.price) if volume is not None else None
    record = dict(object=obj.name, measured_at=d['time'], material=core.MATERIAL_MAP[material][1],
                  density_g_cm3=density, **public_metrics(d), ring=public_ring(d), ring_error=d.get('ring_error', ''),
                  casting=plan, currency=s.currency, alloy_price_per_g=s.price)
    if d.get('section'):
        if d['section'].get('silhouette'):
            record['ring_section']=record['ring']
            record['ring']=public_ring(visibility.view_data(d))
            front=d['section']['silhouette']
            record['front_silhouette']={key:front[key] for key in ('method','grid_mm','resolution','estimated')}
        record['shank_sections'] = [{key:station[key] for key in ('name','angle','thickness_mm','width_mm')}
                                    for station in d['section'].get('shank_stations',[])]
        if d['section'].get('top_depth'):
            record['top_section_depth']={key:d['section']['top_depth'][key] for key in
                ('width_mm','width_radial_mm','depth_section_estimated','depth_method')}
        if d['section'].get('height_profile'): record['ring_heights']=profile.public(d['section']['height_profile'])
        if d['section'].get('height_error'): record['ring_height_error']=d['section']['height_error']
    if 'wall_scan' in d:
        record['sampled_wall_scan'] = {k: v for k, v in d['wall_scan'].items() if k != 'chords'}
        record['sampled_wall_scan']['below_threshold'] = sum(c[2] < s.minimum_wall for c in d['wall_scan']['chords'])
        record['sampled_wall_scan']['threshold_mm'] = s.minimum_wall
    if 'width_scan' in d: record['width_scan'] = d['width_scan']
    return record


def build_report(context, batch=False):
    s = context.scene.jeweler_gauge
    objects = [o for o in context.selected_objects if object_filter(None, o) and not o.jg_alloy.exclude] if batch else [s.target]
    objects = [o for o in objects if o]
    if not objects: raise ValueError('No eligible objects selected')
    records = []
    for obj in objects:
        d = current(context) if obj == s.target else None
        if (not d or 'metrics' not in d or context.scene.as_pointer() in _DIRTY or
                d.get('settings_signature') != settings_signature(context.scene)):
            d = measure(context, obj, s.mode == 'RING' and obj == s.target)
        records.append(report_object(context, obj, d))
    reliable = all(r['volume_mm3'] is not None for r in records)
    total = sum(r['casting']['weight_g'] for r in records if r['casting'])
    return dict(addon='Jeweler Gauge 1.6.1', mm_per_blender_unit=mm_factor(context.scene),
                scale_convention=s.units, objects=records,
                total_weight_g=total if reliable else None,
                total_weight_estimated=any(r.get('volume_estimated',False) for r in records),
                valid_objects_subtotal_g=total,
                notes=['Evaluated viewport meshes; instances must be realized.',
                       'Edge topology/winding checks do not certify absence of self-intersections.',
                       'Smart reconstruction measures a solid union; strict mesh integration sums oriented shells.',
                       'Reconstruction refinement change is a convergence indicator, not a certified accuracy bound.',
                       'Alloy densities are editable estimates. Metal price is a manual input.',
                       'Radial thickness and face-normal wall chords are different measurements.',
                       'Wall/width scan minima are sampled, not guaranteed global minima.',
                       'Pinned probes are snapshots; re-probe after changing geometry or scale.'],
                pinned_probes=[dict(label=p.label, kind=p.kind, value_mm=p.value_mm, source=p.source,
                                    a_world=list(p.a), b_world=list(p.b)) for p in s.probes])


class JG_OT_report(Operator):
    bl_idname = 'jg.report'
    bl_label = 'Create Measurement Report'
    bl_description = 'Write a JSON report to Blender Text Editor; batch sums selected metal objects'
    batch: BoolProperty(default=False)
    def execute(self, context):
        try: report = build_report(context, self.batch)
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        text = bpy.data.texts.new('Jeweler Gauge Report.json')
        text.write(json.dumps(report, indent=2, allow_nan=False))
        self.report({'INFO'}, f'Report in Text Editor: {text.name}')
        return {'FINISHED'}


class JG_OT_export(Operator, ExportHelper):
    bl_idname = 'jg.export'
    bl_label = 'Export Measurements'
    filename_ext = '.csv'
    filter_glob: StringProperty(default='*.csv;*.json', options={'HIDDEN'})
    format: EnumProperty(name='Format', items=[('CSV', 'CSV', 'One row per object'), ('JSON', 'JSON', 'Complete data including scans and pinned probes')], default='CSV')
    batch: BoolProperty(name='Selected metal objects', default=False)
    def execute(self, context):
        try:
            report = build_report(context, self.batch)
            import os
            base, ext = os.path.splitext(self.filepath)
            path = (base if ext.lower() in {'.csv', '.json'} else self.filepath) + ('.json' if self.format == 'JSON' else '.csv')
            if self.format == 'JSON':
                with open(path, 'w', encoding='utf-8') as f: json.dump(report, f, indent=2, allow_nan=False)
            else:
                fields = ['object', 'material', 'density_g_cm3', 'mm_per_blender_unit', 'valid_volume', 'volume_mm3', 'volume_estimated','volume_method','volume_voxel_mm','volume_refinement_change_percent','area_mm2',
                          'weight_g', 'inner_circumference_mm', 'outer_circumference_mm', 'equivalent_inner_diameter_mm',
                          'inner_diameter_min_mm', 'inner_diameter_max_mm', 'radial_thickness_min_mm',
                          'radial_thickness_max_mm', 'ovality_mm', 'casting_charge_estimate_g', 'compensation_scale', 'metal_cost', 'currency', 'warnings']
                fields += [name+'_'+quantity+'_mm' for name in ('left_shank','right_shank','bottom_shank') for quantity in ('thickness','width')]
                fields += ['body_height_mm','total_height_mm','top_height_mm','crown_band_thickness_mm','body_width_mm',
                           'body_depth_mm','top_width_mm','top_depth_mm','body_reference_estimated','body_reference_method',
                           'crown_total_height_mm','round_band_height_mm','extra_crown_height_mm','crown_reference_method',
                           'front_silhouette_grid_mm','top_section_depth_mm','top_tiers_json','world_x_mm','world_y_mm','world_z_mm']
                with open(path, 'w', encoding='utf-8-sig', newline='') as f:
                    writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore'); writer.writeheader()
                    for r in report['objects']:
                        row = dict(r); row.update(r['ring'] or {}); row.update(r['casting'] or {})
                        row.update(r.get('ring_heights',{}))
                        row['top_section_depth_mm']=r.get('top_section_depth',{}).get('width_mm')
                        row['top_tiers_json']=json.dumps(r.get('ring_heights',{}).get('tiers',[]),allow_nan=False)
                        for axis,value in zip('xyz',r['dimensions_mm']): row['world_'+axis+'_mm']=value
                        for station in r.get('shank_sections',[]):
                            name = station['name'].lower().replace(' ','_')
                            row[name+'_thickness_mm'] = station['thickness_mm']
                            row[name+'_width_mm'] = station['width_mm']
                        row['mm_per_blender_unit'] = report['mm_per_blender_unit']
                        row['warnings'] = '; '.join(r['warnings'] + ([r['ring_error']] if r['ring_error'] else []))
                        writer.writerow(row)
            self.report({'INFO'}, 'Measurements exported')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}


def row_value(layout, label, value, unit='mm', precision=3):
    row = layout.row(align=True); row.label(text=label)
    row.label(text='Unavailable' if value is None else f'{value:,.{precision}f} {unit}')


def wrapped(layout, message, width=43, icon='NONE'):
    import textwrap
    lines = textwrap.wrap(message, width)
    for i, line in enumerate(lines): layout.label(text=line, icon=icon if i == 0 else 'NONE')


def visibility_controls(layout,s):
    box=layout.box()
    row=box.row(align=True); row.scale_y=1.3
    row.prop(s,'overlay',text='Measurements',toggle=True,icon='HIDE_OFF' if s.overlay else 'HIDE_ON')
    row=box.row(align=True); row.scale_y=1.6
    row.operator('jg.visibility',text='Show All',icon='HIDE_OFF').preset='ALL'
    row.operator('jg.visibility',text='Hide All',icon='HIDE_ON').preset='NONE'
    for start in range(0,len(visibility.GROUPS),2):
        row=box.row(align=True); row.scale_y=1.4
        for key,label,props in visibility.GROUPS[start:start+2]:
            selected=any(visibility.enabled(s,p) for p in props)
            row.operator('jg.visibility_group',text=label,icon='HIDE_OFF' if selected else 'HIDE_ON',depress=selected and s.overlay).group=key
    row=box.row(align=True); row.scale_y=1.2
    row.operator('jg.visibility',text='Ring Essentials').preset='RING'
    row.operator('jg.visibility',text='3 Crown Heights').preset='CROWN'
    row=box.row(align=True); row.scale_y=1.25
    row.prop(s,'show_labels',text='Labels',toggle=True)
    row.prop(s,'show_hud',text='Dashboard',toggle=True)
    row=box.row(); row.scale_y=1.3; row.prop(s,'font_size',slider=True)
    box.prop(s,'visibility_details',icon='TRIA_DOWN' if s.visibility_details else 'TRIA_RIGHT',emboss=False)
    if s.visibility_details:
        labels={prop:label for prop,label,_ in visibility.CATEGORIES}
        groups=[(label,props) for _,label,props in visibility.GROUPS]
        covered={p for _,props in groups for p in props}
        groups.append(('Inspection / planning',tuple(p for p,_,_ in visibility.CATEGORIES if p not in covered)))
        for title,props in groups:
            sub=box.box();sub.label(text=title)
            for prop in props:
                row=sub.row();row.scale_y=1.15;row.prop(s,prop,text=labels[prop])


class JG_PT_main(Panel):
    bl_label = 'Jeweler Gauge 1.6.1'
    bl_idname = 'JG_PT_main'
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Jeweler'
    def draw(self, context):
        l=self.layout;s=context.scene.jeweler_gauge;d=current(context)
        visibility_controls(l,s)
        row=l.row();row.scale_y=1.5
        row.operator('jg.use_active',text='Measure Active Object',icon='EYEDROPPER')
        l.prop(s,'target');l.prop(s,'mode',expand=True)
        row=l.row(align=True);row.prop(s,'live');row.operator('jg.refresh',text='Refresh',icon='FILE_REFRESH')
        l.label(text=f'Scale: 1 Blender unit = {mm_factor(context.scene):g} mm')
        if context.scene.as_pointer() in _DIRTY:l.label(text='Refresh needed',icon='TIME')
        if d and 'error' in d:wrapped(l,d['error'],icon='ERROR')
        elif d and 'metrics' in d:
            if d.get('live_paused'):l.label(text='Heavy mesh: use Refresh',icon='INFO')
            r=(d.get('section') or {}).get('ring',{})
            if r.get('scale_warning'):l.label(text='Check physical scale below',icon='ERROR')
            elif not d['metrics'].get('volume_available',True):l.label(text='Volume unavailable: see Mesh Details',icon='INFO')
        else:l.label(text='Select an object to measure',icon='INFO')


class JG_PT_results(Panel):
    bl_label='Selected Measurement Values';bl_idname='JG_PT_results';bl_parent_id='JG_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Jeweler';bl_order=10
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;s=context.scene.jeweler_gauge;d=current(context)
        if not s.overlay:l.label(text='Measurements hidden');return
        if not d or 'metrics' not in d:l.label(text='Measure an object first');return
        # The sidebar uses the same categories as the viewport, independently
        # of whether the optional screen dashboard is enabled.
        for title,rows,color in dashboard_cards(context,d):
            box=l.box()
            for label,value in rows:
                if label in {'Target','Physical scale'}:continue
                row=box.row(align=True);row.scale_y=1.15
                row.label(text=label);row.label(text=str(value))


class JG_PT_scale(Panel):
    bl_label='Physical Scale / Calibration';bl_idname='JG_PT_scale';bl_parent_id='JG_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Jeweler';bl_order=20
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;s=context.scene.jeweler_gauge
        l.prop(s,'units')
        if s.units=='CUSTOM':l.prop(s,'mm_per_unit')
        l.label(text=f'1 Blender unit = {mm_factor(context.scene):g} mm')
        if s.mode=='RING':
            l.prop(s,'known_bore');l.operator('jg.calibrate_bore',text='Calibrate From Known Bore',icon='DRIVER_DISTANCE')


class JG_PT_ring(Panel):
    bl_label='Ring / Crown Setup';bl_idname='JG_PT_ring_setup';bl_parent_id='JG_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Jeweler';bl_order=30
    bl_options={'DEFAULT_CLOSED'}
    @classmethod
    def poll(cls,context):return context.scene.jeweler_gauge.mode=='RING'
    def draw(self,context):
        l=self.layout;s=context.scene.jeweler_gauge
        row=l.row(align=True);row.scale_y=1.2
        row.operator('jg.detect_bore',text='Detect Bore',icon='FILE_REFRESH')
        row.operator('jg.unlock_bore' if s.bore_locked else 'jg.lock_bore',text='Unlock' if s.bore_locked else 'Lock',icon='UNLOCKED' if s.bore_locked else 'LOCKED')
        l.operator('jg.selected_bore',text='Use Selected Bore Faces',icon='EDITMODE_HLT')
        l.prop(s,'ring_view')
        if s.ring_view=='FRONT':l.prop(s,'silhouette_resolution')
        controls=l.column();controls.enabled=not s.bore_locked
        controls.prop(s,'axis');controls.prop(s,'center_mode');controls.prop(s,'auto_slice')
        controls.prop(s,'slice',slider=True);l.prop(s,'slice_offset');l.prop(s,'seam_tolerance');l.prop(s,'samples')
        box=l.box();box.label(text='Crown reference')
        box.prop(s,'ring_style');box.prop(s,'custom_top_direction')
        if s.custom_top_direction:box.prop(s,'crown_angle')
        box.prop(s,'height_base_mode')
        if s.height_base_mode=='MANUAL':box.prop(s,'body_top_reference')


class JG_PT_mesh(Panel):
    bl_label='Mesh Details / Measurement Notes';bl_idname='JG_PT_mesh';bl_parent_id='JG_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Jeweler';bl_order=90
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;d=current(context)
        if not d or 'metrics' not in d:l.label(text='Measure an object first');return
        m=d['metrics'];l.label(text=f'{m["triangles"]:,} triangles · {m["shells"]} shell(s)')
        wrapped(l,m.get('volume_method','Mesh integration'))
        if not m['warnings']:l.label(text='Closed edges / consistent winding',icon='CHECKMARK')
        for warning in m['warnings']:wrapped(l,warning,icon='INFO')
        wrapped(l,'Self-intersections and overlapping solids are not certified.',icon='INFO')
        sec=d.get('section') or {};r=sec.get('ring') or {}
        if sec.get('silhouette_error'):wrapped(l,sec['silhouette_error'],icon='INFO')
        if r:
            wrapped(l,r.get('measurement_method','Mesh cross-section'))
            if r.get('scale_warning'):wrapped(l,r['scale_warning'],icon='ERROR')
            l.label(text=f'Measured slice: {r["actual_slice_fraction"]*100:.1f}%')
        hp=sec.get('height_profile')
        if hp:wrapped(l,hp.get('crown_reference_method',hp['body_reference_method']),icon='INFO')


class JG_PT_weight(Panel):
    bl_label = 'Alloys, Weight & Casting'; bl_idname = 'JG_PT_material_setup'; bl_parent_id = 'JG_PT_main'
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Jeweler'
    bl_options={'DEFAULT_CLOSED'};bl_order=40
    def draw(self, context):
        l = self.layout; s = context.scene.jeweler_gauge; d = current(context)
        l.prop(s, 'material'); l.prop(s, 'density')
        l.prop(s,'volume_mode')
        if s.volume_mode!='EXACT':
            l.prop(s,'volume_resolution'); l.operator('jg.refine_volume',icon='FILE_REFRESH')
        wrapped(l, 'Alloy presets are approximate. Enter supplier density for production estimates.')
        obj = s.target
        if obj:
            box = l.box(); box.label(text=f'Object: {obj.name}'); a = obj.jg_alloy
            box.prop(a, 'use_override')
            if a.use_override: box.prop(a, 'material'); box.prop(a, 'density')
            box.prop(a, 'exclude')
        if not d or 'metrics' not in d: return
        volume = d['metrics']['volume_mm3']
        if volume is None: wrapped(l, 'No supported solid volume. Try Smart automatic or Reconstruct solid and inspect mesh notes.', icon='ERROR'); return
        m=d['metrics']
        if m.get('volume_estimated'):
            box=l.box(); box.label(text='Reconstructed volume estimate ≈',icon='INFO')
            row_value(box,'Voxel / sampling spacing',m.get('volume_voxel_mm'),'mm')
            row_value(box,'Change with refinement',m.get('volume_refinement_change_percent'),'%')
            box.label(text=m.get('volume_confidence','Estimate'))
        material, density = alloy(context.scene, obj)
        plan = core.casting_plan(volume, density, s.shrink, s.allowance, s.price)
        box = l.box(); row_value(box, 'Estimated object weight', plan['weight_g'], 'g')
        fineness = core.MATERIAL_MAP[material][3]
        if material.startswith(('AU', 'AG', 'PT')):
            row_value(box, 'Fine precious metal content', plan['weight_g']*fineness, 'g')
        if s.show_comparisons:
            comparison = l.box(); comparison.label(text='Same volume in other materials')
            for code in ('AU24', 'AU18Y', 'AU14Y', 'AG925', 'PT950', 'WAX'):
                m = core.MATERIAL_MAP[code]
                row_value(comparison, m[1].replace(' (approx.)', ''), volume*m[2]/1000, 'g')
        if s.show_casting:
            box = l.box(); box.label(text='Casting planner')
            box.prop(s, 'shrink'); box.prop(s, 'allowance')
            box.label(text=f'Pattern oversize: {plan["compensation_scale"]:.6f}×')
            row_value(box, 'Compensated pattern volume', plan['compensated_pattern_volume_mm3'], 'mm³')
            row_value(box, 'Estimated casting charge', plan['casting_charge_estimate_g'], 'g')
            box.prop(s, 'currency'); box.prop(s, 'price')
            row_value(box, 'Object metal cost', plan['metal_cost'], s.currency, 2)

            if d.get('section'):
                box.prop(s,'target_circ')
                scale=s.target_circ/d['section']['ring']['inner_circumference_mm']
                box.label(text=f'Uniform resize: {scale:.6f}×')
                row_value(box,'Weight after resize',volume*scale**3*density/1000,'g')



class JG_PT_probes(Panel):
    bl_label = 'Thickness, Calipers & Inspection'; bl_idname = 'JG_PT_inspection_tools'; bl_parent_id = 'JG_PT_main'
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Jeweler'
    bl_options={'DEFAULT_CLOSED'};bl_order=50
    def draw(self, context):
        l = self.layout; s = context.scene.jeweler_gauge; d = current(context)
        l.operator('jg.pick', text='Click Wall Probe', icon='EYEDROPPER').kind = 'WALL'
        l.operator('jg.pick', text='Two-Point Surface Caliper', icon='DRIVER_DISTANCE').kind = 'CALIPER'
        wrapped(l, 'Wall probe follows the inward face normal. Caliper is straight distance between two target surface clicks.')
        if s.mode=='RING':
            l.prop(s,'angle',slider=True)
            if d and d.get('section'):
                gauge=radial_gauge(d,s.angle)
                row_value(l,'At selected angle',float(gauge[2]) if gauge else None)
            l.prop(s,'width_slices');l.operator('jg.width_scan',icon='VIEW_ORTHO')
        l.prop(s, 'minimum_wall'); l.prop(s, 'scan_samples'); l.operator('jg.wall_scan', icon='SHADING_SOLID')
        if d and 'wall_scan' in d:
            w = d['wall_scan']; box = l.box()
            row_value(box, 'Sampled wall minimum', w['min_mm'])
            row_value(box, 'Sampled wall mean', w['mean_mm'])
            below = sum(c[2] < s.minimum_wall for c in w['chords'])
            box.label(text=f'{below}/{w["measured"]} chords below threshold')
            box.label(text=f'{w["attempted"]-w["measured"]} ambiguous/missed samples')
            wrapped(box, 'Red = below threshold; green = above. A sampled check can miss tiny thin details.')
        if s.probes:
            l.separator(); l.label(text='Pinned measurement snapshots')
            for p in list(s.probes)[-8:]: row_value(l, p.label, p.value_mm)
            if len(s.probes) > 8: l.label(text=f'{len(s.probes)-8} more in report')
            l.operator('jg.clear_probes', icon='TRASH')
            wrapped(l, 'Re-probe after editing geometry or changing physical scale.', icon='INFO')


class JG_PT_reports(Panel):
    bl_label = 'Reports & Batch Metal Weight'; bl_idname = 'JG_PT_report_tools'; bl_parent_id = 'JG_PT_main'
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Jeweler'
    bl_options={'DEFAULT_CLOSED'};bl_order=70
    def draw(self, context):
        l = self.layout
        l.operator('jg.report', text='Object Report in Text Editor', icon='TEXT').batch = False
        l.operator('jg.report', text='Selected Metal Objects Report', icon='TEXT').batch = True
        l.operator('jg.export', text='Export CSV / JSON', icon='EXPORT')
        wrapped(l, 'Assign each object an alloy and exclude gemstones using the object controls above. Overlapping solids are summed; union them first when necessary.')
        l.separator(); l.operator('jg.calibration', icon='MESH_TORUS')


class JG_PT_overlay(Panel):
    bl_label='Display Appearance';bl_idname='JG_PT_display_settings';bl_parent_id='JG_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Jeweler';bl_order=80
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;s=context.scene.jeweler_gauge
        l.prop(s,'xray');l.prop(s,'hud_detail');l.prop(s,'decimals')
        l.prop(s,'guide_offset',slider=True);l.prop(s,'label_limit')


def guide_geometry(context,data):
    s = context.scene.jeweler_gauge
    options = dict(angle=s.angle,decimals=s.decimals,offset=s.guide_offset,bbox=s.show_bbox,
                   ring=True,diameters=s.show_diameters,plane=s.show_diagnostics,extremes=s.show_diagnostics,
                   focus=s.mode=='RING',custom_gauge=s.show_custom_gauge,
                   inside=s.show_inside,outside=s.show_outside,thickness=s.show_shank_thickness,depth=s.show_shank_depth,
                   heights=s.show_height_guides,top_depth=s.show_top_depth,body=s.show_body_dimensions,
                   slice=data['section']['ring']['actual_slice_fraction'] if data.get('section') else s.slice)
    key = (tuple(options.items()),id(data.get('wall_scan')))
    if data.get('_guide_key') != key:
        data['_guide_geometry'] = guides.build(data,options)
        for item in data['_guide_geometry']['lines']:
            item['world_points'] = (item['points']/data['factor']+data['reference']).tolist()
        data['_guide_key'] = key
    return data['_guide_geometry']


def builtin_shader(name):
    import gpu
    if name not in _SHADERS: _SHADERS[name] = gpu.shader.from_builtin(name)
    return _SHADERS[name]


def draw_lines(coords, color, width=2):
    if len(coords) < 2: return
    import gpu
    from gpu_extras.batch import batch_for_shader
    shader = builtin_shader('POLYLINE_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'LINES', {'pos': coords})
    shader.bind()
    shader.uniform_float('viewportSize', gpu.state.viewport_get()[2:])
    shader.uniform_float('lineWidth', width)
    shader.uniform_float('color', color)
    batch.draw(shader)


def draw_view():
    context = bpy.context
    if not context.scene or not hasattr(context.scene, 'jeweler_gauge'): return
    s = context.scene.jeweler_gauge
    if not s.overlay: return
    d = current(context)
    import gpu
    depth = gpu.state.depth_test_get()
    gpu.state.blend_set('ALPHA'); gpu.state.depth_test_set('NONE' if s.xray else 'LESS_EQUAL')
    try:
        if d and 'metrics' in d:
            geo = guide_geometry(context,d)
            for item in geo['lines']:
                draw_lines(item['world_points'],item['color'],item['width'])
            if 'wall_scan' in d and visibility.enabled(s,'show_diagnostics'):
                scan = d['wall_scan']; key = (id(scan),s.minimum_wall)
                if d.get('_wall_overlay_key') != key:
                    low,high = [],[]
                    for a,b,value in scan['chords']:
                        (low if value < s.minimum_wall else high).extend((a,b))
                    def world_points(points):
                        return (np.asarray(points)/d['factor']+d['reference']).tolist() if points else []
                    d['_wall_overlay_points'] = world_points(low),world_points(high)
                    d['_wall_overlay_key'] = key
                low,high = d['_wall_overlay_points']
                draw_lines(high, (.2, 1., .3, .35), 1.)
                draw_lines(low, (1., .1, .08, .9), 3.)
        for p in s.probes if visibility.enabled(s,'show_probes') else ():
            if s.target and p.source != s.target.name: continue
            draw_lines([p.a, p.b], (1., .25, .65, 1.), 3)
        if visibility.enabled(s,'show_probes') and _HOVER and _HOVER[3] == context.scene.as_pointer():
            draw_lines([_HOVER[0], _HOVER[1]], (1., 1., 1., 1.), 4)
    except Exception:
        # A transient mesh deletion must not break viewport redraw.
        pass
    finally:
        gpu.state.depth_test_set(depth); gpu.state.blend_set('NONE')


def dashboard_cards(context,d):
    d=visibility.view_data(d)
    s = context.scene.jeweler_gauge; m = d['metrics']; dec = s.decimals
    def f(value,unit='mm'): return 'Unavailable' if value is None else f'{value:,.{dec}f} {unit}'
    def vf(value,unit='mm³'): return ('≈ ' if m.get('volume_estimated') and value is not None else '')+f(value,unit)
    volume_rows=[]
    if m.get('volume_estimated'):
        volume_rows=[('Volume method',m.get('volume_method','Reconstruction')),
                     ('Volume grid spacing',f(m.get('volume_voxel_mm'))),
                     ('Volume refinement change',f(m.get('volume_refinement_change_percent'),'%')),
                     ('Volume quality',m.get('volume_confidence','Estimate'))]
    cards = []
    rows = [('Target',d['object_name']),('Physical scale',f'{d["factor"]:g} mm / BU')]
    if context.scene.as_pointer() in _DIRTY: rows.append(('Status','STALE — refresh'))
    rows += [(f'World {axis}',f(v)) for axis,v in zip('XYZ',m['dimensions_mm'])]
    rows += [('Surface area',f(m['area_mm2'],'mm²')),('Volume',vf(m['volume_mm3'])),
             ('Mesh',f'{m["triangles"]:,} tris / {m["shells"]} shell(s)')]
    rows += volume_rows
    if s.target:
        material,density = alloy(context.scene,s.target)
        volume = m['volume_mm3']; mass = None if volume is None else volume*density/1000
        rows += [('Material',core.MATERIAL_MAP[material][1].replace(' (approx.)','')),
                 ('Density',f(density,'g/cm³')),('Weight estimate',vf(mass,'g'))]
    cards.append(('OBJECT MEASUREMENTS',rows,guides.WHITE))
    if d.get('section'):
        r = d['section']['ring']; gauge = radial_gauge(d,s.angle)
        rows = [('Inside circumference',f(r['inner_circumference_mm'])),('Outside circumference',f(r['outer_circumference_mm'])),
                ('Equivalent bore diameter',f(r['equivalent_inner_diameter_mm'])),('Bore diameter min / max',f'{r["inner_diameter_min_mm"]:.{dec}f} / {r["inner_diameter_max_mm"]:.{dec}f} mm'),
                ('Ovality',f(r['ovality_mm'])),('Axial bounding span',f(r['axial_span_mm'])),
                ('Actual measured slice',f'{r["actual_slice_fraction"]*100:.1f}%'),
                (f'Radial wall at {math.degrees(s.angle):.1f}°',f(gauge[2] if gauge else None)),
                ('Radial min / max',f'{r["radial_thickness_min_mm"]:.{dec}f} / {r["radial_thickness_max_mm"]:.{dec}f} mm'),
                ('Mean radial wall',f(r['radial_thickness_mean_mm'])),('EU circumference size',f'{r["inner_circumference_mm"]:.2f}')]
        if r.get('scale_warning'):
            rows=[row for row in rows if row[0]!='EU circumference size']
            rows.insert(0,('Scale check','Verify units / known diameter'))
        elif r['us_size_estimate'] is not None and r['us_size_estimate']>=0 and r['ovality_mm'] <= .15 and r['circularity'] >= .98: rows.append(('US size estimate',f'{r["us_size_estimate"]:.2f}'))
        else: rows.append(('Sizing','Non-round bore'))
        if r.get('bore_locked'): rows.insert(0,('Bore axis','LOCKED to object'))
        if r['ambiguous_rays']: rows.append(('Skipped radial rays',str(r['ambiguous_rays'])))
        cards.append(('RING SECTION',rows,guides.CYAN))
        if 'fitted_bore_diameter_mm' in r:
            cards.append(('BORE DETECTION EVIDENCE',[
                ('Fitted bore diameter',f(r['fitted_bore_diameter_mm'])),
                ('Fitted circle circumference',f(r['fitted_bore_circumference_mm'])),
                ('Radial fit error',f'{r["fit_error_percent"]:.2f}%'),
                ('Bore evidence coverage',f'{r["bore_coverage_percent"]:.1f}%'),
                ('Outside evidence coverage',f'{r["outer_coverage_percent"]:.1f}%')],guides.CYAN))
        if d['section'].get('shank_stations'):
            rows = []
            for station in d['section']['shank_stations']:
                rows += [(station['name']+' thickness',f(station['thickness_mm'])),
                         (station['name']+' maximum depth',f(station['width_mm']))]
            cards.append(('LOCAL SHANK SECTIONS',rows,guides.PINK))
        if d['section'].get('top_depth'):
            depth=d['section']['top_depth']
            cards.append(('TOP / CROWN DEPTH',[('Top / crown depth',('≈ ' if depth.get('depth_section_estimated') else '')+f(depth['width_mm']))],guides.GREEN))
        hp=d['section'].get('height_profile')
        if hp:
            def hf(value,estimated=False): return ('≈ ' if estimated else '')+f(value)
            estimated=hp['body_reference_estimated']
            inner=hp.get('crown_inner_above_bore_mm',hp['base']-(hp['crown_band_thickness_mm'] or 0.))
            rows=[('Inside to crown top',hf(hp.get('crown_total_height_mm',hp['top']-inner),hp.get('crown_silhouette_estimated',False))),
                  ('Round-band height',hf(hp.get('round_band_height_mm',hp['base']-inner),estimated)),
                  ('Extra crown height',hf(hp.get('extra_crown_height_mm',hp['top']-hp['base']),estimated)),
                  ('Ring body height',hf(hp['body_height_mm'],estimated)),('Total height',f(hp['total_height_mm']))]
            rows.append(('Body/top reference',hp['body_reference_method']))
            cards.append(('BODY / TOP HEIGHTS',rows,guides.AMBER))
        elif d['section'].get('height_error'):
            cards.append(('BODY / TOP HEIGHTS',[('Height reference',d['section']['height_error'])],guides.AMBER))
    elif d.get('ring_error'):
        import textwrap
        cards.append(('RING SECTION',[(line,'') for line in textwrap.wrap(d['ring_error'],42)],guides.RED))
    if m['volume_mm3'] is not None and s.target:
        material,density = alloy(context.scene,s.target); volume = m['volume_mm3']
        if s.show_comparisons:
            rows = [(core.MATERIAL_MAP[code][1].replace(' (approx.)',''),f(volume*core.MATERIAL_MAP[code][2]/1000,'g'))
                    for code in ('AU24','AU18Y','AU14Y','AG925','PT950','WAX')]
            cards.append(('SAME VOLUME / OTHER MATERIALS',rows,guides.AMBER))
        if s.show_casting:
            plan = core.casting_plan(volume,density,s.shrink,s.allowance,s.price)
            rows = [('Shrinkage / charge allowance',f'{s.shrink:.2f}% / {s.allowance:.1f}%'),
                    ('Pattern oversize factor',f'{plan["compensation_scale"]:.6f}×'),
                    ('Compensated pattern volume',f(plan['compensated_pattern_volume_mm3'],'mm³')),
                    ('Estimated casting charge',f(plan['casting_charge_estimate_g'],'g')),
                    ('Manual alloy price',f'{s.price:,.2f} {s.currency}/g'),('Object metal cost',f'{plan["metal_cost"]:,.2f} {s.currency}')]
            if material.startswith(('AU','AG','PT')): rows.append(('Fine precious metal',f(plan['weight_g']*core.MATERIAL_MAP[material][3],'g')))
            if d.get('section'):
                scale = s.target_circ/d['section']['ring']['inner_circumference_mm']
                rows += [('Target inside circumference',f(s.target_circ)),('Suggested uniform resize',f'{scale:.6f}×'),
                         ('Weight after uniform resize',f(volume*scale**3*density/1000,'g'))]
            cards.append(('CASTING / SIZING PLANNER',rows,guides.AMBER))
    rows = [('Minimum wall threshold',f(s.minimum_wall)),('Pinned snapshots',str(len(s.probes)))]
    if 'wall_scan' in d:
        scan = d['wall_scan']; below = sum(c[2] < s.minimum_wall for c in scan['chords'])
        rows += [('Wall scan min / max',f'{scan["min_mm"]:.{dec}f} / {scan["max_mm"]:.{dec}f} mm'),
                 ('Wall scan mean',f(scan['mean_mm'])),('Below threshold',f'{below} / {scan["measured"]} samples'),
                 ('Missed wall samples',str(scan['attempted']-scan['measured']))]
    if 'width_scan' in d:
        scan = d['width_scan']; tight = scan['tightest']
        rows += [('Tightest sampled inside',f(tight['circumference_mm'])),
                 ('Tightest slice',f'{tight["slice_fraction"]*100:.1f}%'),('Valid width slices',f'{len(scan["rows"])}/{scan["attempted"]}')]
    cards.append(('INSPECTION / PROBES',rows,guides.PINK))
    if m['warnings']:
        import textwrap
        rows = [(line,'') for warning in m['warnings'] for line in textwrap.wrap(warning,42)]
        cards.append(('MESH NOTES',rows,guides.AMBER if m['valid_volume'] else guides.RED))
    if not s.hud_detail:
        compact = [('Target',d['object_name']),('Physical scale',f'{d["factor"]:g} mm / BU'),
                   ('Volume',vf(m['volume_mm3'])),('Surface area',f(m['area_mm2'],'mm²'))]+volume_rows
        if getattr(s,'show_bbox',True):
            compact[2:2]=[(f'World {axis}',f(value)) for axis,value in zip('XYZ',m['dimensions_mm'])]
        if s.target:
            material,density = alloy(context.scene,s.target)
            compact += [('Material',core.MATERIAL_MAP[material][1].replace(' (approx.)','')),
                        ('Weight estimate',vf(None if m['volume_mm3'] is None else m['volume_mm3']*density/1000,'g'))]
        if context.scene.as_pointer() in _DIRTY: compact.insert(0,('Status','STALE — refresh'))
        if d.get('section'):
            r = d['section']['ring']; gauge = radial_gauge(d,s.angle)
            compact += [('Inside circumference',f(r['inner_circumference_mm'])),('Outside circumference',f(r['outer_circumference_mm'])),
                        ('Bore min / max',f'{r["inner_diameter_min_mm"]:.{dec}f} / {r["inner_diameter_max_mm"]:.{dec}f} mm'),
                        ('Ovality',f(r['ovality_mm'])),('Axial span',f(r['axial_span_mm'])),
                        (f'Radial wall {math.degrees(s.angle):.1f}°',f(gauge[2] if gauge else None)),
                        ('Radial min / max',f'{r["radial_thickness_min_mm"]:.{dec}f} / {r["radial_thickness_max_mm"]:.{dec}f} mm'),
                        ('EU circumference size',f'{r["inner_circumference_mm"]:.2f}'),('Measured slice',f'{r["actual_slice_fraction"]*100:.1f}%')]
            if r.get('scale_warning'):
                compact=[row for row in compact if row[0]!='EU circumference size']
                compact.insert(0,('Scale check','VERIFY UNITS / KNOWN BORE'))
            if r.get('bore_locked'): compact.insert(0,('Bore axis','LOCKED to object'))
            hp=d['section'].get('height_profile')
            if hp:
                def hf(value,estimated=False): return ('≈ ' if estimated else '')+f(value)
                estimated=hp['body_reference_estimated']
                inner=hp.get('crown_inner_above_bore_mm',hp['base']-(hp['crown_band_thickness_mm'] or 0.))
                compact += [('Inside to crown top',hf(hp.get('crown_total_height_mm',hp['top']-inner),hp.get('crown_silhouette_estimated',False))),
                            ('Round-band height',hf(hp.get('round_band_height_mm',hp['base']-inner),estimated)),
                            ('Extra crown height',hf(hp.get('extra_crown_height_mm',hp['top']-hp['base']),estimated)),
                            ('Ring body height',hf(hp['body_height_mm'],estimated)),('Total height',f(hp['total_height_mm']))]
                if estimated: compact.append(('Body/top reference','INFERRED — adjustable plane'))
            elif d['section'].get('height_error'): compact.append(('Height reference','Adjust reference in Ring panel'))
            if d['section'].get('top_depth'):
                depth=d['section']['top_depth']
                compact.append(('Top / crown depth',('≈ ' if depth.get('depth_section_estimated') else '')+f(depth['width_mm'])))
        if 'wall_scan' in d: compact.append(('Sampled wall minimum',f(d['wall_scan']['min_mm'])))
        if 'width_scan' in d: compact.append(('Tightest sampled bore',f(d['width_scan']['tightest']['circumference_mm'])))
        compact.append(('All readouts','Enable Full dashboard'))
        if m['warnings']: compact.append(('Mesh notes',f'{len(m["warnings"])} — see Full dashboard'))
        if d.get('ring_error'): compact.append(('Ring detection','No valid bore slice — see panel'))
        if getattr(s,'mode','OBJECT')=='RING' and getattr(s,'ring_focus',False):
            omitted = {'Axial span','Radial min / max','Ovality','Measured slice'}
            compact = [row for row in compact if row[0] not in omitted]
            sec = d.get('section')
            if sec:
                status = 'Approximate radial profile' if sec['ring'].get('estimated') else 'Measured mesh contour'
                compact.insert(0,('Bore detection',status))
                for station in sec.get('shank_stations',[]):
                    compact.insert(-1,(station['name']+' thickness',f(station['thickness_mm'])))
                    compact.insert(-1,(station['name']+' maximum depth',f(station['width_mm'])))
        cards = [('JEWELER GAUGE',compact,guides.CYAN)]
    return visibility.filter_cards(s,cards)


def screen_rect(x,y,width,height,color):
    from gpu_extras.batch import batch_for_shader
    shader = builtin_shader('UNIFORM_COLOR')
    coords = [(x,y,0),(x+width,y,0),(x+width,y+height,0),(x,y+height,0)]
    batch = batch_for_shader(shader,'TRIS',{'pos':coords},indices=((0,1,2),(0,2,3)))
    shader.bind(); shader.uniform_float('color',color); batch.draw(shader)


def screen_text(text,x,y,color,size):
    import blf
    blf.size(0,size); blf.position(0,x,y,0); blf.color(0,*color); blf.draw(0,text)


def fit_text(text,width):
    import blf
    text = str(text)
    if blf.dimensions(0,text)[0] <= width: return text
    if blf.dimensions(0,'…')[0] > width: return ''
    while text and blf.dimensions(0,text+'…')[0] > width: text = text[:-1]
    return text+'…'


def visible_view_rect(context):
    # Account for tool/sidebar regions that can overlap the WINDOW region.
    left,right = 12,context.region.width-12
    for region in context.area.regions:
        if region.type not in {'UI','TOOLS'} or region.width < 5: continue
        a,b = region.x-context.region.x,region.x+region.width-context.region.x
        if a >= 0 and b <= context.region.width:
            if region.type == 'UI': right = min(right,a-12)
            else: left = max(left,b+12)
    return left,max(right,left+120),18,context.region.height-60


def draw_dashboard(context,d):
    import blf
    s = context.scene.jeweler_gauge
    left,right,bottom,top = visible_view_rect(context)
    cards = dashboard_cards(context,d)
    available = right-left
    font = s.font_size
    total_rows = sum(len(rows)+2 for _,rows,_ in cards)
    preferred_width=max(340,font*23)
    columns=2 if available>=preferred_width*2+12 and (s.hud_detail or total_rows*(font+5)>top-bottom) else 1
    width=min(preferred_width,(available-12*(columns-1))/columns)
    line_height = font+5; y = [top]*columns; rectangles = []
    # Long compact readouts must not disappear as one oversized card.
    capacity=max(1,int((top-bottom-32)/line_height)-2)
    split=[]
    for title,rows,color in cards:
        for start in range(0,len(rows),capacity):
            split.append((title+(' · continued' if start else ''),rows[start:start+capacity],color))
    cards=split
    omitted = 0
    for title,rows,color in cards:
        column = max(range(columns),key=lambda i:y[i]); height = (len(rows)+2)*line_height+8
        if y[column]-height < bottom+24:
            omitted += len(rows); continue
        x = left+column*(width+12); yy = y[column]-height
        screen_rect(x,yy,width,height,(.025,.035,.05,.88))
        screen_rect(x,yy+height-3,width,3,(*color[:3],.85))
        screen_text(title,x+10,yy+height-line_height-3,color,font)
        baseline = yy+height-line_height*2-3
        blf.size(0,font)
        for label,value in rows:
            max_value_width = width*.57
            value = fit_text(value,max_value_width)
            value_width = blf.dimensions(0,value)[0] if value else 0
            max_label = width-26-value_width
            label = fit_text(label,max_label)
            screen_text(label,x+10,baseline,(.68,.74,.82,1.),font)
            if value: screen_text(value,x+width-10-value_width,baseline,(.96,.97,1.,1.),font)
            baseline -= line_height
        rectangles.append((x,yy,x+width,yy+height)); y[column] = yy-10
    if omitted:
        screen_text(f'{omitted} more readouts: enlarge viewport or hide optional cards',left,bottom,guides.AMBER,10)
    return rectangles


def screen_dimension(a,b,color):
    delta = b-a; length = delta.length
    if length < 3: return
    direction = delta/length; perp = Vector((-direction.y,direction.x))
    size = min(8.,length*.25); coords = []
    for point,sign in ((a,1),(b,-1)):
        coords.extend(((point.x,point.y,0),(*(point+direction*sign*size+perp*size*.45),0),
                       (point.x,point.y,0),(*(point+direction*sign*size-perp*size*.45),0)))
    draw_lines(coords,color,1.7)


def draw_callout(context,point,text,color,offset,occupied):
    import blf
    if point is None: return
    left,right,bottom,top = visible_view_rect(context)
    size = context.scene.jeweler_gauge.font_size
    blf.size(0,size)
    lines = text.split('\n')
    width = min(max(blf.dimensions(0,line)[0] for line in lines)+18,right-left)
    lines=[fit_text(line,max(1,width-18)) for line in lines]
    height = len(lines)*(size+4)+12
    x,y,rect=guides.callout_position((point.x,point.y),width,height,(left,right,bottom,top),occupied,offset)
    endpoint = Vector((min(max(point.x,x),x+width),min(max(point.y,y),y+height)))
    draw_lines([(point.x,point.y,0),(endpoint.x,endpoint.y,0)],(*color[:3],.8),1.2)
    screen_rect(x,y,width,height,(.025,.035,.055,.9))
    screen_rect(x,y,3,height,(*color[:3],1.))
    for i,line in enumerate(lines): screen_text(line,x+9,y+height-(i+1)*(size+4)-2,color,size)
    occupied.append(rect)


def draw_weight_summary(context,d):
    import blf
    s=context.scene.jeweler_gauge
    if not visibility.enabled(s,'show_volume'):return []
    left,right,bottom,top=visible_view_rect(context)
    m=d['metrics'];volume=m['volume_mm3'];dec=s.decimals
    approximate='≈ ' if m.get('volume_estimated') else ''
    weight=None;material=s.material
    if s.target:
        material,density=alloy(context.scene,s.target)
        if volume is not None:weight=volume*density/1000
    name=core.MATERIAL_MAP[material][1].replace(' (approx.)','')
    rows=[('Volume', 'Unavailable' if volume is None else f'{approximate}{volume:,.{dec}f} mm³'),
          (name, 'Unavailable' if weight is None else f'{approximate}{weight:,.{dec}f} g')]
    font=s.font_size;blf.size(0,font)
    width=min(right-left,max(blf.dimensions(0,a+'  '+b)[0] for a,b in rows)+24)
    height=2*(font+6)+16;y=top-height
    screen_rect(left,y,width,height,(.025,.035,.05,.88))
    for i,(label,value) in enumerate(rows):
        screen_text(fit_text(label+'  '+value,width-20),left+10,top-(i+1)*(font+6)-2,guides.AMBER,font)
    return [(left,y,left+width,top)]


def draw_pixel():
    context = bpy.context
    if not context.scene or not hasattr(context.scene,'jeweler_gauge'): return
    s = context.scene.jeweler_gauge
    if not s.overlay: return
    import gpu
    d = current(context); occupied = []
    depth = gpu.state.depth_test_get()
    gpu.state.depth_test_set('NONE'); gpu.state.blend_set('ALPHA')
    try:
        if d and 'metrics' in d:
            if s.show_hud: occupied = draw_dashboard(context,d)
            else: occupied = draw_weight_summary(context,d)
            if context.region_data:
                project = lambda p: view3d_utils.location_3d_to_region_2d(context.region,context.region_data,to_world(d,p))
                geo = guide_geometry(context,d)
                for dim in geo['dimensions']:
                    aa,bb = project(dim['a']),project(dim['b'])
                    if aa is not None and bb is not None: screen_dimension(aa,bb,dim['color'])
                if s.show_labels:
                    for item in geo['labels']:
                        draw_callout(context,project(item['point']),item['text'],item['color'],item['offset'],occupied)
        elif d and 'error' in d and s.show_hud:
            screen_text('Jeweler Gauge: '+d['error'],24,context.region.height-75,guides.RED,s.font_size)
        if context.region_data and s.show_labels and visibility.enabled(s,'show_probes'):
            project_world = lambda p: view3d_utils.location_3d_to_region_2d(context.region,context.region_data,Vector(p))
            for p in list(s.probes)[-s.label_limit:]:
                if s.target and p.source != s.target.name: continue
                aa,bb = project_world(p.a),project_world(p.b)
                if aa is not None and bb is not None:
                    screen_dimension(aa,bb,guides.PINK)
                    draw_callout(context,(aa+bb)*.5,f'{p.label} (snapshot)\n{p.value_mm:.{s.decimals}f} mm',guides.PINK,(20,30),occupied)
            if _HOVER and _HOVER[3] == context.scene.as_pointer():
                aa,bb = project_world(_HOVER[0]),project_world(_HOVER[1])
                if aa is not None and bb is not None:
                    screen_dimension(aa,bb,guides.WHITE)
                    draw_callout(context,(aa+bb)*.5,f'Click to pin\n{_HOVER[2]:.{s.decimals}f} mm',guides.WHITE,(18,24),occupied)
    finally:
        gpu.state.depth_test_set(depth); gpu.state.blend_set('NONE')


@persistent
def depsgraph_changed(scene, depsgraph):
    if _VOLUME_BUSY: return
    if not hasattr(scene, 'jeweler_gauge'): return
    s = scene.jeweler_gauge; target = s.target
    if not target: return
    # Geometry dependencies can be any object/datablock (Boolean operands/GN input).
    # Dirty is set only for geometry or target transforms; never material/UI changes.
    for update in depsgraph.updates:
        changed = update.id.original
        if update.is_updated_geometry or (changed == target and update.is_updated_transform):
            _DIRTY[scene.as_pointer()] = time.monotonic()
            break


@persistent
def on_load(_):
    global _HOVER, _MODAL
    _CACHE.clear(); _DIRTY.clear(); _HOVER = None
    if _MODAL: _MODAL.finish()
    for scene in getattr(bpy.data, 'scenes', ()):
        if hasattr(scene,'jeweler_gauge'):
            s=scene.jeweler_gauge
            if hasattr(s,'ui_revision') and s.ui_revision<1:
                s.font_size=max(s.font_size,20)
                s.show_hud=False;s.hud_detail=False;s.ui_revision=1
        if hasattr(scene, 'jeweler_gauge') and scene.jeweler_gauge.target:
            _DIRTY[scene.as_pointer()] = time.monotonic()


def deferred_initialize():
    # Blender wraps bpy.data/bpy.context in restricted objects during register().
    # Timers execute after enable returns; retry if file data is still restricted.
    if getattr(bpy.data, 'scenes', None) is None: return .1
    on_load(None)
    redraw()
    return None


def live_timer():
    context = bpy.context
    if not getattr(context, 'scene', None) or not hasattr(context.scene, 'jeweler_gauge'): return .4
    scene = context.scene; s = scene.jeweler_gauge; key = scene.as_pointer()
    if not s.target or _MODAL is not None: return .4
    d = _CACHE.get(key)
    if d and 'metrics' in d and d.get('settings_signature') != settings_signature(scene):
        _DIRTY.setdefault(key, time.monotonic())
    if s.live and key in _DIRTY and time.monotonic()-_DIRTY[key] > .55:
        # Use original or previously evaluated complexity to avoid accidental UI stalls.
        original_count = len(s.target.data.polygons) if s.target.type == 'MESH' else 0
        count = max(original_count, d.get('metrics', {}).get('triangles', 0) if d else 0)
        if count > _LIVE_FACE_LIMIT:
            if d: d['live_paused'] = 'Live refresh paused for heavy mesh. Use Refresh Measurements.'
        else:
            refresh(context)
    return .4


CLASSES = (JG_ObjectSettings, JG_Probe, JG_Settings, JG_OT_target, JG_OT_refresh, JG_OT_visibility, JG_OT_visibility_group, JG_OT_refine_volume, JG_OT_detect_bore,
           JG_OT_lock_bore,JG_OT_unlock_bore,JG_OT_selected_bore,JG_OT_calibrate_bore,JG_OT_pick,
           JG_OT_clear_probes, JG_OT_calibration, JG_OT_wall_scan, JG_OT_width_scan, JG_OT_report, JG_OT_export,
           JG_PT_main, JG_PT_results, JG_PT_scale, JG_PT_ring, JG_PT_mesh, JG_PT_weight, JG_PT_probes, JG_PT_reports, JG_PT_overlay)


def register():
    for cls in CLASSES: bpy.utils.register_class(cls)
    bpy.types.Scene.jeweler_gauge = PointerProperty(type=JG_Settings)
    bpy.types.Object.jg_alloy = PointerProperty(type=JG_ObjectSettings)
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_changed)
    bpy.app.handlers.load_post.append(on_load)
    bpy.app.handlers.undo_post.append(on_load)
    bpy.app.handlers.redo_post.append(on_load)
    if not bpy.app.background:
        _HANDLES.append(bpy.types.SpaceView3D.draw_handler_add(draw_view, (), 'WINDOW', 'POST_VIEW'))
        _HANDLES.append(bpy.types.SpaceView3D.draw_handler_add(draw_pixel, (), 'WINDOW', 'POST_PIXEL'))
        bpy.app.timers.register(live_timer, persistent=True)
    # Never run scene initialization synchronously inside restricted registration.
    bpy.app.timers.register(deferred_initialize, first_interval=.1)


def unregister():
    if _MODAL: _MODAL.finish()
    if bpy.app.timers.is_registered(deferred_initialize): bpy.app.timers.unregister(deferred_initialize)
    if bpy.app.timers.is_registered(live_timer): bpy.app.timers.unregister(live_timer)
    for handle in _HANDLES: bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
    _HANDLES.clear()
    for collection in (bpy.app.handlers.load_post, bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if on_load in collection: collection.remove(on_load)
    if depsgraph_changed in bpy.app.handlers.depsgraph_update_post: bpy.app.handlers.depsgraph_update_post.remove(depsgraph_changed)
    del bpy.types.Scene.jeweler_gauge
    del bpy.types.Object.jg_alloy
    for cls in reversed(CLASSES): bpy.utils.unregister_class(cls)
    _CACHE.clear(); _DIRTY.clear()


if __name__ == '__main__': register()

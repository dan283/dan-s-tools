"""Viewport guide geometry, expressed in physical mm (no Blender dependency)."""
import math
import numpy as np
from . import core

CYAN = (.12, .85, 1., 1.)
AMBER = (1., .72, .2, 1.)
PINK = (1., .32, .67, 1.)
RED = (1., .22, .16, 1.)
GREEN = (.3, 1., .45, 1.)
WHITE = (.88, .92, 1., 1.)
AXIS_COLORS = ((1., .42, .38, 1.), (.4, 1., .55, 1.), (.4, .65, 1., 1.))


def callout_position(point,width,height,bounds,occupied,offset):
    """Find visible space for a label; never drop it just because its anchor is offscreen."""
    left,right,bottom,top=bounds
    width=min(width,max(right-left,1));height=min(height,max(top-bottom,1))
    px,py=point
    def candidate(x,y):
        x=min(max(x,left),right-width);y=min(max(y,bottom),top-height)
        rect=(x-3,y-3,x+width+3,y+height+3)
        overlap=sum(max(0,min(rect[2],r[2])-max(rect[0],r[0]))*
                    max(0,min(rect[3],r[3])-max(rect[1],r[1])) for r in occupied)
        distance=(x+width*.5-px)**2+(y+height*.5-py)**2
        return overlap,distance,x,y,rect
    offsets=[offset,(20,25),(-width-20,25),(20,-height-25),(-width-20,-height-25),
             (20,65),(-width-20,65),(20,-height-65),(-width-20,-height-65),
             (55,100),(-width-55,100),(55,-height-100),(-width-55,-height-100)]
    candidates=[]
    for dx,dy in offsets:
        option=candidate(px+dx,py+dy)
        if option[0]==0:return option[2:]
        candidates.append(option)
    # A denser canvas search handles large fonts and coincident anchors.
    xs=np.unique(np.r_[np.arange(left,right-width+1,24),right-width])
    ys=np.unique(np.r_[np.arange(bottom,top-height+1,24),top-height])
    candidates.extend(candidate(x,y) for x in xs for y in ys)
    best=min(candidates,key=lambda item:(item[0],item[1]))
    return best[2:]


def focused_ring(data,options):
    """Bore and local shank guides only: no decorative-head or whole-box dimensions."""
    result = dict(lines=[],labels=[],dimensions=[])
    sec = data.get('section')
    if not sec: return result
    r = sec['ring']; u,w,n,o = sec['basis']; c = r['center']
    decimals = options.get('decimals',3)
    approximate = '≈ ' if r.get('estimated') else ''
    def value(x): return 'Unavailable' if x is None else f'{approximate}{x:.{decimals}f} mm'
    def depth_value(station):
        x=station['width_mm']
        return 'Unavailable' if x is None else ('≈ ' if station.get('depth_section_estimated') else '')+f'{x:.{decimals}f} mm'
    def p3(p): return o+p[0]*u+p[1]*w
    def line(points,color,width=1.5):
        result['lines'].append(dict(points=np.asarray(points),color=color,width=width))
    def label(point,text,color,offset):
        result['labels'].append(dict(point=np.asarray(point),text=text,color=color,offset=offset))
    def dim(a,b,color,offset=None):
        a,b = np.asarray(a),np.asarray(b)
        shift = np.zeros(3) if offset is None else np.asarray(offset)
        aa,bb = a+shift,b+shift
        line([aa,bb],color,2.)
        if np.linalg.norm(shift)>1e-12: line([a,aa+shift*.15,b,bb+shift*.15],(*color[:3],.45),1.)
        result['dimensions'].append(dict(a=aa,b=bb,color=color))
    def hit(contour,theta):
        direction = np.array([math.cos(theta),math.sin(theta)])
        hits = core.ray_polygon(c,direction,contour['points'])
        return c+direction*hits[0] if len(hits)==1 else None
    top = sec.get('top_angle',math.pi*.5)
    stations = sec.get('shank_stations',[])
    if options.get('ring',True):
        for contour,color in ((sec['hole'],CYAN),(sec['outer'],AMBER)):
            if not options.get('inside' if contour is sec['hole'] else 'outside',True): continue
            if contour is sec['outer'] and sec.get('outer_complete',True) is False:
                radii = sec['measured_outer']; size = len(radii); pts = []
                for i in range(size):
                    j = (i+1)%size
                    if np.isfinite(radii[i]) and np.isfinite(radii[j]):
                        for k in (i,j):
                            theta = k*math.pi*2/size
                            pts.append(p3(c+radii[k]*np.array([math.cos(theta),math.sin(theta)])))
                if pts: line(pts,AMBER,1.7)
                continue
            pts = [p3(p) for p in contour['points']]
            line([p for i in range(len(pts)) for p in (pts[i],pts[(i+1)%len(pts)])],color,2.)
        inner_anchor = hit(sec['hole'],top+math.pi)
        outer_anchor = hit(sec['outer'],top+math.pi)
        if outer_anchor is None:
            direction=np.array([math.cos(top+math.pi),math.sin(top+math.pi)])
            pts=sec['outer']['points']
            outer_anchor=pts[np.argmax((pts-c)@direction)]
        if inner_anchor is not None and options.get('inside',True):
            label(p3(inner_anchor),'Inside circumference\n'+value(r['inner_circumference_mm']),CYAN,(-185,28))
        if outer_anchor is not None and options.get('outside',True):
            outside_value=value(r['outer_circumference_mm'])
            if r.get('outer_estimated') is False: outside_value=outside_value.removeprefix('≈ ')
            label(p3(outer_anchor),'Outside circumference\n'+outside_value,AMBER,(25,-70))
        for station in stations:
            thickness=options.get('thickness',True); depth=options.get('depth',True)
            if not thickness and not depth: continue
            a,b = station['inner'],station['outer']
            if thickness: dim(a,b,PINK)
            if thickness:
                offset=(-235,35) if station['name'].startswith('Left') else ((30,35) if station['name'].startswith('Right') else (-220,-50))
                label((a+b)*.5,station['name']+' thickness\n'+value(station['thickness_mm']),PINK,offset)
            if depth and station['width_mm'] is not None:
                outward = (b-a)/max(np.linalg.norm(b-a),1e-12)
                body_span=float(np.max(np.ptp(data['v'],axis=0)))
                shift=outward*max(body_span*.0045,np.linalg.norm(b-a)*.18)
                dim(station['width_a'],station['width_b'],GREEN,shift)
                midpoint=(station['width_a']+station['width_b'])*.5+shift
                offset=(-235,-70) if station['name'].startswith('Left') else ((35,-70) if station['name'].startswith('Right') else (35,-90))
                label(midpoint,station['name']+' max depth\n'+depth_value(station),GREEN,offset)
        top_depth=sec.get('top_depth')
        if options.get('top_depth',False) and top_depth:
            a,b=top_depth['width_a'],top_depth['width_b']
            outward=math.cos(top)*u+math.sin(top)*w
            shift=outward*max(float(np.max(np.ptp(data['v'],axis=0)))*.012,1e-5)
            dim(a,b,GREEN,shift)
            label((a+b)*.5+shift,'Top / crown depth\n'+depth_value(top_depth),GREEN,(30,45))
    if options.get('diameters',True):
        for theta,title,offset in ((top+math.pi*.5,'Bore across sides',(25,25)),(top,'Bore top to bottom',(18,-28))):
            a,b = hit(sec['hole'],theta),hit(sec['hole'],theta+math.pi)
            if a is not None and b is not None:
                aa,bb = p3(a),p3(b); dim(aa,bb,CYAN)
                label((aa+bb)*.5,title+'\n'+value(float(np.linalg.norm(bb-aa))),CYAN,offset)
    if options.get('custom_gauge',False):
        angle = options.get('angle',0.); a,b = hit(sec['hole'],angle),hit(sec['outer'],angle)
        if a is not None and b is not None:
            aa,bb = p3(a),p3(b); dim(aa,bb,WHITE)
            label((aa+bb)*.5,f'Custom radial {math.degrees(angle):.1f}°\n'+value(float(np.linalg.norm(bb-aa))),WHITE,(24,30))
    return result


def height_guides(data,options):
    """Dimensions in the bore/crown frame, independent of world-axis boxes."""
    result=dict(lines=[],labels=[],dimensions=[])
    sec=data.get('section') or {}; p=sec.get('height_profile')
    if not p or not (options.get('heights',True) or options.get('body',False)): return result
    c,up,side,axis=p['center'],p['up'],p['lateral'],p['axis']
    span=max(data['metrics']['dimensions_mm']); margin=max(span*options.get('offset',.12),span*1e-5)
    rail=p['half_side']+margin; dec=options.get('decimals',3)
    def value(x,estimated=False):
        return 'Unavailable' if x is None else ('≈ ' if estimated else '')+f'{x:.{dec}f} mm'
    def point(height,lateral=0.,depth=0.): return c+up*height+side*lateral+axis*depth
    def line(a,b,color,width=1.):
        result['lines'].append(dict(points=np.asarray([a,b]),color=color,width=width))
    def dimension(a,b,title,x,color,estimated=False,offset=(20,8),extra=''):
        line(a,b,color,2.)
        result['dimensions'].append(dict(a=np.asarray(a),b=np.asarray(b),color=color))
        result['labels'].append(dict(point=(a+b)*.5,text=title+'\n'+value(x,estimated)+extra,color=color,offset=offset))
    def height(low,high,position,title,x,color,estimated=False,offset=(20,8),extra=''):
        a,b=point(low,position),point(high,position)
        dimension(a,b,title,x,color,estimated,offset,extra)
        line(point(low),a,(*color[:3],.3)); line(point(high),b,(*color[:3],.3))
    inferred=p.get('crown_reference_estimated',p['body_reference_estimated'])
    inner=p.get('crown_inner_above_bore_mm')
    if inner is None and p['crown_band_thickness_mm'] is not None: inner=p['base']-p['crown_band_thickness_mm']
    if options.get('heights',True) and inner is not None:
        height(inner,p['top'],rail+margin*.7,'Inside to crown top',p.get('crown_total_height_mm',p['top']-inner),AMBER,p.get('crown_silhouette_estimated',False),(28,30))
        height(inner,p['base'],rail,'Round-band height',p.get('round_band_height_mm',p['base']-inner),CYAN,inferred,(28,-30))
        height(p['base'],p['top'],rail,'Extra crown height',p.get('extra_crown_height_mm',p['top']-p['base']),AMBER,inferred,(28,30))
    if options.get('body',False):
        height(p['bottom'],p['base'],-rail,'Ring body height',p['body_height_mm'],WHITE,inferred,(-190,12))
        height(p['bottom'],p['top'],-rail-margin*.65,'Total height',p['total_height_mm'],WHITE,False,(-200,-38))
    # A dashed reference marks the split rather than suggesting an actual seam.
    low,high=-rail,rail
    for a,b in zip(np.linspace(low,high,31)[:-1:2],np.linspace(low,high,31)[1::2]):
        line(point(p['base'],a),point(p['base'],b),(*AMBER[:3],.45))
    return result


def build(data, options):
    """Build labeled contours, dimension witnesses and arrows from measured data."""
    original=data.get('section') or {}
    front=original.get('silhouette') if options.get('silhouette',True) else None
    if front:
        sec=dict(original,hole=front['hole'],outer=front['outer'],contours=front['contours'],ring=front['ring'],outer_complete=True)
        data=dict(data,section=sec)
    focused=options.get('focus',False)
    result = focused_ring(data,options) if focused else dict(lines=[], labels=[], dimensions=[])
    decimals = options.get('decimals', 3)
    def value(x): return 'Unavailable' if x is None else f'{x:,.{decimals}f}'
    span = max(data['metrics']['dimensions_mm'])
    margin = max(span*options.get('offset', .12), span*1e-5)
    def line(points, color, width=1.5):
        if len(points) >= 2: result['lines'].append(dict(points=np.asarray(points),color=color,width=width))
    def label(point, text, color=WHITE, offset=(18,18)):
        result['labels'].append(dict(point=np.asarray(point),text=text,color=color,offset=offset))
    def dimension(a, b, text, color, offset=None, text_offset=(12,12)):
        a, b = np.asarray(a), np.asarray(b)
        delta = np.zeros(3) if offset is None else np.asarray(offset)
        aa, bb = a+delta, b+delta
        line([aa,bb],color,2.)
        if np.linalg.norm(delta):
            line([a,aa+delta*.18,b,bb+delta*.18],(*color[:3],.5),1.)
        result['dimensions'].append(dict(a=aa,b=bb,color=color))
        label((aa+bb)*.5,text,color,text_offset)

    lo, hi = data['v'].min(axis=0), data['v'].max(axis=0)
    center = (lo+hi)*.5
    if options.get('bbox', True):
        corners = np.array([[hi[i] if (bits>>i)&1 else lo[i] for i in range(3)] for bits in range(8)])
        edges = []
        for bits in range(8):
            for axis in range(3):
                if not ((bits>>axis)&1): edges.extend((corners[bits],corners[bits|(1<<axis)]))
        line(edges,(.7,.8,.9,.27),1.)
        # World-axis dimensions, with offset witnesses to avoid lying on mesh edges.
        for axis in range(3):
            a = lo.copy(); b = lo.copy(); b[axis] = hi[axis]
            if axis == 0: a[1] = b[1] = hi[1]; a[2] = b[2] = hi[2]; offset = [0,margin,margin*.3]
            elif axis == 1: a[0] = b[0] = hi[0]; offset = [margin,0,-margin*.3]
            else: a[0] = b[0] = hi[0]; a[1] = b[1] = hi[1]; offset = [margin*.6,margin*.6,0]
            text=f'World {"XYZ"[axis]}  {value(hi[axis]-lo[axis])} mm'
            if hi[axis]-lo[axis]>1e-10:
                dimension(a,b,text,AXIS_COLORS[axis],offset)
            else: label(a+np.asarray(offset),text,AXIS_COLORS[axis])

    heights=height_guides(data,options)
    for key in result: result[key].extend(heights[key])
    if focused: return result

    sec = data.get('section')
    if sec:
        u,w,n,o = sec['basis']; r = sec['ring']; c = r['center']
        def p3(p): return o+p[0]*u+p[1]*w
        def point_at(contour, angle):
            direction = np.array([math.cos(angle),math.sin(angle)])
            hits = core.ray_polygon(c,direction,contour['points'])
            return c+direction*hits[0] if len(hits) == 1 else None
        def wall(angle):
            inner = point_at(sec['hole'],angle); outer = point_at(sec['outer'],angle)
            if inner is None or outer is None: return None
            direction = np.array([math.cos(angle),math.sin(angle)])
            ri,ro = np.linalg.norm(inner-c),np.linalg.norm(outer-c)
            if ro <= ri: return None
            for contour in sec.get('contours',[]):
                if contour is sec['hole'] or contour is sec['outer']: continue
                beyond = [h for h in core.ray_polygon(c,direction,contour['points']) if h > ri+1e-5]
                if beyond: ro = min(ro,min(beyond))
            return inner,c+direction*ro,ro-ri
        extent = np.ptp(sec['outer']['points'],axis=0)
        radius = float(np.max(np.linalg.norm(sec['outer']['points']-c,axis=1)))
        if options.get('ring',True):
            for contour,color in ((sec['hole'],CYAN),(sec['outer'],AMBER)):
                pts = [p3(p) for p in contour['points']]
                line([p for i in range(len(pts)) for p in (pts[i],pts[(i+1)%len(pts)])],color,2.)
            for contour,angle,title,color,offset in ((sec['hole'],math.pi,'Inside circumference',CYAN,(-185,28)),
                                                     (sec['outer'],.5,'Outside circumference',AMBER,(24,36))):
                p = point_at(contour,angle)
                if p is None: p = contour['points'][0]
                label(p3(p),f'{title}\n{value(contour["perimeter"])} mm',color,offset)
            # Center and two reference axes help orient the continuous angle gauge.
            cc = p3(c); arm = radius*.12
            line([cc-u*arm,cc+u*arm,cc-w*arm,cc+w*arm],(*CYAN[:3],.6),1.)
            a = options.get('angle',0.)
            chord = wall(a)
            if chord:
                aa,bb,thickness = chord
                dimension(p3(aa),p3(bb),f'Radial wall {math.degrees(a):.1f}°\n{value(thickness)} mm',PINK,text_offset=(30,-45))
            if options.get('diameters',True):
                count = len(r['radial_thickness']); angles = np.arange(count)*2*math.pi/count
                diam = []
                for theta in angles:
                    aa,bb = point_at(sec['hole'],theta),point_at(sec['hole'],theta+math.pi)
                    diam.append(np.linalg.norm(bb-aa) if aa is not None and bb is not None else np.nan)
                if np.any(np.isfinite(diam)):
                    if r['ovality_mm'] > .01:
                        chosen = [(float(angles[np.nanargmin(diam)]),'Bore minimum',CYAN),
                                  (float(angles[np.nanargmax(diam)]),'Bore maximum',(.6,.7,1.,1.))]
                    else: chosen = [(a+math.pi*.5,'Bore diameter',CYAN)]
                    for theta,title,color in chosen:
                        aa,bb = point_at(sec['hole'],theta),point_at(sec['hole'],theta+math.pi)
                        if aa is not None and bb is not None:
                            dimension(p3(aa),p3(bb),f'{title}\n{value(np.linalg.norm(bb-aa))} mm',color,
                                      offset=n*margin*.12,text_offset=(-36,24))
            if options.get('extremes',True) and r['radial_thickness_max_mm']-r['radial_thickness_min_mm'] > .01:
                for i,title,color in ((np.nanargmin(r['radial_thickness']),'Sampled thinnest',RED),
                                      (np.nanargmax(r['radial_thickness']),'Sampled thickest',GREEN)):
                    pair = r['endpoints'][i]
                    if pair:
                        dimension(p3(pair[0]),p3(pair[1]),f'{title}\n{value(r["radial_thickness"][i])} mm',color,text_offset=(20,50))
            # True axial bounding span along the ring axis, not a local shank width.
            axial = data['v']@n
            rail = cc+u*(radius+margin)
            aa = rail+n*(axial.min()-rail@n); bb = rail+n*(axial.max()-rail@n)
            dimension(aa,bb,f'Axial span\n{value(r["axial_span_mm"])} mm',WHITE,text_offset=(30,5))
            line([aa-u*margin,aa+u*margin*.15,bb-u*margin,bb+u*margin*.15],(*WHITE[:3],.4),1.)
            # Visible angle arc at a consistent radius, and a zero-degree reference.
            angles = np.linspace(0,a,max(2,int(abs(a)*24)+2))
            arc = [p3(c+radius*1.09*np.array([math.cos(theta),math.sin(theta)])) for theta in angles]
            if abs(a) > .01:
                line([p for i in range(len(arc)-1) for p in (arc[i],arc[i+1])],(*PINK[:3],.65),1.)
            line([p3(c+np.array([radius,0.])),p3(c+np.array([radius*1.16,0.]))],(*WHITE[:3],.45),1.)
            label(p3(c+np.array([radius*1.16,0.])), '0°',WHITE,(8,-20))
        if options.get('plane',True):
            half = extent*.57
            pts = [p3(c+np.array([x*half[0],y*half[1]])) for x,y in ((-1,-1),(1,-1),(1,1),(-1,1))]
            line([p for i in range(4) for p in (pts[i],pts[(i+1)%4])],(.35,.8,1.,.25),1.)
            label(pts[0],f'Measurement slice {options.get("slice",.5)*100:.1f}%',CYAN,(-120,-25))

    if 'wall_scan' in data and options.get('extremes',True):
        chords = data['wall_scan']['chords']
        if chords:
            aa,bb,thickness = min(chords,key=lambda item:item[2])
            dimension(aa,bb,f'Wall scan minimum\n{value(thickness)} mm',RED,text_offset=(28,55))
    return result

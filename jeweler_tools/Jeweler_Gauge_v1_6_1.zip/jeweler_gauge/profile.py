"""Ring-body and raised-top dimensions in the detected bore frame.

A fused head has no objectively recoverable band/head seam. The automatic
reference uses a robust lower/side shank envelope and is explicitly estimated.
"""
import math
import numpy as np
from . import bore,core


def section_extent(vertices,triangles,center,up,lateral,axis,height):
    segments,basis=bore.segments_at(vertices,triangles,up,float(center@up+height))
    if not len(segments): return None
    u,w,_,o=basis; xy=segments.reshape((-1,2))
    points=o+xy[:,0,None]*u+xy[:,1,None]*w
    side=(points-center)@lateral; depth=(points-center)@axis
    return dict(width_mm=float(np.ptp(side)),depth_mm=float(np.ptp(depth)),
                side_low=float(side.min()),side_high=float(side.max()),
                depth_low=float(depth.min()),depth_high=float(depth.max()))


def envelope(sec,theta):
    """Fit the side/lower shank only; the raised head does not set its radius."""
    r=sec['ring']; center=r['center']
    radii=sec.get('measured_outer')
    if radii is None:
        radii=np.array([np.linalg.norm(pair[1]-center) if pair else np.nan for pair in r['endpoints']])
    angles=np.arange(len(radii))*math.pi*2/len(radii)
    up=np.cos(angles-theta); side=np.sin(angles-theta)
    valid=np.isfinite(radii)&(radii>0)&(up<.45)
    if valid.sum()<max(12,len(radii)//5): raise ValueError('Not enough side/lower shank evidence to separate body and head')
    reference=float(np.nanmedian(radii[valid]))
    x=radii[valid]*side[valid]/reference; y=radii[valid]*up[valid]/reference
    matrix=np.column_stack((x*x,y*y)); weights=np.ones(len(x))
    for _ in range(5):
        fit,*_=np.linalg.lstsq(matrix*weights[:,None],weights,rcond=None)
        if np.any(fit<=0): raise ValueError('Shank envelope does not support a stable body reference')
        residual=np.abs(matrix@fit-1)
        limit=max(float(np.median(residual))*3,.01)
        weights=np.minimum(1.,limit/np.maximum(residual,1e-12))
    a,b=reference/np.sqrt(fit)
    return float(a),float(b),float(np.median(residual)*100)


def analyze(vertices,triangles,sec,style='AUTO',direction=None,manual_base=None):
    v=np.asarray(vertices,dtype=float); t=np.asarray(triangles)
    u,w,n,o=sec['basis']; c=sec['ring']['center']; center=o+c[0]*u+c[1]*w
    theta=sec.get('top_angle',math.pi*.5) if direction is None else float(direction)
    p=v[t]; cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]); area=np.linalg.norm(cross,axis=1)*.5
    normals=cross/np.maximum(np.linalg.norm(cross,axis=1)[:,None],1e-30)
    # Whole-mesh projected protrusions catch a setting that lies outside the
    # central shank section. Uniform angular bins avoid vertex-density bias.
    if direction is None and style!='PLAIN':
        xy=np.column_stack(((v-center)@u,(v-center)@w)); rr=np.linalg.norm(xy,axis=1)
        aa=np.mod(np.arctan2(xy[:,1],xy[:,0]),2*math.pi)
        ids=np.floor(aa/(2*math.pi)*72).astype(int).clip(0,71)
        maximum=np.zeros(72); np.maximum.at(maximum,ids,rr)
        occupied=maximum>0
        baseline=float(np.percentile(maximum[occupied],40))
        excess=np.maximum(maximum-baseline*1.02,0)
        # Isolated spikes should not swing the crown direction.
        cap=max(float(np.percentile(excess[occupied],90)),baseline*.05)
        weights=np.minimum(excess,cap)**2
        peaks=(rr>=maximum[ids]-max(baseline*1e-9,1e-12))&(rr>0)
        counts=np.maximum(np.bincount(ids[peaks],minlength=72),1)
        dx=np.bincount(ids[peaks],weights=xy[peaks,0]/rr[peaks],minlength=72)/counts
        dy=np.bincount(ids[peaks],weights=xy[peaks,1]/rr[peaks],minlength=72)/counts
        vector=np.array([weights@dx,weights@dy])
        if np.count_nonzero(excess>baseline*.015)>=3 and np.linalg.norm(vector)>baseline*baseline*.001:
            theta=math.atan2(vector[1],vector[0])
        # A broad signet/setting shelf defines a more precise crown direction
        # than discrete angular bins, particularly on decimated meshes.
        crown=math.cos(theta)*u+math.sin(theta)*w
        planar=normals-(normals@n)[:,None]*n
        planar/=np.maximum(np.linalg.norm(planar,axis=1)[:,None],1e-30)
        planar*=np.where(planar@crown>=0,1.,-1.)[:,None]
        centroids=p.mean(axis=1)-center
        radial=np.linalg.norm(centroids-(centroids@n)[:,None]*n,axis=1)
        candidates=np.flatnonzero((planar@crown>math.cos(math.radians(18)))&
            (np.abs(normals@n)<.15)&(radial>baseline*1.025)&(centroids@crown>baseline*.8)&(area>0))
        best=None; support=0.
        for index in candidates[np.argsort(area[candidates])[-32:]]:
            group=candidates[planar[candidates]@planar[index]>math.cos(math.radians(2))]
            score=float(area[group].sum())
            if score>support:
                support=score; best=np.sum(planar[group]*area[group,None],axis=0)
        if best is not None and support>baseline*baseline*.05:
            theta=math.atan2(best@w,best@u)
    up=math.cos(theta)*u+math.sin(theta)*w
    lateral=-math.sin(theta)*u+math.cos(theta)*w
    x=(v-center)@lateral; y=(v-center)@up; z=(v-center)@n
    half_side,base,envelope_error=envelope(sec,theta)
    radius=sec.get('bore_fit',{}).get('radius',sec['ring']['equivalent_inner_diameter_mm']/2)
    merge=min(sec.get('merge_tolerance',.005),float(np.max(np.ptp(v,axis=0)))*.0002)
    ray_scale=30./max(float(np.max(np.ptp(v,axis=0))),1e-30)
    hits=bore.line_hits((v-center)*ray_scale,t,np.zeros(3),up,merge*ray_scale)/ray_scale
    positive=hits[hits>radius*.5]
    inner=None; observed=None
    if len(positive)>=2: inner,observed=map(float,positive[:2])
    threshold=max(radius*.025,abs(base-radius)*.12)
    # Exact source vertices retain total height, including ornaments and gems.
    top=float(y.max()); bottom=float(y.min()); total=top-bottom
    cy=y[t].mean(axis=1); cx=x[t].mean(axis=1)
    protruding=(cy>base+threshold*.3)&(np.abs(cx)<half_side*.95)
    support=float(area[protruding].sum()/max(area.sum(),1e-30))
    raised=(top>base+threshold and support>.003) if style=='AUTO' else style=='RAISED'
    inferred=False; method='Measured body outline'
    if manual_base is not None:
        if not (radius*.5<float(manual_base)<=top+merge):
            raise ValueError('Body-top reference must lie above the finger opening center and below the model top')
        base=float(manual_base); raised=top>base+merge
        method='User-defined body/top reference plane'
    elif not raised:
        base=top
    elif observed is not None and abs(observed-base)<=threshold:
        base=observed; method='Body surface measured on crown ray'
    else:
        inferred=True; method='Side/lower shank envelope; inferred body/top split'
    if raised and top<=base+merge:
        # Forcing raised mode cannot create a head on a plain band or put the
        # body/top plane beyond the actual geometry.
        raised=False; base=top; inferred=False; method='Measured body outline'
    body_height=base-bottom
    body_points=v[y<base-merge]
    if not len(body_points): raise ValueError('No ring body below the selected reference')
    body_width=float(np.ptp((body_points-center)@lateral))
    body_depth=float(np.ptp((body_points-center)@n))
    top_height=max(0.,top-base) if raised else 0.
    result=dict(has_raised_top=bool(raised),body_height_mm=float(body_height),total_height_mm=float(total),
                top_height_mm=float(top_height),body_width_mm=body_width,body_depth_mm=body_depth,
                body_top_above_bore_mm=float(base),body_bottom_below_bore_mm=float(-bottom),
                crown_band_thickness_mm=float(base-inner) if inner is not None and base>inner else None,
                body_reference_estimated=bool(inferred),body_reference_method=method,
                body_envelope_error_percent=envelope_error,top_direction_degrees=float(math.degrees(theta)),
                top_width_mm=None,top_depth_mm=None,tiers=[],center=center,up=up,lateral=lateral,axis=n,
                bottom=bottom,base=base,top=top,half_side=half_side)
    if not raised: return result
    # Crop the mesh geometrically at the reference plane; include cut-edge
    # intersections so coarse triangulation cannot shrink the top footprint.
    top_points=v[y>base+merge*.1]
    segments,basis=bore.segments_at(v,t,up,float(center@up+base+merge*.2))
    if len(segments):
        uu,ww,_,oo=basis; pp=segments.reshape((-1,2))
        top_points=np.vstack((top_points,oo+pp[:,0,None]*uu+pp[:,1,None]*ww))
    if len(top_points):
        side=(top_points-center)@lateral; depth=(top_points-center)@n
        result['top_width_mm']=float(np.ptp(side)); result['top_depth_mm']=float(np.ptp(depth))
        result['top_bounds']=dict(side_low=float(side.min()),side_high=float(side.max()),
                                 depth_low=float(depth.min()),depth_high=float(depth.max()))
    # Prefer distinct material intervals on the crown ray. They match a ring
    # body, a raised base/setting and a separate raised ornament in the sketch.
    intervals=[]
    if len(positive)%2==0:
        for low,high in zip(positive[::2],positive[1::2]):
            if low>=base-merge and high>base+merge:
                intervals.append((max(float(low),base),float(high),'Measured separate crown-ray interval'))
    if not intervals or intervals[-1][1]<top-threshold or intervals[0][0]>base+threshold:
        # Fused/touching tiers have no ray gap. Broad horizontal shelves provide
        # geometric reference levels; small engraving facets are ignored.
        flat=(np.abs(normals@up)>.97)&(np.ptp(y[t],axis=1)<max(merge*2,radius*1e-5))&(cy>base+threshold*.15)&(cy<top-threshold*.15)
        values=cy[flat]; sizes=area[flat]
        levels=[]
        if len(values):
            order=np.argsort(values); values,sizes=values[order],sizes[order]
            starts=np.r_[0,np.flatnonzero(np.diff(values)>max(merge*4,radius*.002))+1]
            ends=np.r_[starts[1:],len(values)]
            for a,b in zip(starts,ends):
                level=float(np.average(values[a:b],weights=sizes[a:b]))
                if sizes[a:b].sum()>max(radius*radius*.06,area.sum()*.0015): levels.append(level)
        # Cap the hierarchy to the broadest few shelves, not dozens of details.
        if len(levels)>3: levels=[]
        boundaries=[base]+levels+[top]
        intervals=[(a,b,'Geometric shelf reference' if levels else 'Body/top reference envelope')
                   for a,b in zip(boundaries[:-1],boundaries[1:]) if b-a>merge]
    for i,(low,high,tier_method) in enumerate(intervals):
        extent=section_extent(v,t,center,up,lateral,n,(low+high)*.5)
        # Empty slices are gaps between separate parts, not additional tiers.
        if not extent: continue
        row=dict(name=f"Top tier {len(result['tiers'])+1}",height_mm=float(high-low),bottom_above_bore_mm=low,
                 top_above_bore_mm=high,method=tier_method,estimated=bool(inferred or 'interval' not in tier_method),
                 width_mm=None,depth_mm=None)
        if extent: row.update(width_mm=extent['width_mm'],depth_mm=extent['depth_mm'])
        result['tiers'].append(row)
    return result


def public(result):
    return {key:value for key,value in result.items() if key not in {'center','up','lateral','axis','bottom','base','top','half_side'}}


def front_crown(vertices,sec,result,manual_base=None):
    """Only three crown heights, using the complete front silhouette.

    The imaginary circular band is concentric with the identified finger bore;
    its radius comes from the silhouette's side/lower shank, not crown shelves.
    """
    front=sec.get('silhouette')
    if not front: return result
    u,w,n,o=sec['basis']; c=sec['ring']['center']; center=o+c[0]*u+c[1]*w
    up=result['up']; side=result['lateral']; theta=math.atan2(up@w,up@u)
    outer=front['outer']['points']-c
    radius=np.linalg.norm(outer,axis=1)
    vertical=outer@np.array([math.cos(theta),math.sin(theta)])
    good=(radius>0)&(vertical/radius<.45)
    if good.sum()<16: raise ValueError('Too little lower silhouette evidence for a circular shank reference')
    reference=float(np.median(radius[good]))
    for _ in range(4):
        error=np.abs(radius[good]-reference)
        keep=error<max(float(np.median(error))*3,reference*.007)
        if keep.sum()<16: break
        reference=float(np.median(radius[good][keep]))
    hits=core.ray_polygon(c,np.array([math.cos(theta),math.sin(theta)]),front['hole']['points'])
    if not len(hits): raise ValueError('Front silhouette has no inner crown reference')
    inner=float(hits[0]); y=(np.asarray(vertices)-center)@up
    top=float(y.max()); bottom=float(y.min())
    base=reference if manual_base is None else float(manual_base)
    if not inner<=base<=top+front['grid_mm']:
        raise ValueError('Circular/manual crown reference lies outside the supported crown region')
    base=min(base,top)
    extra=max(0.,top-base)
    result.update(center=center,base=base,top=top,bottom=bottom,
        crown_inner_above_bore_mm=inner,crown_total_height_mm=top-inner,
        round_band_height_mm=base-inner,extra_crown_height_mm=extra,
        crown_reference_method='Manual reference plane' if manual_base is not None else 'Circular exterior fitted to front silhouette sides/lower shank',
        crown_reference_estimated=manual_base is None,crown_silhouette_estimated=True,
        round_reference_radius_mm=reference,front_silhouette_grid_mm=front['grid_mm'],
        body_height_mm=base-bottom,total_height_mm=top-bottom,top_height_mm=extra,
        body_top_above_bore_mm=base,body_bottom_below_bore_mm=-bottom,
        crown_band_thickness_mm=base-inner,body_reference_estimated=manual_base is None,
        body_reference_method='Circular exterior fitted to front silhouette sides/lower shank',
        has_raised_top=bool(extra>max(reference*.012,front['grid_mm']*2)),tiers=[])
    return result

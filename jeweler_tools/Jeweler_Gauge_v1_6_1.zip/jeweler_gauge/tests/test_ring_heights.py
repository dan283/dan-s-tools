"""Physical height splits, tiers and guides on simple and messy ring meshes."""
import json
import ast
import csv
import tempfile
import pathlib
import sys
import types
import math
import unittest
import numpy as np
from test_geometry import annulus
from test_signets_and_guides import profile, bore, data_for, signet, guides, addon
from test_dashboard import functions, context
from test_bore_lock_and_scale import api, settings, data


def box(lo,hi):
    v=np.array([[x,y,z] for z in (lo[2],hi[2]) for y in (lo[1],hi[1]) for x in (lo[0],hi[0])])
    t=np.array([[0,3,1],[0,2,3],[4,5,7],[4,7,6],[0,1,5],[0,5,4],
                [2,6,7],[2,7,3],[0,4,6],[0,6,2],[1,3,7],[1,7,5]])
    return v,t


def stacked(touching=False,offset=0.):
    v,t=annulus(segments=96)
    heights=(11.,13.,13.,19.) if touching else (11.1,13.1,13.3,19.3)
    for width,depth,low,high in ((12.,8.,*heights[:2]),(6.,6.,*heights[2:])):
        vv,tt=box((-width/2,low,offset-depth/2),(width/2,high,offset+depth/2))
        t=np.vstack((t,tt+len(v))); v=np.vstack((v,vv))
    return v,t


def measured(v,t,**kw):
    d=data_for(v,t)
    # The actual path supplies inferred crown/station direction.
    bore.stations(v,t,d['section'])
    p=profile.analyze(v,t,d['section'],**kw)
    d['section']['height_profile']=p
    return p,d


class RingHeightTests(unittest.TestCase):
    def test_plain_band_height_and_crown_thickness(self):
        for segments in (16,96,256):
            p,d=measured(*annulus(segments=segments))
            self.assertFalse(p['has_raised_top'])
            self.assertAlmostEqual(p['body_height_mm'],22.,places=7)
            self.assertAlmostEqual(p['total_height_mm'],22.,places=7)
            self.assertEqual(p['top_height_mm'],0.)
            self.assertAlmostEqual(p['crown_band_thickness_mm'],2.,places=7)
            self.assertEqual(p['tiers'],[])

    def test_separate_setting_and_raised_element(self):
        p,d=measured(*stacked())
        self.assertTrue(p['has_raised_top'])
        self.assertFalse(p['body_reference_estimated'])
        for key,value in [('body_height_mm',22.),('total_height_mm',30.3),('top_height_mm',8.3),
                          ('top_width_mm',12.),('top_depth_mm',8.),('body_depth_mm',4.),
                          ('crown_band_thickness_mm',2.)]:
            self.assertAlmostEqual(p[key],value,delta=.002,msg=key)
        self.assertEqual(len(p['tiers']),2)
        np.testing.assert_allclose([r['height_mm'] for r in p['tiers']],[2.,6.],atol=.002)
        np.testing.assert_allclose([r['width_mm'] for r in p['tiers']],[12.,6.],atol=.002)
        self.assertTrue(all(not row['estimated'] for row in p['tiers']))
        self.assertAlmostEqual(d['section']['ring']['inner_circumference_mm'],2*96*9*math.sin(math.pi/96),places=7)

    def test_touching_top_tiers_use_visible_shelf(self):
        p,_=measured(*stacked(touching=True))
        self.assertEqual(len(p['tiers']),2)
        np.testing.assert_allclose([r['height_mm'] for r in p['tiers']],[2.,6.],atol=.002)
        self.assertTrue(all(row['estimated'] for row in p['tiers']))

    def test_fused_signet_reference_is_explicitly_estimated(self):
        p,_=measured(*signet(96))
        self.assertTrue(p['has_raised_top'])
        self.assertTrue(p['body_reference_estimated'])
        self.assertAlmostEqual(p['body_height_mm'],22.,delta=.015)
        self.assertAlmostEqual(p['top_height_mm'],.5,delta=.015)
        self.assertIn('inferred',p['body_reference_method'])

    def test_rotated_crown_frame_preserves_all_heights(self):
        v,t=stacked()
        a=.63; rotation=np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]])
        p,_=measured(v@rotation.T,t)
        self.assertAlmostEqual(p['body_height_mm'],22.,delta=.02)
        self.assertAlmostEqual(p['top_height_mm'],8.3,delta=.02)
        self.assertAlmostEqual(p['top_width_mm'],12.,delta=.02)

    def test_setting_outside_central_bore_slice_is_detected(self):
        p,_=measured(*stacked(offset=9.))
        self.assertTrue(p['has_raised_top'])
        self.assertAlmostEqual(p['body_height_mm'],22.,delta=.01)
        self.assertAlmostEqual(p['top_height_mm'],8.3,delta=.01)
        self.assertAlmostEqual(p['top_depth_mm'],8.,delta=.01)

    def test_disconnected_reversed_and_noisy_geo(self):
        v,t=stacked(); soup=v[t].reshape((-1,3))
        soup+=np.random.default_rng(13).normal(0,.00005,soup.shape)
        tt=np.arange(len(soup)).reshape((-1,3)); tt[::2]=tt[::2,::-1]
        sec=bore.section(bore.find(soup,tt,np.eye(3),normal=[0,0,1]))
        bore.stations(soup,tt,sec)
        p=profile.analyze(soup,tt,sec)
        self.assertAlmostEqual(p['body_height_mm'],22.,delta=.015)
        self.assertAlmostEqual(p['top_height_mm'],8.3,delta=.015)
        self.assertEqual(len(p['tiers']),2)

    def test_manual_plane_and_plain_override(self):
        v,t=stacked()
        p,_=measured(v,t,manual_base=12.)
        self.assertEqual(p['body_reference_method'],'User-defined body/top reference plane')
        self.assertAlmostEqual(p['body_height_mm'],23.,delta=.002)
        p,_=measured(v,t,style='PLAIN')
        self.assertFalse(p['has_raised_top'])
        self.assertAlmostEqual(p['body_height_mm'],30.3,delta=.002)
        with self.assertRaises(ValueError): measured(v,t,manual_base=40.)

    def test_oval_plain_height_uses_actual_outline(self):
        p,_=measured(*annulus(oval=(1.2,.8)))
        self.assertFalse(p['has_raised_top'])
        self.assertAlmostEqual(p['body_height_mm'],17.6,places=7)
        self.assertAlmostEqual(p['body_width_mm'],26.4,places=7)

    def test_forced_raised_mode_cannot_invent_top_on_plain_oval(self):
        p,d=measured(*annulus(oval=(1.2,.8)),style='RAISED')
        self.assertFalse(p['has_raised_top'])
        self.assertEqual(p['top_height_mm'],0.)
        d.update(object_name='Plain oval',factor=1.)
        env,_=functions()
        self.assertTrue(env['dashboard_cards'](context(),d))

    def test_height_guides_and_independent_toggles(self):
        p,d=measured(*stacked())
        geo=guides.build(d,dict(focus=True,bbox=False,body=True))
        for prefix,expected in [('Ring body height',22.),('Inside to crown top',10.3),('Total height',30.3),
                                ('Round-band height',2.),('Extra crown height',8.3)]:
            label=next(l for l in geo['labels'] if l['text'].startswith(prefix))
            dim=next(item for item in geo['dimensions'] if np.allclose((item['a']+item['b'])/2,label['point']))
            self.assertAlmostEqual(np.linalg.norm(dim['a']-dim['b']),expected,delta=.002)
        self.assertFalse(any(l['text'].startswith(('Top tier ','Top footprint')) for l in geo['labels']))
        geo=guides.build(d,dict(focus=True,bbox=False,heights=False))
        self.assertFalse(any('height' in l['text'] for l in geo['labels']))
        geo=guides.build(d,dict(focus=True,bbox=False,tiers=False))
        self.assertFalse(any(l['text'].startswith('Top tier ') for l in geo['labels']))
        geo=guides.build(d,dict(focus=False,bbox=False,body=True))
        self.assertTrue(any(l['text'].startswith('Ring body height') for l in geo['labels']))

    def test_dashboard_and_report_values(self):
        p,d=measured(*stacked()); d.update(object_name='Stacked ring',factor=1.)
        env,_=functions()
        for full in (False,True):
            ctx=context(full);ctx.scene.jeweler_gauge.show_body_dimensions=True
            rows={key:value for _,items,_ in env['dashboard_cards'](ctx,d) for key,value in items}
            for label in ('Ring body height','Total height','Inside to crown top','Round-band height','Extra crown height'):
                self.assertIn(label,rows)
        encoded=json.dumps(profile.public(p),allow_nan=False)
        self.assertNotIn('"up"',encoded)
        self.assertEqual(json.loads(encoded)['top_height_mm'],p['top_height_mm'])

    def test_actual_wrapper_keeps_bore_if_bad_reference(self):
        s=settings(); s.height_base_mode='MANUAL'; s.body_top_reference=40.
        v,t=annulus(segments=32); d=data(v,t,s)
        sec=api()['section_at'](d,s,object())
        self.assertIn('height_error',sec)
        self.assertAlmostEqual(sec['ring']['equivalent_inner_diameter_mm'],2*32*9*math.sin(math.pi/32)/math.pi,delta=.002)

    def test_whole_head_direction_also_orients_shank_stations(self):
        s=settings(); s.auto_slice=False
        v,t=stacked(offset=9.)
        angle=.63; rotate=np.array([[math.cos(angle),-math.sin(angle),0],[math.sin(angle),math.cos(angle),0],[0,0,1]])
        # Explicitly use a slice inside the shank, clear of the offset head.
        s.slice=2./15.
        sec=api()['section_at'](data(v@rotate.T,t,s),s,object())
        theta=sec['height_profile']['top_direction_degrees']*math.pi/180.
        self.assertAlmostEqual(sec['top_angle'],theta,places=7)
        for station in sec['shank_stations']:
            self.assertAlmostEqual(station['thickness_mm'],2.,delta=.005)
            self.assertAlmostEqual(station['width_mm'],4.,delta=.005)

    def test_height_dimensions_scale_without_changing_geometry_choice(self):
        v,t=stacked()
        for scale in (.001,1.,1000.):
            s=settings(); d=data(v*scale,t,s)
            sec=api()['section_at'](d,s,object())
            p=sec['height_profile']
            self.assertTrue(p['has_raised_top'])
            self.assertAlmostEqual(p['body_height_mm']/scale,22.,delta=.015)
            self.assertAlmostEqual(p['top_height_mm']/scale,8.3,delta=.015)
            self.assertAlmostEqual(p['crown_band_thickness_mm']/scale,2.,delta=.015)
            np.testing.assert_allclose([row['height_mm']/scale for row in p['tiers']],[2.,6.],atol=.015)

    def test_rounded_raised_element_above_setting(self):
        v,t=annulus(segments=64)
        vv,tt=box((-6,11.1,-4),(6,13.1,4)); t=np.vstack((t,tt+len(v))); v=np.vstack((v,vv))
        # Closed hemisphere above a separate setting: its height is the dome
        # radius, not its diameter or the complete setting-plus-dome stack.
        rows=9; cols=32
        vv=np.array([[3*math.cos(phi)*math.cos(a),13.3+3*math.sin(phi),3*math.cos(phi)*math.sin(a)]
                     for phi in np.linspace(0,math.pi/2,rows) for a in np.arange(cols)*2*math.pi/cols])
        faces=[]
        for row in range(rows-1):
            for col in range(cols):
                a=row*cols+col; b=row*cols+(col+1)%cols; c=a+cols; dd=b+cols
                faces.extend(((a,b,c),(b,dd,c)))
        center=len(vv); vv=np.vstack((vv,[0,13.3,0]))
        faces.extend((center,col,(col+1)%cols) for col in range(cols))
        t=np.vstack((t,np.asarray(faces)+len(v))); v=np.vstack((v,vv))
        p,_=measured(v,t)
        self.assertAlmostEqual(p['body_height_mm'],22.,delta=.002)
        self.assertAlmostEqual(p['top_height_mm'],5.3,delta=.002)
        np.testing.assert_allclose([row['height_mm'] for row in p['tiers']],[2.,3.],atol=.002)

    def test_object_report_includes_json_safe_height_and_tier_data(self):
        p,d=measured(*stacked()); d['time']='test'
        tree=ast.parse((addon/'__init__.py').read_text())
        nodes=[node for node in tree.body if getattr(node,'name',None) in {'public_metrics','public_ring','report_object'}]
        ctx=context(); s=ctx.scene.jeweler_gauge
        env=dict(core=profile.core,profile=profile,alloy=lambda *_:('AG925',10.36))
        exec(compile(ast.Module(body=nodes,type_ignores=[]),'report-object','exec'),env)
        obj=type('Object',(),{'name':'Stacked ring'})()
        record=env['report_object'](ctx,obj,d)
        encoded=json.dumps(record,allow_nan=False)
        self.assertEqual(json.loads(encoded)['ring_heights']['tiers'][1]['height_mm'],p['tiers'][1]['height_mm'])

    def test_csv_exports_xyz_height_and_tiers(self):
        p,d=measured(*stacked()); d['time']='test'
        ctx=context(); tree=ast.parse((addon/'__init__.py').read_text())
        names={'public_metrics','public_ring','report_object','JG_OT_export'}
        nodes=[node for node in tree.body if getattr(node,'name',None) in names]
        class Operator:
            def report(self,*args): pass
        class ExportHelper: pass
        env=dict(core=profile.core,profile=profile,json=json,csv=csv,Operator=Operator,ExportHelper=ExportHelper,
                 StringProperty=lambda **_:None,EnumProperty=lambda **_:None,BoolProperty=lambda **_:None,
                 alloy=lambda *_:('AG925',10.36))
        exec(compile(ast.Module(body=nodes,type_ignores=[]),'csv-export','exec'),env)
        obj=types.SimpleNamespace(name='Stacked ring')
        report=dict(objects=[env['report_object'](ctx,obj,d)],mm_per_blender_unit=1.)
        env['build_report']=lambda *_:report
        with tempfile.TemporaryDirectory() as folder:
            op=env['JG_OT_export'](); op.filepath=str(pathlib.Path(folder)/'ring.csv'); op.format='CSV'; op.batch=False
            self.assertEqual(op.execute(ctx),{'FINISHED'})
            with open(op.filepath,encoding='utf-8-sig') as handle: row=next(csv.DictReader(handle))
            self.assertAlmostEqual(float(row['body_height_mm']),22.)
            self.assertAlmostEqual(float(row['world_y_mm']),30.3)
            self.assertEqual(len(json.loads(row['top_tiers_json'])),2)

    def test_small_viewport_does_not_drop_entire_height_dashboard(self):
        p,d=measured(*stacked()); d.update(object_name='Stacked ring',factor=1.)
        previous=sys.modules.get('blf')
        sys.modules['blf']=types.SimpleNamespace(size=lambda *_:None,dimensions=lambda _,text:(len(text)*7,14))
        try:
            env,calls=functions()
            rectangles=env['draw_dashboard'](context(False,width=310,height=440),d)
            self.assertTrue(rectangles)
            self.assertTrue(any(call[0]=='text' and call[1][0]=='Target' for call in calls))
            self.assertTrue(all(0<=r[0]<r[2]<=310 and 0<=r[1]<r[3]<=440 for r in rectangles))
        finally:
            if previous is None: sys.modules.pop('blf',None)
            else: sys.modules['blf']=previous


if __name__=='__main__': unittest.main(verbosity=2)

import math
import unittest
import numpy as np
from test_geometry import annulus,core
from test_signets_and_guides import bore,guides,signet


def measure(v,t,normal=None):
    result = bore.find(v,t,np.eye(3),normal=normal)
    sec = bore.section(result)
    bore.exact_contours(v,t,sec)
    sec['ring']['axial_span_mm'] = float(np.ptp(v@sec['basis'][2]))
    bore.stations(v,t,sec)
    return sec


class BoreMeasurementTests(unittest.TestCase):
    def test_concave_outside_uses_full_boundary_not_first_radial_hits(self):
        corners=np.array([[-14,-14],[14,-14],[14,14],[7,14],[7,10],[4,10],[4,14],[-14,14]],float)
        outer=np.concatenate([a+(b-a)*np.arange(6)[:,None]/6 for a,b in zip(corners,np.roll(corners,-1,axis=0))])
        count=len(outer); v,t=annulus(segments=count)
        for level in range(3): v[(level*2+1)*count:(level*2+2)*count,:2]=outer
        expected=core.polygon_info(outer)['perimeter']
        sec=measure(v,t,[0,0,1])
        self.assertAlmostEqual(sec['ring']['outer_circumference_mm'],expected,places=6)
        self.assertFalse(sec['ring']['outer_estimated'])
        self.assertGreater(expected,2*math.pi*14)
        # Destroy all shared indices: the same concave contour must still be traced.
        soup=v[t].reshape((-1,3)); faces=np.arange(len(soup)).reshape((-1,3))
        soup+=np.random.default_rng(29).normal(0,.00005,soup.shape)
        messy=measure(soup,faces,[0,0,1])
        self.assertAlmostEqual(messy['ring']['outer_circumference_mm'],expected,delta=.01)
        self.assertTrue(messy['ring']['outer_estimated'])

    def test_missing_bore_patch_still_uses_exact_irregular_outside(self):
        v,t=signet(96); expected=core.select_ring(core.section_loops(v,t,[0,0,0],[0,0,1])[0])[1]['perimeter']
        keep=np.ones(len(t),bool)
        for sector in (10,11):
            keep[sector*12:sector*12+2]=False; keep[sector*12+4:sector*12+6]=False
        sec=measure(v,t[keep],[0,0,1])
        self.assertAlmostEqual(sec['ring']['outer_circumference_mm'],expected,places=6)
        self.assertTrue(sec['ring']['inner_estimated']); self.assertFalse(sec['ring']['outer_estimated'])

    def test_decimated_12_sided_ring_measures_real_polygon(self):
        v,t = annulus(segments=12)
        sec = measure(v,t,[0,0,1])
        self.assertFalse(sec['ring']['estimated'])
        self.assertAlmostEqual(sec['ring']['inner_circumference_mm'],24*9*math.sin(math.pi/12),places=6)
        self.assertTrue(all(abs(p['width_mm']-4.)<.001 for p in sec['shank_stations']))

    def test_broken_unwelded_seams_do_not_prevent_ring_measurement(self):
        v,t = annulus(segments=96)
        rng = np.random.default_rng(74)
        broken = v[t].reshape((-1,3))+rng.normal(0,.0004,(len(t)*3,3))
        faces = np.arange(len(broken)).reshape((-1,3))
        self.assertFalse(core.mesh_metrics(broken,faces)['valid_volume'])
        sec = measure(broken,faces,[0,0,1])
        self.assertTrue(sec['ring']['estimated'])
        self.assertAlmostEqual(sec['ring']['equivalent_inner_diameter_mm'],18.,delta=.025)
        self.assertTrue(all(abs(p['width_mm']-4.)<.01 for p in sec['shank_stations']))

    def test_missing_faces_reconstructs_small_gaps_and_marks_estimate(self):
        v,t = annulus(segments=96)
        # Delete the inner surface triangles from two adjacent angular sectors.
        remove = np.zeros(len(t),dtype=bool)
        for sector in (10,11):
            remove[sector*12:sector*12+2] = True
            remove[sector*12+4:sector*12+6] = True
        t = t[~remove]
        sec = measure(v,t,[0,0,1])
        self.assertAlmostEqual(sec['ring']['equivalent_inner_diameter_mm'],18.,delta=.03)
        self.assertLess(sec['ring']['bore_coverage_percent'],100.)
        self.assertTrue(sec['ring']['estimated'])

    def test_tiny_head_loop_cannot_replace_main_bore(self):
        v,t = signet(128)
        # Destroy topological connectivity of the real band while keeping its
        # surface geometry, then add a tiny closed ring to the decorative top.
        vv = v[t].reshape((-1,3)); tt = np.arange(len(vv)).reshape((-1,3))
        rng = np.random.default_rng(1); vv += rng.normal(0,.00015,vv.shape)
        tiny,tf = annulus(ri=.0008,ro=.0012,height=.002,segments=24)
        tiny += np.array([0.,12.,0.])
        final_v = np.vstack((vv,tiny)); final_t = np.vstack((tt,tf+len(vv)))
        sec = measure(final_v,final_t)
        self.assertGreater(sec['ring']['inner_circumference_mm'],50.)
        self.assertLess(sec['ring']['inner_circumference_mm'],60.)
        self.assertLess(np.linalg.norm(sec['ring']['center']),.02)

    def test_rotated_signet_side_width_excludes_broad_head(self):
        v,t = signet(128)
        a,b = .66,.93
        rx = np.array([[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]])
        ry = np.array([[math.cos(b),0,math.sin(b)],[0,1,0],[-math.sin(b),0,math.cos(b)]])
        rotate = ry@rx; vv = v@rotate.T
        sec = measure(vv,t)
        self.assertGreater(abs(sec['basis'][2]@rotate[:,2]),.999)
        sides = sec['shank_stations'][:2]
        self.assertEqual(len(sides),2)
        self.assertTrue(all(abs(p['width_mm']-4.)<.03 for p in sides))
        self.assertGreater(sec['ring']['axial_span_mm'],7.9)

    def test_reversed_faces_and_duplicate_triangles_still_give_shank_sections(self):
        v,t = annulus(segments=64)
        messy = t.copy(); messy[::3] = messy[::3,::-1]
        messy = np.vstack((messy,messy[::7]))
        sec = measure(v,messy,[0,0,1])
        self.assertAlmostEqual(sec['ring']['equivalent_inner_diameter_mm'],18.,delta=.035)
        self.assertEqual(len(sec['shank_stations']),3)
        self.assertTrue(all(abs(p['thickness_mm']-2.)<.005 for p in sec['shank_stations']))

    def test_large_missing_arc_is_not_silently_invented(self):
        v,t = annulus(segments=96)
        keep = np.array([sector not in range(10,35) for sector in range(96) for _ in range(12)])
        with self.assertRaises(ValueError): measure(v,t[keep],[0,0,1])

    def test_ring_focus_guides_measure_shank_and_respect_box_toggle(self):
        v,t = signet(128); sec = measure(v,t,[0,0,1])
        data = dict(v=v,t=t,metrics=core.mesh_metrics(v,t),section=sec)
        geo = guides.build(data,dict(focus=True,ring=True,diameters=True,bbox=True,plane=True,extremes=True))
        labels = [p['text'] for p in geo['labels']]
        for name in ('Left shank','Right shank','Bottom shank'):
            self.assertTrue(any(text.startswith(name+' thickness\n') for text in labels))
            self.assertTrue(any(text.startswith(name+' max depth\n') for text in labels))
        self.assertFalse(any('Axial span' in text or 'Sampled thickest' in text for text in labels))
        for axis,extent in zip('XYZ',np.ptp(v,axis=0)):
            self.assertIn(f'World {axis}  {extent:.3f} mm',labels)
        hidden=guides.build(data,dict(focus=True,ring=True,diameters=True,bbox=False))
        self.assertFalse(any(label['text'].startswith('World ') for label in hidden['labels']))
        self.assertTrue(any(text.startswith('Inside circumference') for text in labels))
        self.assertTrue(any(text.startswith('Outside circumference') for text in labels))


if __name__ == '__main__': unittest.main(verbosity=2)

"""Analytic geometry regression suite; run with Python + NumPy."""
import importlib.util
import math
import pathlib
import unittest
import numpy as np

root = pathlib.Path(__file__).resolve().parents[1]
core_path = root/'core.py' if (root/'core.py').exists() else root/'jeweler_gauge/core.py'
spec = importlib.util.spec_from_file_location('core', core_path)
core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)


def annulus(ri=9., ro=11., height=4., segments=256, oval=(1., 1.), comfort=0.):
    """Closed band; optional mid-width narrower finger opening."""
    vertices, quads = [], []
    levels = [(-height/2, ri+comfort), (0., ri), (height/2, ri+comfort)]
    for z, inner in levels:
        for radius in (inner, ro):
            for a in np.arange(segments)*2*math.pi/segments:
                vertices.append((radius*math.cos(a)*oval[0], radius*math.sin(a)*oval[1], z))
    def idx(level, side, i): return (level*2+side)*segments+i%segments
    for i in range(segments):
        j = (i+1)%segments
        # outwards orientation: inner surface clockwise, outer counterclockwise.
        for k in range(2):
            quads.append((idx(k, 0, j), idx(k, 0, i), idx(k+1, 0, i), idx(k+1, 0, j)))
            quads.append((idx(k, 1, i), idx(k, 1, j), idx(k+1, 1, j), idx(k+1, 1, i)))
        quads.append((idx(0, 0, i), idx(0, 0, j), idx(0, 1, j), idx(0, 1, i)))
        quads.append((idx(2, 0, j), idx(2, 0, i), idx(2, 1, i), idx(2, 1, j)))
    triangles = []
    for a, b, c, d in quads: triangles.extend(((a, b, c), (a, c, d)))
    return np.array(vertices), np.array(triangles)


def section(v, t, n=(0., 0., 1.), z=0.):
    loops, basis, rejected = core.section_loops(v, t, np.array(n)*z, n)
    pair = core.select_ring(loops)
    assert pair is not None, (len(loops), rejected)
    return core.ring_metrics(*pair, samples=360)


class GeometryTests(unittest.TestCase):
    def test_round_band_perimeters_volume_and_area(self):
        v, t = annulus()
        result = core.mesh_metrics(v, t)
        self.assertTrue(result['valid_volume'])
        self.assertEqual(result['shells'], 1)
        polygon_factor = 256*math.sin(2*math.pi/256)/2
        self.assertAlmostEqual(result['volume_mm3'], polygon_factor*(121-81)*4, places=8)
        r = section(v, t)
        self.assertAlmostEqual(r['inner_circumference_mm'], 2*256*9*math.sin(math.pi/256), places=7)
        self.assertAlmostEqual(r['outer_circumference_mm'], 2*256*11*math.sin(math.pi/256), places=7)
        self.assertAlmostEqual(r['radial_thickness_min_mm'], 2., delta=.0002)
        self.assertAlmostEqual(r['radial_thickness_max_mm'], 2., delta=.0002)
        self.assertAlmostEqual(r['inner_diameter_min_mm'], 18., delta=.002)

    def test_polygon_mesh_is_not_claimed_analytic_circle(self):
        v, t = annulus(segments=12)
        r = section(v, t)
        self.assertLess(r['inner_circumference_mm'], 2*math.pi*9)
        self.assertAlmostEqual(r['inner_circumference_mm'], 24*9*math.sin(math.pi/12), delta=1e-5)

    def test_oval_diameter_and_auto_axis(self):
        v, t = annulus(oval=(1.2, .8))
        r = section(v, t)
        self.assertAlmostEqual(r['inner_diameter_min_mm'], 14.4, delta=.004)
        self.assertAlmostEqual(r['inner_diameter_max_mm'], 21.6, delta=.004)
        self.assertAlmostEqual(r['ovality_mm'], 7.2, delta=.004)
        axis = core.detect_axis(v, t, np.eye(3))
        self.assertGreater(abs(axis[2]), .9999)

    def test_applied_rotation_and_translation(self):
        v, t = annulus()
        # Arbitrary rotation that does not match any world axis.
        a = .74; b = .56
        rx = np.array([[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]])
        ry = np.array([[math.cos(b),0,math.sin(b)],[0,1,0],[-math.sin(b),0,math.cos(b)]])
        matrix = ry@rx
        vv = v@matrix.T+np.array([123., -86., 52.])
        axis = core.detect_axis(vv, t, np.eye(3))
        self.assertGreater(abs(axis@matrix[:, 2]), .99999)
        loops, basis, rejected = core.section_loops(vv, t, vv.mean(axis=0), axis)
        self.assertEqual(rejected, 0)
        r = core.ring_metrics(*core.select_ring(loops))
        self.assertAlmostEqual(r['inner_circumference_mm'], section(v,t)['inner_circumference_mm'], places=7)
        self.assertAlmostEqual(core.mesh_metrics(vv,t)['volume_mm3'], core.mesh_metrics(v,t)['volume_mm3'], places=7)

    def test_inward_normals_and_reflected_transform(self):
        v, t = annulus()
        vv = v*np.array([-2., 1.5, .5])
        self.assertAlmostEqual(core.mesh_metrics(vv,t)['volume_mm3'], core.mesh_metrics(v,t)['volume_mm3']*1.5, places=7)
        self.assertTrue(core.mesh_metrics(v,t[:, ::-1])['valid_volume'])

    def test_broken_mesh_rejects_weight(self):
        v, t = annulus()
        m = core.mesh_metrics(v, t[:-1])
        self.assertFalse(m['valid_volume']); self.assertIsNone(m['volume_mm3'])
        self.assertGreater(m['boundary_edges'], 0)

    def test_flipped_face_and_duplicate_face_rejected(self):
        v, t = annulus()
        bad = t.copy(); bad[0] = bad[0, ::-1]
        self.assertFalse(core.mesh_metrics(v, bad)['valid_volume'])
        bad = np.vstack((t,t[0]))
        self.assertGreater(core.mesh_metrics(v,bad)['nonmanifold_edges'],0)

    def test_comfort_fit_tightest_is_at_middle(self):
        v,t = annulus(comfort=.4)
        mid = section(v,t,z=0.)
        side = section(v,t,z=1.8)
        self.assertLess(mid['inner_circumference_mm'],side['inner_circumference_mm'])
        self.assertAlmostEqual(side['equivalent_inner_diameter_mm']-mid['equivalent_inner_diameter_mm'], .72, delta=.001)

    def test_multiple_shells_flagged(self):
        v,t = annulus()
        vv = np.vstack((v,v+np.array([30.,0,0])))
        tt = np.vstack((t,t+len(v)))
        m = core.mesh_metrics(vv,tt)
        self.assertEqual(m['shells'],2); self.assertTrue(m['warnings'])

    def test_ring_does_not_pair_disjoint_contours(self):
        v,t = annulus()
        vv = np.vstack((v,v+np.array([30.,0,0])))
        tt = np.vstack((t,t+len(v)))
        loops,_,_ = core.section_loops(vv,tt,[0,0,0],[0,0,1])
        h,out = core.select_ring(loops)
        self.assertLess(np.linalg.norm(out['center']-h['center']),.001)
        self.assertAlmostEqual(out['perimeter']/h['perimeter'],11/9,places=7)

    def test_custom_center_outside_bore_rejected(self):
        v,t = annulus()
        loops,_,_ = core.section_loops(v,t,[0,0,0],[0,0,1])
        self.assertIsNone(core.select_ring(loops,[20,20]))

    def test_odd_sample_count_still_measures_opposite_diameter(self):
        v,t = annulus()
        loops,_,_ = core.section_loops(v,t,[0,0,0],[0,0,1])
        r = core.ring_metrics(*core.select_ring(loops), samples=37)
        self.assertAlmostEqual(r['inner_diameter_min_mm'],18.,delta=.002)

    def test_pierced_band_chord_stops_at_first_cutout(self):
        angles = np.arange(360)*2*math.pi/360
        hole = core.polygon_info(np.column_stack((9*np.cos(angles),9*np.sin(angles))))
        out = core.polygon_info(np.column_stack((11*np.cos(angles),11*np.sin(angles))))
        cut = core.polygon_info(np.array([[9.5,-.3],[10.5,-.3],[10.5,.3],[9.5,.3]]))
        r = core.ring_metrics(hole,out,360,boundaries=[hole,out,cut])
        self.assertAlmostEqual(r['radial_thickness'][0],.5,places=7)
        self.assertAlmostEqual(r['radial_thickness'][180],2.,places=7)

    def test_casting_density_units_and_shrinkage(self):
        p = core.casting_plan(1000,19.32,2.,20.,100.)
        self.assertAlmostEqual(p['weight_g'],19.32)
        self.assertAlmostEqual(p['compensation_scale'],1/.98)
        self.assertAlmostEqual(p['casting_charge_estimate_g'],23.184)
        self.assertAlmostEqual(p['metal_cost'],1932.)
        self.assertAlmostEqual(p['compensated_pattern_volume_mm3'],1000/.98**3)


if __name__ == '__main__': unittest.main(verbosity=2)

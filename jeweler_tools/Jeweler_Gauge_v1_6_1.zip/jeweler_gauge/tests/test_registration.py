"""Exercise actual lifecycle functions against simulated restricted Blender API.

No Blender runtime is available here; these mocks specifically reproduce the
reported installation restriction, not all of Blender's registration behavior.
"""
import ast
import pathlib
import types
import unittest
import time


class Restricted:
    def __init__(self): self.accesses = []
    def __getattr__(self, name):
        self.accesses.append(name)
        raise AttributeError(f"'_RestrictData' object has no attribute '{name}'")


class Timers:
    def __init__(self): self.callbacks = {}
    def register(self, callback, **kwargs): self.callbacks[callback] = kwargs
    def unregister(self, callback): del self.callbacks[callback]
    def is_registered(self, callback): return callback in self.callbacks


def lifecycle(background=False):
    root = pathlib.Path(__file__).resolve().parents[1]
    source = root/'__init__.py' if (root/'__init__.py').exists() else root/'jeweler_gauge/__init__.py'
    tree = ast.parse(source.read_text())
    names = {'register', 'unregister', 'on_load', 'deferred_initialize', 'redraw', 'live_timer'}
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    for node in nodes: node.decorator_list = []
    handlers = types.SimpleNamespace(**{name: [] for name in ('depsgraph_update_post','load_post','undo_post','redo_post')})
    registered, draw_handles = [], []
    def draw_add(*args):
        handle = object(); draw_handles.append(handle); return handle
    def draw_remove(handle, region): draw_handles.remove(handle)
    bpy = types.SimpleNamespace(data=Restricted(), context=Restricted(),
        app=types.SimpleNamespace(background=background, timers=Timers(), handlers=handlers),
        types=types.SimpleNamespace(Scene=type('Scene', (), {}), Object=type('Object', (), {}),
              SpaceView3D=types.SimpleNamespace(draw_handler_add=draw_add,draw_handler_remove=draw_remove)),
        utils=types.SimpleNamespace(register_class=registered.append,unregister_class=registered.remove))
    env = dict(bpy=bpy, time=time, _CACHE={}, _DIRTY={}, _HANDLES=[], _MODAL=None, _HOVER=None,
               CLASSES=(object(),object()), JG_Settings=object(), JG_ObjectSettings=object(),
               PointerProperty=lambda **kwargs: object(), depsgraph_changed=lambda *args: None,
               draw_view=lambda: None, draw_pixel=lambda: None)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),env)
    return env, registered, draw_handles


class RegistrationTests(unittest.TestCase):
    def test_register_never_reads_restricted_data_or_context(self):
        for background in (False,True):
            with self.subTest(background=background):
                env,registered,draw_handles = lifecycle(background)
                env['register']()
                self.assertEqual(env['bpy'].data.accesses,[])
                self.assertEqual(env['bpy'].context.accesses,[])
                self.assertEqual(len(registered),2)
                self.assertTrue(env['bpy'].app.timers.is_registered(env['deferred_initialize']))
                env['unregister']()
                self.assertEqual(registered,[])
                self.assertEqual(draw_handles,[])
                self.assertEqual(env['bpy'].app.timers.callbacks,{})

    def test_deferred_init_retries_then_initializes_real_scenes(self):
        env,_,_ = lifecycle()
        env['register']()
        self.assertEqual(env['deferred_initialize'](),.1)
        scene = types.SimpleNamespace(jeweler_gauge=types.SimpleNamespace(target=object()),as_pointer=lambda:42)
        env['bpy'].data = types.SimpleNamespace(scenes=[scene],window_managers=[])
        self.assertIsNone(env['deferred_initialize']())
        self.assertIn(42,env['_DIRTY'])
        env['unregister']()

    def test_live_timer_tolerates_restricted_context(self):
        env,_,_ = lifecycle()
        self.assertEqual(env['live_timer'](),.4)


if __name__ == '__main__': unittest.main(verbosity=2)

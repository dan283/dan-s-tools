"""Front-projection crowns, maximum local depths and coherent visibility."""
import math
import types
import unittest
import numpy as np
from test_geometry import annulus,core
from test_signets_and_guides import bore,silhouette,profile,guides,visibility,data_for
from test_ring_heights import box
from test_bore_lock_and_scale import api,settings,data
from test_dashboard import functions,context


def sweep(cross,segments=64):
    v=np.array([[q*math.cos(a),q*math.sin(a),z] for q,z in cross for a in np.arange(segments)*2*math.pi/segments])
    faces=[]
    for k in range(len(cross)):
        for i in range(segments):
            a=k*segments+i; b=k*segments+(i+1)%segments
            c=((k+1)%len(cross))*segments+i; d=((k+1)%len(cross))*segments+(i+1)%segments
            faces.extend(((a,b,c),(b,d,c)))
    return v,np.asarray(faces)


def front_ring():
    v,t=annulus(segments=64)
    head,faces=box((-6,10.7,5),(6,17,9))
    return np.vstack((v,head)),np.vstack((t,faces+len(v)))


def measurement(v,t,resolution=1024):
    s=settings(); s.ring_view='FRONT'; s.silhouette_resolution=resolution
    d=data(v,t,s); d['metrics']=core.mesh_metrics(d['v'],d['t']); d['object_name']='Front ring'
    d['section']=api()['section_at'](d,s,object())
    return d


def options(s):
    return dict(focus=True,bbox=s.show_bbox,ring=True,inside=s.show_inside,outside=s.show_outside,
                diameters=s.show_diameters,thickness=s.show_shank_thickness,depth=s.show_shank_depth,
                heights=s.show_height_guides,top_depth=s.show_top_depth,body=s.show_body_dimensions,custom_gauge=s.show_custom_gauge)


class FrontAndDepthTests(unittest.TestCase):
    def test_front_includes_connected_head_outside_center_slice(self):
        d=measurement(*front_ring()); sec=d['section']; front=sec['silhouette']
        u,w,n,o=sec['basis']; p=sec['height_profile']
        center=sec['ring']['center']
        outer3=o+front['outer']['points'][:,0,None]*u+front['outer']['points'][:,1,None]*w
        self.assertAlmostEqual(np.max((outer3-p['center'])@p['up']),17.,delta=front['grid_mm']*2)
        self.assertAlmostEqual(sec['ring']['outer_circumference_mm'],2*64*11*math.sin(math.pi/64),delta=.002)
        self.assertGreater(front['ring']['outer_circumference_mm'],sec['ring']['outer_circumference_mm']+4)
        self.assertAlmostEqual(p['crown_total_height_mm'],8.,delta=.04)
        self.assertAlmostEqual(p['round_band_height_mm'],2.,delta=.04)
        self.assertAlmostEqual(p['extra_crown_height_mm'],6.,delta=.04)
        self.assertAlmostEqual(p['crown_total_height_mm'],p['round_band_height_mm']+p['extra_crown_height_mm'],places=9)
        self.assertEqual(p['tiers'],[])

    def test_silhouette_keeps_real_concavity(self):
        v,t=annulus(segments=96)
        for lo,hi in (((-14,8,-3),(4,14,3)),((7,8,-3),(14,14,3))):
            vv,tt=box(lo,hi); t=np.vstack((t,tt+len(v))); v=np.vstack((v,vv))
        d=data_for(v,t); front=silhouette.ring(v,t,d['section'],1024)
        u,w,_,o=d['section']['basis']
        def pt(x,y): q=np.array([x,y,0])-o;return np.array([q@u,q@w])
        self.assertFalse(core.inside(pt(5,12),front['outer']['points']))
        self.assertTrue(core.inside(pt(8,12),front['outer']['points']))

    def test_projection_is_topology_and_winding_independent(self):
        v,t=front_ring(); d=data_for(v,t); good=silhouette.ring(v,t,d['section'],768)
        soup=v[t].reshape((-1,3)); faces=np.arange(len(soup)).reshape((-1,3));faces[::2]=faces[::2,::-1]
        faces=np.vstack((faces,faces[::9]))
        messy=silhouette.ring(soup,faces,d['section'],768)
        self.assertAlmostEqual(good['outer']['perimeter'],messy['outer']['perimeter'],places=7)
        self.assertAlmostEqual(good['hole']['perimeter'],messy['hole']['perimeter'],places=7)

    def test_silhouette_circumferences_converge_and_are_marked_sampled(self):
        v,t=annulus(segments=64);sec=data_for(v,t)['section']
        expected=2*64*11*math.sin(math.pi/64)
        coarse=silhouette.ring(v,t,sec,256);fine=silhouette.ring(v,t,sec,1536)
        self.assertLess(abs(fine['outer']['perimeter']-expected),.08)
        self.assertLess(abs(fine['outer']['perimeter']-expected),abs(coarse['outer']['perimeter']-expected))
        self.assertTrue(fine['estimated'])
        self.assertLess(fine['grid_mm'],coarse['grid_mm'])

    def test_widest_cross_section_replaces_mid_wall_chord(self):
        v,t=sweep([(9,-1),(9,1),(10,2),(10.8,4),(11,2),(11,-2),(10.8,-4),(10,-2)])
        sec=data_for(v,t)['section'];bore.stations(v,t,sec)
        for station in sec['shank_stations']:
            self.assertAlmostEqual(station['width_mm'],8.,delta=.002)
            self.assertAlmostEqual(station['width_radial_mm'],10.8,delta=.002)
            self.assertAlmostEqual(np.linalg.norm(station['width_b']-station['width_a']),8.,delta=.002)
            self.assertFalse(station['depth_section_estimated'])

    def test_maximum_depth_is_same_radial_level_not_global_bbox(self):
        v,t=sweep([(9,-1),(9,1),(10,1),(10.8,4),(11,1),(11,-1),(10.2,-4),(10,-1)])
        sec=data_for(v,t)['section'];bore.stations(v,t,sec)
        self.assertAlmostEqual(np.ptp(v[:,2]),8.)
        for station in sec['shank_stations']:
            self.assertAlmostEqual(station['width_mm'],5.75,delta=.002)
            n=sec['basis'][2];chord=station['width_b']-station['width_a']
            self.assertAlmostEqual(abs(chord@n),np.linalg.norm(chord),places=7)

    def test_maximum_section_depth_follows_applied_rotation(self):
        v,t=sweep([(9,-1),(9,1),(10,2),(10.8,4),(11,2),(11,-2),(10.8,-4),(10,-2)])
        a=.63;rot=np.array([[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]])
        sec=data_for(v@rot.T,t,rot[:,2])['section'];bore.stations(v@rot.T,t,sec)
        self.assertTrue(all(abs(station['width_mm']-8.)<.003 for station in sec['shank_stations']))

    def test_crown_only_means_exactly_three_height_arrows(self):
        d=measurement(*front_ring());s=types.SimpleNamespace();visibility.preset(s,'CROWN')
        geo=guides.build(d,options(s));labels=[p['text'].split('\n')[0] for p in geo['labels']]
        self.assertEqual(set(labels),{'Inside to crown top','Round-band height','Extra crown height'})
        self.assertEqual(len(geo['dimensions']),3)
        for label in geo['labels']:
            dim=next(x for x in geo['dimensions'] if np.allclose((x['a']+x['b'])/2,label['point']))
            value=float(label['text'].split('\n')[1].replace('≈ ','').split()[0])
            self.assertAlmostEqual(value,np.linalg.norm(dim['b']-dim['a']),delta=.001)

    def test_categories_hide_guides_and_hud_together(self):
        d=measurement(*front_ring());env,_=functions();ctx=context();s=ctx.scene.jeweler_gauge
        for preset in ('NONE','CROWN','RING','ALL'):
            visibility.preset(s,preset)
            geo=guides.build(d,options(s));cards=env['dashboard_cards'](ctx,d)
            if preset=='NONE': self.assertFalse(geo['lines']);self.assertFalse(cards)
            if preset=='CROWN':
                rows=[label for _,items,_ in cards for label,_ in items if label not in {'Target','Physical scale'}]
                self.assertEqual(set(rows),{'Inside to crown top','Round-band height','Extra crown height'})
            self.assertFalse(any('Top tier' in x['text'] or 'Top footprint' in x['text'] for x in geo['labels']))
        visibility.preset(s,'RING');s.show_shank_depth=False;s.show_outside=False
        geo=guides.build(d,options(s));cards=env['dashboard_cards'](ctx,d)
        self.assertFalse(any('shank max depth' in x['text'] or 'Outside circumference' in x['text'] for x in geo['labels']))
        self.assertFalse(any('maximum depth' in label or label=='Outside circumference' for _,items,_ in cards for label,_ in items))

    def test_green_depth_arrows_have_matching_individual_readouts(self):
        d=measurement(*front_ring());s=types.SimpleNamespace();visibility.preset(s,'RING')
        geo=guides.build(d,options(s))
        labels=[x for x in geo['labels'] if x['color']==guides.GREEN]
        self.assertEqual(len(labels),4)
        self.assertEqual({x['text'].split('\n')[0] for x in labels},
                         {'Left shank max depth','Right shank max depth','Bottom shank max depth','Top / crown depth'})
        for label in labels:
            dimension=next(x for x in geo['dimensions'] if x['color']==guides.GREEN and
                           np.allclose((x['a']+x['b'])*.5,label['point']))
            shown=float(label['text'].split('\n')[1].replace('≈ ','').split()[0])
            self.assertAlmostEqual(shown,np.linalg.norm(dimension['a']-dimension['b']),delta=.001)
        s.show_top_depth=False
        self.assertFalse(any(x['text'].startswith('Top / crown depth') for x in guides.build(d,options(s))['labels']))

    def test_top_depth_includes_head_outside_the_central_slice(self):
        d=measurement(*front_ring());sec=d['section'];depth=sec['top_depth']
        self.assertIsNotNone(depth)
        self.assertAlmostEqual(depth['width_mm'],11.,delta=.01)
        axis=sec['basis'][2]
        self.assertAlmostEqual(abs((depth['width_b']-depth['width_a'])@axis),depth['width_mm'],places=7)
        self.assertTrue(depth['depth_section_estimated'])
        ctx=context();visibility.preset(ctx.scene.jeweler_gauge,'RING')
        env,_=functions();rows={label:value for _,items,_ in env['dashboard_cards'](ctx,d) for label,value in items}
        self.assertIn('Top / crown depth',rows)

    def test_large_callouts_with_crowded_and_offscreen_anchors_remain_visible(self):
        occupied=[];bounds=(12,1000,18,900)
        anchors=[(500,450)]*12+[(-200,1300),(1400,-300)]
        for anchor in anchors:
            x,y,rect=guides.callout_position(anchor,240,60,bounds,occupied,(20,25))
            self.assertGreaterEqual(x,bounds[0]);self.assertGreaterEqual(y,bounds[2])
            self.assertLessEqual(x+240,bounds[1]);self.assertLessEqual(y+60,bounds[3])
            self.assertFalse(any(rect[0]<r[2] and rect[2]>r[0] and rect[1]<r[3] and rect[3]>r[1] for r in occupied))
            occupied.append(rect)


if __name__=='__main__': unittest.main(verbosity=2)

import ast
import importlib.util
import math
import pathlib
import sys
import types
import unittest
import numpy as np
from test_geometry import annulus, core

root = pathlib.Path(__file__).resolve().parents[1]
addon = root if (root/'core.py').exists() else root/'jeweler_gauge'
package = types.ModuleType('jg_test_geometry'); package.__path__ = [str(addon)]
package.core = core
sys.modules['jg_test_geometry'] = package; sys.modules['jg_test_geometry.core'] = core
spec = importlib.util.spec_from_file_location('jg_test_geometry.guides',addon/'guides.py')
guides = importlib.util.module_from_spec(spec); spec.loader.exec_module(guides)
spec = importlib.util.spec_from_file_location('jg_test_geometry.bore',addon/'bore.py')
bore = importlib.util.module_from_spec(spec); spec.loader.exec_module(bore)
package.bore = bore
sys.modules['jg_test_geometry.bore'] = bore
spec = importlib.util.spec_from_file_location('jg_test_geometry.profile',addon/'profile.py')
profile = importlib.util.module_from_spec(spec); spec.loader.exec_module(profile)
spec = importlib.util.spec_from_file_location('jg_test_geometry.silhouette',addon/'silhouette.py')
silhouette = importlib.util.module_from_spec(spec); spec.loader.exec_module(silhouette)
package.silhouette = silhouette
sys.modules['jg_test_geometry.silhouette'] = silhouette
spec = importlib.util.spec_from_file_location('jg_test_geometry.visibility',addon/'visibility.py')
visibility = importlib.util.module_from_spec(spec); spec.loader.exec_module(visibility)


def signet(segments=1024):
    v,t = annulus(segments=segments)
    for level in range(3):
        ids = np.arange((level*2+1)*segments,(level*2+2)*segments)
        original_y = v[ids,1].copy()
        mask = original_y > 4
        top = ids[mask]
        v[top,1] = np.minimum(11.5,4+(original_y[mask]-4)*2)
        v[top,0] *= 1+.2*(original_y[mask]-4)/7
        v[top,2] *= 1+(original_y[mask]-4)/7
    return v,t


def data_for(v,t,axis=(0,0,1)):
    loops,basis,rejected = core.section_loops(v,t,[0,0,0],axis)
    h,out = core.select_ring(loops)
    r = core.ring_metrics(h,out,boundaries=loops)
    n = basis[2]; r['axial_span_mm'] = float(np.ptp(v@n)); r['actual_slice_fraction'] = .5
    return dict(v=v,t=t,metrics=core.mesh_metrics(v,t),section=dict(hole=h,outer=out,ring=r,basis=basis,contours=loops))


class SignetGuideTests(unittest.TestCase):
    def test_dense_signet_detects_real_circular_bore(self):
        v,t = signet(2048)
        # Apply a rotation: finger axis lies along Y, matching common imported rings.
        rotate = np.array([[1,0,0],[0,0,-1],[0,1,0]])
        v = v@rotate.T
        n = core.detect_axis(v,t,np.eye(3))
        self.assertGreater(abs(n[1]),.99999)
        d = data_for(v,t,n)
        self.assertTrue(d['metrics']['valid_volume'])
        self.assertAlmostEqual(d['section']['ring']['inner_circumference_mm'],2*2048*9*math.sin(math.pi/2048),places=7)
        self.assertGreater(d['section']['ring']['radial_thickness_max_mm'],2.4)

    def test_identical_stl_seams_join_without_moving_vertices(self):
        v,t = signet(256)
        split = v[t].reshape((-1,3)); face_ids = np.arange(len(split)).reshape((-1,3))
        welded,faces,joined = core.weld_exact(split,face_ids)
        self.assertGreater(joined,0)
        self.assertTrue(core.mesh_metrics(welded,faces)['valid_volume'])
        self.assertAlmostEqual(core.mesh_metrics(welded,faces)['volume_mm3'],core.mesh_metrics(v,t)['volume_mm3'],places=7)
        np.testing.assert_array_equal(welded[faces],v[t])

    def test_near_coplanar_dense_sections_do_not_break_contours(self):
        v,t = annulus(segments=2048)
        loops,basis,rejected = core.section_loops(v,t,[0,0,0],[0,0,1])
        self.assertEqual(rejected,0); self.assertEqual(len(loops),2)
        r = core.ring_metrics(*core.select_ring(loops))
        self.assertAlmostEqual(r['inner_circumference_mm'],4096*9*math.sin(math.pi/2048),places=7)

    def test_auto_axis_can_find_bore_outside_bounding_midplane(self):
        v,t = annulus()
        cube = np.array([[x,y,z] for z in (8.,12.) for y in (-.3,.3) for x in (10.,10.6)])
        ct = np.array([[0,3,1],[0,2,3],[4,5,7],[4,7,6],[0,1,5],[0,5,4],
                       [2,6,7],[2,7,3],[0,4,6],[0,6,2],[1,3,7],[1,7,5]])
        vv = np.vstack((v,cube)); tt = np.vstack((t,ct+len(v)))
        axis = core.detect_axis(vv,tt,np.eye(3))
        self.assertGreater(abs(axis[2]),.99999)
        # Exercise the actual Blender wrapper's auto-slice fallback with a minimal scene.
        tree = ast.parse((addon/'__init__.py').read_text())
        nodes = [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'section_at','contour_section'}]
        env = dict(np=np,core=core,bore=bore,profile=profile)
        exec(compile(ast.Module(body=nodes,type_ignores=[]),'section_at','exec'),env)
        s = types.SimpleNamespace(axis='AUTO',slice=.5,slice_offset=0.,center_mode='AUTO',auto_slice=True,samples=360)
        d = dict(v=vv,t=tt,axes=np.eye(3))
        sec = env['section_at'](d,s,types.SimpleNamespace())
        self.assertNotEqual(sec['ring']['actual_slice_fraction'],.5)
        self.assertAlmostEqual(sec['ring']['equivalent_inner_diameter_mm'],18.,delta=.001)
        s.auto_slice = False
        with self.assertRaises(ValueError): env['section_at'](d,s,types.SimpleNamespace())

    def test_dimension_arrows_match_physical_lengths_and_labels(self):
        v,t = annulus()
        d = data_for(v,t)
        geo = guides.build(d,dict(angle=.72,decimals=3,bbox=True,plane=True,ring=True))
        texts = [label['text'] for label in geo['labels']]
        self.assertTrue(any('Inside circumference\n56.547 mm' == text for text in texts))
        self.assertTrue(any('Outside circumference\n69.113 mm' == text for text in texts))
        self.assertTrue(any('Axial span\n4.000 mm' == text for text in texts))
        for axis,expected in zip('XYZ',(22.,22.,4.)):
            label = next(l for l in geo['labels'] if l['text'].startswith('World '+axis))
            dim = next(dim for dim in geo['dimensions'] if np.allclose((dim['a']+dim['b'])/2,label['point']))
            self.assertAlmostEqual(np.linalg.norm(dim['b']-dim['a']),expected,places=7)
        for line in geo['lines']:
            self.assertTrue(np.isfinite(line['points']).all())
            self.assertEqual(len(line['points'])%2,0)

    def test_guide_toggles_and_nonuniform_transform(self):
        v,t = annulus(oval=(1.2,.8)); v[:,2] *= 1.5
        d = data_for(v,t)
        geo = guides.build(d,dict(bbox=True,ring=False,plane=False,extremes=False))
        self.assertEqual(len(geo['dimensions']),3)
        self.assertTrue(all(l['text'].startswith('World ') for l in geo['labels']))
        geo = guides.build(d,dict(bbox=False,ring=True,plane=False))
        labels = [l['text'] for l in geo['labels']]
        self.assertTrue(any(t.startswith('Bore minimum\n14.400') for t in labels))
        self.assertTrue(any(t.startswith('Bore maximum\n21.600') for t in labels))


if __name__ == '__main__': unittest.main(verbosity=2)

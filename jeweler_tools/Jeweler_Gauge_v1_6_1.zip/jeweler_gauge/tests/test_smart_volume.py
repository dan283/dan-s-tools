import ast
import importlib.util
import json
import time
import sys
import types
import unittest
import numpy as np
from test_geometry import core,annulus
from test_signets_and_guides import addon

spec=importlib.util.spec_from_file_location('jg_test_geometry.solid',addon/'solid.py')
solid=importlib.util.module_from_spec(spec); spec.loader.exec_module(solid)


def cube(size=10.,offset=(0,0,0)):
    v=np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],
                [0,0,1],[1,0,1],[1,1,1],[0,1,1]],dtype=float)*size+offset
    t=np.array([[0,2,1],[0,3,2],[4,5,6],[4,6,7],[0,1,5],[0,5,4],
                [1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7]])
    return v,t


class SmartVolumeTests(unittest.TestCase):
    def test_reconstructed_solid_cannot_fill_detected_finger_bore(self):
        from test_bore_measure import measure
        v,t=annulus(segments=64); sec=measure(v,t,[0,0,1])
        solid.verify_bore_void(v,t,sec,.1)
        filled,faces=cube(30.,(-15,-15,-15))
        with self.assertRaisesRegex(ValueError,'filled the finger bore'):
            solid.verify_bore_void(filled,faces,sec,.1)

    def test_measure_cache_and_report_use_estimated_mass_despite_invalid_source(self):
        source=ast.parse((addon/'__init__.py').read_text())
        names={'measure','public_metrics','public_ring','report_object','build_report'}
        nodes=[node for node in source.body if isinstance(node,ast.FunctionDef) and node.name in names]
        v,t=cube(); t=t[2:]; calls=[]
        def backend(context,v,t,resolution): calls.append(resolution); return dict(volume_mm3=1000.)
        obj=types.SimpleNamespace(name='Broken jewelry',modifiers=[])
        settings=types.SimpleNamespace(volume_mode='AUTO',volume_resolution=192,target=obj,mode='OBJECT',
                                       shrink=1.5,allowance=20.,price=0.,currency='HUF',units='MM',probes=[])
        scene=types.SimpleNamespace(jeweler_gauge=settings,as_pointer=lambda:123)
        context=types.SimpleNamespace(scene=scene)
        cache={}
        env=dict(np=np,time=time,core=core,_CACHE=cache,_DIRTY={},_VOLUME_BUSY=False,
                 solid=types.SimpleNamespace(resolve=solid.resolve,blender_voxel=backend),
                 snapshot=lambda context,obj:dict(v=v.copy(),t=t.copy(),object_name=obj.name,object_pointer=42,factor=1.,duplicate_vertices_joined=0),
                 alloy=lambda *args:('AG925',10.36),mm_factor=lambda scene:1.,settings_signature=lambda scene:('test',))
        exec(compile(ast.Module(body=nodes,type_ignores=[]),'measure/report','exec'),env)
        d=env['measure'](context,obj,False); d['settings_signature']=('test',); cache[123]=d
        d2=env['measure'](context,obj,False)
        self.assertEqual(calls,[96,192]); self.assertFalse(d2['metrics']['valid_volume'])
        self.assertEqual(d2['metrics']['volume_mm3'],1000.); self.assertFalse(env['_VOLUME_BUSY'])
        env['current']=lambda context:d
        report=env['build_report'](context)
        self.assertAlmostEqual(report['total_weight_g'],10.36)
        self.assertTrue(report['total_weight_estimated']); json.dumps(report,allow_nan=False)

    def test_closed_mesh_keeps_exact_volume_without_voxel_work(self):
        v,t=annulus(segments=48); m=core.mesh_metrics(v,t)
        r=solid.resolve(m,lambda count:self.fail('Unnecessary reconstruction'),v,t)
        self.assertEqual(r['volume_mm3'],m['volume_mm3']); self.assertFalse(r['volume_estimated'])

    def test_scanline_ring_preserves_finger_opening(self):
        v,t=annulus(segments=96); r=solid.scanline_volume(v,t,128)
        self.assertAlmostEqual(r['volume_mm3'],core.mesh_metrics(v,t)['volume_mm3'],delta=4.)
        self.assertLess(r['volume_mm3'],550.)

    def test_reversed_duplicated_unwelded_triangle_soup(self):
        v,t=cube(); soup=v[t].reshape((-1,3)); faces=np.arange(len(soup)).reshape((-1,3))
        faces[::2]=faces[::2,::-1]; faces=np.vstack((faces,faces[::3]))
        r=solid.scanline_volume(soup,faces,80)
        self.assertAlmostEqual(r['volume_mm3'],1000.,places=7)

    def test_missing_cube_face_uses_two_independent_directions(self):
        v,t=cube(); r=solid.scanline_volume(v,t[2:],80)
        self.assertAlmostEqual(r['volume_mm3'],1000.,places=7)
        self.assertGreater(max(r['odd_columns_percent']),90.)

    def test_small_missing_ring_patch_still_has_supported_volume(self):
        v,t=annulus(segments=96); missing=np.ones(len(t),dtype=bool)
        missing[120:122]=False
        r=solid.scanline_volume(v,t[missing],128)
        self.assertAlmostEqual(r['volume_mm3'],core.mesh_metrics(v,t)['volume_mm3'],delta=5.)

    def test_hollow_enclosed_cavity_remains_void(self):
        a,at=cube(); b,bt=cube(4.,(3,3,3))
        r=solid.scanline_volume(np.vstack((a,b)),np.vstack((at,bt[:,::-1]+len(a))),100)
        self.assertAlmostEqual(r['volume_mm3'],936.,places=6)

    def test_plane_cannot_be_given_invented_solid_volume(self):
        v,t=cube()
        with self.assertRaises(ValueError): solid.scanline_volume(v,t[:2],64)
        planar=v[:4]; faces=t[:2]
        with self.assertRaises(ValueError):
            solid.resolve(core.mesh_metrics(planar,faces),lambda count:self.fail('Planar surface passed to remesher'),planar,faces)

    def test_reconstruction_records_spacing_change_and_keeps_topology_audit(self):
        v,t=cube(); t=t[2:]; m=core.mesh_metrics(v,t); calls=[]
        def reconstruct(count): calls.append(count); return dict(volume_mm3=990. if count==96 else 1000.)
        r=solid.resolve(m,reconstruct,v,t,192)
        self.assertEqual(calls,[96,192]); self.assertTrue(r['volume_estimated'])
        self.assertAlmostEqual(r['volume_refinement_change_percent'],1.)
        self.assertAlmostEqual(r['volume_voxel_mm'],10/192)
        self.assertFalse(m['valid_volume']); self.assertEqual(r['volume_mm3']*10.36/1000,10.36)

    def test_backend_failure_uses_geometry_instead_of_signed_invalid_volume(self):
        v,t=cube(); t=t[2:]; m=core.mesh_metrics(v,t)
        def unavailable(count): raise RuntimeError('Unavailable')
        r=solid.resolve(m,unavailable,v,t,96)
        self.assertEqual(r['volume_method'],'Multi-axis paired-section estimate')
        self.assertAlmostEqual(r['volume_mm3'],1000.,places=7)
        self.assertEqual(r['volume_backend_note'],'Unavailable')

    def test_multiple_closed_shells_require_reconstruction(self):
        v,t=cube(); b,bt=cube(10.,(5,0,0)); vv=np.vstack((v,b)); tt=np.vstack((t,bt+len(v)))
        m=core.mesh_metrics(vv,tt); calls=[]
        def union(count): calls.append(count); return dict(volume_mm3=1500.)
        r=solid.resolve(m,union,vv,tt)
        self.assertEqual(len(calls),2); self.assertEqual(r['volume_mm3'],1500.)

    def test_native_temporary_copy_is_cleaned_on_success_and_error(self):
        original=sys.modules.get('bpy'); v,t=cube(); normalized=v/10.-.5
        for fail in (False,True):
            removed=[]; modifiers=[]
            class Items:
                def __init__(self,data): self.data=data
                def __len__(self): return len(self.data)
                def foreach_get(self,key,target): target[:]=self.data.ravel()
            result=types.SimpleNamespace(vertices=Items(normalized),loop_triangles=Items(t),calc_loop_triangles=lambda:None)
            mesh=types.SimpleNamespace(from_pydata=lambda *args:None,update=lambda:None)
            def new_modifier(*args):
                item=types.SimpleNamespace(); modifiers.append(item); return item
            def to_mesh():
                if fail: raise RuntimeError('Simulated evaluation failure')
                return result
            evaluated=types.SimpleNamespace(to_mesh=to_mesh,to_mesh_clear=lambda:removed.append('evaluated'))
            obj=types.SimpleNamespace(modifiers=types.SimpleNamespace(new=new_modifier),evaluated_get=lambda dep:evaluated)
            sys.modules['bpy']=types.SimpleNamespace(data=types.SimpleNamespace(
                meshes=types.SimpleNamespace(new=lambda name:mesh,remove=lambda mesh:removed.append('mesh')),
                objects=types.SimpleNamespace(new=lambda *args:obj,remove=lambda *args,**kw:removed.append('object'))))
            context=types.SimpleNamespace(scene=types.SimpleNamespace(collection=types.SimpleNamespace(objects=types.SimpleNamespace(link=lambda obj:None))),
                                          evaluated_depsgraph_get=lambda:object())
            try:
                if fail:
                    with self.assertRaises(RuntimeError): solid.blender_voxel(context,v,t,192)
                else: self.assertAlmostEqual(solid.blender_voxel(context,v,t,192)['volume_mm3'],1000.)
                self.assertEqual(removed,['evaluated','object','mesh'])
                self.assertFalse(modifiers[0].use_remove_disconnected)
                self.assertAlmostEqual(modifiers[0].voxel_size,1/192)
            finally:
                if original is None: sys.modules.pop('bpy',None)
                else: sys.modules['bpy']=original


if __name__=='__main__': unittest.main()

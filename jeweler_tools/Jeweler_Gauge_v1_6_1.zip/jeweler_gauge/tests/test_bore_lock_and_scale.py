import ast
import math
import types
import unittest
import numpy as np
from test_geometry import core,annulus
from test_signets_and_guides import bore,guides,addon,signet,profile,silhouette


def api():
    tree=ast.parse((addon/'__init__.py').read_text())
    names={'section_at','contour_section','save_bore_lock','JG_OT_calibrate_bore'}
    nodes=[node for node in tree.body if getattr(node,'name',None) in names]
    class Operator:
        def report(self,*args): pass
    env=dict(np=np,core=core,bore=bore,profile=profile,silhouette=silhouette,Operator=Operator,
             to_mm=lambda data,point:(np.asarray(point)-data['reference'])*data['factor'])
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'bore-lock','exec'),env)
    return env


def settings():
    obj=types.SimpleNamespace(matrix_world=np.eye(4))
    return types.SimpleNamespace(target=obj,axis='AUTO',center_mode='AUTO',slice=.5,slice_offset=0.,samples=360,
                                 auto_slice=True,seam_tolerance=.005,bore_locked=False,lock_object=None,
                                 lock_center=(0,0,0),lock_normal=(0,0,1),known_bore=18.,units='MM',mm_per_unit=1.)


def data(v,t,s,factor=1.):
    matrix=np.asarray(s.target.matrix_world); world=v@matrix[:3,:3].T+matrix[:3,3]
    reference=(world.min(axis=0)+world.max(axis=0))*.5
    axes=[matrix[:3,i]/np.linalg.norm(matrix[:3,i]) for i in range(3)]
    return dict(v=(world-reference)*factor,t=t,axes=axes,reference=reference,factor=factor)


class BoreLockScaleTests(unittest.TestCase):
    def test_outside_refinement_does_not_redefine_noisy_finger_bore(self):
        v,t=annulus(segments=96); soup=v[t].reshape((-1,3))
        soup+=np.random.default_rng(112).normal(0,.0002,soup.shape)
        faces=np.arange(len(soup)).reshape((-1,3))
        sec=bore.section(bore.find(soup,faces,np.eye(3),normal=[0,0,1]))
        inside=sec['ring']['inner_circumference_mm']; center=sec['ring']['center'].copy()
        walls=sec['ring']['radial_thickness'].copy(); points=sec['hole']['points'].copy()
        bore.exact_contours(soup,faces,sec)
        self.assertEqual(sec['ring']['inner_circumference_mm'],inside)
        np.testing.assert_array_equal(sec['ring']['center'],center)
        np.testing.assert_array_equal(sec['hole']['points'],points)
        np.testing.assert_array_equal(sec['ring']['radial_thickness'],walls)
        self.assertAlmostEqual(sec['ring']['outer_circumference_mm'],69.1,delta=.05)

    def test_wrong_unit_setting_does_not_change_which_axis_is_detected(self):
        v,t=signet(64); rotate=np.array([[1,0,0],[0,0,-1],[0,1,0]])
        v=v@rotate.T
        for scale in (.001,1.,1000.):
            with self.subTest(scale=scale):
                env=api(); s=settings(); d=data(v*scale,t,s)
                sec=env['section_at'](d,s,types.SimpleNamespace())
                self.assertGreater(abs(sec['basis'][2][1]),.999)
                self.assertAlmostEqual(sec['ring']['inner_circumference_mm']/scale,56.52596,delta=.05)
                self.assertEqual(bool(sec['ring']['scale_warning']),scale!=1.)
                if scale!=1.: self.assertIsNone(sec['ring']['us_size_estimate'])
                d['section']=sec; d['metrics']=core.mesh_metrics(d['v'],d['t'])
                geo=guides.build(d,dict(focus=True,bbox=True))
                self.assertLess(max(np.abs(line['points']).max() for line in geo['lines'])/scale,35.)

    def test_selected_rim_finds_actual_rotated_bore_center(self):
        theta=np.arange(64)*2*math.pi/64
        points=np.column_stack((9*np.cos(theta),9*np.sin(theta),np.zeros(64)))
        angle=.72; rotate=np.array([[1,0,0],[0,math.cos(angle),-math.sin(angle)],[0,math.sin(angle),math.cos(angle)]])
        center=np.array([7.,-3.,2.]); points=points@rotate.T+center
        fit=bore.selected_bore(points)
        self.assertGreater(abs(fit['normal']@rotate[:,2]),.999999)
        np.testing.assert_allclose(fit['center'],center,atol=1e-8)
        self.assertAlmostEqual(fit['radius'],9.,places=8)

    def test_selected_cylinder_normals_find_axis_even_when_longer_than_diameter(self):
        theta=np.arange(32)*math.pi*2/32
        circle=np.column_stack((9*np.cos(theta),9*np.sin(theta),np.zeros(32)))
        points=np.vstack((circle+[0,0,-20],circle+[0,0,20]))
        normals=np.column_stack((np.cos(theta),np.sin(theta),np.zeros(32)))
        fit=bore.selected_bore(points,normals)
        self.assertGreater(abs(fit['normal'][2]),.999999)

    def test_short_arc_selection_cannot_be_mistaken_for_full_bore(self):
        theta=np.linspace(0,math.pi/3,30)
        points=np.column_stack((9*np.cos(theta),9*np.sin(theta),np.zeros(30)))
        with self.assertRaises(ValueError): bore.selected_bore(points)

    def test_locked_bore_moves_rotates_and_scales_with_object(self):
        v,t=signet(96); env=api(); s=settings(); scene=types.SimpleNamespace(jeweler_gauge=s)
        context=types.SimpleNamespace(scene=scene)
        d=data(v,t,s); sec=env['section_at'](d,s,scene)
        env['save_bore_lock'](context,d,sec)
        angle=.91; rotate=np.array([[math.cos(angle),0,math.sin(angle)],[0,1,0],[-math.sin(angle),0,math.cos(angle)]])
        s.target.matrix_world[:3,:3]=rotate@np.diag([1.,1.,2.])
        s.target.matrix_world[:3,3]=[12.,-43.,17.]
        changed=data(v,t,s); result=env['section_at'](changed,s,scene)
        self.assertTrue(result['ring']['bore_locked'])
        expected=np.linalg.inv(s.target.matrix_world[:3,:3]).T@np.asarray(s.lock_normal)
        expected/=np.linalg.norm(expected)
        self.assertGreater(abs(result['basis'][2]@expected),.999999)
        self.assertAlmostEqual(result['ring']['inner_circumference_mm'],sec['ring']['inner_circumference_mm'],places=6)
        self.assertTrue(all(abs(p['width_mm']-8.)<.01 for p in result['shank_stations'][:2]))

    def test_known_bore_calibration_corrects_mm_metres_and_cubed_mass(self):
        v,t=annulus(segments=96); v*=.001
        env=api(); s=settings(); scene=types.SimpleNamespace(jeweler_gauge=s); context=types.SimpleNamespace(scene=scene)
        def refresh(context):
            factor=s.mm_per_unit if s.units=='CUSTOM' else 1.
            d=data(v,t,s,factor); d['section']=env['section_at'](d,s,scene)
            d['metrics']=core.mesh_metrics(d['v'],d['t']); return d
        env['refresh']=refresh
        before=refresh(context)
        self.assertLess(before['metrics']['volume_mm3'],.000001)
        self.assertEqual(env['JG_OT_calibrate_bore']().execute(context),{'FINISHED'})
        after=refresh(context)
        self.assertTrue(s.bore_locked); self.assertEqual(s.units,'CUSTOM')
        self.assertAlmostEqual(after['section']['ring']['equivalent_inner_diameter_mm'],18.,places=6)
        self.assertGreater(after['metrics']['volume_mm3'],490.)
        mass=after['metrics']['volume_mm3']*10.36/1000
        self.assertGreater(mass,5.); self.assertLess(mass,5.4)
        self.assertIsNone(after['section']['ring']['scale_warning'])


if __name__=='__main__': unittest.main()

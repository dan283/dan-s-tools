"""Dashboard data and narrow-viewport layout tests (text metrics simulated)."""
import ast
import math
import sys
import types
import unittest
import numpy as np
from test_signets_and_guides import addon, data_for, guides,visibility
from test_geometry import annulus, core


def functions():
    tree = ast.parse((addon/'__init__.py').read_text())
    names = {'dashboard_cards','draw_dashboard','visible_view_rect','fit_text'}
    nodes = [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    calls = []
    def gauge(data,angle):
        sec = data['section']; center = sec['ring']['center']; direction = np.array([math.cos(angle),math.sin(angle)])
        ri = core.ray_polygon(center,direction,sec['hole']['points'])[0]
        ro = core.ray_polygon(center,direction,sec['outer']['points'])[0]
        return None,None,ro-ri
    env = dict(core=core,guides=guides,visibility=visibility,math=math,_DIRTY={},alloy=lambda scene,obj:('AG925',10.36),
               radial_gauge=gauge,screen_rect=lambda *args:calls.append(('rect',args)),
               screen_text=lambda *args:calls.append(('text',args)))
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'dashboard','exec'),env)
    return env,calls


def context(full=False,width=1200,height=1000):
    s = types.SimpleNamespace(decimals=3,angle=.72,minimum_wall=.8,probes=[],hud_detail=full,
            show_comparisons=True,show_casting=True,shrink=1.5,allowance=20.,price=100.,currency='HUF',
            target_circ=56.,font_size=13,target=object(),show_quality=True)
    scene = types.SimpleNamespace(jeweler_gauge=s,as_pointer=lambda:123)
    return types.SimpleNamespace(scene=scene,region=types.SimpleNamespace(x=0,width=width,height=height),area=types.SimpleNamespace(regions=[]))


def data():
    v,t = annulus()
    d = data_for(v,t); d['object_name'] = 'Known band'; d['factor'] = 1.
    return d


class DashboardTests(unittest.TestCase):
    def test_wrong_scale_never_shows_negative_ring_size(self):
        env,_=functions(); d=data()
        d['section']['ring'].update(scale_warning='Verify scale',us_size_estimate=None)
        for full in (False,True):
            cards=env['dashboard_cards'](context(full),d)
            rows={key:value for _,items,_ in cards for key,value in items}
            self.assertIn('Scale check',rows)
            self.assertNotIn('US size estimate',rows); self.assertNotIn('EU circumference size',rows)

    def test_reconstructed_volume_and_mass_have_visible_quality_readouts(self):
        env,_=functions(); d=data()
        d['metrics'].update(volume_estimated=True,volume_method='Voxel solid reconstruction',
                            volume_voxel_mm=.1,volume_refinement_change_percent=1.2,volume_confidence='Stable estimate')
        for full in (False,True):
            cards=env['dashboard_cards'](context(full),d)
            rows={key:value for _,items,_ in cards for key,value in items}
            self.assertTrue(rows['Volume'].startswith('≈ ')); self.assertTrue(rows['Weight estimate'].startswith('≈ '))
            self.assertEqual(rows['Volume refinement change'],'1.200 %')
            self.assertEqual(rows['Volume quality'],'Stable estimate')

    def test_full_dashboard_includes_actual_measurements_and_materials(self):
        env,_ = functions(); d = data(); cards = env['dashboard_cards'](context(True),d)
        rows = {key:value for _,items,_ in cards for key,value in items}
        self.assertEqual(rows['Inside circumference'],'56.547 mm')
        self.assertEqual(rows['Outside circumference'],'69.113 mm')
        self.assertEqual(rows['Volume'],'502.604 mm³')
        self.assertEqual(rows['Weight estimate'],'5.207 g')
        self.assertIn('Pattern oversize factor',rows)
        self.assertIn('Gold 18k yellow',rows)
        self.assertIn('Sterling silver 925',rows)

    def test_compact_mode_preserves_core_measurements(self):
        env,_ = functions(); cards = env['dashboard_cards'](context(False),data())
        self.assertEqual(len(cards),1)
        rows = dict(cards[0][1])
        for key in ('Inside circumference','Outside circumference','Volume','Weight estimate','Bore min / max'):
            self.assertIn(key,rows)
        self.assertNotIn('Measured slice',rows)

    def test_small_viewport_layout_and_truncation_terminate(self):
        previous = sys.modules.get('blf')
        sys.modules['blf'] = types.SimpleNamespace(size=lambda *args:None,dimensions=lambda font,text:(len(text)*7,14))
        try:
            env,calls = functions()
            self.assertEqual(env['fit_text']('some long text',2),'')
            self.assertEqual(env['fit_text']('abc',100),'abc')
            rectangles = env['draw_dashboard'](context(False,width=310,height=800),data())
            self.assertTrue(rectangles)
            self.assertTrue(calls)
            self.assertTrue(all(0 <= r[0] < r[2] <= 310 for r in rectangles))
        finally:
            if previous is None: sys.modules.pop('blf',None)
            else: sys.modules['blf'] = previous


if __name__ == '__main__': unittest.main(verbosity=2)

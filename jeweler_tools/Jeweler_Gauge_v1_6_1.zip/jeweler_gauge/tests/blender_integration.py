"""Run after extracting ZIP: blender --background --python this_file.py.

Not executed in the build environment (Blender unavailable).
This resets scene contents in its process: run on a fresh/background session.
"""
import sys
from pathlib import Path
import math
import tempfile
import json
import bpy

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
# Packaged tests live inside jeweler_gauge/tests; checkout tests beside add-on.
if not (Path(__file__).resolve().parents[2]/'jeweler_gauge').exists():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import jeweler_gauge as jg

jg.register()
try:
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    s = scene.jeweler_gauge
    s.units = 'MM'
    s.show_bbox=True; s.show_body_dimensions=True
    assert bpy.ops.jg.calibration() == {'FINISHED'}
    d = jg.refresh(bpy.context)
    assert d and d['metrics']['valid_volume']
    assert abs(d['metrics']['volume_mm3']-502.6043601492) < .001
    assert abs(d['section']['ring']['inner_circumference_mm']-56.5472484206) < .001
    assert abs(jg.radial_gauge(d,.723)[2]-2.) < .001
    geo = jg.guide_geometry(bpy.context,d)
    assert any(l['text'].startswith('Inside circumference') for l in geo['labels'])
    assert len(geo['dimensions']) >= 5
    assert any(l['text'].startswith('Left shank') for l in geo['labels'])
    assert all(any(l['text'].startswith('World '+axis) for l in geo['labels']) for axis in 'XYZ')
    assert len(d['section']['shank_stations']) == 3
    heights=d['section']['height_profile']
    assert not heights['has_raised_top']
    assert abs(heights['body_height_mm']-22.) < .002
    assert abs(heights['crown_band_thickness_mm']-2.) < .002
    assert any(l['text'].startswith('Ring body height') for l in geo['labels'])
    cards = jg.dashboard_cards(bpy.context,d)
    assert cards
    s.hud_detail = True
    assert len(jg.dashboard_cards(bpy.context,d)) >= 4
    # Cast a surface ray onto the outer wall, then test the inward chord.
    tree = jg.get_bvh(d)
    from mathutils import Vector
    hit,normal,face,distance = tree.ray_cast(Vector((15.,.05,.1)),Vector((-1.,0.,0.)))
    chord = jg.wall_ray(d,hit,normal)
    assert chord and abs(chord[2]-2.) < .003
    assert bpy.ops.jg.wall_scan() == {'FINISHED'}
    assert bpy.ops.jg.width_scan() == {'FINISHED'}
    d = jg.current(bpy.context)
    assert 'wall_scan' in d and 'width_scan' in d
    jg.add_probe(bpy.context,d,chord[0],chord[1],chord[2])
    report = jg.build_report(bpy.context)
    json.dumps(report,allow_nan=False)
    assert report['pinned_probes']
    assert abs(report['objects'][0]['ring_heights']['body_height_mm']-22.) < .002
    assert abs(report['total_weight_g']-502.6043601492*10.36/1000) < .0001
    # Scale and modifier evaluation must affect the actual measured volume.
    obj = s.target
    obj.scale = (2.,1.,.5)
    bpy.context.view_layer.update()
    d2 = jg.refresh(bpy.context)
    assert abs(d2['metrics']['volume_mm3']-d['metrics']['volume_mm3']) < .001
    bevel = obj.modifiers.new('Test bevel','BEVEL'); bevel.width = .05; bevel.segments = 2
    bpy.context.view_layer.update()
    d3 = jg.refresh(bpy.context)
    assert d3['metrics']['valid_volume'] and d3['metrics']['volume_mm3'] < d2['metrics']['volume_mm3']
    # Damaged topology should retain the source audit but reconstruct mass.
    obj.modifiers.clear()
    import bmesh
    bm = bmesh.new(); bm.from_mesh(obj.data); bm.faces.ensure_lookup_table()
    bmesh.ops.delete(bm,geom=[bm.faces[0]],context='FACES')
    bm.to_mesh(obj.data); bm.free(); obj.data.update(); bpy.context.view_layer.update()
    d4 = jg.refresh(bpy.context)
    assert not d4['metrics']['valid_volume'] and d4['metrics']['volume_mm3'] is not None
    assert d4['metrics']['volume_estimated']
    assert abs(d4['metrics']['volume_mm3']-d2['metrics']['volume_mm3'])/d2['metrics']['volume_mm3']<.08
    assert not any(o.name.startswith('__JG_volume_') for o in bpy.data.objects)
    reconstructed_report=jg.build_report(bpy.context)
    assert reconstructed_report['total_weight_g'] is not None
    assert reconstructed_report['total_weight_estimated']
    s.volume_mode='EXACT'
    d5=jg.refresh(bpy.context)
    assert d5['metrics']['volume_mm3'] is None
    # New bore lock and known-size calibration on a fresh clean model.
    s.units='MM'
    assert bpy.ops.jg.calibration()=={'FINISHED'}
    clean=s.target
    assert bpy.ops.jg.lock_bore()=={'FINISHED'}
    assert jg.current(bpy.context)['section']['ring']['bore_locked']
    clean.scale=(.001,.001,.001)
    bpy.context.view_layer.update()
    tiny=jg.refresh(bpy.context)
    assert tiny['section']['ring']['scale_warning']
    assert tiny['section']['ring']['us_size_estimate'] is None
    s.known_bore=18.
    assert bpy.ops.jg.calibrate_bore()=={'FINISHED'}
    calibrated=jg.current(bpy.context)
    assert abs(calibrated['section']['ring']['equivalent_inner_diameter_mm']-18.)<.001
    assert calibrated['metrics']['volume_mm3']>490.
    assert not calibrated['section']['ring']['scale_warning']
    assert bpy.ops.jg.unlock_bore()=={'FINISHED'}
    assert bpy.ops.jg.report() == {'FINISHED'}
    print('Jeweler Gauge Blender integration checks passed')
finally:
    jg.unregister()

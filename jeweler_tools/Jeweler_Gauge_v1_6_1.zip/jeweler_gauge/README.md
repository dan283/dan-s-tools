# Jeweler Gauge 1.6.1

1.6.1 makes **Measurements** the first section in the sidebar. Large **Show All / Hide All** buttons and six group switches control **Bore / outlines**, **Shank**, **Crown**, **XYZ / overall**, **Weight / volume**, and **Calipers**. Selected buttons mean that group is visible; **Customize categories** opens individual switches, grouped by purpose. **Ring Essentials** and **3 Crown Heights** give quick presets. Individual category visibility affects guides and the optional measurement table.

The main panel stays compact after measuring. **Selected Measurement Values**, **Physical Scale / Calibration**, **Ring / Crown Setup**, **Alloys, Weight & Casting**, **Thickness, Calipers & Inspection**, **Reports**, **Display Appearance**, and **Mesh Details / Measurement Notes** start collapsed. Mesh warnings and reconstruction paragraphs no longer expand the main panel. Scale is still shown on one line; a scale problem shows a short status and its full detail is available below.

Viewport text defaults to **20 px** (previously 13), adjustable at the top up to **48 px**. On first installation/load of 1.6.1, existing settings smaller than 20 px are raised to 20; larger settings remain. The full viewport dashboard starts off, including for migrated scenes. A small two-line **volume / selected alloy weight** summary stays visible when its category is on. Enable **Dashboard** when you want the complete selected readout table; it keeps your chosen font size instead of shrinking to tiny text.

Each shank thickness gets its own **pink** label; every axial depth arrow gets a separate **green** numeric label at the actual widest chord. The new **Top / crown depth** measures the maximum axial envelope in the radial plane toward the crown, including parts outside the central ring slice. It is an approximate outline depth, not metal wall thickness: separated crown parts can include empty space in this envelope. Its own category is in the Crown group. **3 Crown Heights** still shows exactly the three height measurements. Front/crown direction controls also orient this upper depth measurement.

Callouts search additional screen space when their first position is occupied, and offscreen guide anchors can dock their labels to the visible area. If the screen has insufficient room for all requested labels, the least-overlapping placement is used; hide optional groups or reduce Label size for more room. Numeric depth readouts are no longer silently dropped on a label-placement collision. JSON/CSV exports include the upper cross-section depth separately from the old full top bounding depth.


1.6.0 replaces the crown clutter with **three heights**: **Inside to crown top**, **Round-band height**, and **Extra crown height**. The default **Front silhouette** projects and unions the complete mesh along the detected finger-bore axis; it does not slice through the crown. Internal shelves, engraving and tier boundaries are excluded from the main exterior guide. The hypothetical round exterior is fitted from the silhouette's side/lower shank. The two fitted heights are estimates and retain an adjustable reference plane. Old crown-tier and footprint guide labels are removed.

**Shank maximum depth** now cuts each left/right/bottom shank in its radial/axial plane and finds the widest axial chord over the complete local profile. Its arrow sits at that chord, even when the maximum is near the outside wall. This is neither a wall-midpoint chord nor a bounding depth combining extrema at different radial positions. Open/noisy cross-sections may use a marked approximate envelope.

**Viewport Guides & Labels** provides **Show All**, **Hide All**, **Ring Essentials** and **Crown Only**, plus independent categories for inside/outside circumference, diameters/sizing, shank thickness, maximum depth, the three crown heights, optional body heights, XYZ bounds, volume/material weight, mesh information, probes, advanced diagnostics, notes, alloy comparisons and casting. Categories control both guide geometry and dashboard readouts. Hide All also hides pinned/interactive probes. Checking a category again restores the overlay. XYZ/body dimensions and advanced extras are optional; the clean preset focuses on ring measurements.

Silhouette outlines and circumferences are **sampled estimates**, marked **≈**. **Silhouette resolution** controls grid spacing; finer sampling retains smaller outline features but is not a certified error bound. The method preserves supported concavities rather than taking a convex hull. Disconnected or reversed triangles can contribute without connected topology. If the projected geometry does not support a finger opening, the panel reports the failure and uses the supported measured section instead. **Central section (diagnostic)** remains available. Bore selection, locking, known-diameter scale calibration and volume reconstruction still use their established geometry paths. A projected aperture can differ from a central-section bore, particularly with comfort-fit or axially varying inner surfaces. Front-view reports preserve the original measurements under `ring_section`, include projection method/resolution/grid spacing, and export the three new crown fields. No extra crown tiers are shown, even under Show All.

Earlier versions:

1.5.0 added **ring-body height, total height, raised-top height, crown-band thickness, top footprint width/depth and separate supported top-tier heights**. Plain bands, fused signets and stacked settings use the same finger-bore frame. The top is inspected over the complete evaluated mesh, including features outside the selected ring section. Broad setting/signet planes refine crown direction on rotated or decimated geometry. Side/bottom shank stations follow that direction. These measurements appear in the panel, viewport guides, dashboards and reports; previous circumference, XYZ, volume and alloy-weight measurements are retained.

1.4.0 builds on the 1.2 finger-bore path. Geometric reconstruction now refines only the outside contour: it cannot replace the finger opening, change its center or overwrite the radial wall samples. Bore detection is normalized internally for reliable geometry selection when mm/metre interpretation is wrong; displayed dimensions still obey your explicit physical scale. New tools identify a bore from selected rim/inner-wall geometry, lock its axis/center in object coordinates, and calibrate all measurements from a known round-bore diameter. Implausible physical sizes show a scale warning instead of negative nominal ring sizes. Voxel estimates are rejected if they fill the detected finger opening.

The main panel is explicitly titled **Jeweler Gauge 1.6.1**. A panel titled **Jeweler's Toolkit** belongs to a different add-on; disable its overlay while testing this ZIP to avoid mixing guides and values.

1.3.1 enables the bounding-box outline and labeled world X/Y/Z dimension arrows alongside focused ring guides. The bounding-box toggle now works independently of ring focus. Compact dashboards show X, Y and Z as separate millimetre readouts. Dimensions include the whole evaluated object and its transforms, including the decorative head.

1.3.0 traces irregular and concave outside boundaries geometrically, even when mesh indices are disconnected. The outside contour is measured independently of damaged bore surfaces. Smart volume now keeps exact integration for a valid single shell and automatically reconstructs damaged or multiple-shell geometry on a temporary voxel copy. Volume/weight estimates include a resolution comparison in the viewport and reports. **Refine Volume / Weight** increases resolution without editing your jewelry.

1.2.0 rebuilds ring detection around the main finger opening. It rejects tiny decorative loops, finds circular evidence in geometric sections without requiring connected or consistently oriented faces, and measures local shank width/thickness at the left, right and bottom. The automatic slice is centered in the side shank, rather than the whole object's bounding box. Ring-focus guides hide measurements of the head and whole-object XYZ extents by default.

1.1.0 adds labeled viewport dimension arrows, witness lines, bore diameters, XYZ bounding dimensions, slice/angle guides, thickness extrema, pinned caliper labels and a compact/full measurement dashboard. It also replaces coordinate rounding in contour joining with shared mesh-edge IDs, joins identical seam coordinates for measurement only, and searches alternate bore slices when the bounding midplane misses the opening.

1.0.1 fixes installation with Blender's restricted registration context. Scene initialization now runs after registration through a deferred timer, which is removed if the add-on is disabled before it fires. If the previous installation failed, restart Blender before installing this patched ZIP to clear partially registered classes.

A mesh measurement add-on for Blender 4.2 and later, designed using APIs available in Blender 5.x. No external services or extra Python packages are required; NumPy is bundled with Blender. This is a measuring tool: the measuring operations do not resize, remesh or modify your jewelry.

## Install

1. Keep `Jeweler_Gauge_v1_0.zip` zipped.
2. Open **Edit → Preferences → Add-ons → menu at the upper right → Install from Disk**. Select the ZIP and enable **Jeweler Gauge**. On versions with an **Install…** button, use that button.
3. In the 3D View press **N**, then open the **Jeweler** tab.
4. Select your jewelry and press **Measure Active Object**.
5. Check **Physical scale** before relying on any dimensions or weights.

## Scale is explicit

The default respects **Scene Properties → Units → Unit Scale**. One Blender unit represents `1000 × Unit Scale` millimetres, even if the scene unit display says “None”. Therefore a scene at the default scale treats an 18-unit diameter as 18,000 mm.

If your model was built with an 18-unit diameter to mean 18 mm, choose **1 Blender unit = 1 mm**. This changes measurement interpretation only; it does not alter the scene or geometry. **Custom calibration** accepts any physical millimetres per Blender unit. Object transforms are included, and scale need not be applied.

**Known inner diameter mm → Calibrate Scale From Known Bore** sets mm per Blender unit from a physically known round-bore diameter and the measured equivalent diameter. It updates dimensions, volume (cubed scale), material weights and sizing together, and locks the detected bore. Enter a verified physical diameter, not a desired target size. Check that the guides surround the true finger opening before calibrating. Strongly oval/incorrect-axis profiles cannot use this round-bore calibration; choose a custom scale instead. This calibration is scene-wide and therefore affects every object measured in this scene. It changes no object geometry or transforms.

If an imported metre-based ring is around 0.02 Blender units wide but interpreted as 1 BU = 1 mm, it will display approximately 0.02 mm. Conversely, mm-model coordinates interpreted using default scene scale become thousands of millimetres. The tool flags these likely ×1000 mistakes, keeps the same detected bore under numerical normalization, and asks you to choose the right physical convention or calibrate. It cannot determine a ring's real size from a screenshot alone.

**Create 18 mm Calibration Band** in the Reports panel adds a known ring in your current convention: 18 mm inner diameter, 22 mm outer diameter and 4 mm axial width. At 256 polygon segments, its expected measured inside circumference is about **56.547248 mm**, outside circumference **69.113304 mm**, volume **502.604360 mm³** and radial thickness approximately **2 mm**. Small differences from an ideal circle are real tessellation differences. The button adds a new mesh and leaves existing jewelry alone.

## Ring mode

- **Main finger bore detection** uses robust circle hypotheses, angular evidence and paired inner/outer ray hits in raw triangle cuts. Object/PCA axes, surface-normal axes and normal-pair directions provide candidates for rotated rings. Features with a radius below 9% of the body's largest world extent are rejected as decorative/mesh-scale details. A detected circle must have near-complete radial support and substantial paired wall evidence; one tiny closed loop cannot become the ring bore.
- **Inner and outer circumference** use exact stitched contours when a verified main opening has usable loops. On disconnected/reversed-face triangle meshes, endpoints of the raw section segments are joined geometrically with the configured seam tolerance, duplicate segments ignored, and closed boundaries traced. Corners and concave details count toward the outside perimeter; no circular formula or convex hull replaces them. A complete outside contour is used independently when the inner surface is damaged. Radial profiles remain a fallback for small gaps; these can miss sub-sample details and are marked approximate. The measured outside is the outline at the chosen shank section, not a silhouette of all decorations or an average around every axial slice.
- A damaged mesh can still provide usable bore and shank dimensions. Small angular gaps (up to 24 degrees per gap) may be interpolated and the profile marked approximate with **≈** on its guides. The actual bore/outside coverage is reported. A broad missing arc or insufficient circular evidence is rejected; it cannot be recovered reliably from a screenshot or absent geometry. Outside circumference stays unavailable when no complete outside profile can be supported.
- **Find main finger bore** searches supported circular cross-sections. You can choose local X/Y/Z or the rotated **3D cursor Z** axis if detection is unsuitable. A closed, sufficiently large oval opening can use the exact-contour fallback.
- **Use Selected Bore / Inner Wall:** in Edit Mode, select vertices/edges around a bore rim, or the inner-wall faces, and click the button. The selection must surround most of the bore; a small decorative arc is refused. The selected circle/inner-wall normals establish a trusted axis and center, then measurement is centered in the local side shank. Your selection and original geometry are preserved. Evaluated modifiers still provide the measured surface; heavy deformations can make the source selection unsuitable.
- **Lock Current Bore** fixes the measured axis, center and section in object coordinates. The lock follows object movement, rotation and nonuniform scale, using the inverse-transpose normal transform. It does not attach to deforming vertices: unlock/reselect after reshaping the bore. Axis/automatic-slice controls are disabled while locked; **Slice offset mm** remains available. **Unlock Bore** enables automatic section search again; **Re-detect Main Bore** clears the lock and old axis settings. A new target does not inherit another object's lock.
- **Auto-center slice in shank** finds a supported bore slice, then uses local left/right shank-width centers to place the measuring section. A wider signet head therefore does not define the band-width midpoint. The panel reports the actual measured slice. Dragging the slice control turns automatic search off. The **Measure Active Object** button resets detection for a different ring.
- **Slice through width** moves the cross-section between the object's axial bounding extremes. **Slice offset mm** adds a physical offset. A setting or decoration extending sideways can change this bounding span; place the slice in the shank yourself.
- **Opening center** comes from the detected bore's geometric evidence (or the exact contour fallback). Use the **3D cursor** option to seed the intended opening.
- **Left/right/bottom shank sections** are oriented relative to the broad decorative top, inferred from the outside profile. Their thickness is measured radially between the bore and the first outer material boundary. Their width is measured along the bore axis, at the radial midpoint of that local wall. These are actual local band sections, not the whole signet's width/height.
- The overlay shows the inside contour in cyan, outside contour in amber, local thickness in pink and local width in green. **Show through mesh** controls occlusion.
- **Gauge angle** is continuous and intersects the contour at the requested angle. Angle zero follows the frame's projected world reference axis; on a Z-axis ring it points along world +X. The scan's minimum/maximum use the chosen number of angular samples.
- Radial thickness begins at the finger opening and stops at the first boundary, including intervening cutouts. Ambiguous rays in shapes that are not star-shaped are skipped.
- **Minimum/maximum bore diameter** measure opposite rays through the chosen center. They are center-based diameters, not arbitrary caliper/Feret diameters. **Equivalent bore diameter** is inside perimeter divided by π. **Ovality** is the difference between the largest and smallest measured center-based diameters.
- **EU circumference size** displays the inside circumference in millimetres. **US size estimate** is a nominal linear conversion, shown only for sufficiently round bores. It is an estimate, not a certified chart lookup or finger-fitting recommendation.
- **Scan Ring Across Width** samples the band at several slices and reports the tightest measured inside circumference. Useful for comfort-fit and tapered interiors. This is a sampled estimate and can miss a narrow restriction between slices.
- **Sizing planner** gives a uniform scale factor for a desired inside circumference and predicts weight after scaling. It also shows how much the walls would change. It does not alter your model.

## Viewport guides and dashboard

The viewport overlay is enabled by default after setting a measurement target. Open **Viewport Guides & Labels** in the Jeweler panel to adjust it. **Focus guides on bore and shank** is enabled by default in ring mode, including when upgrading from 1.1.

- Ring-focus callouts label inside/outside circumferences, two bore diameters, and combined thickness/width values at the left, right and bottom shank. Arrows and witness lines are attached to the measured ring surfaces.
- **Bounding box / XYZ dimensions** independently controls a faint box outline and labeled X/Y/Z arrows, in both ring and object mode. It is enabled by default. The box uses world axes and includes the complete evaluated object, including decorations. Head-biased axial span, plane-frame labels, angular zero and top thickness extrema remain hidden in ring-focus mode; disable ring focus to show the older diagnostic guide layout.
- **Custom angle guide** can add a measurement at the chosen gauge angle. It is off by default to keep the shank guides readable.
- Pinned wall/caliper measurements have labeled arrows and retain the word **snapshot** to distinguish them from live geometry readings.
- The **Measurement dashboard** shows the main dimensions, ring data, surface area, volume, alloy and estimated weight. Turn on **Full dashboard / all readouts** to include alloy weight comparisons, density, ring-size estimates, casting/shrinkage/cost plans, resizing predictions, wall/width scans and mesh warnings.
- Dashboard cards and labels use dark backgrounds; callouts try alternate positions to avoid overlapping each other or dashboard cards. Offscreen/fully crowded callouts are omitted. Compact mode leaves more space for guides. In a small viewport the full dashboard reduces its font and reports any omitted rows; widen the viewport or hide optional comparison/casting cards to see the remaining readings.
- Guide categories, font size, decimal precision, guide spacing, pinned-label count and visibility through the mesh are configurable. These are draw overlays, not added curve/text objects; they are intended for the interactive viewport and are not included in a normal render.

For a signet such as the screenshot, use **Measure Active Object**, then **Re-detect Main Bore** to clear any old axis/slice choices. Check the physical scale and leave **Auto-center slice in shank** enabled. A dense mesh may require manual **Refresh Measurements**. The 0.005 mm loop in the screenshot is rejected by the body-relative feature-size guard. Tests reproduce that failure mode by adding a tiny closed head loop to a disconnected/noisy signet band. The exact uploaded mesh was not available, so its topology has not been tested directly.

## Crown and body references

**Ring Sections & Sizing → Crown: three heights** shows the three crown dimensions. The first starts on the finger opening directly beneath the crown and ends at the highest projected geometry. The second ends at the imaginary circular exterior reconstructed from the lower/side shank. The third spans that reference to the crown top; the second plus third equals the first. All three follow the detected crown direction in the bore plane.

For an unusual signet, use **Set crown direction manually** and/or **Body / top split → Manual reference plane**. The plane value is in physical mm above the bore center. The dashed guide identifies the chosen reference. **Whole ring body dimensions** independently enables body/total height. Separate gemstone objects are not included automatically: all contributing parts must belong to the measured evaluated mesh. The add-on cannot infer gemstone versus metal from geometry, so keep stones separate for material-weight planning.

## Probes and thin-wall inspection

**Click Wall Probe:** hover over the target, then click to pin a normal-direction material chord. Multiple clicks pin multiple probes. Middle mouse and the mouse wheel remain available for navigation; Esc/right click finishes. The mesh needs closed edges and consistent face winding. The measured thickness is the first exit along the inward triangle face normal. On slopes or curved details this differs from both radial thickness and the mathematically shortest local wall distance.

**Two-Point Surface Caliper:** click two points on the measurement target to record their straight-line distance. This works on open meshes too. Click more pairs to add more calipers; Esc finishes.

Pinned measurements survive saving the .blend. They are **snapshots**: re-probe after editing, moving or rescaling the geometry or changing physical scale. They do not attach themselves to moving vertices. The report records their source object and both world positions.

**Scan Wall Thickness:** samples triangle surfaces in proportion to face area, casts normal-direction chords and draws those below your **Minimum wall mm** threshold in red. The scan reports measured/missed sample counts. Increasing sample count gives more coverage but takes longer. Thin edges and engraving details may fall between samples; the reported minimum is not a guaranteed minimum for the entire solid. Set a threshold appropriate to your alloy, process and supplier.

## Volume, weight and alloys

The tool measures the evaluated **viewport mesh**, including deformation, subdivision and Boolean modifiers. Curves/text can be measured through their evaluated meshes. For Geometry Nodes, use **Realize Instances** upstream of the final mesh output: unrealized instances are not part of the measured mesh. Render-only modifier settings are not used. Bounding dimensions are world-axis extents.

**Smart automatic** is the default volume method. A closed single shell uses double-precision signed tetrahedral integration with a nearby origin. Identical seam coordinates are joined for measurement only. A damaged mesh or multiple shells instead triggers Blender's voxel remesher on a temporary normalized copy; duplicate/degenerate faces are filtered and inconsistent normals corrected on that copy. The temporary object is removed afterward. The original mesh, modifiers, transforms, selections and density settings are preserved. Reconstruction is intended to measure overlapping shells as a solid rather than sum their overlaps. Deep cavities, self-intersections and ambiguous open geometry need inspection; edge topology alone cannot certify a physical solid.

**Reconstruct solid** forces reconstruction, including for a closed but self-intersecting mesh. **Strict mesh only** retains the original closed-edge/consistent-winding requirement and does not reconstruct defects. The source mesh audit remains separate from reconstructed volume: a damaged mesh can show invalid source topology while supplying an approximate volume and weight. Surface area and probes continue to use the source evaluated geometry.

Reconstruction runs at half the selected **Volume resolution**, then the full resolution (default 192 voxels across the longest physical extent). In ring mode, three unoriented ray tests also check that the reconstructed solid leaves the detected finger-opening center empty. A voxel result that fills it is rejected and the source-section fallback tried. This is a specific bore-preservation guard, not a certification of every cavity or recess. Volume, sampling/voxel spacing, relative change between resolutions, and an estimate-quality label appear in both compact/full dashboards and the weight panel. **Refine Volume / Weight** raises the resolution, up to 512. Small details thinner than the voxel spacing may disappear or merge. The percentage is a convergence indicator, **not a guaranteed error bound**. A stable result can still reflect the wrong interpretation of a large missing surface. Estimates are marked **≈**; verify physical scale and supplier density.

If native voxel reconstruction fails, a NumPy fallback integrates paired triangle intersections on three projected grids. It ignores face orientation, merges duplicated hits, rejects unmatched columns and requires at least two supported directions. It preserves a supported finger opening/cavity rather than filling the bounding box. This fallback can misread overlapping shells and reports that limitation. A plane or geometry with insufficient independent solid evidence remains unavailable. It cannot infer an arbitrary missing solid from absent geometry.

Only the current target's unchanged volume is cached, so changing the bore slice or material need not reconstruct the same object again. Edited geometry, physical scale, volume method or resolution invalidates this cache. Dense reconstruction can pause Blender briefly; use manual refresh for heavy meshes.

`Weight in grams = volume in mm³ × density in g/cm³ ÷ 1000`.

Presets include fine/22k/18k/14k/9k gold, yellow/rose/white gold variants, fine/sterling/935 silver, platinum, palladium, titanium, steel, brass, copper, wax, resin and diamond. **Alloy presets are representative estimates**, especially white gold and platinum alloys. Enter your foundry or alloy supplier's density for more accurate planning. Choosing a preset resets the density; you can edit the density afterward. No composition-based precision is implied by the preset's displayed number.

Use **Use object alloy** on each target to assign its own density. **Exclude from batch metal weight** keeps gemstones and display helpers out of the selected-objects report. It does not prevent inspection of that object by itself. A fused mesh containing both stones and metal cannot be separated by the tool's density calculation; keep those as separate objects for mass planning. Blender material slots do not automatically assign physical density.

The comparison table shows the same measured volume in several materials. Fine precious metal content uses the preset fineness; select the appropriate fineness preset when overriding density. **Custom density** has no inferred fineness.

## Casting and costs

- **Linear shrinkage %** gives a suggested pattern oversize factor `1 / (1 − shrinkage)`. This is your process assumption; the add-on does not apply it.
- The compensated pattern volume scales with the cube of that factor.
- **Charge allowance %** adds a manual reserve to the object's finished mass for sprues/buttons/process needs. It is a planning estimate; actual casting-tree mass requires measuring a modeled tree.
- **Alloy price / g** and **Currency** are manual inputs. Metal cost is mass multiplied by the entered alloy price. It excludes labor, gems, taxes and other costs. Batch reports use the same entered price for all alloys, so use separate reports if their prices differ.

## Reports and refresh

Create JSON reports in Blender's Text Editor, or export **CSV/JSON** to disk. The file browser has a **Selected metal objects** option for batches. Reports include volume method, approximation status, grid spacing, refinement change, source topology, weights, densities, scan summaries, pinned probes and scale. Batch JSON flags totals containing reconstructed estimates; a total is unavailable only when an included object has no supported volume. A subtotal of measurable objects is still given. Separate selected objects are summed: union reconstruction operates within each object, not across the batch. Only the target ring receives ring-section data in a batch.

Live measurements are debounced. Mesh edits, target transforms and geometry dependency changes invalidate the readings. Heavy meshes pause automatic refresh; use **Refresh Measurements** after changes. Probes/scans can take time on dense meshes. Existing scan results survive a refresh when geometry and relevant settings remain identical, and are discarded when their underlying geometry changes.

## Validation status

Height-specific checks cover plain/oval/decimated rings, fused signet references, touching and separated stacked tiers, a raised hemisphere, rotated crowns, offset heads outside the main slice, noisy disconnected/reversed triangle meshes, manual overrides, physical-scale invariance, shank alignment, height-guide lengths/toggles, dashboard readouts and JSON report serialization.

Regression tests cover decimated bands, noisy/disconnected seams, missing patches, reversed/duplicated triangles, a rotated signet, rejection of tiny decorative bores, focused guides, concave outside boundaries, outside refinement without altering the finger opening, mm/metre detection invariance, selection-based axes, lock transforms, calibration of cubed volume/weight, rejection of a filled finger bore, hollow volumes, damaged solid estimates, refinement metadata, cache/report integration and temporary-copy cleanup. Registration, native voxel plumbing, calibration operator and text-layout tests simulate Blender APIs. See the packaged `validation.json` for the test count. Python syntax validation passes.

Blender is not available in the build environment. Native voxel reconstruction, add-on registration, interactive clicks, GPU overlays and Blender 5.3 operation have **not been executed in Blender** here. Numerical contour and paired-section volume tests run without Blender. `tests/blender_integration.py` provides a background integration check, including reconstructed mass on a damaged ring, to run in Blender. The calibration button provides a quick in-scene check. This package is intended for Blender 4.2+ / 5.x but should not be treated as runtime-certified.

## References

- Blender evaluated geometry API: https://docs.blender.org/api/current/bpy.types.Object.html
- Blender BVHTree: https://docs.blender.org/api/current/mathutils.bvhtree.html
- Blender voxel remesh modifier: https://docs.blender.org/api/current/bpy.types.RemeshModifier.html
- Blender GPU shaders: https://docs.blender.org/api/current/gpu.shader.html
- GIA ring sizing: https://www.gia.edu/quality-assurance-benchmark/accurate-determination-finger-ring-size
- GIA nominal size chart: https://4cs.gia.edu/en-us/blog/how-to-determine-ring-size-tips-and-ring-size-chart/
- Heraeus pure precious-metal densities: https://www.heraeus-precious-metals.com/dam/jcr%3A95a2a240-d359-4b85-b3ac-875b940ebe71/melting-temperatures-en.pdf
- LBMA example 18k yellow density (equal silver/copper balance): https://www.lbma.org.uk/wonders-of-gold/items/density-of-gold

No changes to your original geometry are required for measuring. Reconstruction creates and removes a temporary copy. The calibration button creates a persistent calibration band.

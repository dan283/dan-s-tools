"""Union of projected triangles; front outlines independent of mesh topology.

Scanline distances locate outline edges at sub-grid positions. This is a sampled
projection, not a convex hull, central section or face-winding calculation.
"""
import numpy as np
from . import core


def merge_intervals(low,high,tolerance=0.):
    order=np.argsort(low); low,high=low[order],high[order]
    maximum=np.maximum.accumulate(high)
    starts=np.r_[0,np.flatnonzero(low[1:]>maximum[:-1]+tolerance)+1]
    return low[starts],np.maximum.reduceat(high,starts)


def projection(vertices,triangles,basis,resolution=768):
    u,w,n,o=basis; v=np.asarray(vertices); t=np.asarray(triangles)
    xy=np.column_stack(((v-o)@u,(v-o)@w)); p=xy[t]
    area=np.abs((p[:,1,0]-p[:,0,0])*(p[:,2,1]-p[:,0,1])-(p[:,1,1]-p[:,0,1])*(p[:,2,0]-p[:,0,0]))
    extent=np.ptp(xy,axis=0); span=float(extent.max())
    if span<=0: raise ValueError('No projected ring extent')
    p=p[area>span*span*1e-14]
    if not len(p): raise ValueError('No supported front-facing projected surfaces')
    step=span/max(128,min(2048,int(resolution)))
    lo=xy.min(axis=0)-step*2.37; hi=xy.max(axis=0)+step*2.37
    xs=np.arange(lo[0],hi[0]+step,step); ys=np.arange(lo[1],hi[1]+step,step)
    field=np.full((len(ys),len(xs)),-step*2,dtype=float)
    lower=p[:,:,1].min(axis=1); upper=p[:,:,1].max(axis=1)
    # Sweep active triangles rather than comparing every face on every row.
    first=np.searchsorted(ys,lower,side='right'); last=np.searchsorted(ys,upper,side='left')
    begins={}; ends={}
    for i,(a,b) in enumerate(zip(first,last)):
        if a<b:
            begins.setdefault(int(a),[]).append(i); ends.setdefault(int(b),[]).append(i)
    active=set()
    for row,y in enumerate(ys):
        active.difference_update(ends.get(row,())); active.update(begins.get(row,()))
        if not active: continue
        q=p[np.fromiter(active,dtype=int)]; a=q; b=np.roll(q,-1,axis=1)
        dy=b[:,:,1]-a[:,:,1]
        crosses=((a[:,:,1]<y)!=(b[:,:,1]<y))&(np.abs(dy)>span*1e-14)
        fraction=np.divide(y-a[:,:,1],dy,out=np.zeros_like(dy),where=crosses)
        hit=a[:,:,0]+fraction*(b[:,:,0]-a[:,:,0])
        left=np.min(np.where(crosses,hit,np.inf),axis=1)
        right=np.max(np.where(crosses,hit,-np.inf),axis=1)
        good=(right-left)>span*1e-13
        if not np.any(good): continue
        left,right=merge_intervals(left[good],right[good],span*1e-12)
        edges=np.column_stack((left,right)).ravel()
        index=np.searchsorted(edges,xs,side='right')
        before=edges[np.clip(index-1,0,len(edges)-1)]; after=edges[np.clip(index,0,len(edges)-1)]
        distance=np.minimum(np.abs(xs-before),np.abs(xs-after))
        field[row]=np.minimum(distance,step*2)*np.where(index%2,1.,-1.)
    loops=trace(field,xs,ys)
    return dict(contours=loops,grid_mm=float(step),resolution=int(resolution),
                estimated=True,method='Front silhouette: sampled union of projected triangles')


def simplify(points,tolerance):
    """Remove sub-grid marching zigzags while retaining genuine corners."""
    p=np.asarray(points)
    first=int(np.argmin(p[:,0])); p=np.roll(p,-first,axis=0)
    opposite=int(np.argmax(np.linalg.norm(p-p[0],axis=1)))
    def arc(q):
        keep={0,len(q)-1}; stack=[(0,len(q)-1)]
        while stack:
            a,b=stack.pop()
            if b-a<2: continue
            delta=q[b]-q[a]; length=float(delta@delta)
            if length<1e-30: distance=np.linalg.norm(q[a+1:b]-q[a],axis=1)
            else:
                f=np.clip((q[a+1:b]-q[a])@delta/length,0.,1.)
                distance=np.linalg.norm(q[a+1:b]-q[a]-f[:,None]*delta,axis=1)
            index=int(np.argmax(distance))+a+1
            if distance[index-a-1]>tolerance:
                keep.add(index); stack.extend(((a,index),(index,b)))
        return q[sorted(keep)]
    left=arc(p[:opposite+1]);right=arc(np.vstack((p[opposite:],p[:1])))
    return np.vstack((left[:-1],right[:-1]))


def trace(field,xs,ys):
    """March zero crossings and join by shared grid-edge IDs, preserving holes."""
    ny,nx=field.shape
    samples=np.stack((field[:-1,:-1],field[:-1,1:],field[1:,1:],field[1:,:-1]),axis=-1)
    code=np.sum((samples>0)*np.array([1,2,4,8]),axis=-1)
    cases={1:((3,0),),2:((0,1),),3:((3,1),),4:((1,2),),6:((0,2),),7:((3,2),),
           8:((2,3),),9:((2,0),),11:((2,1),),12:((1,3),),13:((1,0),),14:((0,3),)}
    locations={}; adjacency={}
    offsets=np.array([[0,0],[1,0],[1,1],[0,1]],float)
    corners=((0,1),(1,2),(3,2),(0,3))
    for case in range(1,15):
        rr,cc=np.nonzero(code==case)
        if not len(rr): continue
        for row,col in zip(rr,cc):
            f=samples[row,col]
            if case in (5,10):
                center=float(f.mean())>0
                pairs=((0,1),(2,3)) if (case==5)==center else ((3,0),(1,2))
            else: pairs=cases[case]
            for ea,eb in pairs:
                ids=[]
                for edge in (ea,eb):
                    a,b=corners[edge]
                    if edge==0: key=int(row*nx+col)
                    elif edge==2: key=int((row+1)*nx+col)
                    elif edge==3: key=int(ny*nx+row*nx+col)
                    else: key=int(ny*nx+row*nx+col+1)
                    if key not in locations:
                        fraction=f[a]/(f[a]-f[b])
                        q=offsets[a]+fraction*(offsets[b]-offsets[a])
                        locations[key]=np.array([xs[col]+q[0]*(xs[1]-xs[0]),ys[row]+q[1]*(ys[1]-ys[0])])
                    ids.append(key)
                a,b=ids; adjacency.setdefault(a,[]).append(b); adjacency.setdefault(b,[]).append(a)
    visited=set(); loops=[]
    for first in adjacency:
        if first in visited or len(adjacency[first])!=2: continue
        path=[]; previous=None; current=first
        for _ in range(len(adjacency)+1):
            if current in visited: break
            visited.add(current); path.append(locations[current])
            neighbors=adjacency[current]
            if len(neighbors)!=2: break
            nxt=neighbors[0] if neighbors[0]!=previous else neighbors[1]
            previous,current=current,nxt
            if current==first:
                if len(path)>=4:
                    points=simplify(path,(xs[1]-xs[0])*.3)
                    if len(points)>=4: loops.append(core.polygon_info(points))
                break
    return loops


def ring(vertices,triangles,sec,resolution=768):
    result=projection(vertices,triangles,sec['basis'],resolution)
    center=sec['ring']['center']; contours=result['contours']
    containing=[c for c in contours if core.inside(center,c['points'])]
    if len(containing)<2: raise ValueError('The projected mesh does not support an open finger-bore silhouette')
    containing.sort(key=lambda c:abs(c['area']))
    hole=containing[0]; outer=containing[-1]
    expected=sec['ring']['equivalent_inner_diameter_mm']*.5
    equivalent=np.sqrt(abs(hole['area'])/np.pi)
    if not .65*expected<equivalent<1.4*expected:
        raise ValueError('Front silhouette opening does not agree with the identified finger bore')
    result.update(hole=hole,outer=outer,basis=sec['basis'],center=center)
    return result

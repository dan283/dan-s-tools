"""Find the main finger bore from geometric cuts, independent of mesh topology.

Fits are feature estimates. Missing geometry is never presented as exact volume.
"""
import math
import numpy as np
from . import core


def segments_at(vertices,triangles,normal,height):
    v,t = np.asarray(vertices),np.asarray(triangles)
    u,w,n = core.frame(normal); o = n*height
    distance = (v-o)@n
    # Move away from coplanar triangle rows without welding/rounding cut points.
    epsilon = max(float(np.max(np.ptp(v,axis=0)))*1e-9,1e-7)
    if np.any(np.abs(distance) < epsilon*.1):
        o = o+n*epsilon*.371; distance = (v-o)@n
    d = distance[t]
    mask = (d.min(axis=1)<0)&(d.max(axis=1)>0)
    tt,dd = t[mask],d[mask]
    if not len(tt): return np.empty((0,2,2)),(u,w,n,o)
    aa,bb = np.array([0,1,2]),np.array([1,2,0])
    crosses = (dd[:,aa]<0)!=(dd[:,bb]<0)
    rows,edges = np.nonzero(crosses)
    a,b = tt[rows,aa[edges]],tt[rows,bb[edges]]
    fraction = distance[a]/(distance[a]-distance[b])
    pp = v[a]+fraction[:,None]*(v[b]-v[a])-o
    xy = np.column_stack((pp@u,pp@w)).reshape((-1,2,2))
    lengths = np.linalg.norm(xy[:,1]-xy[:,0],axis=1)
    return xy[lengths > epsilon*.01],(u,w,n,o)


def sample_segments(segments,count=500):
    lengths = np.linalg.norm(segments[:,1]-segments[:,0],axis=1)
    cumulative = np.cumsum(lengths)
    if not len(cumulative) or cumulative[-1] <= 0: return np.empty((0,2))
    targets = (np.arange(count)+.5)*cumulative[-1]/count
    ids = np.minimum(np.searchsorted(cumulative,targets),len(segments)-1)
    start = np.r_[0.,cumulative[:-1]]
    f = (targets-start[ids])/np.maximum(lengths[ids],1e-30)
    return segments[ids,0]+f[:,None]*(segments[ids,1]-segments[ids,0])


def segment_hits(segments,center,direction,merge=.005):
    a = segments[:,0]-center; edge = segments[:,1]-segments[:,0]
    def cross(x,y): return x[...,0]*y[...,1]-x[...,1]*y[...,0]
    den = cross(direction,edge); mask = np.abs(den)>1e-14
    rr = np.full(len(a),np.inf); ss = np.full(len(a),np.inf)
    rr[mask] = cross(a[mask],edge[mask])/den[mask]
    ss[mask] = cross(a[mask],direction)/den[mask]
    hits = np.sort(rr[mask&(rr>1e-8)&(ss>=-1e-8)&(ss<=1+1e-8)])
    if not len(hits): return np.empty(0)
    # Geometric coincidence tolerance handles overlapping/duplicated cut faces.
    split = np.r_[0,np.flatnonzero(np.diff(hits)>merge)+1,len(hits)]
    return np.array([np.median(hits[a:b]) for a,b in zip(split[:-1],split[1:])])


def circle_models(points,span,preferred=None):
    rng = np.random.default_rng(2081)
    count = 420
    ids = rng.integers(0,len(points),(count,3)); p = points[ids]
    a,b,c = p[:,0],p[:,1],p[:,2]
    ab,ac = b-a,c-a
    den = 2*(ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0])
    good = np.abs(den)>span*span*.003
    a,ab,ac,den = a[good],ab[good],ac[good],den[good]
    q1,q2 = np.sum(ab*ab,axis=1),np.sum(ac*ac,axis=1)
    delta = np.column_stack(((q1*ac[:,1]-q2*ab[:,1])/den,
                            (ab[:,0]*q2-ac[:,0]*q1)/den))
    centers = a+delta; radii = np.linalg.norm(delta,axis=1)
    # Reject decorative/triangulation pinholes relative to the whole jewelry.
    good = (radii>=span*.09)&(radii<=span*.65)
    centers,radii = centers[good],radii[good]
    if preferred is not None:
        centers = np.vstack((centers,np.asarray(preferred)))
        radii = np.r_[radii,np.median(np.linalg.norm(points-preferred,axis=1))]
    if not len(radii): return []
    distance = np.linalg.norm(points[None,:,:]-centers[:,None,:],axis=2)
    tolerance = np.maximum(.008,radii*.025)
    near = np.abs(distance-radii[:,None]) < tolerance[:,None]
    scores = near.sum(axis=1)
    choices = np.argsort(scores)[::-1]
    result = []
    for i in choices:
        if scores[i] < len(points)*.08: break
        center,radius = centers[i],radii[i]
        if any(np.linalg.norm(center-cc)<radius*.03 and abs(radius-rr)<radius*.03 for cc,rr in result): continue
        # Refine against inlier points; topology/winding never enters the fit.
        pp = points[near[i]]
        for _ in range(3):
            matrix = np.column_stack((2*pp[:,0],2*pp[:,1],np.ones(len(pp))))
            fit,*_ = np.linalg.lstsq(matrix,np.sum(pp*pp,axis=1),rcond=None)
            center = fit[:2]; radius = math.sqrt(max(float(fit[2]+center@center),1e-12))
            residual = np.abs(np.linalg.norm(points-center,axis=1)-radius)
            mask = residual < max(.008,radius*.025)
            if np.count_nonzero(mask)<12: break
            pp = points[mask]
        if not span*.09<=radius<=span*.65: continue
        if preferred is not None and np.linalg.norm(center-preferred)>radius*.15: continue
        result.append((center,radius))
        if len(result)>=9: break
    return result


def radial_profile(segments,center,radius,samples=144,merge=.005):
    angles = np.arange(samples)*2*math.pi/samples
    inner,outer = np.full(samples,np.nan),np.full(samples,np.nan)
    for i,theta in enumerate(angles):
        hits = segment_hits(segments,center,np.array([math.cos(theta),math.sin(theta)]),merge)
        # Ignore isolated debris well inside the fitted opening. Do not accept
        # a purported bore unless most rays agree with the circular evidence.
        near = hits[(hits>=radius*.6)&(hits<=radius*1.4)]
        if not len(near): continue
        ri = near[0]
        if abs(ri-radius)>max(.025,radius*.08): continue
        inner[i] = ri
        after = hits[hits>ri+merge]
        if len(after): outer[i] = after[0]
    return angles,inner,outer


def fit_bore(segments,span,preferred=None):
    if len(segments)<12: return None
    points = sample_segments(segments)
    if len(points)<12: return None
    best = None
    for center,radius in circle_models(points,span,preferred):
        angles,inner,outer = radial_profile(segments,center,radius,72)
        valid = np.isfinite(inner); pair = valid & np.isfinite(outer)
        if valid.mean()<.85 or pair.mean()<.65: continue
        radial = inner[valid]
        residual = float(np.median(np.abs(radial-radius)))/radius
        close = float(np.count_nonzero(valid & (np.abs(inner-radius)<radius*.06)))/len(inner)
        if close < .78 or residual>.055: continue
        # Refit the center from first-hit evidence, not the outer envelope.
        pp = center+np.column_stack((np.cos(angles[valid]),np.sin(angles[valid])))*inner[valid,None]
        matrix = np.column_stack((2*pp[:,0],2*pp[:,1],np.ones(len(pp))))
        fit,*_ = np.linalg.lstsq(matrix,np.sum(pp*pp,axis=1),rcond=None)
        center = fit[:2]; radius = math.sqrt(max(float(fit[2]+center@center),1e-12))
        score = valid.mean()*pair.mean()*(radius/span)**.6/(1+residual*40)
        if best is None or score>best['score']:
            best = dict(center=center,radius=radius,score=float(score),relative_fit_error=residual,
                        inner_coverage=float(valid.mean()),wall_coverage=float(pair.mean()))
    return best


def candidate_axes(vertices,triangles,local_axes):
    v,t = np.asarray(vertices),np.asarray(triangles)
    _,pca = np.linalg.eigh(np.cov(v.T))
    candidates = list(local_axes)+[pca[:,i] for i in range(3)]+list(np.eye(3))
    p = v[t]; cross = np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]); area = np.linalg.norm(cross,axis=1)
    valid = area>1e-14; normals = cross[valid]/area[valid,None]; weights = area[valid]
    if len(normals):
        covariance = (normals*weights[:,None]).T@normals/weights.sum()
        _,eig = np.linalg.eigh(covariance); candidates += [eig[:,i] for i in range(3)]
        rng = np.random.default_rng(9107)
        ids = rng.choice(len(normals),(2500,2),p=weights/weights.sum())
        pairs = np.cross(normals[ids[:,0]],normals[ids[:,1]])
        length = np.linalg.norm(pairs,axis=1); pairs = pairs[length>.25]/length[length>.25,None]
        if len(pairs):
            sign = np.sign(pairs[np.arange(len(pairs)),np.argmax(np.abs(pairs),axis=1)])
            pairs *= sign[:,None]
            keys = np.rint(pairs/.14).astype(int)
            unique,inverse,counts = np.unique(keys,axis=0,return_inverse=True,return_counts=True)
            for i in np.argsort(counts)[-5:]: candidates.append(pairs[inverse==i].mean(axis=0))
    result = []
    for n in candidates:
        n = np.asarray(n,dtype=float); length = np.linalg.norm(n)
        if length<1e-12: continue
        n = n/length
        if any(abs(n@other)>.999 for other in result): continue
        result.append(n)
    return result


def find(vertices,triangles,local_axes,slice_fraction=.5,normal=None,auto_slice=True,preferred_world=None,offset_mm=0.):
    """Find geometry in a consistent numerical range, then restore physical units.

    A mistaken mm/metre setting must not change WHICH finger opening is found.
    This normalization changes no displayed units or physical calibration.
    """
    v=np.asarray(vertices); span=float(np.max(np.ptp(v,axis=0)))
    if span<=0: raise ValueError('No measurable ring body')
    scale=30./span if span<1. or span>200. else 1.
    preferred=None if preferred_world is None else np.asarray(preferred_world)*scale
    result=_find(v*scale,triangles,local_axes,slice_fraction,normal,auto_slice,preferred,offset_mm*scale)
    if scale!=1.:
        result['fit']['center']/=scale; result['fit']['radius']/=scale
        result['segments']/=scale
        u,w,n,o=result['basis']; result['basis']=(u,w,n,o/scale)
    return result


def _find(vertices,triangles,local_axes,slice_fraction=.5,normal=None,auto_slice=True,preferred_world=None,offset_mm=0.):
    v = np.asarray(vertices); span = float(np.max(np.ptp(v,axis=0)))
    if span<=0: raise ValueError('No measurable ring body')
    axes = [np.asarray(normal)] if normal is not None else candidate_axes(v,triangles,local_axes)
    best = None
    for n in axes:
        n = n/np.linalg.norm(n); axial = v@n
        fractions = [slice_fraction]
        if auto_slice: fractions += [f for f in (.35,.65,.2,.8,.1,.9) if abs(f-slice_fraction)>1e-8]
        local_best = None
        for fraction in fractions:
            height = float(axial.min()+np.ptp(axial)*fraction+offset_mm)
            segments,basis = segments_at(v,triangles,n,height)
            u,w,_,o = basis
            preferred = None if preferred_world is None else np.array([(preferred_world-o)@u,(preferred_world-o)@w])
            fit = fit_bore(segments,span,preferred)
            if fit is None: continue
            aspect = np.ptp(axial)/(fit['radius']*2)
            score = fit['score']/(1+aspect*aspect*2)
            result = dict(fit=fit,basis=basis,segments=segments,fraction=float(fraction),score=float(score))
            if local_best is None or score>local_best['score']: local_best = result
            # When the center slice gives a well supported circular bore, try
            # other axis candidates rather than recutting every axial fraction.
            if fraction==slice_fraction and fit['inner_coverage']>.98 and fit['wall_coverage']>.9: break
        if local_best and (best is None or local_best['score']>best['score']): best = local_best
    if best is None:
        raise ValueError('No main finger opening with enough circular and wall evidence. Choose the bore axis/3D cursor center; tiny decorative loops are ignored.')
    return best


def fill_small_gaps(values,max_degrees=24):
    values = np.asarray(values).copy(); size = len(values); valid = np.isfinite(values)
    if not valid.any(): return values,False
    runs = 0; maximum = 0
    for flag in np.r_[valid,valid]:
        runs = 0 if flag else runs+1; maximum = max(maximum,runs)
    if maximum*360/size>max_degrees: return values,False
    ids = np.flatnonzero(valid)
    values[~valid] = np.interp(np.flatnonzero(~valid),np.r_[ids-size,ids,ids+size],np.tile(values[valid],3))
    return values,True


def section(result,samples=360,merge=.005):
    fit,basis,segments = result['fit'],result['basis'],result['segments']
    center,radius = fit['center'],fit['radius']
    angles,inner,outer = radial_profile(segments,center,radius,samples,merge)
    measured_inner,measured_outer = inner.copy(),outer.copy()
    inner,inner_ok = fill_small_gaps(inner)
    outer,outer_ok = fill_small_gaps(outer)
    if not inner_ok: raise ValueError('Finger bore has a gap too large to reconstruct reliably at this slice')
    directions = np.column_stack((np.cos(angles),np.sin(angles)))
    hole = core.polygon_info(center+directions*inner[:,None])
    if outer_ok:
        out = core.polygon_info(center+directions*outer[:,None])
        ring = core.ring_metrics(hole,out,samples,center)
    else:
        # Retain real local wall samples even when no complete outside loop exists.
        out = core.polygon_info(center+directions*np.where(np.isfinite(outer),outer,np.maximum(inner,radius*1.1))[:,None])
        ring = core.ring_metrics(hole,out,samples,center)
        ring['outer_circumference_mm'] = None
    thickness = measured_outer-measured_inner
    pairs = [(center+d*ri,center+d*ro) if np.isfinite(ri) and np.isfinite(ro) else None
             for d,ri,ro in zip(directions,measured_inner,measured_outer)]
    valid = thickness[np.isfinite(thickness)&(thickness>0)]
    ring.update(radial_thickness=thickness,endpoints=pairs,center=center,
                radial_thickness_min_mm=float(valid.min()),radial_thickness_max_mm=float(valid.max()),
                radial_thickness_mean_mm=float(valid.mean()),ambiguous_rays=int(np.count_nonzero(~np.isfinite(thickness))),
                fitted_bore_diameter_mm=float(radius*2),fitted_bore_circumference_mm=float(radius*math.pi*2),
                fit_error_percent=float(fit['relative_fit_error']*100),
                bore_coverage_percent=float(np.isfinite(measured_inner).mean()*100),
                outer_coverage_percent=float(np.isfinite(measured_outer).mean()*100),
                estimated=True,
                measurement_method='Topology-independent radial mesh section; small gaps interpolated' if np.any(~np.isfinite(measured_inner)) else 'Topology-independent radial mesh section',
                actual_slice_fraction=result['fraction'],slice_position_mm=float(basis[3]@basis[2]),
                open_contours=0,extra_contours=0)
    return dict(hole=hole,outer=out,ring=ring,basis=basis,contours=[hole,out],
                segments=segments,bore_fit=fit,measured_inner=measured_inner,measured_outer=measured_outer,
                outer_complete=bool(outer_ok),merge_tolerance=merge)


def geometric_loops(segments,tolerance=.005):
    """Join cut endpoints by geometry, retaining concavities and all edges.

    Spatial hashing checks adjacent bins (no rounding-bin seam failure).
    Duplicated edges are ignored; ambiguous branches are refused.
    """
    positions=[]; bins={}; graph={}
    tolerance=max(float(tolerance),1e-9)
    for segment in segments:
        nodes=[]
        for point in segment:
            key=tuple(np.floor(point/tolerance).astype(int)); best=None; distance=tolerance
            for dx in (-1,0,1):
                for dy in (-1,0,1):
                    for node in bins.get((key[0]+dx,key[1]+dy),()):
                        d=float(np.linalg.norm(point-positions[node]))
                        if d<=distance: best=node; distance=d
            if best is None:
                best=len(positions); positions.append(point.copy()); bins.setdefault(key,[]).append(best)
            nodes.append(best)
        a,b=nodes
        if a==b: continue
        graph.setdefault(a,set()).add(b); graph.setdefault(b,set()).add(a)
    loops=[]; visited=set()
    for start in graph:
        if start in visited: continue
        stack=[start]; component=set()
        while stack:
            node=stack.pop()
            if node in component: continue
            component.add(node); stack.extend(graph[node]-component)
        visited.update(component)
        if any(len(graph[node])!=2 for node in component): continue
        order=[]; previous=None; current=start
        while True:
            order.append(current); following=next(node for node in graph[current] if node!=previous)
            previous,current=current,following
            if current==start: break
        if len(order)>=3:
            info=core.polygon_info(np.array([positions[i] for i in order]))
            if info['area']>tolerance*tolerance: loops.append(info)
    return loops


def exact_contours(vertices,triangles,sec):
    """Preserve the 1.2 bore path; refine the outside independently.

    Geometric outside reconstruction never changes the finger opening, its
    center, radial wall samples, or diameter used for sizing/calibration.
    """
    u,w,n,o = sec['basis']; fit = sec['bore_fit']
    loops,basis,rejected = core.section_loops(vertices,triangles,o,n)
    pair = core.select_ring(loops,fit['center'])
    if pair is not None:
        h,out=pair; diameter=h['perimeter']/math.pi
        if .8 < diameter/(fit['radius']*2) < 1.2 and h['area']>fit['radius']**2*2:
            measured=core.ring_metrics(h,out,len(sec['ring']['radial_thickness']),fit['center'],loops)
            extras={key:value for key,value in sec['ring'].items() if key not in measured}
            measured.update(extras,estimated=False,inner_estimated=False,outer_estimated=False,
                            measurement_method='Main bore verified; exact stitched mesh contour')
            sec.update(hole=h,outer=out,contours=loops,ring=measured,basis=basis,outer_complete=True)
    h=sec['hole']; ring=sec['ring']; inner_estimated=ring.get('inner_estimated',ring.get('estimated',True))
    sample=h['points'][::max(1,len(h['points'])//32)]
    def enclosing(contours):
        return [loop for loop in contours if loop['area']>h['area']*1.001 and
                all(core.inside(point,loop['points']) for point in sample)]
    outers=enclosing(loops); outer_geometric=False
    if not outers:
        rebuilt=geometric_loops(sec['segments'],sec.get('merge_tolerance',.005))
        outers=enclosing(rebuilt); outer_geometric=True
    if not outers: return sec
    out=min(outers,key=lambda loop:loop['area'])
    ring.update(outer_circumference_mm=out['perimeter'],estimated=bool(inner_estimated or outer_geometric),
                inner_estimated=bool(inner_estimated),outer_estimated=bool(outer_geometric),
                outer_measurement_method='Geometrically joined mesh boundary' if outer_geometric else 'Exact mesh boundary',
                outer_coverage_percent=100.)
    previous_outer=sec['outer']
    sec['contours']=[out if contour is previous_outer else contour for contour in sec['contours']]
    if not any(contour is out for contour in sec['contours']): sec['contours'].append(out)
    sec.update(outer=out,outer_complete=True)
    return sec


def selected_bore(points,normals=None):
    """Infer the bore axis/center from a selected rim or inner-wall faces."""
    points=np.asarray(points,dtype=float)
    if len(points)<8: raise ValueError('Select at least eight vertices around the bore, or its inner-wall faces')
    centered=points-points.mean(axis=0)
    _,vectors=np.linalg.eigh(np.cov(centered.T))
    candidates=[vectors[:,0]]
    if normals is not None and len(normals)>=4:
        normals=np.asarray(normals,dtype=float)
        normals=normals[np.linalg.norm(normals,axis=1)>1e-10]
        if len(normals)>=4:
            _,axes=np.linalg.eigh(normals.T@normals)
            candidates.insert(0,axes[:,0])
    best=None
    for normal in candidates:
        u,w,n=core.frame(normal); origin=points.mean(axis=0)
        xy=np.column_stack((centered@u,centered@w))
        matrix=np.column_stack((2*xy[:,0],2*xy[:,1],np.ones(len(points))))
        fit,*_=np.linalg.lstsq(matrix,np.sum(xy*xy,axis=1),rcond=None)
        radius=math.sqrt(max(float(fit[2]+fit[:2]@fit[:2]),0))
        if radius<=1e-12: continue
        distance=np.linalg.norm(xy-fit[:2],axis=1)
        residual=float(np.percentile(np.abs(distance-radius),90)/radius)
        angles=np.mod(np.arctan2(xy[:,1]-fit[1],xy[:,0]-fit[0]),math.pi*2)
        covered=len(np.unique(np.floor(angles/(math.pi*2)*12).astype(int)))
        if covered<8 or residual>.1: continue
        result=dict(normal=n,center=origin+u*fit[0]+w*fit[1],radius=radius,residual=residual)
        if best is None or residual<best['residual']: best=result
    if best is None: raise ValueError('Selection does not surround a supported finger bore; select its rim or inner wall')
    return best


def scale_hint(diameter):
    """Diagnose common unit mismatches without assigning an unknown ring size."""
    if diameter is None or not np.isfinite(diameter) or diameter<=0: return None
    if .006<=diameter<=.04:
        return 'Bore is below 0.04 mm. Likely metres interpreted as mm: check Scene units, or calibrate from a known inner diameter.'
    if 6000<=diameter<=40000:
        return 'Bore is above 6000 mm. Likely mm interpreted as metres: choose 1 BU = 1 mm, or calibrate from a known inner diameter.'
    if not 6<=diameter<=40:
        return 'Unusual physical bore size. Verify the bore axis and scale before using ring sizes or weight.'
    return None


def line_hits(vertices,triangles,origin,direction,merge=.005):
    """All unoriented triangle ray hits; tolerates reversed faces/open topology."""
    v,t = np.asarray(vertices),np.asarray(triangles); hits = []
    for start in range(0,len(t),32768):
        p = v[t[start:start+32768]]
        e1,e2 = p[:,1]-p[:,0],p[:,2]-p[:,0]
        h = np.cross(direction,e2); determinant = np.einsum('ij,ij->i',e1,h)
        good = np.abs(determinant)>1e-12
        inv = np.zeros(len(p)); inv[good] = 1/determinant[good]
        q = origin-p[:,0]; uu = inv*np.einsum('ij,ij->i',q,h)
        qq = np.cross(q,e1); vv = inv*(qq@direction); distance = inv*np.einsum('ij,ij->i',e2,qq)
        good &= (uu>=-1e-8)&(vv>=-1e-8)&(uu+vv<=1+1e-8)
        hits.extend(distance[good].tolist())
    hits = np.sort(hits)
    if not len(hits): return np.empty(0)
    split = np.r_[0,np.flatnonzero(np.diff(hits)>merge)+1,len(hits)]
    return np.array([np.median(hits[a:b]) for a,b in zip(split[:-1],split[1:])])


def maximum_section_depth(vertices,triangles,origin,radial,axis,inner,outer,merge=.005,outer_envelope=False):
    """Widest axial chord anywhere in the local radial shank cross-section."""
    tangent=np.cross(axis,radial); tangent/=np.linalg.norm(tangent)
    raw,basis=segments_at(vertices,triangles,tangent,float(origin@tangent))
    if not len(raw): return None
    u,w,_,o=basis; pp=raw.reshape((-1,2)); points=o+pp[:,0,None]*u+pp[:,1,None]*w
    points=points-origin
    cut=np.column_stack((points@radial,points@axis)).reshape((-1,2,2))
    loops=geometric_loops(cut,merge)
    chosen=[loop for loop in loops if core.inside(np.array([(inner+outer)*.5,0.]),loop['points'])]
    estimated=False
    if outer_envelope:
        # Top depth describes the visible envelope at one radial level, across
        # fused or disconnected crown parts. It is not material thickness.
        edges=cut; estimated=True
    elif chosen:
        loop=min(chosen,key=lambda item:abs(item['area']))['points']
        edges=np.stack((loop,np.roll(loop,-1,axis=0)),axis=1)
    else:
        # Open/noisy cuts still support an envelope, but cannot certify which
        # disconnected surface belongs to the same shank component.
        low=inner*.6; high=outer+max((outer-inner)*3,inner*.25)
        good=(cut[:,:,0].min(axis=1)>low)&(cut[:,:,0].max(axis=1)<high)
        edges=cut[good]; estimated=True
    if not len(edges): return None
    values=np.unique(edges[:,:,0].ravel())
    # Between cut vertices all boundary segments are linear, so a maximum
    # occurs at a vertex level. Include mid-levels for open/degenerate cuts.
    values=np.unique(np.r_[values,(values[:-1]+values[1:])*.5])
    if outer_envelope: values=np.unique(np.r_[inner,outer,values[(values>=inner)&(values<=outer)]])
    best=None; width=-1.
    for q in values:
        a,b=edges[:,0],edges[:,1]; delta=b[:,0]-a[:,0]
        crossing=(q>=np.minimum(a[:,0],b[:,0])-merge*.01)&(q<=np.maximum(a[:,0],b[:,0])+merge*.01)
        regular=crossing&(np.abs(delta)>merge*1e-6)
        fraction=np.clip((q-a[regular,0])/delta[regular],0.,1.)
        z=a[regular,1]+fraction*(b[regular,1]-a[regular,1])
        flat=crossing&~regular
        if np.any(flat): z=np.r_[z,edges[flat,:,1].ravel()]
        if len(z)<2: continue
        depth=float(z.max()-z.min())
        if depth>width:
            width=depth; best=(float(q),float(z.min()),float(z.max()))
    if best is None or width<=merge*1e-5: return None
    q,low,high=best
    return dict(width_mm=width,width_a=origin+radial*q+axis*low,width_b=origin+radial*q+axis*high,
                width_radial_mm=q,depth_section_estimated=estimated,
                depth_method='Maximum axial envelope of top radial cross-section' if outer_envelope else 'Maximum axial chord of local radial cross-section')


def stations(vertices,triangles,sec,merge=.005,crown_angle=None):
    r = sec['ring']; u,w,n,o = sec['basis']; center = r['center']
    count = len(r['radial_thickness']); angles = np.arange(count)*math.pi*2/count
    radii = sec.get('measured_outer')
    if radii is None: radii = np.array([np.linalg.norm(pair[1]-center) if pair else np.nan for pair in r['endpoints']])
    directions = np.column_stack((np.cos(angles),np.sin(angles)))
    base = np.nanpercentile(radii,60)
    positive = np.maximum(np.nan_to_num(radii-base,nan=0),0)
    # A single stray triangle/spike must not dictate the decorative-top direction.
    cap = max(float(np.percentile(positive,90)),float(np.nanmedian(radii))*.015)
    excess = np.minimum(positive,cap)**2
    decoration = np.sum(directions*excess[:,None],axis=0)
    if np.linalg.norm(decoration)<max(float(np.nanmedian(radii))**2*.05,1e-9):
        world_up = np.array([0,0,1.]); decoration = np.array([world_up@u,world_up@w])
        if np.linalg.norm(decoration)<.1: decoration = np.array([0.,1.])
    top_angle = math.atan2(decoration[1],decoration[0])
    if crown_angle is not None: top_angle=float(crown_angle)
    result = []
    for title,theta in (('Left shank',top_angle+math.pi*.5),('Right shank',top_angle-math.pi*.5),('Bottom shank',top_angle+math.pi)):
        d = np.array([math.cos(theta),math.sin(theta)])
        if 'segments' in sec:
            hits = segment_hits(sec['segments'],center,d,merge)
            radius = sec['bore_fit']['radius']; after = hits[hits>=radius*.6]
            if len(after)<2: continue
            ri,ro = after[:2]
        else:
            inner,outer = core.ray_polygon(center,d,sec['hole']['points']),core.ray_polygon(center,d,sec['outer']['points'])
            if len(inner)!=1 or len(outer)!=1: continue
            ri,ro = inner[0],outer[0]
        a,b = o+(center+d*ri)[0]*u+(center+d*ri)[1]*w,o+(center+d*ro)[0]*u+(center+d*ro)[1]*w
        middle = (a+b)*.5
        origin=o+center[0]*u+center[1]*w
        depth=maximum_section_depth(vertices,triangles,origin,d[0]*u+d[1]*w,n,ri,ro,merge)
        station=dict(name=title,angle=float(theta),thickness_mm=float(ro-ri),width_mm=None,
                     inner=a,outer=b,width_a=None,width_b=None,center=middle)
        if depth: station.update(depth)
        result.append(station)
    sec['shank_stations'] = result; sec['top_angle'] = float(top_angle)
    direction=np.array([math.cos(top_angle),math.sin(top_angle)])
    radial=direction[0]*u+direction[1]*w
    origin=o+center[0]*u+center[1]*w
    inner_hits=core.ray_polygon(center,direction,sec['hole']['points'])
    inner=float(inner_hits[0]) if len(inner_hits) else float(r['equivalent_inner_diameter_mm'])*.5
    outer=float(np.max((np.asarray(vertices)-origin)@radial))
    top_depth=maximum_section_depth(vertices,triangles,origin,radial,n,inner,outer,merge,outer_envelope=True)
    sec['top_depth']=dict(top_depth,name='Top / crown depth') if top_depth else None
    return result

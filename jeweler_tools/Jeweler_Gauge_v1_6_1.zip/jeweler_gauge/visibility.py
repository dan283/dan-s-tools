"""Meaningful viewport categories shared by guides, HUD and presets."""
CATEGORIES=(
    ('show_inside','Inside circumference','Opening outline and circumference'),
    ('show_outside','Outside circumference','Front exterior outline and circumference'),
    ('show_diameters','Bore diameters / ring size','Bore diameter arrows and sizing readouts'),
    ('show_shank_thickness','Shank thickness','Left, right and bottom radial wall thickness'),
    ('show_shank_depth','Shank maximum depth','Widest axial chord of each local radial cross-section'),
    ('show_height_guides','Crown: three heights','Inside to top, hypothetical round band, and extra crown'),
    ('show_top_depth','Top / crown depth','Maximum axial depth through the top radial cross-section'),
    ('show_body_dimensions','Whole ring body dimensions','Body and total height; separate from the three crown heights'),
    ('show_bbox','World XYZ bounding box','World-axis extents of the complete object'),
    ('show_volume','Volume / material weight','Volume, density, mass and reconstruction quality'),
    ('show_surface','Surface / mesh information','Surface area and evaluated triangle counts'),
    ('show_probes','Pinned calipers / wall probes','Pinned snapshots and interactive probe guides'),
    ('show_diagnostics','Advanced section diagnostics','Slice, radial extrema and scan summaries'),
    ('show_quality','Measurement notes','Source mesh audit, scale checks and detection information'),
    ('show_comparisons','Other alloy weights','Same volume in other materials'),
    ('show_casting','Casting / resizing planner','Shrinkage, charge, cost and resizing assumptions'),
    ('show_custom_gauge','Custom radial angle','Additional radial thickness at your chosen angle'),
)
DEFAULT_ON={'show_inside','show_outside','show_diameters','show_shank_thickness','show_shank_depth',
            'show_height_guides','show_top_depth','show_volume','show_probes'}

GROUPS=(
    ('BORE','Bore / outlines',('show_inside','show_outside','show_diameters')),
    ('SHANK','Shank',('show_shank_thickness','show_shank_depth')),
    ('CROWN','Crown',('show_height_guides','show_top_depth')),
    ('SIZE','XYZ / overall',('show_bbox','show_body_dimensions')),
    ('MASS','Weight / volume',('show_volume',)),
    ('PROBES','Calipers',('show_probes',)),
)


def toggle_group(settings,group):
    props=next(props for key,_,props in GROUPS if key==group)
    value=not any(enabled(settings,p) for p in props)
    for prop in props: setattr(settings,prop,value)
    settings.overlay=any(enabled(settings,p) for p,_,_ in CATEGORIES)


def view_data(data):
    sec=data.get('section') or {}; front=sec.get('silhouette')
    if not front: return data
    return dict(data,section=dict(sec,hole=front['hole'],outer=front['outer'],ring=front['ring'],
                contours=front['contours'],outer_complete=True))


def enabled(settings,name):
    return bool(getattr(settings,name,name in DEFAULT_ON))


def preset(settings,name):
    on=set() if name=='NONE' else {p for p,_,_ in CATEGORIES} if name=='ALL' else DEFAULT_ON if name=='RING' else {'show_height_guides'}
    for prop,_,_ in CATEGORIES: setattr(settings,prop,prop in on)
    settings.overlay=name!='NONE'
    settings.hud_detail=name=='ALL'


def row_category(label):
    if label.startswith('World '): return 'show_bbox'
    if label.startswith(('Inside circumference','Front inside')): return 'show_inside'
    if label.startswith(('Outside circumference','Front outside')): return 'show_outside'
    if label.startswith(('Inside to crown top','Round-band height','Extra crown height')): return 'show_height_guides'
    if label.startswith('Top / crown depth'): return 'show_top_depth'
    if label.startswith(('Ring body height','Total height','Body width','Body axial','Top width','Top footprint')): return 'show_body_dimensions'
    if label.startswith(('Crown band thickness','Raised top height','Top tier')): return None
    if label.startswith(('Left shank','Right shank','Bottom shank')):
        return 'show_shank_thickness' if 'thickness' in label else 'show_shank_depth'
    if label.startswith(('Volume','Material','Density','Weight')): return 'show_volume'
    if label.startswith(('Surface area','Mesh')): return 'show_surface' if label!='Mesh notes' else 'show_quality'
    if label.startswith(('Bore min','Bore diameter','Bore across','Bore top','Equivalent bore','Ovality','EU circumference','US size','Sizing')): return 'show_diameters'
    if label.startswith(('Radial wall','At selected angle')): return 'show_custom_gauge'
    if label.startswith(('Axial span','Axial bounding','Radial min','Mean radial','Actual measured','Measured slice','Sampled','Tightest','Minimum wall','Pinned snapshots','Wall scan','Missed wall','Below threshold','Valid width')): return 'show_diagnostics'
    if label.startswith(('Bore detection','Bore axis','Scale check','Body/top reference','Height reference','Skipped','Status')): return 'show_quality'
    if label in {'Target','Physical scale'}: return 'META'
    if label=='All readouts': return None
    return 'show_quality'


def filter_cards(settings,cards):
    if not getattr(settings,'overlay',True) or not any(enabled(settings,p) for p,_,_ in CATEGORIES): return []
    result=[]
    for title,rows,color in cards:
        if title=='SAME VOLUME / OTHER MATERIALS': category='show_comparisons'
        elif title=='CASTING / SIZING PLANNER': category='show_casting'
        elif title=='BORE DETECTION EVIDENCE' or title=='MESH NOTES': category='show_quality'
        else: category=None
        if category:
            if enabled(settings,category): result.append((title,rows,color))
            continue
        rows=[(label,value) for label,value in rows if row_category(label)=='META' or
              (row_category(label) and enabled(settings,row_category(label)))]
        if rows: result.append((title,rows,color))
    return result

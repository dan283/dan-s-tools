"""Morph Snapshot Brush for Blender.

Copyright (C) 2026 Dan Ulrich
SPDX-License-Identifier: GPL-3.0-or-later
"""

bl_info = {
    "name": "Morph Snapshot Brush",
    "author": "Dan Ulrich",
    "version": (1, 4, 0),
    "blender": (4, 3, 0),
    "location": "Sculpt Mode > Toolbar and N-panel > Tool",
    "description": "Paint a stored sculpt state back onto a mesh",
    "category": "Sculpt",
}

import math
import os
import time

import bpy
import gpu
import numpy as np
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup, WorkSpaceTool
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from mathutils.bvhtree import BVHTree


ADDON_PREFIX = "msb"
SNAPSHOT_PREFIX = ".msb_snapshot_"
TOOL_ICON = os.path.join(os.path.dirname(__file__), "icons", "morph_snapshot")
SLOT_ITEMS = (
    ("0", "Snapshot 1", "First stored state"),
    ("1", "Snapshot 2", "Second stored state"),
    ("2", "Snapshot 3", "Third stored state"),
    ("3", "Snapshot 4", "Fourth stored state"),
)

# Preview uploads copy every coordinate and make Blender refresh the mesh even
# when a dab changed only a small patch. Keep the requested bandwidth bounded
# on dense meshes; the exact result is always uploaded when the stroke ends.
PREVIEW_COORDINATE_BUDGET = 120_000_000.0  # bytes/second, before Blender rebuilds
PREVIEW_MIN_HZ = 2.0
PREVIEW_MAX_HZ = 30.0
MAX_DABS_PER_EVENT = 32
_GRID_OFFSET_CACHE = {}
NATIVE_POSITION_ATTRIBUTE = ".sculpt_persistent_co"
NATIVE_NORMAL_ATTRIBUTE = ".sculpt_persistent_no"
NATIVE_DISPLACEMENT_ATTRIBUTE = ".sculpt_persistent_disp"
NATIVE_TARGET_KEY = "msb_native_target"


def _attribute_name(slot):
    return f"{SNAPSHOT_PREFIX}{slot}"


def _count_key(slot):
    return f"msb_snapshot_{slot}_vertex_count"


def _topology_key(slot):
    return f"msb_snapshot_{slot}_topology"


def _revision_key(slot):
    return f"msb_snapshot_{slot}_revision"


def _topology_signature(mesh):
    """Cheap guard against restoring a snapshot to changed topology."""
    return f"{len(mesh.vertices)}:{len(mesh.edges)}:{len(mesh.polygons)}:{len(mesh.loops)}"


def _snapshot_attribute(mesh, slot):
    attribute = mesh.attributes.get(_attribute_name(slot))
    if attribute and attribute.domain == 'POINT' and attribute.data_type == 'FLOAT_VECTOR':
        return attribute
    return None


def _snapshot_is_valid(mesh, slot):
    attribute = _snapshot_attribute(mesh, slot)
    return bool(
        attribute
        and len(attribute.data) == len(mesh.vertices)
        and mesh.get(_count_key(slot), -1) == len(mesh.vertices)
        and mesh.get(_topology_key(slot), "") == _topology_signature(mesh)
    )


def _multires_snapshot_property(slot):
    return f"msb_multires_snapshot_{slot}"


def _multires_snapshot_mesh(obj, slot):
    return getattr(obj, _multires_snapshot_property(slot), None)


def _working_original(obj):
    return getattr(obj, "msb_multires_original", None)


def _object_snapshot_is_valid(obj, slot):
    if _multires_modifier(obj) and not _working_original(obj):
        snapshot = _multires_snapshot_mesh(obj, slot)
        return bool(snapshot and len(snapshot.vertices) > 0)
    return _snapshot_is_valid(obj.data, slot)


def _multires_modifier(obj):
    return next((modifier for modifier in obj.modifiers if modifier.type == 'MULTIRES'), None)


def _validate_mesh_context(context, require_snapshot=True):
    obj = context.object
    if not obj or obj.type != 'MESH':
        return None, "Select a mesh object"
    if context.mode != 'SCULPT':
        return None, "Enter Sculpt Mode first"
    if getattr(obj, "use_dynamic_topology_sculpting", False):
        return None, "Disable Dynamic Topology; a morph snapshot requires unchanged topology"
    if obj.data.shape_keys and obj.active_shape_key_index != 0:
        return None, "Select the Basis shape key before using Morph Snapshot Brush"
    if require_snapshot:
        slot = context.scene.msb_settings.snapshot_slot
        if not _object_snapshot_is_valid(obj, slot):
            return None, "Capture a valid snapshot for the selected slot first"
    return obj, ""


def _read_mesh_coordinates_np(mesh):
    values = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", values)
    return values.reshape((-1, 3))


def _write_mesh_coordinates(obj, values):
    obj.data.vertices.foreach_set("co", values)
    # Mesh.update() already tags the mesh for dependency-graph evaluation and
    # sends a geometry notifier. Object.update_tag(DATA) repeated the expensive
    # invalidation and made dense-mesh previews noticeably less responsive.
    obj.data.update()


def _adaptive_preview_hz(vertex_count):
    """Choose a conservative live-preview rate from coordinate upload size."""
    coordinate_bytes = max(1, int(vertex_count)) * 3 * np.dtype(np.float32).itemsize
    return max(
        PREVIEW_MIN_HZ,
        min(PREVIEW_MAX_HZ, PREVIEW_COORDINATE_BUDGET / coordinate_bytes),
    )


def _grid_neighbor_offsets(reach):
    """Reuse the small grid stencil instead of allocating it for every dab."""
    offsets = _GRID_OFFSET_CACHE.get(reach)
    if offsets is None:
        axis = np.arange(-reach, reach + 1, dtype=np.int64)
        offsets = np.stack(
            np.meshgrid(axis, axis, axis, indexing='ij'), axis=-1
        ).reshape((-1, 3))
        # Avoid retaining unexpectedly large arrays if a huge brush is used.
        if reach <= 8:
            _GRID_OFFSET_CACHE[reach] = offsets
    return offsets


def _read_snapshot_np(mesh, slot):
    attribute = _snapshot_attribute(mesh, slot)
    values = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
    attribute.data.foreach_get("vector", values)
    return values.reshape((-1, 3))


def _store_snapshot_attribute(mesh, slot, coordinates):
    name = _attribute_name(slot)
    old = mesh.attributes.get(name)
    if old:
        mesh.attributes.remove(old)
    attribute = mesh.attributes.new(name=name, type='FLOAT_VECTOR', domain='POINT')
    attribute.data.foreach_set("vector", np.asarray(coordinates, dtype=np.float32).reshape(-1))
    mesh[_count_key(slot)] = len(mesh.vertices)
    mesh[_topology_key(slot)] = _topology_signature(mesh)
    mesh[_revision_key(slot)] = int(mesh.get(_revision_key(slot), 0)) + 1
    if NATIVE_TARGET_KEY in mesh:
        del mesh[NATIVE_TARGET_KEY]
    mesh.update()


def _remove_snapshot_attribute(mesh, slot):
    attribute = mesh.attributes.get(_attribute_name(slot))
    if attribute:
        mesh.attributes.remove(attribute)
    for key in (_count_key(slot), _topology_key(slot), _revision_key(slot)):
        if key in mesh:
            del mesh[key]
    if NATIVE_TARGET_KEY in mesh:
        del mesh[NATIVE_TARGET_KEY]


def _ensure_vector_attribute(mesh, name):
    attribute = mesh.attributes.get(name)
    if attribute and (
        attribute.domain != 'POINT' or attribute.data_type != 'FLOAT_VECTOR'
    ):
        mesh.attributes.remove(attribute)
        attribute = None
    if attribute is None:
        attribute = mesh.attributes.new(name=name, type='FLOAT_VECTOR', domain='POINT')
    return attribute


def _install_native_snapshot_target(mesh, slot):
    """Expose the selected snapshot to Blender's native persistent Layer brush."""
    target_id = (
        f"{slot}:{int(mesh.get(_revision_key(slot), 0))}:"
        f"{_topology_signature(mesh)}"
    )
    position_attribute = mesh.attributes.get(NATIVE_POSITION_ATTRIBUTE)
    normal_attribute = mesh.attributes.get(NATIVE_NORMAL_ATTRIBUTE)
    if (
        mesh.get(NATIVE_TARGET_KEY, "") == target_id
        and position_attribute
        and normal_attribute
        and len(position_attribute.data) == len(mesh.vertices)
        and len(normal_attribute.data) == len(mesh.vertices)
    ):
        return

    snapshot = _snapshot_attribute(mesh, slot)
    if snapshot is None:
        raise RuntimeError("The selected snapshot is missing")

    positions = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
    snapshot.data.foreach_get("vector", positions)
    position_attribute = _ensure_vector_attribute(mesh, NATIVE_POSITION_ATTRIBUTE)
    position_attribute.data.foreach_set("vector", positions)

    # Layer requires the persistent-normal attribute to exist. At zero layer
    # height it is multiplied by zero, so no expensive normal copy is needed.
    _ensure_vector_attribute(mesh, NATIVE_NORMAL_ATTRIBUTE)

    # Reset Layer's per-vertex height history whenever the target changes.
    displacement = mesh.attributes.get(NATIVE_DISPLACEMENT_ATTRIBUTE)
    if displacement:
        mesh.attributes.remove(displacement)

    mesh[NATIVE_TARGET_KEY] = target_id
    mesh.update()


def _activate_native_layer_brush(context):
    sculpt = getattr(context.tool_settings, "sculpt", None)
    brush = getattr(sculpt, "brush", None) if sculpt else None
    if brush and getattr(brush, "sculpt_brush_type", None) == 'LAYER':
        return brush

    # Selecting the Morph tool normally loads Blender's Essentials Layer
    # brush automatically. This fallback also handles add-on hot reloads.
    try:
        bpy.ops.brush.asset_activate(
            asset_library_type='ESSENTIALS',
            asset_library_identifier="",
            relative_asset_identifier=(
                "brushes/essentials_brushes-mesh_sculpt.blend/Brush/Layer"
            ),
        )
    except (AttributeError, RuntimeError, TypeError):
        return None

    brush = getattr(sculpt, "brush", None)
    if brush and getattr(brush, "sculpt_brush_type", None) == 'LAYER':
        return brush
    return None


def _configure_native_layer_brush(context, settings, brush):
    """Mirror the add-on controls onto Blender's native Layer brush."""
    brush.sculpt_brush_type = 'LAYER'
    brush.use_persistent = True
    brush.height = 0.0
    brush.strength = settings.strength
    brush.spacing = max(1, min(1000, int(round(settings.spacing * 100.0))))
    brush.use_frontface = settings.front_faces_only
    brush.use_accumulate = True

    curve_presets = {
        'SMOOTH': 'SMOOTH',
        'SPHERE': 'SPHERE',
        'ROOT': 'ROOT',
        'SHARP': 'SHARP',
        'LINEAR': 'LIN',
        'CONSTANT': 'CONSTANT',
    }
    try:
        brush.curve_preset = curve_presets.get(settings.falloff, 'SMOOTH')
    except (AttributeError, TypeError, ValueError):
        pass

    sculpt = context.tool_settings.sculpt
    for name, value in (
        ("use_symmetry_x", settings.symmetry_x),
        ("use_symmetry_y", settings.symmetry_y),
        ("use_symmetry_z", settings.symmetry_z),
    ):
        if hasattr(sculpt, name):
            setattr(sculpt, name, value)

    unified = getattr(sculpt, "unified_paint_settings", None)
    if unified is None:
        unified = getattr(context.tool_settings, "unified_paint_settings", None)
    if unified is not None and getattr(unified, "use_unified_strength", False):
        unified.strength = settings.strength


def _evaluated_multires_mesh(context, obj, modifier, name):
    """Create an exact mesh at the current sculpt level, through Multires only."""
    if context.mode == 'SCULPT':
        bpy.ops.object.mode_set(mode='OBJECT')
    old_levels = modifier.levels
    disabled = []
    found_multires = False
    for item in obj.modifiers:
        if item == modifier:
            found_multires = True
            continue
        if found_multires and item.show_viewport:
            disabled.append(item)
            item.show_viewport = False
    try:
        modifier.levels = modifier.sculpt_levels
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        result = bpy.data.meshes.new_from_object(
            evaluated,
            preserve_all_data_layers=True,
            depsgraph=depsgraph,
        )
        result.name = name
    finally:
        modifier.levels = old_levels
        for item in disabled:
            item.show_viewport = True
        context.view_layer.update()
    return result


def _set_multires_snapshot(obj, slot, mesh):
    prop = _multires_snapshot_property(slot)
    old = getattr(obj, prop, None)
    mesh.use_fake_user = True
    setattr(obj, prop, mesh)
    if old and old != mesh:
        old.use_fake_user = False
        if old.users == 0:
            bpy.data.meshes.remove(old)


def _sync_work_snapshot_to_original(work, slot):
    original = _working_original(work)
    if not original or not _snapshot_is_valid(work.data, slot):
        return
    coordinates = _read_snapshot_np(work.data, slot)
    snapshot = _multires_snapshot_mesh(original, slot)
    if not snapshot or len(snapshot.vertices) != len(work.data.vertices):
        snapshot = work.data.copy()
        snapshot.name = f"{original.name}_MSB_Snapshot_{int(slot) + 1}"
        _set_multires_snapshot(original, slot, snapshot)
    snapshot.vertices.foreach_set("co", coordinates.reshape(-1))
    snapshot.update()


def _status_text(context, text=None):
    workspace = getattr(context, "workspace", None)
    if workspace:
        workspace.status_text_set(text)


class MSB_Settings(PropertyGroup):
    snapshot_slot: EnumProperty(name="Stored State", items=SLOT_ITEMS, default="0")
    strength: FloatProperty(
        name="Strength",
        description="Amount moved toward or away from the stored state per dab",
        default=0.35,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
    )
    direction: EnumProperty(
        name="Direction",
        items=(
            ('RESTORE', "Restore", "Move the current surface toward the stored state"),
            ('EXAGGERATE', "Exaggerate", "Move away from the stored state"),
        ),
        default='RESTORE',
    )
    falloff: EnumProperty(
        name="Falloff",
        items=(
            ('SMOOTH', "Smooth", "Smooth S-curve falloff"),
            ('SPHERE', "Sphere", "Rounded sphere falloff"),
            ('ROOT', "Root", "Broad, soft falloff"),
            ('SHARP', "Sharp", "Concentrated falloff"),
            ('LINEAR', "Linear", "Straight linear falloff"),
            ('CONSTANT', "Constant", "No falloff inside the radius"),
        ),
        default='SMOOTH',
    )
    spacing: FloatProperty(
        name="Spacing",
        description="Distance between dabs as a fraction of brush diameter",
        default=0.12,
        min=0.01,
        max=1.0,
        subtype='FACTOR',
    )
    preview_mode: EnumProperty(
        name="Stroke Preview",
        description="Control how often dense meshes are sent back to Blender while painting; every mode commits the exact result on release",
        items=(
            (
                'ADAPTIVE',
                "Adaptive",
                "Automatically reduce viewport refreshes as mesh density and update cost increase",
            ),
            (
                'LIVE',
                "Maximum Live",
                "Try to refresh at 30 Hz; this can stall on very dense meshes",
            ),
            (
                'ON_RELEASE',
                "On Release",
                "Keep painting responsive and show the result only when the mouse is released",
            ),
        ),
        default='ADAPTIVE',
    )
    front_faces_only: BoolProperty(
        name="Front Faces Only",
        description="Avoid affecting vertices whose normals face away from the view",
        default=True,
    )
    respect_mask: BoolProperty(
        name="Respect Sculpt Mask",
        description="Reduce the effect using the mesh sculpt mask attribute",
        default=True,
    )
    symmetry_x: BoolProperty(name="X", description="Mirror brush dabs across local X", default=True)
    symmetry_y: BoolProperty(name="Y", description="Mirror brush dabs across local Y", default=False)
    symmetry_z: BoolProperty(name="Z", description="Mirror brush dabs across local Z", default=False)
    restore_entire_strength: FloatProperty(
        name="Blend",
        description="Blend used by Restore Entire Mesh",
        default=1.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
    )


def _sculpt_radius_source(context):
    """Return Blender's real Sculpt radius owner/property, honoring Unified Size."""
    tool_settings = context.tool_settings
    sculpt = getattr(tool_settings, "sculpt", None)

    # Blender 5.0+ moved unified paint settings from ToolSettings onto each
    # Paint mode (Sculpt, Image Paint, Vertex Paint, etc.).
    unified = getattr(sculpt, "unified_paint_settings", None)
    # Compatibility with Blender 4.x and earlier layouts.
    if unified is None:
        unified = getattr(tool_settings, "unified_paint_settings", None)

    if unified is not None and getattr(unified, "use_unified_size", False):
        return unified, "size"
    brush = getattr(sculpt, "brush", None) if sculpt is not None else None
    if brush and hasattr(brush, "size"):
        return brush, "size"
    if unified is not None and hasattr(unified, "size"):
        return unified, "size"
    return None, None


def _sculpt_radius(context):
    owner, property_name = _sculpt_radius_source(context)
    if owner is None:
        return 50.0
    size = float(getattr(owner, property_name, 50))
    # Blender 5.0 changed Brush.size and UnifiedPaintSettings.size from a
    # pixel radius to a pixel diameter. The Morph engine works in radius.
    if bpy.app.version >= (5, 0, 0):
        size *= 0.5
    return max(0.5, size)


def _set_sculpt_radius(context, radius):
    """Write the radius to both Sculpt stores so tool changes keep the value."""
    diameter_size = bpy.app.version >= (5, 0, 0)
    maximum_radius = 2500.0 if diameter_size else 5000.0
    radius = max(0.5, min(maximum_radius, float(radius)))
    stored_size = int(round(radius * 2.0 if diameter_size else radius))
    tool_settings = context.tool_settings
    sculpt = getattr(tool_settings, "sculpt", None)
    unified = getattr(sculpt, "unified_paint_settings", None)
    if unified is None:
        unified = getattr(tool_settings, "unified_paint_settings", None)

    if unified is not None and hasattr(unified, "size"):
        try:
            unified.size = stored_size
        except (AttributeError, TypeError, ValueError):
            pass

    brush = getattr(sculpt, "brush", None) if sculpt is not None else None
    if brush is not None and hasattr(brush, "size"):
        try:
            brush.size = stored_size
        except (AttributeError, TypeError, ValueError):
            pass
    return stored_size * 0.5 if diameter_size else float(stored_size)


def _spatial_hash_keys(cells):
    """Return fast 64-bit hashes for integer XYZ grid cells."""
    cells = np.asarray(cells, dtype=np.int64)
    return np.bitwise_xor(
        np.bitwise_xor(cells[..., 0] * 73856093, cells[..., 1] * 19349663),
        cells[..., 2] * 83492791,
    )


class MSB_OT_capture_snapshot(Operator):
    bl_idname = "sculpt.msb_capture_snapshot"
    bl_label = "Capture Morph Snapshot"
    bl_description = "Store the current mesh or evaluated Multires sculpt level"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj, message = _validate_mesh_context(context, require_snapshot=False)
        if not obj:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}

        slot = context.scene.msb_settings.snapshot_slot
        multires = _multires_modifier(obj)
        if multires and not _working_original(obj):
            snapshot = _evaluated_multires_mesh(
                context,
                obj,
                multires,
                f"{obj.name}_MSB_Snapshot_{int(slot) + 1}",
            )
            _set_multires_snapshot(obj, slot, snapshot)
            bpy.ops.object.mode_set(mode='SCULPT')
            self.report(
                {'INFO'},
                f"Snapshot {int(slot) + 1} captured at Multires level {multires.sculpt_levels} "
                f"({len(snapshot.vertices):,} vertices)",
            )
        else:
            coordinates = _read_mesh_coordinates_np(obj.data)
            _store_snapshot_attribute(obj.data, slot, coordinates)
            _sync_work_snapshot_to_original(obj, slot)
            self.report({'INFO'}, f"Snapshot {int(slot) + 1} captured ({len(obj.data.vertices):,} vertices)")
        return {'FINISHED'}


class MSB_OT_clear_snapshot(Operator):
    bl_idname = "sculpt.msb_clear_snapshot"
    bl_label = "Clear Morph Snapshot"
    bl_description = "Remove the stored state from the selected slot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj, message = _validate_mesh_context(context, require_snapshot=False)
        if not obj:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        slot = context.scene.msb_settings.snapshot_slot
        original = _working_original(obj) or obj
        snapshot = _multires_snapshot_mesh(original, slot)
        if snapshot:
            setattr(original, _multires_snapshot_property(slot), None)
            snapshot.use_fake_user = False
            if snapshot.users == 0:
                bpy.data.meshes.remove(snapshot)
        _remove_snapshot_attribute(obj.data, slot)
        self.report({'INFO'}, f"Snapshot {int(slot) + 1} cleared")
        return {'FINISHED'}


class MSB_OT_restore_entire(Operator):
    bl_idname = "sculpt.msb_restore_entire"
    bl_label = "Restore Entire Mesh"
    bl_description = "Blend the complete mesh toward the selected stored state"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj, message = _validate_mesh_context(context)
        if not obj:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        if _multires_modifier(obj) and not _working_original(obj):
            obj = _create_multires_work_object(context, obj)
            if not _object_snapshot_is_valid(obj, context.scene.msb_settings.snapshot_slot):
                _return_to_multires_original(context, obj, False)
                self.report({'ERROR'}, "Stored and current Multires levels do not match")
                return {'CANCELLED'}
        settings = context.scene.msb_settings
        current = _read_mesh_coordinates_np(obj.data)
        target = _read_snapshot_np(obj.data, settings.snapshot_slot)
        factor = settings.restore_entire_strength
        current += (target - current) * factor
        _write_mesh_coordinates(obj, current.reshape(-1))
        context.view_layer.update()
        return {'FINISHED'}


class MSB_OT_swap_snapshot(Operator):
    bl_idname = "sculpt.msb_swap_snapshot"
    bl_label = "Swap Stored and Current"
    bl_description = "Restore the stored state and replace it with the current state"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj, message = _validate_mesh_context(context)
        if not obj:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        if _multires_modifier(obj) and not _working_original(obj):
            obj = _create_multires_work_object(context, obj)
            if not _object_snapshot_is_valid(obj, context.scene.msb_settings.snapshot_slot):
                _return_to_multires_original(context, obj, False)
                self.report({'ERROR'}, "Stored and current Multires levels do not match")
                return {'CANCELLED'}
        mesh = obj.data
        slot = context.scene.msb_settings.snapshot_slot
        current = _read_mesh_coordinates_np(mesh)
        stored = _read_snapshot_np(mesh, slot)
        _write_mesh_coordinates(obj, stored.reshape(-1))
        _snapshot_attribute(mesh, slot).data.foreach_set("vector", current.reshape(-1))
        mesh[_revision_key(slot)] = int(mesh.get(_revision_key(slot), 0)) + 1
        if NATIVE_TARGET_KEY in mesh:
            del mesh[NATIVE_TARGET_KEY]
        mesh.update()
        _sync_work_snapshot_to_original(obj, slot)
        context.view_layer.update()
        return {'FINISHED'}


def _create_multires_work_object(context, original):
    modifier = _multires_modifier(original)
    work_mesh = _evaluated_multires_mesh(
        context,
        original,
        modifier,
        f"{original.name}_MSB_WorkMesh",
    )
    for slot, _label, _description in SLOT_ITEMS:
        snapshot = _multires_snapshot_mesh(original, slot)
        if snapshot and len(snapshot.vertices) == len(work_mesh.vertices):
            _store_snapshot_attribute(work_mesh, slot, _read_mesh_coordinates_np(snapshot))

    work = bpy.data.objects.new(f"{original.name}_MSB_Work", work_mesh)
    work.matrix_world = original.matrix_world.copy()
    work.msb_multires_original = original
    work.msb_multires_modifier = modifier.name
    target_collection = original.users_collection[0] if original.users_collection else context.collection
    target_collection.objects.link(work)

    for selected in list(context.selected_objects):
        selected.select_set(False)
    original.hide_set(True)
    work.hide_set(False)
    work.select_set(True)
    context.view_layer.objects.active = work
    bpy.ops.object.mode_set(mode='SCULPT')
    return work


class MSB_OT_prepare_multires(Operator):
    bl_idname = "sculpt.msb_prepare_multires"
    bl_label = "Enter Full-Resolution Morph Mode"
    bl_description = "Create an exact working mesh for fast morph painting and later reshape it back into Multires"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj, message = _validate_mesh_context(context, require_snapshot=False)
        if not obj:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        modifier = _multires_modifier(obj)
        if not modifier:
            self.report({'ERROR'}, "The active object has no Multires modifier")
            return {'CANCELLED'}
        slot = context.scene.msb_settings.snapshot_slot
        snapshot = _multires_snapshot_mesh(obj, slot)
        if not snapshot:
            self.report({'ERROR'}, "Capture a Multires snapshot first")
            return {'CANCELLED'}
        work = _create_multires_work_object(context, obj)
        self.report({'INFO'}, f"Full-resolution morph mode: {len(work.data.vertices):,} vertices")
        return {'FINISHED'}


def _return_to_multires_original(context, work, apply_changes):
    original = _working_original(work)
    if not original:
        return False, "The working mesh has lost its Multires source link"
    modifier = original.modifiers.get(work.msb_multires_modifier)
    if not modifier or modifier.type != 'MULTIRES':
        return False, "The source Multires modifier no longer exists"

    bpy.ops.object.mode_set(mode='OBJECT')
    original.hide_set(False)
    for selected in list(context.selected_objects):
        selected.select_set(False)
    work.select_set(True)
    original.select_set(True)
    context.view_layer.objects.active = original

    if apply_changes:
        try:
            with context.temp_override(
                object=original,
                active_object=original,
                selected_objects=[work, original],
                selected_editable_objects=[work, original],
            ):
                result = bpy.ops.object.multires_reshape(modifier=modifier.name)
        except RuntimeError as error:
            result = {'CANCELLED'}
            failure = str(error)
        else:
            failure = "Multires Reshape was cancelled; verify matching sculpt level and topology"
        if 'FINISHED' not in result:
            original.hide_set(True)
            original.select_set(False)
            work.select_set(True)
            context.view_layer.objects.active = work
            bpy.ops.object.mode_set(mode='SCULPT')
            return False, failure

    work_mesh = work.data
    bpy.data.objects.remove(work, do_unlink=True)
    if work_mesh.users == 0:
        bpy.data.meshes.remove(work_mesh)
    original.hide_set(False)
    original.select_set(True)
    context.view_layer.objects.active = original
    bpy.ops.object.mode_set(mode='SCULPT')
    return True, ""


class MSB_OT_apply_multires(Operator):
    bl_idname = "sculpt.msb_apply_multires"
    bl_label = "Apply Back to Multires"
    bl_description = "Use native Multires Reshape to commit the working surface to the original displacement grids"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        work = context.object
        if not work or not _working_original(work):
            self.report({'ERROR'}, "The active object is not a Morph Snapshot Multires working mesh")
            return {'CANCELLED'}
        success, message = _return_to_multires_original(context, work, True)
        if not success:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        self.report({'INFO'}, "Morph result applied to the Multires displacement grids")
        return {'FINISHED'}


class MSB_OT_discard_multires(Operator):
    bl_idname = "sculpt.msb_discard_multires"
    bl_label = "Discard Morph Session"
    bl_description = "Delete the working mesh and return to the unchanged Multires object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        work = context.object
        if not work or not _working_original(work):
            self.report({'ERROR'}, "The active object is not a Morph Snapshot Multires working mesh")
            return {'CANCELLED'}
        success, message = _return_to_multires_original(context, work, False)
        if not success:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        return {'FINISHED'}


class MSB_OT_adjust_radius(Operator):
    bl_idname = "sculpt.msb_adjust_radius"
    bl_label = "Adjust Morph Snapshot Radius"
    bl_description = "Adjust the shared Sculpt brush radius"
    bl_options = {'INTERNAL', 'BLOCKING'}

    _draw_handle = None

    @classmethod
    def poll(cls, context):
        return (
            context.mode == 'SCULPT'
            and context.area is not None
            and context.area.type == 'VIEW_3D'
        )

    def _draw_radius(self):
        vertices = []
        for index in range(65):
            angle = (index / 64.0) * math.tau
            vertices.append((
                self._center.x + math.cos(angle) * self._radius,
                self._center.y + math.sin(angle) * self._radius,
            ))
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": vertices})
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.0)
        shader.bind()
        shader.uniform_float("color", (0.20, 0.80, 1.00, 0.95))
        batch.draw(shader)
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')

    def _remove_draw_handler(self):
        if self._draw_handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handle, 'WINDOW')
            self._draw_handle = None

    def _finish(self, context, cancelled=False):
        if cancelled:
            _set_sculpt_radius(context, self._initial_radius)
        self._remove_draw_handler()
        _status_text(context, None)
        if context.area:
            context.area.tag_redraw()
        return {'CANCELLED'} if cancelled else {'FINISHED'}

    def invoke(self, context, event):
        if context.region is None or context.region.type != 'WINDOW':
            self.report({'ERROR'}, "Adjust the radius inside the 3D Viewport")
            return {'CANCELLED'}
        self._initial_radius = _sculpt_radius(context)
        self._radius = self._initial_radius
        self._initial_mouse_x = event.mouse_x
        self._center = Vector((event.mouse_region_x, event.mouse_region_y))
        self._draw_handle = bpy.types.SpaceView3D.draw_handler_add(
            self._draw_radius, (), 'WINDOW', 'POST_PIXEL'
        )
        context.window_manager.modal_handler_add(self)
        _status_text(
            context,
            f"Morph Snapshot radius: {self._radius:g} px | Move mouse, LMB confirms, Esc/RMB cancels",
        )
        if context.area:
            context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'ESC', 'RIGHTMOUSE'}:
            return self._finish(context, cancelled=True)
        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'} and event.value == 'PRESS':
            return self._finish(context)
        if event.type == 'MOUSEMOVE':
            delta = event.mouse_x - self._initial_mouse_x
            self._radius = _set_sculpt_radius(context, self._initial_radius + delta)
            _status_text(
                context,
                f"Morph Snapshot radius: {self._radius:g} px | LMB confirms, Esc/RMB cancels",
            )
            if context.area:
                context.area.tag_redraw()
        return {'RUNNING_MODAL'}


class MSB_OT_native_brush_stroke(Operator):
    bl_idname = "sculpt.msb_native_brush_stroke"
    bl_label = "Native Morph Snapshot Stroke"
    bl_description = "Restore toward the snapshot using Blender's native PBVH Layer engine"
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return (
            context.mode == 'SCULPT'
            and context.object is not None
            and context.object.type == 'MESH'
        )

    def invoke(self, context, event):
        settings = context.scene.msb_settings

        # Moving away from an arbitrary target is not representable by the
        # native Layer brush. Keep the previous vector engine for that mode.
        if settings.direction != 'RESTORE' or event.ctrl:
            result = bpy.ops.sculpt.msb_brush_stroke('INVOKE_DEFAULT')
            return {'FINISHED'} if 'RUNNING_MODAL' in result else result

        obj, message = _validate_mesh_context(context)
        if not obj:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        if context.area.type != 'VIEW_3D' or context.region.type != 'WINDOW':
            self.report({'ERROR'}, "Start the stroke inside the 3D Viewport")
            return {'CANCELLED'}

        if _multires_modifier(obj) and not _working_original(obj):
            obj = _create_multires_work_object(context, obj)
            if not _object_snapshot_is_valid(obj, settings.snapshot_slot):
                _return_to_multires_original(context, obj, False)
                self.report(
                    {'ERROR'},
                    "The stored snapshot level does not match the current Multires sculpt level",
                )
                return {'CANCELLED'}

        try:
            _install_native_snapshot_target(obj.data, settings.snapshot_slot)
        except (RuntimeError, TypeError, ValueError) as error:
            self.report({'ERROR'}, f"Could not prepare native morph target: {error}")
            return {'CANCELLED'}

        brush = _activate_native_layer_brush(context)
        if brush is None:
            self.report(
                {'ERROR'},
                "Blender's Layer brush could not be activated; reselect the Morph Snapshot tool",
            )
            return {'CANCELLED'}
        _configure_native_layer_brush(context, settings, brush)

        result = bpy.ops.sculpt.brush_stroke(
            'INVOKE_DEFAULT',
            mode='NORMAL',
            ignore_background_click=True,
        )
        # The native operator owns the modal stroke after returning RUNNING_MODAL.
        return {'FINISHED'} if 'RUNNING_MODAL' in result else result


class MSB_OT_brush_stroke(Operator):
    bl_idname = "sculpt.msb_brush_stroke"
    bl_label = "Morph Snapshot Brush Stroke"
    bl_description = "Paint the current mesh toward the selected stored state"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    def _build_spatial_data(self, context, obj):
        mesh = obj.data
        self._coordinates = _read_mesh_coordinates_np(mesh)
        self._start_coordinates = self._coordinates.copy()
        matrix = np.asarray(obj.matrix_world, dtype=np.float32)
        self._linear = matrix[:3, :3]
        self._translation = matrix[:3, 3]
        self._world_coordinates = self._coordinates @ self._linear.T + self._translation
        self._inverse_matrix = obj.matrix_world.inverted()

        # Blender's object ray-cast may rebuild acceleration data after every
        # coordinate upload. A stroke-local BVH keeps hit testing independent
        # from viewport refreshes and is rebuilt for the next stroke.
        try:
            self._bvh = BVHTree.FromObject(
                obj,
                context.evaluated_depsgraph_get(),
                deform=True,
                cage=False,
                epsilon=0.0,
            )
        except (RuntimeError, TypeError, ValueError):
            self._bvh = None

        self._grid_origin = None
        self._grid_cell_size = 0.0
        self._grid_order = None
        self._grid_sorted_keys = None
        self._grid_motion_margin = 0.0
        self._mesh_dirty = False
        self._preview_was_uploaded = False
        self._last_flush_duration = 0.0
        self._preview_mode = self._settings.preview_mode
        if self._preview_mode == 'ON_RELEASE':
            self._base_preview_interval = math.inf
        elif self._preview_mode == 'LIVE':
            self._base_preview_interval = 1.0 / PREVIEW_MAX_HZ
        else:
            self._base_preview_interval = 1.0 / _adaptive_preview_hz(len(mesh.vertices))
        self._next_preview_time = time.perf_counter() + self._base_preview_interval

        self._world_normals = None
        if self._settings.front_faces_only:
            normals = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
            mesh.vertices.foreach_get("normal", normals)
            normals = normals.reshape((-1, 3))
            normal_matrix = np.linalg.inv(self._linear).T
            self._world_normals = normals @ normal_matrix.T
            lengths = np.linalg.norm(self._world_normals, axis=1)
            nonzero = lengths > 1.0e-12
            self._world_normals[nonzero] /= lengths[nonzero, None]

        self._mask = None
        if self._settings.respect_mask:
            mask_attribute = mesh.attributes.get(".sculpt_mask")
            if mask_attribute and mask_attribute.domain == 'POINT' and mask_attribute.data_type == 'FLOAT':
                self._mask = np.empty(len(mesh.vertices), dtype=np.float32)
                mask_attribute.data.foreach_get("value", self._mask)

    def _ray_hit(self, context, mouse):
        region = context.region
        rv3d = context.region_data
        origin_world = view3d_utils.region_2d_to_origin_3d(region, rv3d, mouse)
        direction_world = view3d_utils.region_2d_to_vector_3d(region, rv3d, mouse).normalized()
        origin_local = self._inverse_matrix @ origin_world
        direction_local = (self._inverse_matrix.to_3x3() @ direction_world).normalized()
        if self._bvh is not None:
            location_local, _normal, _face, _distance = self._bvh.ray_cast(
                origin_local, direction_local
            )
            if location_local is None:
                return None
        else:
            hit, location_local, _normal, _face = self._obj.ray_cast(
                origin_local, direction_local
            )
            if not hit:
                return None
        location_world = self._obj.matrix_world @ location_local
        self._radius = _sculpt_radius(context)
        edge_mouse = Vector((mouse.x + self._radius, mouse.y))
        edge_world = view3d_utils.region_2d_to_location_3d(region, rv3d, edge_mouse, location_world)
        radius_world = max((edge_world - location_world).length, 1.0e-8)
        return location_world, radius_world, direction_world

    def _symmetry_centers(self, hit_world):
        inverse = self._obj.matrix_world.inverted()
        local = inverse @ hit_world
        centers = [local]
        for axis, enabled in enumerate((
            self._settings.symmetry_x,
            self._settings.symmetry_y,
            self._settings.symmetry_z,
        )):
            if enabled and abs(local[axis]) > 1.0e-9:
                mirrored = []
                for center in centers:
                    value = center.copy()
                    value[axis] *= -1.0
                    mirrored.append(value)
                centers.extend(mirrored)
        return [np.asarray(self._obj.matrix_world @ center, dtype=np.float32) for center in centers]

    def _falloff_array(self, normalized_distance):
        value = np.clip(1.0 - normalized_distance, 0.0, 1.0)
        kind = self._settings.falloff
        if kind == 'CONSTANT':
            value.fill(1.0)
        elif kind == 'SHARP':
            np.square(value, out=value)
        elif kind == 'ROOT':
            np.sqrt(value, out=value)
        elif kind == 'SPHERE':
            value = np.sqrt(np.maximum(0.0, 1.0 - np.square(1.0 - value)))
        elif kind == 'SMOOTH':
            value = value * value * (3.0 - 2.0 * value)
        return value

    def _ensure_spatial_grid(self, radius_world):
        if self._grid_order is not None:
            return
        self._grid_cell_size = max(float(radius_world), 1.0e-8)
        self._grid_origin = (
            np.min(self._world_coordinates, axis=0) - self._grid_cell_size * 0.5
        )
        cells = np.floor(
            (self._world_coordinates - self._grid_origin) / self._grid_cell_size
        ).astype(np.int64)
        keys = _spatial_hash_keys(cells)
        self._grid_order = np.argsort(keys)
        self._grid_sorted_keys = keys[self._grid_order]

    def _grid_candidates(self, center, radius_world):
        search_radius = float(radius_world) + self._grid_motion_margin
        reach = max(1, int(math.ceil(search_radius / self._grid_cell_size)))

        # At very large radii a full vectorized scan is cheaper than producing
        # and searching thousands of grid-cell keys.
        if (reach * 2 + 1) ** 3 > 4096:
            return np.arange(len(self._world_coordinates), dtype=np.int64)

        center_cell = np.floor(
            (np.asarray(center, dtype=np.float32) - self._grid_origin) / self._grid_cell_size
        ).astype(np.int64)
        offsets = _grid_neighbor_offsets(reach)
        keys = np.unique(_spatial_hash_keys(offsets + center_cell))
        left = np.searchsorted(self._grid_sorted_keys, keys, side='left')
        right = np.searchsorted(self._grid_sorted_keys, keys, side='right')
        chunks = [
            self._grid_order[int(start):int(end)]
            for start, end in zip(left, right)
            if start < end
        ]
        if not chunks:
            return np.empty(0, dtype=np.int64)
        if len(chunks) == 1:
            return chunks[0]
        return np.concatenate(chunks)

    def _dab(self, context, mouse, event):
        hit = self._ray_hit(context, mouse)
        if not hit:
            return False
        hit_world, radius_world, view_direction = hit
        self._ensure_spatial_grid(radius_world)
        pressure = max(0.0, min(1.0, getattr(event, "pressure", 1.0) or 1.0))
        reverse = event.ctrl
        direction = self._settings.direction
        if reverse:
            direction = 'EXAGGERATE' if direction == 'RESTORE' else 'RESTORE'

        radius_squared = radius_world * radius_world
        index_parts = []
        weight_parts = []
        for center in self._symmetry_centers(hit_world):
            candidates = self._grid_candidates(center, radius_world)
            if not candidates.size:
                continue
            delta = self._world_coordinates[candidates] - center
            distance_squared = np.einsum('ij,ij->i', delta, delta)
            inside = distance_squared < radius_squared
            indices = candidates[inside]
            if indices.size:
                distances = np.sqrt(distance_squared[inside]) / radius_world
                weights = self._falloff_array(distances)
                index_parts.append(indices)
                weight_parts.append(weights)

        if not index_parts:
            return False
        if len(index_parts) == 1:
            indices = index_parts[0]
            weights = weight_parts[0]
        else:
            combined_indices = np.concatenate(index_parts)
            combined_weights = np.concatenate(weight_parts)
            indices, inverse = np.unique(combined_indices, return_inverse=True)
            weights = np.zeros(len(indices), dtype=np.float32)
            np.maximum.at(weights, inverse, combined_weights)

        if self._settings.front_faces_only:
            direction_np = np.asarray(view_direction, dtype=np.float32)
            facing = self._world_normals[indices] @ -direction_np > 0.0
            weights = weights[facing]
            indices = indices[facing]
            if not indices.size:
                return False

        factors = weights * self._settings.strength * pressure
        if self._settings.respect_mask and self._mask is not None:
            factors *= 1.0 - self._mask[indices]
        factors = np.clip(factors, 0.0, 1.0)

        if direction == 'RESTORE':
            self._coordinates[indices] += (
                self._snapshot[indices] - self._coordinates[indices]
            ) * factors[:, None]
        else:
            self._coordinates[indices] += (
                self._coordinates[indices] - self._snapshot[indices]
            ) * factors[:, None]

        self._world_coordinates[indices] = (
            self._coordinates[indices] @ self._linear.T + self._translation
        )
        reference_world = self._start_coordinates[indices] @ self._linear.T + self._translation
        movement = np.linalg.norm(self._world_coordinates[indices] - reference_world, axis=1)
        if movement.size:
            self._grid_motion_margin = max(
                self._grid_motion_margin,
                float(np.max(movement)),
            )
        self._mesh_dirty = True
        return True

    def _flush_mesh(self, context, force=False):
        if not self._mesh_dirty:
            return False
        now = time.perf_counter()
        if not force and (
            self._preview_mode == 'ON_RELEASE' or now < self._next_preview_time
        ):
            return False
        started = now
        _write_mesh_coordinates(self._obj, self._coordinates.reshape(-1))
        finished = time.perf_counter()
        self._mesh_dirty = False
        self._preview_was_uploaded = True
        self._last_flush_duration = finished - started

        if self._preview_mode == 'LIVE':
            self._next_preview_time = started + self._base_preview_interval
        else:
            # Leave some event-loop breathing room when Blender itself takes
            # longer than the density-based budget predicted. This adapts to
            # the user's CPU, modifiers and current Sculpt data, not just N.
            rebuild_recovery = self._last_flush_duration * 0.25
            self._next_preview_time = max(
                started + self._base_preview_interval,
                finished + rebuild_recovery,
            )
        if context.area:
            context.area.tag_redraw()
        return True

    def _finish(self, context, cancelled=False):
        _status_text(context, None)
        if cancelled:
            # In On Release mode Blender's mesh was never touched, so Escape
            # can cancel immediately without an unnecessary full rebuild.
            if self._preview_was_uploaded:
                _write_mesh_coordinates(self._obj, self._start_coordinates.reshape(-1))
            self._mesh_dirty = False
        else:
            self._flush_mesh(context, force=True)
        context.view_layer.update()
        if context.area:
            context.area.tag_redraw()
        return {'CANCELLED'} if cancelled else {'FINISHED'}

    def invoke(self, context, event):
        obj, message = _validate_mesh_context(context)
        if not obj:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        if context.area.type != 'VIEW_3D' or context.region.type != 'WINDOW':
            self.report({'ERROR'}, "Start the stroke inside the 3D Viewport")
            return {'CANCELLED'}

        if _multires_modifier(obj) and not _working_original(obj):
            obj = _create_multires_work_object(context, obj)
            if not _object_snapshot_is_valid(obj, context.scene.msb_settings.snapshot_slot):
                _return_to_multires_original(context, obj, False)
                self.report(
                    {'ERROR'},
                    "The stored snapshot level does not match the current Multires sculpt level",
                )
                return {'CANCELLED'}

        self._obj = obj
        self._settings = context.scene.msb_settings
        self._snapshot = _read_snapshot_np(obj.data, self._settings.snapshot_slot)
        self._build_spatial_data(context, obj)
        self._mouse = Vector((event.mouse_region_x, event.mouse_region_y))
        self._radius = _sculpt_radius(context)
        self._last_dab = self._mouse.copy()
        context.window_manager.modal_handler_add(self)
        if self._preview_mode == 'ON_RELEASE':
            preview_text = "preview on release"
        elif self._preview_mode == 'LIVE':
            preview_text = "maximum live preview"
        else:
            preview_hz = 1.0 / self._base_preview_interval
            preview_text = f"adaptive preview up to {preview_hz:.0f} Hz"
        _status_text(
            context,
            f"Morph Snapshot: {preview_text} | Ctrl reverses | Esc / RMB cancels",
        )
        self._dab(context, self._mouse, event)
        # Small meshes can show the first dab immediately. On dense meshes the
        # first forced upload would block before the user can even move the pen.
        self._flush_mesh(
            context,
            force=(self._preview_mode == 'LIVE' or len(obj.data.vertices) < 250_000),
        )
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not self._obj or self._obj.name not in bpy.data.objects:
            return self._finish(context, cancelled=True)
        if event.type in {'ESC', 'RIGHTMOUSE'}:
            return self._finish(context, cancelled=True)
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            return self._finish(context)
        if event.type == 'MOUSEMOVE':
            self._mouse = Vector((event.mouse_region_x, event.mouse_region_y))
            distance = (self._mouse - self._last_dab).length
            self._radius = _sculpt_radius(context)
            step = max(1.0, self._radius * 2.0 * self._settings.spacing)
            if distance >= step:
                count = min(MAX_DABS_PER_EVENT, max(1, int(distance / step)))
                start = self._last_dab.copy()
                for index in range(1, count + 1):
                    point = start.lerp(self._mouse, index / count)
                    self._dab(context, point, event)
                self._last_dab = self._mouse.copy()
                self._flush_mesh(context)
            if context.area:
                context.area.tag_redraw()
        return {'RUNNING_MODAL'}


def _draw_brush_settings(layout, context, compact=False):
    settings = context.scene.msb_settings
    layout.prop(settings, "strength", text="Strength")
    if not compact:
        layout.label(text=f"Radius: Sculpt brush ({_sculpt_radius(context):g} px)")
        layout.prop(settings, "direction", expand=True)
        layout.prop(settings, "falloff")


class MSB_WST_morph_brush(WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'SCULPT'
    bl_idname = "msb.morph_snapshot_brush"
    bl_label = "Morph Snapshot"
    bl_description = "Paint a stored mesh state back onto the current sculpt"
    bl_icon = TOOL_ICON
    bl_widget = None
    bl_options = {'USE_BRUSHES'}
    bl_keymap = (
        (
            "sculpt.msb_native_brush_stroke",
            {"type": 'LEFTMOUSE', "value": 'PRESS'},
            {"properties": []},
        ),
        (
            "sculpt.msb_adjust_radius",
            {"type": 'F', "value": 'PRESS'},
            {"properties": []},
        ),
    )

    @staticmethod
    def draw_settings(context, layout, tool):
        _draw_brush_settings(layout, context, compact=True)


class MSB_PT_panel(Panel):
    bl_label = "Morph Snapshot"
    bl_idname = "MSB_PT_morph_snapshot"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"

    @classmethod
    def poll(cls, context):
        return context.mode == 'SCULPT' and context.object and context.object.type == 'MESH'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.msb_settings
        obj = context.object
        mesh = obj.data
        slot = settings.snapshot_slot

        original = _working_original(obj)
        if original:
            session = layout.box()
            session.label(text=f"Multires session: {original.name}", icon='MOD_MULTIRES')
            session.label(text=f"Working resolution: {len(mesh.vertices):,} vertices")
            row = session.row(align=True)
            row.operator("sculpt.msb_apply_multires", icon='CHECKMARK')
            row.operator("sculpt.msb_discard_multires", text="Discard", icon='X')

        layout.prop(settings, "snapshot_slot", text="")
        row = layout.row(align=True)
        row.operator("sculpt.msb_capture_snapshot", text="Capture Current", icon='ADD')
        row.operator("sculpt.msb_clear_snapshot", text="", icon='TRASH')

        status_box = layout.box()
        multires = _multires_modifier(obj)
        multires_snapshot = _multires_snapshot_mesh(obj, slot) if multires and not original else None
        if multires_snapshot:
            status_box.label(
                text=f"Stored Multires surface: {len(multires_snapshot.vertices):,} vertices",
                icon='CHECKMARK',
            )
        elif _snapshot_is_valid(mesh, slot):
            status_box.label(text=f"Stored: {len(mesh.vertices):,} vertices", icon='CHECKMARK')
        elif _snapshot_attribute(mesh, slot):
            status_box.label(text="Stored topology no longer matches", icon='ERROR')
        else:
            status_box.label(text="No state stored in this slot", icon='INFO')

        layout.separator()
        _draw_brush_settings(layout, context)
        layout.prop(settings, "spacing")
        if settings.direction == 'RESTORE':
            layout.label(text="Native PBVH engine", icon='CHECKMARK')
        else:
            box = layout.box()
            box.label(text="Exaggerate uses the slower Python engine", icon='INFO')
            box.prop(settings, "preview_mode")
        layout.prop(settings, "front_faces_only")
        layout.prop(settings, "respect_mask")

        row = layout.row(align=True)
        row.label(text="Symmetry")
        row.prop(settings, "symmetry_x", toggle=True)
        row.prop(settings, "symmetry_y", toggle=True)
        row.prop(settings, "symmetry_z", toggle=True)

        layout.separator()
        row = layout.row(align=True)
        row.prop(settings, "restore_entire_strength", text="Blend")
        row.operator("sculpt.msb_restore_entire", text="Restore All")
        layout.operator("sculpt.msb_swap_snapshot", icon='FILE_REFRESH')

        if multires and not original:
            box = layout.box()
            box.label(text="Full-resolution Multires mode", icon='MOD_MULTIRES')
            box.label(text=f"Base: {len(mesh.vertices):,} verts | Sculpt level: {multires.sculpt_levels}")
            box.operator("sculpt.msb_prepare_multires", icon='SCULPTMODE_HLT')

        if getattr(obj, "use_dynamic_topology_sculpting", False):
            box = layout.box()
            box.alert = True
            box.label(text="Disable Dynamic Topology", icon='ERROR')


def _set_registered_tool_brush_type(tool_class, brush_type):
    """Patch the registered ToolDef; register_tool omits brush_type for add-ons."""
    try:
        from bl_ui.space_toolsystem_common import ToolDef, ToolSelectPanelHelper

        toolbar = ToolSelectPanelHelper._tool_class_from_space_type(
            tool_class.bl_space_type
        )
        tools = toolbar._tools[tool_class.bl_context_mode]
        for index, item in enumerate(tools):
            if isinstance(item, ToolDef) and item.idname == tool_class.bl_idname:
                replacement = item._replace(brush_type=brush_type)
                tools[index] = replacement
                tool_class._bl_tool = replacement
                return True
            if isinstance(item, tuple):
                group = list(item)
                for sub_index, sub_item in enumerate(group):
                    if isinstance(sub_item, ToolDef) and sub_item.idname == tool_class.bl_idname:
                        replacement = sub_item._replace(brush_type=brush_type)
                        group[sub_index] = replacement
                        tools[index] = tuple(group)
                        tool_class._bl_tool = replacement
                        return True
    except (AttributeError, ImportError, KeyError, TypeError):
        pass
    return False


classes = (
    MSB_Settings,
    MSB_OT_capture_snapshot,
    MSB_OT_clear_snapshot,
    MSB_OT_restore_entire,
    MSB_OT_swap_snapshot,
    MSB_OT_prepare_multires,
    MSB_OT_apply_multires,
    MSB_OT_discard_multires,
    MSB_OT_adjust_radius,
    MSB_OT_native_brush_stroke,
    MSB_OT_brush_stroke,
    MSB_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.msb_settings = PointerProperty(type=MSB_Settings)
    bpy.types.Object.msb_multires_original = PointerProperty(type=bpy.types.Object)
    bpy.types.Object.msb_multires_modifier = StringProperty()
    for slot, _label, _description in SLOT_ITEMS:
        setattr(
            bpy.types.Object,
            _multires_snapshot_property(slot),
            PointerProperty(type=bpy.types.Mesh),
        )
    # Brush assets removed/rearranged several historical toolbar tool IDs.
    # Registering without an `after` dependency keeps this working across both
    # the Blender 4.x asset-shelf transition and Blender 5.x.
    bpy.utils.register_tool(MSB_WST_morph_brush, separator=True, group=False)
    _set_registered_tool_brush_type(MSB_WST_morph_brush, 'LAYER')


def unregister():
    try:
        bpy.utils.unregister_tool(MSB_WST_morph_brush)
    except RuntimeError:
        pass
    if hasattr(bpy.types.Scene, "msb_settings"):
        del bpy.types.Scene.msb_settings
    for name in ("msb_multires_original", "msb_multires_modifier"):
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)
    for slot, _label, _description in SLOT_ITEMS:
        name = _multires_snapshot_property(slot)
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

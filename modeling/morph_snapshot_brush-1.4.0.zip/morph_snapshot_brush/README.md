# Morph Snapshot Brush 1.4.0

An interactive Blender sculpt tool inspired by Pablo Dobarro's Sculpt
Snapshots prototype and ZBrush's StoreMT/Morph Brush workflow.

## Install

1. In Blender, open **Edit > Preferences > Get Extensions**.
2. Use the drop-down menu and choose **Install from Disk**.
3. Select `morph_snapshot_brush-1.4.0.zip`.
4. Enable **Morph Snapshot Brush** if Blender does not enable it automatically.

## Use

1. Select a mesh and enter Sculpt Mode.
2. Open **N-panel > Tool > Morph Snapshot**.
3. Choose a slot and click **Capture Current**.
4. Sculpt the object using normal Blender brushes.
5. Select **Morph Snapshot** in the left toolbar.
6. Paint to restore the stored form locally.

Hold **Ctrl** during a stroke to temporarily reverse Restore/Exaggerate.
Use **Esc** or right-click to cancel the complete stroke.

The Morph Snapshot radius is always Blender's current Sculpt brush radius. It
honors **Unified Size** and there is no separate add-on radius. While the Morph
Snapshot tool is active, press `F`, move the mouse left/right, then left-click
to confirm (`Esc` or right-click cancels). The new value is written to both the
active Sculpt brush and Blender's unified Sculpt size so switching tools keeps
the same visible radius.

Blender 5.x stores Sculpt size as a diameter, while Blender 4.x stores it as a
radius. The add-on handles that version difference internally, so a Draw brush
and the Morph Snapshot brush now have the same on-screen footprint.

Morph Snapshot is registered as a Blender Sculpt brush tool, so it uses
Blender's native Sculpt cursor rather than a Python-drawn approximation. Native
cursor color, surface projection, falloff overlay and visibility preferences
therefore apply to Morph Snapshot too.

`Restore Entire Mesh` and `Swap Stored / Current` are useful for testing or
switching between two states.

## Fast high-resolution engine

Version 1.4 replaces Restore painting with Blender's native Layer-brush PBVH
engine. The selected snapshot is installed as the Layer persistent base and the
layer height is set to zero. Blender therefore moves only the vertices in the
touched PBVH nodes toward the snapshot, using the same local update path as
native sculpt brushes. There is no Python vertex search, full coordinate upload,
or whole-mesh dependency-graph rebuild for each dab.

The snapshot target is prepared once after capture or slot changes. Subsequent
Restore strokes run natively. Multires still enters the exact full-resolution
working-mesh session first, then uses the same native PBVH engine and can be
reshaped back to the original Multires grids.

**Exaggerate** and Ctrl-reverse still use the older Python vector engine because
Blender's Layer brush can restore to an arbitrary target but cannot extrapolate
away from that target. The preview controls apply only to that fallback mode.

Version 1.2 adds a stroke-local BVH and a vectorized spatial hash, so each dab
tests nearby grid cells instead of scanning every vertex. Multiple dabs in one
mouse event are combined into one mesh upload, and dense-mesh viewport refresh
is capped at 30 Hz. The benefit increases with mesh density; the final upload
cost still depends on mesh size and hardware.

Version 1.3 adds **Stroke Preview** performance modes:

- **Adaptive** (default) budgets coordinate uploads by vertex count and then
  adapts again to the measured Blender rebuild time. Light meshes can update at
  30 Hz, a one-million-vertex mesh targets about 10 Hz, and very dense meshes
  refresh less often so the input loop gets time to respond.
- **Maximum Live** requests the old 30 Hz behavior regardless of density.
- **On Release** performs no expensive viewport rebuild while dragging and
  commits the exact painted result when the mouse is released.

All three modes calculate the same dabs and produce the same final mesh. The
update path also avoids a redundant dependency-graph invalidation, reuses grid
query stencils, and skips reading normals or mask data when their options are
disabled.

## Multires workflow

1. Set the Multires **Sculpt Level** you intend to work at.
2. Click **Capture Current**. The complete evaluated surface at that level is
   stored, not the base cage.
3. Sculpt the Multires object normally.
4. Choose **Morph Snapshot** and start a stroke, or click
   **Enter Full-Resolution Morph Mode**. The add-on creates an exact temporary
   working surface and hides the source object.
5. Paint the stored form back. You can use several Morph Snapshot strokes and
   ordinary Sculpt brushes on the working surface.
6. Click **Apply Back to Multires**. Blender's native Multires **Reshape**
   transfers the matching full-resolution coordinates into the original
   displacement grids. **Discard** returns without changing the Multires object.

Do not change the Multires sculpt level between snapshot capture and entering
the morph session. There is no voxel remesh or nearest-surface reprojection;
the source and working surfaces use matching vertex indices.

## Limitations

- Snapshot and current mesh topology must match.
- Dynamic Topology must be disabled.
- The custom deformation is a workspace tool, not a native brush asset. Python
  add-ons cannot add a new native Sculpt brush engine to Blender's Brush Asset
  Shelf.
- A full-resolution Multires snapshot and working mesh temporarily consume
  additional memory.
- Very dense meshes still require Blender to upload the changed coordinate
  array and refresh the viewport after each dab.

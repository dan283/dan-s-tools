#include <vector>
#include <map>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
struct V {double x,y,z; V operator+(V b)const{return{x+b.x,y+b.y,z+b.z};} V operator*(double s)const{return{x*s,y*s,z*s};}};
struct E {int a,b,f0=-1,f1=-1;};
extern "C" {
#ifdef _WIN32
#define API __declspec(dllexport)
#else
#define API __attribute__((visibility("default")))
#endif
static int subdivide_impl(const double* xyz,int nv,const int* indices,const int* offsets,int nf,double** outxyz,int* outnv,int** outidx,int** outoff,int* outnf,bool linear){
 if(!xyz||!indices||!offsets||!outxyz||!outnv||!outidx||!outoff||!outnf||nv<1||nf<1||nv>40000000||nf>40000000)return 1;
 try{
 std::vector<V> verts(nv);for(int i=0;i<nv;i++){verts[i]={xyz[i*3],xyz[i*3+1],xyz[i*3+2]};if(!std::isfinite(verts[i].x)||!std::isfinite(verts[i].y)||!std::isfinite(verts[i].z))return 2;}
 std::map<std::pair<int,int>,int> lookup;std::vector<E> edges;std::vector<std::vector<int>> vf(nv),ve(nv),fe(nf);
 std::vector<V> fp(nf);
 if(offsets[0]!=0||offsets[nf]>160000000)return 2;
 for(int f=0;f<nf;f++){int start=offsets[f],end=offsets[f+1],n=end-start;if(n<3||n>1000000||start<0||end>160000000)return 2;V sum{0,0,0};for(int j=start;j<end;j++){int a=indices[j],b=indices[start+(j-start+1)%n];if(a<0||a>=nv||b<0||b>=nv||a==b)return 2;sum=sum+verts[a];vf[a].push_back(f);auto key=std::minmax(a,b);auto it=lookup.find(key);int ei;if(it==lookup.end()){ei=(int)edges.size();lookup[key]=ei;edges.push_back({key.first,key.second,f,-1});ve[a].push_back(ei);ve[b].push_back(ei);}else{ei=it->second;if(edges[ei].f1!=-1)return 3;edges[ei].f1=f;}fe[f].push_back(ei);}fp[f]=sum*(1.0/n);}
 size_t nc=(size_t)nv+edges.size()+nf;if(nc>60000000)return 4;std::vector<V> result(nc);
 for(int i=0;i<nv;i++){std::vector<int> bounds;for(int e:ve[i])if(edges[e].f1<0)bounds.push_back(edges[e].a==i?edges[e].b:edges[e].a);
 if(linear){result[i]=verts[i];continue;}
 if(bounds.size()==2){result[i]=verts[i]*0.75+(verts[bounds[0]]+verts[bounds[1]])*0.125;continue;}if(!bounds.empty()||ve[i].empty()||vf[i].empty()){result[i]=verts[i];continue;}
 V F{0,0,0},R{0,0,0};for(int f:vf[i])F=F+fp[f];for(int e:ve[i])R=R+(verts[edges[e].a]+verts[edges[e].b])*0.5;double n=(double)vf[i].size();result[i]=F*(1.0/n/n)+R*(2.0/ve[i].size()/n)+verts[i]*((n-3.0)/n);}
 for(size_t e=0;e<edges.size();e++){auto &ed=edges[e];V p=verts[ed.a]+verts[ed.b];result[nv+e]=(linear||ed.f1<0)?p*0.5:(p+fp[ed.f0]+fp[ed.f1])*0.25;}
 for(int f=0;f<nf;f++)result[nv+edges.size()+f]=fp[f];
 std::vector<int> oi;std::vector<int> oo;oi.reserve((size_t)offsets[nf]*4);oo.reserve((size_t)offsets[nf]+1);oo.push_back(0);
 for(int f=0;f<nf;f++){int start=offsets[f],n=offsets[f+1]-start;for(int k=0;k<n;k++){oi.push_back(indices[start+k]);oi.push_back(nv+fe[f][k]);oi.push_back(nv+(int)edges.size()+f);oi.push_back(nv+fe[f][(k+n-1)%n]);oo.push_back((int)oi.size());}}
 *outxyz=new double[nc*3];*outidx=new int[oi.size()];*outoff=new int[oo.size()];for(size_t i=0;i<nc;i++){(*outxyz)[3*i]=result[i].x;(*outxyz)[3*i+1]=result[i].y;(*outxyz)[3*i+2]=result[i].z;}std::copy(oi.begin(),oi.end(),*outidx);std::copy(oo.begin(),oo.end(),*outoff);*outnv=(int)nc;*outnf=(int)oo.size()-1;return 0;
 }catch(...){return 5;}}
API int sculpt_subdivide(const double* xyz,int nv,const int* indices,const int* offsets,int nf,double** outxyz,int* outnv,int** outidx,int** outoff,int* outnf){
 return subdivide_impl(xyz,nv,indices,offsets,nf,outxyz,outnv,outidx,outoff,outnf,false);
}
API int sculpt_subdivide_mode(const double* xyz,int nv,const int* indices,const int* offsets,int nf,double** outxyz,int* outnv,int** outidx,int** outoff,int* outnf,int linear){
 return subdivide_impl(xyz,nv,indices,offsets,nf,outxyz,outnv,outidx,outoff,outnf,linear!=0);
}
API void sculpt_free_xyz(double* p){delete[] p;} API void sculpt_free_int(int* p){delete[] p;}
// Catmull-Clark is linear for a fixed topology. Subdivide the difference
// between the changed parent and its last synchronized state, then add that
// displacement to the sculpted child without replacing its detail.
API int sculpt_propagate_mode(const double* old_parent,const double* new_parent,int nv,
  const int* indices,const int* offsets,int nf,const double* child,int child_nv,
  double** updated,int linear){
 if(!old_parent||!new_parent||!indices||!offsets||!child||!updated||nv<1||child_nv<1)return 1;
 *updated=nullptr;
 double* delta=nullptr;double* raised=nullptr;int* inds=nullptr;int* offs=nullptr;
 int raised_nv=0,raised_nf=0;
 try{
   delta=new double[(size_t)nv*3];
   for(size_t k=0;k<(size_t)nv*3;k++)delta[k]=new_parent[k]-old_parent[k];
   int rc=subdivide_impl(delta,nv,indices,offsets,nf,&raised,&raised_nv,&inds,&offs,&raised_nf,linear!=0);
   delete[] delta;delta=nullptr;
   if(rc){delete[] raised;delete[] inds;delete[] offs;return rc;}
   if(raised_nv!=child_nv){delete[] raised;delete[] inds;delete[] offs;return 6;}
   double* result=new double[(size_t)child_nv*3];
   for(size_t k=0;k<(size_t)child_nv*3;k++)result[k]=child[k]+raised[k];
   delete[] raised;delete[] inds;delete[] offs;
   *updated=result;return 0;
 }catch(...){delete[] delta;delete[] raised;delete[] inds;delete[] offs;return 5;}
}
API int sculpt_propagate(const double* old_parent,const double* new_parent,int nv,
  const int* indices,const int* offsets,int nf,const double* child,int child_nv,
  double** updated){return sculpt_propagate_mode(old_parent,new_parent,nv,indices,offsets,nf,child,child_nv,updated,0);}
// Project broad high-level movement to the coarse cage. Neighbour averaging
// attenuates local high-frequency sculpt strokes on the coarser levels.
API int sculpt_project(const double* previous,const double* current,int child_nv,
 const int* indices,const int* offsets,int parent_nv,int nf,double* parent_out){
 if(!previous||!current||!indices||!offsets||!parent_out||parent_nv<1||child_nv<parent_nv)return 1;
 try{
 std::vector<V> delta(parent_nv),sum(parent_nv,{0,0,0});
 std::vector<int> count(parent_nv,0);
 for(int v=0;v<parent_nv;v++)delta[v]={current[v*3]-previous[v*3],current[v*3+1]-previous[v*3+1],current[v*3+2]-previous[v*3+2]};
 for(int f=0;f<nf;f++){
  int begin=offsets[f],end=offsets[f+1];if(begin<0||end<begin||end-begin<3)return 2;
  for(int j=begin;j<end;j++){int a=indices[j],b=indices[j+1<end?j+1:begin];if(a<0||b<0||a>=parent_nv||b>=parent_nv)return 2;
   sum[a]=sum[a]+delta[b];count[a]++;}
 }
 for(int v=0;v<parent_nv;v++){V d=count[v] ? delta[v]*0.5+sum[v]*(0.5/count[v]):delta[v];
  for(int k=0;k<3;k++)parent_out[v*3+k]+=k==0?d.x:(k==1?d.y:d.z);}
 return 0;
 }catch(...){return 5;}
}
}

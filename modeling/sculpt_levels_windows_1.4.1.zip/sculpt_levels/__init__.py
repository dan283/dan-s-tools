bl_info = {"name":"Sculpt Levels","author":"OpenAI","version":(1,4,1),"blender":(4,3,0),"location":"Properties > Object > Sculpt Levels","description":"Native subdivision with editable mesh levels","category":"Mesh"}
import bpy
import ctypes as C
import os
from array import array
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty

_NATIVE = None
MAX_FACES = 8000000

class SculptLevelEntry(bpy.types.PropertyGroup):
    mesh: PointerProperty(type=bpy.types.Mesh)
    parent_reference: PointerProperty(type=bpy.types.Mesh)
    edit_reference: PointerProperty(type=bpy.types.Mesh)
    linear: BoolProperty(default=False)

def backend():
    global _NATIVE
    if _NATIVE is None:
        # Version the DLL filename: Windows keeps a loaded DLL locked, and
        # Blender may continue using its old handle after an add-on update.
        path = os.path.join(os.path.dirname(__file__), 'sculpt_levels_141.dll')
        if not os.path.isfile(path):
            raise RuntimeError('Native library for Sculpt Levels 1.4.1 is missing; reinstall its complete ZIP')
        lib = C.CDLL(path)
        pdouble = C.POINTER(C.c_double); pint = C.POINTER(C.c_int)
        lib.sculpt_subdivide.argtypes = [pdouble,C.c_int,pint,pint,C.c_int,C.POINTER(pdouble),C.POINTER(C.c_int),C.POINTER(pint),C.POINTER(pint),C.POINTER(C.c_int)]
        lib.sculpt_subdivide.restype=C.c_int
        lib.sculpt_subdivide_mode.argtypes=lib.sculpt_subdivide.argtypes+[C.c_int]
        lib.sculpt_subdivide_mode.restype=C.c_int
        lib.sculpt_free_xyz.argtypes=[pdouble];lib.sculpt_free_int.argtypes=[pint]
        if not hasattr(lib,'sculpt_propagate') or not hasattr(lib,'sculpt_project'):
            raise RuntimeError('Loaded an outdated native library. Restart Blender and reinstall Sculpt Levels 1.4.1.')
        lib.sculpt_propagate.argtypes=[pdouble,pdouble,C.c_int,pint,pint,C.c_int,pdouble,C.c_int,C.POINTER(pdouble)]
        lib.sculpt_propagate.restype=C.c_int
        lib.sculpt_propagate_mode.argtypes=lib.sculpt_propagate.argtypes+[C.c_int]
        lib.sculpt_propagate_mode.restype=C.c_int
        lib.sculpt_project.argtypes=[pdouble,pdouble,C.c_int,pint,pint,C.c_int,C.c_int,pdouble]
        lib.sculpt_project.restype=C.c_int
        _NATIVE=lib
    return _NATIVE

def subdivide(mesh, linear=False):
    n=len(mesh.vertices); faces=len(mesh.polygons); corners=len(mesh.loops)
    if not n or not faces: raise ValueError('Select a mesh with faces')
    if corners>MAX_FACES or faces>MAX_FACES//4: raise ValueError('Subdivision exceeds the 8 million face safety limit')
    coords=array('d',[0.0])*(3*n); mesh.vertices.foreach_get('co',coords)
    indices=array('i',[0])*corners;mesh.loops.foreach_get('vertex_index',indices)
    starts=array('i',[0])*faces;counts=array('i',[0])*faces
    mesh.polygons.foreach_get('loop_start',starts);mesh.polygons.foreach_get('loop_total',counts)
    offsets=array('i',starts);offsets.append(corners)
    lib=backend();pdouble=C.POINTER(C.c_double);pint=C.POINTER(C.c_int)
    xyz=pdouble();idx=pint();off=pint();nv=C.c_int();nf=C.c_int()
    # from_buffer avoids duplicating the input arrays in Python.
    xbuf=(C.c_double*(3*n)).from_buffer(coords)
    ibuf=(C.c_int*corners).from_buffer(indices)
    obuf=(C.c_int*(faces+1)).from_buffer(offsets)
    status=lib.sculpt_subdivide_mode(xbuf,n,ibuf,obuf,faces,C.byref(xyz),C.byref(nv),C.byref(idx),C.byref(off),C.byref(nf),int(linear))
    if status: raise ValueError({1:'Invalid input',2:'Malformed mesh',3:'Non-manifold edge with more than two faces',4:'Mesh too large',5:'Native allocation failed'}.get(status,'Native error'))
    try:
        result=bpy.data.meshes.new(mesh.name+' / subdivided')
        try:
            result.vertices.add(nv.value)
            result.loops.add(nf.value*4)
            result.polygons.add(nf.value)
            result.vertices.foreach_set('co',C.cast(xyz,C.POINTER(C.c_double*(nv.value*3))).contents)
            result.loops.foreach_set('vertex_index',C.cast(idx,C.POINTER(C.c_int*(nf.value*4))).contents)
            loop_starts=array('i',(i*4 for i in range(nf.value)))
            loop_totals=array('i',[4])*nf.value
            result.polygons.foreach_set('loop_start',loop_starts)
            result.polygons.foreach_set('loop_total',loop_totals)
            result.update(calc_edges=True)
            result['sculpt_levels_parent_vertices']=n
            result['sculpt_levels_parent_faces']=faces
            result['sculpt_levels_linear']=bool(linear)
            return result
        except Exception:
            bpy.data.meshes.remove(result)
            raise
    finally:
        lib.sculpt_free_xyz(xyz);lib.sculpt_free_int(idx);lib.sculpt_free_int(off)

def array_from_mesh(mesh):
    values=array('d',[0.0])*(len(mesh.vertices)*3)
    mesh.vertices.foreach_get('co',values)
    return values

def coordinate_reference(mesh, name):
    """Store just positions; reference meshes never need edges or faces."""
    reference=bpy.data.meshes.new(name)
    try:
        reference.vertices.add(len(mesh.vertices))
        reference.vertices.foreach_set('co',array_from_mesh(mesh))
        reference.update()
        return reference
    except Exception:
        bpy.data.meshes.remove(reference)
        raise

def ensure_references(entry, parent):
    # Older saved projects did not have the reference meshes. Start tracking
    # their current shapes; existing sculpted detail remains in entry.mesh.
    if entry.parent_reference is None:
        entry.parent_reference=coordinate_reference(parent,parent.name+' / level reference')
    if entry.edit_reference is None:
        entry.edit_reference=coordinate_reference(entry.mesh,entry.mesh.name+' / edit reference')

def propagate(parent, reference, child, linear=False):
    """Move a detailed child by the subdivided difference of its parent."""
    n=len(parent.vertices);nf=len(parent.polygons);nc=len(parent.loops)
    if len(reference.vertices)!=n:
        raise ValueError('Parent topology changed; saved detail cannot be propagated')
    p=array('d',[0.0])*(n*3);r=array('d',[0.0])*(n*3)
    parent.vertices.foreach_get('co',p);reference.vertices.foreach_get('co',r)
    if p==r:return False
    faces=array('i',[0])*nc;parent.loops.foreach_get('vertex_index',faces)
    starts=array('i',[0])*nf;parent.polygons.foreach_get('loop_start',starts)
    starts.append(nc)
    high_count=len(child.vertices)
    high=array('d',[0.0])*(high_count*3);child.vertices.foreach_get('co',high)
    lib=backend();output=C.POINTER(C.c_double)()
    code=lib.sculpt_propagate_mode((C.c_double*(n*3)).from_buffer(r),
        (C.c_double*(n*3)).from_buffer(p),n,
        (C.c_int*nc).from_buffer(faces),(C.c_int*(nf+1)).from_buffer(starts),nf,
        (C.c_double*(high_count*3)).from_buffer(high),high_count,C.byref(output),int(linear))
    if code:raise ValueError(f'Native detail propagation failed ({code}); mesh topology may have changed')
    try:
        child.vertices.foreach_set('co',C.cast(output,C.POINTER(C.c_double*(high_count*3))).contents)
        child.update()
        reference.vertices.foreach_set('co',p)
        reference.update()
        return True
    finally:lib.sculpt_free_xyz(output)

def project(parent, parent_reference, child, edit_reference):
    """Move the coarse cage by the smoothed component of a detailed edit."""
    n=len(parent.vertices); nf=len(parent.polygons);nc=len(parent.loops)
    hn=len(child.vertices)
    if len(edit_reference.vertices)!=hn:
        raise ValueError('Higher level topology changed; cannot project edits')
    old=array('d',[0.0])*(hn*3);current=array('d',[0.0])*(hn*3)
    edit_reference.vertices.foreach_get('co',old)
    child.vertices.foreach_get('co',current)
    if old==current:return
    faces=array('i',[0])*nc;parent.loops.foreach_get('vertex_index',faces)
    offsets=array('i',[0])*nf;parent.polygons.foreach_get('loop_start',offsets);offsets.append(nc)
    lower=array('d',[0.0])*(n*3);parent.vertices.foreach_get('co',lower)
    lib=backend()
    code=lib.sculpt_project((C.c_double*(hn*3)).from_buffer(old),
        (C.c_double*(hn*3)).from_buffer(current),hn,
        (C.c_int*nc).from_buffer(faces),(C.c_int*(nf+1)).from_buffer(offsets),n,nf,
        (C.c_double*(n*3)).from_buffer(lower))
    if code:raise ValueError(f'Native coarse projection failed ({code})')
    parent.vertices.foreach_set('co',lower);parent.update()
    # The detailed child already includes the broad move. Synchronize its
    # reference to prevent the same movement being applied twice on return.
    parent_reference.vertices.foreach_set('co',lower);parent_reference.update()
    edit_reference.vertices.foreach_set('co',current);edit_reference.update()

def normalized_history(raw):
    """Remove duplicate parent levels saved by releases before 1.3.2."""
    values=[int(value) for value in raw]
    if len(values)%2:
        raise ValueError('Invalid subdivision history')
    history=[]
    for i in range(0,len(values),2):
        pair=values[i:i+2]
        if history[-2:]!=pair:
            history.extend(pair)
    return history


def reconstruct_lower(mesh):
    """Recover the parent topology from our contiguous face-quads layout."""
    history=normalized_history(mesh.get('sculpt_levels_history',[]))
    if len(history)>=2:
        nv,nf=int(history[-2]),int(history[-1])
    else:
        nv=int(mesh.get('sculpt_levels_parent_vertices',0))
        nf=int(mesh.get('sculpt_levels_parent_faces',0))
    infer=nv<3 or nf<1
    if infer and not mesh.get('sculpt_levels_reconstructed',False):
        raise ValueError('No reconstructable subdivision history on this mesh')
    # Legacy 1.3 meshes stored only the immediate parent. Once we reconstruct
    # it, older parent counts can be inferred from native vertex/face order.
    if nv<3 or nf<1 or nv>=len(mesh.vertices):
        if not infer:raise ValueError('Invalid parent count in the subdivision history')
    nq=len(mesh.polygons)
    if nq>MAX_FACES:
        raise ValueError('The subdivision face layout has changed')
    totals=array('i',[0])*nq;mesh.polygons.foreach_get('loop_total',totals)
    if any(t!=4 for t in totals):
        raise ValueError('Reconstruction needs unmodified quad topology')
    corners=array('i',[0])*(nq*4);mesh.loops.foreach_get('vertex_index',corners)
    if infer:
        nv=min(corners[p*4+1] for p in range(nq))
        nf=sum(p==0 or corners[p*4+2]!=corners[(p-1)*4+2] for p in range(nq))
    if nv<3 or nf<1 or nv>=len(mesh.vertices) or nq<3*nf:
        raise ValueError('This mesh has no recoverable parent topology')
    recovered=[];p=0;previous_center=-1;first_center=corners[2]
    while p<nq:
        center=corners[4*p+2]
        if center!=first_center+len(recovered) or center<=previous_center or center<nv:
            raise ValueError('This mesh is not in the original subdivision order')
        previous_center=center
        verts=[]
        while p<nq and corners[4*p+2]==center:
            a,b,_,d=corners[4*p:4*p+4]
            if a>=nv or a<0 or b<nv or d<nv or b>=first_center or d>=first_center:
                raise ValueError('Subdivision topology has changed')
            verts.append(a)
            p+=1
        if len(verts)<3 or len(set(verts))!=len(verts):
            raise ValueError('Cannot recover the parent face loops')
        recovered.append(verts)
    if len(recovered)!=nf:
        raise ValueError('Subdivision parent face count does not match')
    coords=array_from_mesh(mesh)
    result=bpy.data.meshes.new(mesh.name+' / reconstructed lower')
    try:
        result.vertices.add(nv)
        result.vertices.foreach_set('co',coords[:nv*3])
        nc=sum(len(face) for face in recovered)
        result.loops.add(nc)
        result.polygons.add(nf)
        flat=array('i');starts=array('i');sizes=array('i')
        for face in recovered:
            starts.append(len(flat));sizes.append(len(face));flat.extend(face)
        result.loops.foreach_set('vertex_index',flat)
        result.polygons.foreach_set('loop_start',starts)
        result.polygons.foreach_set('loop_total',sizes)
        result.update(calc_edges=True)
        if len(history)>=4:
            result['sculpt_levels_history']=history[:-2]
            result['sculpt_levels_parent_vertices']=int(history[-4])
            result['sculpt_levels_parent_faces']=int(history[-3])
        linear_history=list(mesh.get('sculpt_levels_linear_history',[]))
        if len(linear_history)>=2:
            result['sculpt_levels_linear_history']=linear_history[:-1]
            result['sculpt_levels_linear']=bool(linear_history[-2])
        result['sculpt_levels_reconstructed']=True
        return result
    except Exception:
        bpy.data.meshes.remove(result)
        raise

def free_unused(meshes):
    for mesh in meshes:
        if mesh is not None and mesh.name in bpy.data.meshes and mesh.users==0:
            bpy.data.meshes.remove(mesh)

def editable_mode(context):
    return (context.object is not None and context.object.type=='MESH'
            and context.mode in {'OBJECT','SCULPT','EDIT_MESH'}
            and (context.mode!='EDIT_MESH' or len(context.objects_in_mode)==1))

def restore_mode(obj, mode, report):
    if mode and obj.mode=='OBJECT':
        try:bpy.ops.object.mode_set(mode=mode)
        except Exception as exc:report({'WARNING'},f'Return to {mode.title()} Mode manually: {exc}')

class SCULPTLEVELS_OT_subdivide(bpy.types.Operator):
    bl_idname='sculpt_levels.subdivide'; bl_label='Subdivide'; bl_description='Create a new editable Catmull-Clark level from the current mesh'; bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):
        return editable_mode(context)
    def execute(self,context):
        obj=context.object;levels=obj.sculpt_level_meshes
        if levels and obj.sculpt_level_index+1<len(levels):
            self.report({'ERROR'},'Move to the highest level before adding a new one')
            return {'CANCELLED'}
        return_mode={'SCULPT':'SCULPT','EDIT_MESH':'EDIT'}.get(context.mode)
        try:
            if return_mode:
                # Leaving the mode writes its latest sculpt or BMesh edits.
                bpy.ops.object.mode_set(mode='OBJECT')
            linear=obj.sculpt_level_method=='LINEAR'
            new=subdivide(obj.data,linear=linear)
            known=[]
            for old_entry in list(levels)[:-1]:
                known.extend((len(old_entry.mesh.vertices),len(old_entry.mesh.polygons)))
            ancestry=normalized_history(obj.data.get('sculpt_levels_history',[]))
            if len(ancestry)<len(known):ancestry=known
            current=[len(obj.data.vertices),len(obj.data.polygons)]
            if ancestry[-2:]!=current:ancestry.extend(current)
            new['sculpt_levels_history']=ancestry
            methods=list(obj.data.get('sculpt_levels_linear_history',[]))
            methods.append(int(linear))
            new['sculpt_levels_linear_history']=methods
            if not levels:
                item=levels.add();item.mesh=obj.data;obj.sculpt_level_index=0
            reference=coordinate_reference(obj.data,obj.data.name+' / level reference')
            edit_reference=coordinate_reference(new,new.name+' / edit reference')
            item=levels.add();item.mesh=new;item.parent_reference=reference;item.edit_reference=edit_reference;item.linear=linear
            obj.data=new;obj.sculpt_level_index=len(levels)-1
            self.report({'INFO'},f'Created level {obj.sculpt_level_index}: {len(new.polygons):,} quads')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}
        finally:
            restore_mode(obj,return_mode,self.report)

class SCULPTLEVELS_OT_switch(bpy.types.Operator):
    bl_idname='sculpt_levels.switch';bl_label='Switch Sculpt Level';bl_options={'REGISTER','UNDO'}
    direction:IntProperty(default=-1)
    @classmethod
    def poll(cls,context):
        return (context.object is not None and context.object.type=='MESH'
                and context.mode in {'OBJECT','SCULPT','EDIT_MESH'}
                and (context.mode!='EDIT_MESH' or len(context.objects_in_mode)==1))
    def execute(self,context):
        obj=context.object;target=obj.sculpt_level_index+self.direction
        if target<0 or target>=len(obj.sculpt_level_meshes):return {'CANCELLED'}
        mesh=obj.sculpt_level_meshes[target].mesh
        if mesh is None:self.report({'ERROR'},'Stored mesh level is missing');return {'CANCELLED'}
        return_mode={'SCULPT':'SCULPT','EDIT_MESH':'EDIT'}.get(context.mode)
        original_mesh=obj.data
        original_level=obj.sculpt_level_index
        try:
            if return_mode:
                bpy.ops.object.mode_set(mode='OBJECT')
            if target<original_level:
                for k in range(original_level,target,-1):
                    entry=obj.sculpt_level_meshes[k]
                    parent=obj.sculpt_level_meshes[k-1].mesh
                    ensure_references(entry,parent)
                    project(parent,entry.parent_reference,entry.mesh,entry.edit_reference)
            if target>original_level:
                for k in range(original_level+1,target+1):
                    parent=obj.sculpt_level_meshes[k-1].mesh
                    entry=obj.sculpt_level_meshes[k]
                    ensure_references(entry,parent)
                    changed=propagate(parent,entry.parent_reference,entry.mesh,entry.linear)
                    if changed and entry.edit_reference is not None:
                        entry.edit_reference.vertices.foreach_set('co',
                            array_from_mesh(entry.mesh))
                        entry.edit_reference.update()
            obj.data=mesh
            obj.sculpt_level_index=target
        except Exception as exc:
            if obj.mode=='OBJECT':
                obj.data=original_mesh
                obj.sculpt_level_index=original_level
            self.report({'ERROR'},f'Could not switch level: {exc}')
            return {'CANCELLED'}
        finally:
            if return_mode and obj.mode=='OBJECT':
                try:
                    bpy.ops.object.mode_set(mode=return_mode)
                except Exception as exc:
                    self.report({'WARNING'},f'Level switched; return to {return_mode.title()} Mode manually: {exc}')
        return {'FINISHED'}

class SCULPTLEVELS_OT_delete_higher(bpy.types.Operator):
    bl_idname='sculpt_levels.delete_higher';bl_label='Delete Higher Levels'
    bl_description='Remove all levels above the current mesh, including sculpt detail stored there'
    bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):
        return editable_mode(context) and context.object.sculpt_level_index+1<len(context.object.sculpt_level_meshes)
    def execute(self,context):
        obj=context.object;levels=obj.sculpt_level_meshes
        pending=[]
        while len(levels)>obj.sculpt_level_index+1:
            entry=levels[-1]
            pending.extend((entry.mesh,entry.parent_reference,entry.edit_reference))
            levels.remove(len(levels)-1)
        free_unused(pending)
        self.report({'INFO'},'Deleted levels above the current level')
        return {'FINISHED'}

class SCULPTLEVELS_OT_delete_lower(bpy.types.Operator):
    bl_idname='sculpt_levels.delete_lower';bl_label='Delete Lower Levels'
    bl_description='Remove all levels below the current mesh; current level becomes level 0'
    bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):
        return editable_mode(context) and context.object.sculpt_level_index>0
    def execute(self,context):
        obj=context.object;levels=obj.sculpt_level_meshes
        known=[]
        for k in range(obj.sculpt_level_index):
            mesh=levels[k].mesh
            known.extend((len(mesh.vertices),len(mesh.polygons)))
        original=list(obj.data.get('sculpt_levels_history',[]))
        ancestry=normalized_history(original)
        if len(known)>len(ancestry):ancestry=known
        if ancestry!=original and ancestry:
            obj.data['sculpt_levels_history']=ancestry
        known_methods=[int(levels[k].linear) for k in range(1,obj.sculpt_level_index+1)]
        if len(known_methods)>len(obj.data.get('sculpt_levels_linear_history',[])):
            obj.data['sculpt_levels_linear_history']=known_methods
        pending=[]
        for _ in range(obj.sculpt_level_index):
            entry=levels[0]
            pending.extend((entry.mesh,entry.parent_reference,entry.edit_reference))
            levels.remove(0)
        obj.sculpt_level_index=0
        # The first surviving level no longer has a parent, so its reference
        # meshes are redundant. Its reconstruction metadata stays on the mesh.
        pending.extend((levels[0].parent_reference,levels[0].edit_reference))
        levels[0].parent_reference=None;levels[0].edit_reference=None
        free_unused(pending)
        self.report({'INFO'},'Current mesh is now the lowest level')
        return {'FINISHED'}

class SCULPTLEVELS_OT_reconstruct(bpy.types.Operator):
    bl_idname='sculpt_levels.reconstruct';bl_label='Reconstruct All Lower Levels'
    bl_description='Reconstruct every recoverable lower level from subdivision history; keep the current detailed mesh'
    bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):
        return (editable_mode(context) and context.object.sculpt_level_index==0
                and (bool(context.object.data.get('sculpt_levels_parent_vertices'))
                     or bool(context.object.data.get('sculpt_levels_history'))
                     or bool(context.object.data.get('sculpt_levels_reconstructed')))
                )
    def execute(self,context):
        obj=context.object;return_mode={'SCULPT':'SCULPT','EDIT_MESH':'EDIT'}.get(context.mode)
        generated=[]
        try:
            if return_mode:bpy.ops.object.mode_set(mode='OBJECT')
            levels=obj.sculpt_level_meshes
            child=obj.data
            stopping_reason=''
            # Every successful pass has fewer vertices, so topology itself
            # bounds the loop without an arbitrary level limit.
            while True:
                try:lower=reconstruct_lower(child)
                except ValueError as exc:
                    stopping_reason=str(exc)
                    break
                generated.append(lower)
                child=lower
            if not generated:
                raise ValueError(stopping_reason or 'No lower level could be reconstructed')
            if not levels:
                entry=levels.add();entry.mesh=obj.data
            for lower in generated:
                current=levels[0]
                if current.parent_reference is None:
                    current.parent_reference=coordinate_reference(lower,lower.name+' / level reference')
                if current.edit_reference is None:
                    current.edit_reference=coordinate_reference(current.mesh,current.mesh.name+' / edit reference')
                current.linear=bool(current.mesh.get('sculpt_levels_linear',False))
                new_entry=levels.add();new_entry.mesh=lower
                levels.move(len(levels)-1,0)
            obj.sculpt_level_index=len(generated)
            message=f'Reconstructed {len(generated)} lower level(s); current detail is unchanged'
            if stopping_reason:message+=f'. Stopped: {stopping_reason}'
            self.report({'INFO'},message)
            return {'FINISHED'}
        except Exception as exc:
            free_unused(generated)
            self.report({'ERROR'},f'Reconstruction failed: {exc}')
            return {'CANCELLED'}
        finally:restore_mode(obj,return_mode,self.report)

class SCULPTLEVELS_PT_panel(bpy.types.Panel):
    bl_label='Sculpt Levels';bl_idname='SCULPTLEVELS_PT_panel';bl_space_type='PROPERTIES';bl_region_type='WINDOW';bl_context='object'
    @classmethod
    def poll(cls,context):return context.object is not None and context.object.type=='MESH'
    def draw(self,context):
        layout=self.layout;obj=context.object;count=len(obj.sculpt_level_meshes)
        layout.label(text=f'Level {obj.sculpt_level_index} of {max(0,count-1)}')
        layout.label(text=f'{len(obj.data.polygons):,} faces')
        edit_ready=context.mode!='EDIT_MESH' or len(context.objects_in_mode)==1
        row=layout.row(align=True);row.enabled=context.mode in {'OBJECT','SCULPT','EDIT_MESH'} and edit_ready
        a=row.row();a.enabled=obj.sculpt_level_index>0;a.operator('sculpt_levels.switch',text='Lower Level',icon='TRIA_DOWN').direction=-1
        b=row.row();b.enabled=obj.sculpt_level_index+1<count;b.operator('sculpt_levels.switch',text='Higher Level',icon='TRIA_UP').direction=1
        row=layout.row();row.enabled=context.mode in {'OBJECT','SCULPT','EDIT_MESH'} and edit_ready and len(obj.data.loops)<=MAX_FACES
        row.prop(obj,'sculpt_level_method',text='Method')
        row.operator('sculpt_levels.subdivide',text='Subdivide',icon='MOD_SUBSURF')
        box=layout.box();box.label(text='Level Management')
        row=box.row(align=True);row.enabled=edit_ready
        a=row.row();a.enabled=obj.sculpt_level_index>0;a.operator('sculpt_levels.delete_lower',text='Delete Lower')
        b=row.row();b.enabled=obj.sculpt_level_index+1<count;b.operator('sculpt_levels.delete_higher',text='Delete Higher')
        row=box.row();row.enabled=edit_ready and obj.sculpt_level_index==0 and (
            bool(obj.data.get('sculpt_levels_parent_vertices'))
            or bool(obj.data.get('sculpt_levels_history'))
            or bool(obj.data.get('sculpt_levels_reconstructed')))
        row.operator('sculpt_levels.reconstruct',text='Reconstruct All Lower',icon='MOD_DECIM')

classes=(SculptLevelEntry,SCULPTLEVELS_OT_subdivide,SCULPTLEVELS_OT_switch,
    SCULPTLEVELS_OT_delete_higher,SCULPTLEVELS_OT_delete_lower,
    SCULPTLEVELS_OT_reconstruct,SCULPTLEVELS_PT_panel)
def register():
    for cls in classes:bpy.utils.register_class(cls)
    bpy.types.Object.sculpt_level_meshes=CollectionProperty(type=SculptLevelEntry)
    bpy.types.Object.sculpt_level_index=IntProperty(default=0,min=0)
    bpy.types.Object.sculpt_level_method=EnumProperty(name='Subdivision',items=(
        ('SMOOTH','Smooth','Catmull-Clark smooth subdivision'),
        ('LINEAR','Linear','Split each face into quads without smoothing')),
        default='SMOOTH')
def unregister():
    del bpy.types.Object.sculpt_level_method
    del bpy.types.Object.sculpt_level_index;del bpy.types.Object.sculpt_level_meshes
    for cls in reversed(classes):bpy.utils.unregister_class(cls)

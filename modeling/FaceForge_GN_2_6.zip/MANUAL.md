# FaceForge GN 2.6 — artist and pipeline guide

## Rig setup and persistence

Initialize the production neutral before creating targets. Mesh data is made single-user at initialization. A rest-position attribute, topology fingerprint and one managed GN modifier are created. Deltas and authoring references live on the mesh itself, so baked targets do not depend on external files or target objects. Save the .blend normally.

Keep FaceForge at the top of the modifier stack. The output is input geometry plus facial displacement, preserving downstream UVs, materials and armature deformation. This release manages one facial network on each mesh; it does not provide the demo's multi-deformer stack manager.

The **Rig** field remains available while another target mesh is selected. Clear the pin to follow the selected object. Search matches channel/target names; group filter matches channel groups. Active-only and mixer pages keep large rigs manageable. Gain, mute, channel values and envelope update immediately. Stage, mask, source and interpolation edits trigger a network rebuild. Failed rebuilds display a red diagnostic while the last successful graph is retained where possible.

## Primary authoring: your neutral to jawOpen

Select the neutral mesh, open N → FaceForge and click **Initialize Neutral**. Click **New Shape**, enter `jawOpen`, choose **Sculpt** or **Edit**, and confirm. Creation immediately opens an isolated working copy in the chosen mode. Move vertices or use your normal sculpt brushes. Click **Done** in FaceForge to commit. The neutral becomes visible again and the channel is set to 1.0 automatically.

**Edit** and **Sculpt** switch modes within the same session. Tab is also available through Blender. Done flushes Edit Mode data before reading the mesh. Vertex count/order/connectivity must remain unchanged. Do not use Dyntopo, Remesh, extrusion, deletion or applied subdivision. The working copy uses base mesh topology; downstream rig modifiers are not copied into the authoring session.

**Cancel** restores the pre-session mixer values and envelope. It preserves an existing shape unchanged; when cancelling a newly created shape it removes that target and any channel introduced by that creation. Done previews the edited target in isolation, unmutes it, and sets envelope to 1.0. Other targets' mute settings remain unchanged. Preview This Shape sets the selected target's authoring driver values. If it is muted or the envelope is zero, use Target tools & settings / Pipeline to restore visibility.

The session data lives in the .blend. Save normally; unfinished working sessions can be reopened and completed with the addon enabled. A topology error keeps the working mesh available for repair or Cancel. Do not manually delete the session object or target while editing.

## In-betweens and interpolation

Zero unrelated channels, put the desired parent slider at 0.5 and click **Edit** or **Sculpt** under EDIT CURRENT MIX. The addon automatically creates or reopens that stage; target-list selection does not affect this choice. The default starting mesh is the parent's isolated interpolated pose at that weight. Edit it and click Done. The original channel now passes through your new shape at 0.5. Other active channels are excluded when authoring an ordinary in-between.

An in-between is an **absolute** neutral-relative stage. It does not automatically follow later changes to the hero shape. There is no Maya-style relative in-between mode in this release. Multiple stages on one channel interpolate; they are not separate additive animator controls. Zero and duplicate stage weights are rejected. Automatic single-channel authoring accepts finite nonzero stage weights, including values beyond ±1. Imported names such as `jawOpen_N` also remain supported. Channel slider ranges are selectable soft 0–1 or −1–1 bounds. Type outside them to exaggerate. Each authored branch extrapolates with its final segment slope beyond its last stage. Without a negative branch, negative values invert the first positive segment, and vice versa.

Select a stored stage and choose **Curved** directly below the list. Curved uses a natural cubic spline through the neutral and authored stages, preserving the exact stage positions with continuous first and second derivatives across each signed branch. Paths are inferred entirely from the sculpts and their channel weights, with no bend direction or world-scale parameter. A neutral plus a single target remains straight; add an inbetween to describe an arc. Collinear samples cannot define an off-line arc. Preview between stored weights to see the change. Outside the authored range the end tangent continues linearly, with a smooth join. Signed branches are independent and can have different tangents at zero. Natural cubic interpolation may overshoot; it is not a collision or volume solver.

## Combination correctives

Pose at least two channels, then click **Edit** or **Sculpt** under EDIT CURRENT MIX. All nonzero channel values become activation peaks. A matching stored corrective is reopened; otherwise a new Product corrective is named and created automatically. Its driver values appear above the buttons. Product/Minimum remains adjustable in Target tools & settings. The session shows the combined shape. Sculpt only the fix, then click Done. The stored delta is the edited result minus the pre-correction pose, so it does not apply the underlying shapes twice.

Product multiplies normalized signed driver activations; Minimum uses the smallest activation. Both saturate at their peaks. A driver with a negative peak responds to that negative side. If any driver is zero or on the opposite side, the correction vanishes. Correctives have no independent animator slider. Their gain and mute controls live in Target tools & settings.

This is a saturated combination model, not a local radial pose-space/RBF solver. A corrective at 0.5 remains fully active beyond 0.5 when its other drivers are active. Several corrective targets with the same drivers are additive, not automatic corrective in-betweens. Use unique intentional corrections and review the full range.

Creating a higher-order combo subtracts the entire currently evaluated network at its driver pose, including existing active correction residuals. Editing an existing combo builds its reference from the network with that combo excluded. Changing a primary preserves correction deltas; re-enter Edit/Sculpt on affected combos to review them. Drivers refer to primary channels, not other corrective objects. Their names/peaks are displayed as readable labels; raw driver JSON is not exposed in the artist UI.

## Live meshes and modifier targets

Add selected meshes automatically interprets production names. Primary stages are connected live by default; imported combination objects are stored as residuals. A live mesh's evaluated local positions are sampled by vertex index, subtracting a stored authoring reference. Object translation/rotation/scale for display is ignored, so meshes can be arranged beside the rig.

Topology-preserving modifiers on live sources can update the target. Topology-changing source modifiers are rejected during connection/rebuild/validation. Changes to a live source after connection can invalidate it, so Validate after changing modifiers. Never create a dependency cycle or use the rig itself as its source.

**Freeze** stores the evaluated displacement and disconnects the source. Freeze before deleting live sources. Baked targets survive source deletion; live targets cannot be expected to survive source deletion without freezing.

A manually connected live corrective is an absolute sculpted pose minus its stored authoring reference. Freeze/re-sculpt if its activating pose changes substantially.

## Masks

Select a target, assign a vertex group or click Paint mask. New masks start at weight 1 so the shape remains visible before painting. Zero removes displacement; one keeps it. Invert swaps weights. Blur performs repeated edge-neighbour averaging; iterations affect spread. This also smooths across any mesh connections that exist, so inspect the result around mouth and eyelid seams.

In an Edit/Sculpt session, the working shape includes the current mask and gain. Commit solves the edited displacement back through those weights. Zero-weight vertices cannot affect the target; moving them is rejected with the session retained. Cancel, change the mask and retry if you need to author there. Gain must be above zero to edit.

Bake mask multiplies the stored displacement by the current mask and removes the mask assignment. It freezes a live source first. Gain remains separate. Mask painting updates the GN vertex-group attribute without rebuilding at every brush stroke.

## Split and mirror

Split produces complementary positive-X (`_L`) and negative-X (`_R`) channel targets. Labels follow local X conventions, not an inferred anatomical left/right. The centre is half-weight. Transition width uses local mesh units. Their summed displacements recover the effective original target. **The original is retained**: mute it when using the split channels to avoid additive duplication. Primary/progressive stages are supported; recreate the desired split-channel combos separately.

Mirror uses a nearest-vertex mapping on the neutral reflected across local X=0. It requires a bijection and every match within tolerance. Asymmetric neutrals are rejected rather than silently matching unrelated vertices. Set Mirror target name and Mirror channel above the Mirror button. The selected stage's mask and gain are baked into the mirrored displacement. Mirroring combo driver semantics is not automatic.

## Revised neutral

Make a neutral copy with identical indexed topology, revise it and select that copy while the old rig is pinned. Update base replaces the neutral positions and adds the neutral revision to stored authoring references. Existing displacement deltas remain unchanged. Live sources are frozen first.

This is additive propagation, not local deformation-gradient adaptation. A radically different head proportion needs transfer and sculpt review. Directly editing the initialized neutral triggers a validation error. For an accidental sculpt, choose **Import / Export & Pipeline → Recover Edits to Neutral**, name the recovered shape and confirm. It captures the current base coordinates as a new primary and restores the saved neutral. For an intended neutral redesign, use Update Base from Selected Neutral. Vertex-count/connectivity/order fingerprints detect structural changes, but cannot prove semantic vertex correspondence if somebody permutes vertices while preserving an identical graph representation.

## Named mesh and OBJ network import

Set **Rig** to an initialized neutral and select target meshes in Object Mode. **Import / Export & Pipeline → Add Shapes from Selected Meshes** imports their local-space coordinates as stored targets. It validates indexed topology and rejects duplicate names/stages. The main import no longer creates live links automatically; explicit live-source controls remain available under Target tools & settings.

**Build Network from OBJ Folder** creates a new rig. A blank neutral name finds one `home`, `neutral`, `base` or `basis` OBJ. If multiple candidates exist, enter the exact neutral filename/stem. A custom scene mesh can supply the neutral instead; its data is copied. If the folder also includes a custom-named neutral OBJ, enter its name so it is excluded from the targets. **Import OBJ Shapes** adds targets to an existing rig. Package manifests take precedence over filename inference and the mode dropdown.

Raw OBJ creation reads geometry only. UVs/materials are retained when supplying a scene neutral, but are not reconstructed from raw OBJ material libraries. Coordinates use unchanged Blender local axes and units. Preserve vertex order when moving between Maya/ZBrush/Blender.

| Target name | Meaning |
|---|---|
| `jawOpen` | Primary at +1 |
| `jawOpen_50` | Stage at 0.5 |
| `jawOpen_N` | Stage at -1 |
| `jawopen_eyesClosed` | Combo at jawOpen=1, eyesClosed=1 |
| `jawOpen_50_eyesClosed` | Combo at jawOpen=0.5, eyesClosed=1 |
| `jawOpen_20_eyesClosed_80` | Combo at jawOpen=0.2, eyesClosed=0.8 |
| `jawOpen+eyesClosed` | Explicit separator for a full combo |
| `mouth_smile_L_50` | Stage on full channel name mouth_smile_L |

The importer resolves full primary names before numeric stage tokens. Case variants can refer to a uniquely named existing channel. Separate primary channels differing only by case are rejected. Include the primary meshes or use an existing rig with those channels. Ambiguous naming requires renaming or a manifest; names do not infer anatomy.

## Export: Combined versus Difference

**Export Shapes** writes all targets using readable target filenames, a neutral OBJ and a schema-2 `faceforge.json`. Choose a fresh folder; no existing exports are overwritten. Filename sanitization collisions are rejected. Export leaves the current mixer, pose sliders, mute states and envelope unchanged. Geometry definitions ignore preview mutes and envelope; target masks/gains are included.

**Combined poses** evaluate every primary, in-between and corrective at the target's specified channel values. At `jawOpen_50`, the one-channel interpolation returns the authored 0.5 shape. At `jawOpen_50_eyesClosed`, both channels and every active corrective are evaluated. This is the final combined network output, rather than only the corrections preceding the target in a list.

**Shape differences** write a conventional mesh with the neutral as its base:

- Primary: neutral + its effective displacement.
- In-between: neutral + its effective stage displacement minus the full same-signed primary displacement multiplied by the absolute stage weight. For a 0.5 stage, the comparison is the primary at half strength. Other in-betweens are not part of this baseline. If no full same-signed primary exists, the baseline is zero.
- Combo: neutral + only that target's effective corrective residual, excluding primary motion and other corrective contributions.

A difference file therefore preserves the mesh silhouette around neutral and can be sculpted externally. It does not contain bare vectors around the origin. Import with **Shape differences**, or preserve the manifest so the mode is automatic. Signed primary endpoints are imported before intermediate differences.

Combined combo files may contain each other's influence. On import the addon solves their activation matrix together to recover residuals. Linearly dependent/duplicate corrective poses cannot uniquely recover those differences and are rejected; use Difference export in that case. Arbitrary artist-supplied combined sculpts define the network at their named poses. Review interpolation between them.

Schema-1 packages from older versions remain supported through their original hierarchical importer. New schema-2 packages carry mode, channel paths, signed driver weights and stored poses. Masks/gains are flattened into the exported geometry. External live connections and animation actions are not exported.

## Different topology transfer

Pin the source and select exactly one clean destination mesh. Align neutral surfaces in world space and set Transfer max distance. The tool constructs source neutral triangles, finds each destination vertex's nearest triangle, interpolates source displacements barycentrically, then transforms those vectors into destination-local coordinates. Channel structure, interpolation, combo residuals, effective masks and poses transfer; live connections become stored deltas.

Every destination vertex must fall within max distance before initialization begins. This distance uses world-space Blender units. Nearest-surface mappings are prone to matching opposing lips, eyelid/eyeball-adjacent regions and thin folds. The tool does not understand facial anatomy, UV seams or landmarks. Review all targets. It is not the Sumner–Popović gradient-optimization method, and there is no claim of guaranteed production-perfect retargeting.

## Poses and animation

Set shape channels, enter a unique Pose name and **Store**. Every stored pose has a 0–1 weight slider. Weighted channel values add across active poses without a [-1,1] clamp. **Apply** solos the selected pose. **All Poses Off** zeros all channels. **Update Stored Pose** replaces the selected pose's channel snapshot with the current mix. Delete removes the pose and recomputes the remaining active mix.

Manual channel editing detaches all pose sliders while retaining the current channel values. Done after shape authoring detaches pose sliders to preview the edited target; Cancel restores the prior channel values and pose weights. Pose sliders are for authoring/review; key the resulting shape channels with **Key Pose** for animation. Envelopes, mutes and gains are not part of a stored pose.

Bake sampled animation creates a NEW mesh with Basis plus one key per integer frame in the requested range. Keys are animated with piecewise-linear weights to reconstruct those samples. Source GN rig and action remain intact. Downstream armature/subdivision modifiers are not copied; the bake represents pre-armature facial deformation. Fractional frames only linearly interpolate neighbouring samples and do not exactly reproduce curved trajectories. Memory grows with frames × vertices; the hard range limit is 10001 samples, but use a much smaller range on dense meshes. Source geometry must retain its indexed topology.

## Validation and recovery

Validate checks topology, attributes, channel/stage expressions, masks, live evaluated topology and modifier placement. Rebuild regenerates the graph and driver sockets. Rename/remove shape targets through this panel. The UI prevents unrelated rig mutations during an active sculpt session. Done rejects changed working topology and keeps the working mesh; Cancel restores the rig visibility and previous mix.

This release has automated Blender integration coverage, not a full production show trial. Keep ordinary .blend revisions before restructuring a large rig. Existing native facial controllers, camera tracking, wrinkle maps, FACS semantics, RBF solving, collision, corrective transfer optimization and multi-layer deformer management are outside this release.

## Selecting a stored target explicitly

The main Edit/Sculpt buttons always use the current mixer. To edit a selected stored target regardless of the mixer, expand **Target tools & settings → Edit Selected Target (ignores mixer)**. If multiple legacy targets have identical combo driver peaks, use this explicit route to choose which one to revise. Pose matches use a 0.00001 tolerance; negligible slider noise is treated as zero.

## 2.5 curve migration

Existing GN graphs rebuild automatically when the addon is enabled or a file opens. Old tension, tangent strength, bulge and bend-direction fields are retained internally for file compatibility but ignored. No user adjustment is needed. Existing intermediate poses change to the new interpolation. Authored channel stages remain exact. Correctives are stored residuals, so review them when migrating a rig previously using Curved: their original underlying pose may differ. You can revert the addon using your saved original file if you need the previous evaluation. Corrective activations still saturate at their specified peaks.

## Organizing large rigs

Use the shared search, group dropdown, type and active filters above the mixer. Assign Group on the stored list supports a selected family or the entire filtered set. Inbetweens inherit their channel group; corrective combinations have their own group. Sort by family, name or group, or choose Custom and use the arrows. Filters do not delete or disable shapes. Quickset still uses the actual stored stage/driver weights regardless of sorting. X clears filters.

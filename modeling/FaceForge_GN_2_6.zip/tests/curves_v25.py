import sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy,numpy as np
import faceforge_gn as F
from faceforge_gn import engine as E,pipeline as P
from faceforge_gn.core import basis
F.register()
knots=[(.2,'a'),(.65,'b'),(1.,'c')]
curves=basis(knots,'CURVED',extrapolate=True)
def coeff(w):return np.array([curves[u].evaluate({'w':w}) for _,u in knots])
for w in [.2,.65,1.]:
 h=1e-4;a=coeff(w-2*h);b=coeff(w-h);c=coeff(w);d=coeff(w+h);e=coeff(w+2*h)
 np.testing.assert_allclose((c-b)/h,(d-c)/h,atol=.012)
 np.testing.assert_allclose((c-2*b+a)/h**2,(e-2*d+c)/h**2,atol=.06)
print('PASS C2 continuity at uneven stages and tangent extrapolation join')
normalized=[]
for scale in [1e-6,1.,1e6]:
 bpy.ops.mesh.primitive_monkey_add();o=bpy.context.object;E.put_coords(o.data,E.coords(o.data)*scale);E.initialize(o)
 rest=E.coords(o.data);deltas=[]
 for (weight,name),delta in zip(knots,[(.2,.35,0),(.65,.6,.1),(1,0,.2)]):
  p=rest.copy();p[0]+=np.array(delta)*scale;deltas.append(p-rest);E.add(o,name,p,ch='jawOpen',weight=weight)
 c=o.ffgn.channels[0];c.interpolation='CURVED';E.rebuild(o)
 def actual(w):
  c.value=w;o.update_tag();bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh()
  try:return E.coords(m)
  finally:ev.to_mesh_clear()
 results=[]
 for w in [-.25,0,.1,.2,.4,.65,.8,1,1.3]:
  p=actual(w);np.testing.assert_allclose(p/scale,E.evaluate(o)/scale,atol=3e-5)
  results.append((p-rest)/scale)
  if w in [.2,.65,1]:np.testing.assert_allclose((p-rest)/scale,deltas[[.2,.65,1].index(w)]/scale,atol=2e-5)
 normalized.append(results)
 c.value=.4;curved=actual(.4);c.interpolation='LINEAR';linear=actual(.4);assert np.linalg.norm((curved-linear)[0]/scale)>.02;c.interpolation='CURVED'
 # Old bulge/axis values no longer affect the new solver.
 before=actual(.4);c.arc_bulge=100;c.arc_axis=(0,0,0);c.tension=1;c.arc_strength=0
 np.testing.assert_allclose(actual(.4)/scale,before/scale,atol=2e-5)
 if scale==1:
  folder=Path(tempfile.mkdtemp());P.export_network(o,folder);copy=P.build_folder(bpy.context,folder)
  for w in [.1,.4,.8,1.3]:np.testing.assert_allclose(E.evaluate(o,{'jawOpen':w}),E.evaluate(copy,{'jawOpen':w}),atol=2e-5)
  mod=next(m for m in o.modifiers if m.type=='NODES');mod.node_group['ffgn_curve_version']=24;F.upgrade_curves();assert mod.node_group['ffgn_curve_version']==25
for other in normalized[1:]:np.testing.assert_allclose(normalized[0],other,atol=4e-5)
print('PASS actual GN scale invariance 1e-6 to 1e6, exact stages, spatial curves, legacy-control independence, pipeline and migration')
# With only two samples the honest solution is a straight line.
for w in [-.5,.25,1.5]:assert abs(basis([(1,'a')],'CURVED',extrapolate=True)['a'].evaluate({'w':w})-w)<1e-9
print('ALL 2.5 CURVE TESTS PASSED',bpy.app.version_string)

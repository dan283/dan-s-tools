"""Run: blender --background --factory-startup --python tests/blender_integration.py
Or use a matching official bpy wheel: python tests/blender_integration.py.
"""
import sys, tempfile, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy
import numpy as np
import faceforge_gn as F
from faceforge_gn import engine as E
F.register()

def mesh(name,vertices=None):
    me=bpy.data.meshes.new(name)
    v=vertices or [(-1,0,0),(1,0,0),(1,1,0),(-1,1,0)]
    me.from_pydata(v,[],[tuple(range(len(v)))])
    ob=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(ob); return ob

def actual(o):
    o.update_tag(); bpy.context.view_layer.update()
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get()); me=ev.to_mesh()
    try: return E.coords(me)
    finally: ev.to_mesh_clear()

def close(a,b): np.testing.assert_allclose(a,b,atol=3e-5,rtol=3e-5)

o=mesh('Neutral'); E.initialize(o); rest=E.coords(o.data).copy()
a=rest.copy(); a[:,2]+=.7
b=rest.copy(); b[:,1]+=.4
half=rest.copy(); half[:,2]+=.5; half[:,1]+=.1
negative=rest.copy(); negative[:,2]-=.3
E.add(o,'jawOpen',a,ch='jawOpen'); E.add(o,'smile',b,ch='smile')
E.add(o,'jawOpen_50',half,ch='jawOpen',weight=.5); E.add(o,'jawOpen_N',negative,ch='jawOpen',weight=-1.)
combo=a+b-rest; combo[:,0]+=.2
ct=E.add(o,'jawOpen+smile',combo,'COMBO',drivers=[('jawOpen',1.),('smile',1.)]); E.rebuild(o)
for interp in ['LINEAR','CURVED']:
    o.ffgn.channels['jawOpen'].interpolation=interp; E.rebuild(o)
    for x in [-1,-.6,0,.25,.5,.75,1]:
        for y in [0,.35,1]:
            o.ffgn.channels['jawOpen'].value=x; o.ffgn.channels['smile'].value=y
            close(actual(o),E.evaluate(o))
print('PASS: GN / evaluator agreement: 42 signed, progressive, curved, combo poses')
o.ffgn.channels['jawOpen'].value=1; o.ffgn.channels['smile'].value=1
close(actual(o),combo)
ct.mute=True; close(actual(o),a+b-rest); ct.mute=False; ct.gain=.5; close(actual(o),a+b-rest+(combo-(a+b-rest))*.5); ct.gain=1
print('PASS: live mute and gain drivers')
g=o.vertex_groups.new(name='mouth'); g.add([0,1],1.,'REPLACE'); ct.mask=g.name; E.rebuild(o)
close(actual(o),E.evaluate(o)); ct.invert_mask=True; E.rebuild(o); close(actual(o),E.evaluate(o)); ct.mask=''; ct.invert_mask=False
# Live source in object-local space: moving the object should not change its facial delta.
src=mesh('live',a.tolist()); src.location=(6,3,2)
lt=E.add(o,'live',a,ch='live',source=src); E.rebuild(o)
o.ffgn.channels['jawOpen'].value=0; o.ffgn.channels['smile'].value=0; o.ffgn.channels['live'].value=1
close(actual(o),a)
src.data.vertices[0].co.z+=.2; src.data.update(); close(actual(o),E.evaluate(o))
E.freeze(o,lt); E.rebuild(o); baked=actual(o); bpy.data.objects.remove(src,do_unlink=True); close(actual(o),baked)
print('PASS: mask / live sculpture / object transform independence / freeze and deletion')
# Package round trip, with non-default curve tension and masked contributions.
o.ffgn.channels['jawOpen'].tension=.15; E.rebuild(o)
package=Path(tempfile.mkdtemp())/'package'; E.export_package(o,package)
dest=mesh('Imported'); E.initialize(dest); E.import_package(dest,package)
for x,y,z in [(.25,.4,0),(.75,1,1),(-.5,0,.25),(1,1,0)]:
    for ob in [o,dest]:
        for c in ob.ffgn.channels: c.value={'jawOpen':x,'smile':y,'live':z}[c.name]
    close(actual(o),actual(dest))
print('PASS: absolute OBJ + manifest round trip including corrective residuals')
# Symmetric neutral mapping and complementary split sum.
idx=E.mirror_map(o,.0001); assert len(set(idx))==4
stage=o.ffgn.targets[0]; E.split(o,stage,.2)
left=o.ffgn.targets[-2]; right=o.ffgn.targets[-1]
close(E.attr(o.data,left.attribute)+E.attr(o.data,right.attribute),E.attr(o.data,stage.attribute))
print('PASS: mirror bijection and complementary split')
# Different vertex count transfer.
retopo=mesh('Retopo',[(-1,0,0),(1,0,0),(0,1,0)])
E.transfer(dest,retopo,.001)
for c in retopo.ffgn.channels: c.value=1. if c.name=='jawOpen' else 0.
expected=E.coords(retopo.data).copy(); expected[:,2]+=.7
close(actual(retopo),expected)
print('PASS: different topology barycentric displacement transfer')
# Ensure failed topology import does not mutate an empty rig.
bad=mesh('Wrong topology'); E.initialize(bad); bad.data.vertices.add(1)
try: E.check(bad); raise AssertionError('Expected topology rejection')
except ValueError: pass
print('PASS: changed topology rejection')
# Key channels, bake via the public operator and validate its output.
bpy.context.scene.ffgn_settings.owner=dest
s=bpy.context.scene.ffgn_settings; s.bake_start=1; s.bake_end=3
for c in dest.ffgn.channels:
    c.value=0; c.keyframe_insert('value',frame=1)
    c.value=.8; c.keyframe_insert('value',frame=3)
assert bpy.ops.ffgn.action(action='BAKE')=={'FINISHED'}
baked=bpy.context.object
for fr in range(1,4):
    bpy.context.scene.frame_set(fr); close(actual(baked),actual(dest))
print('PASS: sampled native key animation bake')
# UI operators: new target, isolated sculpt commit, pose, rebuild.
s.owner=dest; s.new_name='browUp'
assert bpy.ops.ffgn.action(action='NEW')=={'FINISHED'}
assert bpy.ops.ffgn.action(action='EDIT')=={'FINISHED'}
s.edit_object.data.vertices[0].co.z+=.1
assert bpy.ops.ffgn.action(action='COMMIT')=={'FINISHED'}
dest.ffgn.channels['browUp'].value=1
close(actual(dest),E.evaluate(dest))
s.new_name='TestPose'; assert bpy.ops.ffgn.action(action='POSE_SAVE')=={'FINISHED'}
assert bpy.ops.ffgn.action(action='ZERO')=={'FINISHED'}
assert bpy.ops.ffgn.action(action='POSE_APPLY')=={'FINISHED'}
assert bpy.ops.ffgn.action(action='VALIDATE')=={'FINISHED'}
print('PASS: public operator sculpt/commit and pose workflow')
print('ALL BLENDER INTEGRATION CHECKS PASSED',bpy.app.version_string)
# Extra production cases: painted masks/gain exports and neutral updates.
dest.animation_data.action=None  # Static pose tests must not be overridden by the preceding animation bake fixture.
maskgroup=dest.vertex_groups.new(name='export_mask'); maskgroup.add([0,1],1.,'REPLACE')
hero=dest.ffgn.targets[0]; hero.mask=maskgroup.name; hero.gain=.75
E.blur_mask(dest,hero,2); E.rebuild(dest)
package2=Path(tempfile.mkdtemp())/'masked'; E.export_package(dest,package2)
d2=mesh('Masked Imported'); E.initialize(d2); E.import_package(d2,package2)
for ob in [dest,d2]:
    for c in ob.ffgn.channels: c.value=.6 if c.name in {'jawOpen','smile'} else 0.
close(actual(dest),actual(d2))
print('PASS: mask/gain flattened into portable absolute packages')
# Signed, partial-peak combo and higher-order residual ordering.
E.add(dest,'signedPose',E.evaluate(dest,{'jawOpen':-.5,'smile':.7},envelope=False)+.01,'COMBO',drivers=[('jawOpen',-.5),('smile',.7)],mode='MINIMUM')
E.rebuild(dest)
package3=Path(tempfile.mkdtemp())/'signed'; E.export_package(dest,package3)
d3=mesh('Signed Imported'); E.initialize(d3); E.import_package(d3,package3)
for ob in [dest,d3]:
    for c in ob.ffgn.channels: c.value={'jawOpen':-.3,'smile':.4}.get(c.name,0.)
close(actual(dest),actual(d3)); print('PASS: signed partial-peak minimum corrective round trip')
# Base revision propagates unchanged deltas, including correction references.
old=E.evaluate(d3); new=E.coords(d3.data)+np.array([.05,0,.03],dtype=np.float32)
revision=E.mesh_object(d3,'Revision',new)
bpy.ops.object.select_all(action='DESELECT'); revision.select_set(True); bpy.context.view_layer.objects.active=revision
s.owner=d3
assert bpy.ops.ffgn.action(action='UPDATE_BASE')=={'FINISHED'}
close(E.evaluate(d3),old+np.array([.05,0,.03])); close(actual(d3),E.evaluate(d3))
print('PASS: revised neutral propagation without changed shape deltas')
# Blender .blend persistence and driver paths.
name=d3.name; expected=E.evaluate(d3); filename=Path(tempfile.mkdtemp())/'persistence.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(filename)); bpy.ops.wm.open_mainfile(filepath=str(filename))
loaded=bpy.data.objects[name]; close(actual(loaded),expected)
assert len([m for m in loaded.modifiers if m.type=='NODES'])==1
print('PASS: save/reopen persistence, single deformer, functioning drivers')
print('EXTENDED INTEGRATION CHECKS PASSED',bpy.app.version_string)

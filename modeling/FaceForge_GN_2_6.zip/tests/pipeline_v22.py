import sys,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy,numpy as np
import faceforge_gn as F
from faceforge_gn import engine as E,authoring as A,pipeline as P
from faceforge_gn.core import parse_names
F.register()
def mesh(name):
    m=bpy.data.meshes.new(name);m.from_pydata([(-1,0,0),(1,0,0),(1,1,0),(-1,1,0)],[],[(0,1,2,3)])
    o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);return o
def close(a,b):np.testing.assert_allclose(a,b,atol=3e-5,rtol=3e-5)
def actual(o):
    o.update_tag();bpy.context.view_layer.update();e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=e.to_mesh()
    try:return E.coords(m)
    finally:e.to_mesh_clear()
names=['jawOpen','eyesClosed','jawOpen_50','jawopen_eyesClosed','jawOpen_50_eyesClosed']
specs={s['name']:s for s in parse_names(names)}
assert specs['jawOpen_50']['weight']==.5
assert specs['jawopen_eyesClosed']['drivers']==[('jawOpen',1),('eyesClosed',1)]
assert specs['jawOpen_50_eyesClosed']['drivers']==[('jawOpen',.5),('eyesClosed',1)]
assert parse_names(['jawOpen_50_eyesClosed'],['jawOpen','eyesClosed'])[0]['kind']=='COMBO'
print('PASS: supplied naming examples and existing-rig resolution')
o=mesh('Reference');E.initialize(o);rest=E.coords(o.data)
jaw=rest.copy();jaw[:,2]-=.4
E.add(o,'jawOpen',jaw,ch='jawOpen')
eye=rest.copy();eye[0,1]+=.2
E.add(o,'eyesClosed',eye,ch='eyesClosed')
half=rest+(jaw-rest)*.5;half[1,1]+=.08
E.add(o,'jawOpen_50',half,ch='jawOpen',weight=.5)
for name,weight,delta in [('jawopen_eyesClosed',1,.03),('jawOpen_50_eyesClosed',.5,.07)]:
    p=E.evaluate(o,{'jawOpen':weight,'eyesClosed':1});p[2,0]+=delta
    E.add(o,name,p,'COMBO',drivers=[('jawOpen',weight),('eyesClosed',1)])
E.rebuild(o)
# Modifier controls identify type, channel weights and target name, without opaque UIDs.
g=o.modifiers[0].node_group
panels=[x.name for x in g.interface.items_tree if x.item_type=='PANEL']
assert any('In-between | jawOpen @ 0.5' in x for x in panels)
assert any('Combo | jawOpen @ 0.5 + eyesClosed @ 1' in x for x in panels)
assert not any(t.uid in n for t in o.ffgn.targets for n in panels)
close(actual(o),E.evaluate(o));print('PASS: readable GN panels and functioning drivers')
root=Path(tempfile.mkdtemp())
for mode in ['COMBINED','DIFFERENCE']:
    folder=root/mode;P.export_network(o,folder,mode)
    stage,_=E.read_obj(folder/'jawOpen_50.obj')
    close(stage,half if mode=='COMBINED' else rest+half-rest-(jaw-rest)*.5)
    combo=o.ffgn.targets[-1];p,_=E.read_obj(folder/(combo.name+'.obj'))
    close(p,E.evaluate(o,E.target_pose(combo),envelope=False) if mode=='COMBINED' else rest+P.effective(o,combo))
    dest=mesh(mode);E.initialize(dest);P.import_folder(dest,folder)
    for x,y in [(0,0),(.2,.8),(.5,1),(1,1),(.75,.4)]:
        pose={'jawOpen':x,'eyesClosed':y};close(E.evaluate(o,pose),E.evaluate(dest,pose));A.pose(dest,pose);close(actual(dest),E.evaluate(dest))
print('PASS: combined and difference exports reconstruct the same full corrective network')
# Named meshes use their local vertex positions, independent of display placement.
sources=[]
for t in o.ffgn.targets:
    ob=E.mesh_object(o,t.name,E.evaluate(o,E.target_pose(t),envelope=False));ob.location.x=8;sources.append(ob)
d=mesh('Mesh import');E.initialize(d);P.import_meshes(d,sources)
close(E.evaluate(o,{'jawOpen':.5,'eyesClosed':1}),E.evaluate(d,{'jawOpen':.5,'eyesClosed':1}))
print('PASS: selected meshes build primary/in-between/weighted-combo targets')
# Raw folder neutral discovery and explicit custom filename/scene neutral paths.
raw=root/'raw';raw.mkdir();E.write_obj(raw/'home.obj',o,rest)
for t in o.ffgn.targets:E.write_obj(raw/(t.name+'.obj'),o,E.evaluate(o,E.target_pose(t),envelope=False))
built=P.build_folder(bpy.context,raw);close(E.evaluate(built,{'jawOpen':.5,'eyesClosed':1}),E.evaluate(o,{'jawOpen':.5,'eyesClosed':1}))
(raw/'home.obj').rename(raw/'myRest.obj')
built=P.build_folder(bpy.context,raw,'myRest');close(E.attr(built.data,E.REST),rest)
built=P.build_folder(bpy.context,raw,'myRest',o);close(E.attr(built.data,E.REST),rest)
print('PASS: OBJ network build from home, named neutral, and scene mesh')
# Public pose editor: store -> fade -> off -> mix -> update -> delete.
s=bpy.context.scene.ffgn_settings;s.owner=o
A.pose(o,{'jawOpen':.2,'eyesClosed':.8});s.pose_name='First'
assert bpy.ops.ffgn.action(action='POSE_SAVE')=={'FINISHED'}
p=o.ffgn.poses[0];p.weight=.5;close(list(E.values(o).values()),[.1,.4]);close(actual(o),E.evaluate(o))
p.weight=0;close(list(E.values(o).values()),[0,0])
p.weight=1;close(list(E.values(o).values()),[.2,.8])
A.pose(o,{'jawOpen':.6,'eyesClosed':.1});assert p.weight==0
s.pose_name='Second';bpy.ops.ffgn.action(action='POSE_SAVE')
p2=o.ffgn.poses[1];p2.weight=.5;p.weight=.5;close(list(E.values(o).values()),[.4,.45])
bpy.ops.ffgn.action(action='POSE_OFF');close(list(E.values(o).values()),[0,0])
o.ffgn.active_pose=0;bpy.ops.ffgn.action(action='POSE_APPLY');close(list(E.values(o).values()),[.2,.8])
A.pose(o,{'jawOpen':.7});bpy.ops.ffgn.action(action='POSE_UPDATE');assert abs(json.loads(p.values)['jawOpen']-.7)<1e-5
bpy.ops.ffgn.action(action='POSE_DELETE');close(list(E.values(o).values()),[0,0])
# A sculpt session must restore pose sliders on Cancel and detach them on Done.
o.ffgn.active_pose=0;bpy.ops.ffgn.action(action='POSE_APPLY')
weights=[p.weight for p in o.ffgn.poses];A.begin_pose(bpy.context,o,'EDIT');A.finish(bpy.context,False)
assert [p.weight for p in o.ffgn.poses]==weights
A.begin_pose(bpy.context,o,'EDIT');A.finish(bpy.context,True)
assert all(p.weight==0 for p in o.ffgn.poses)
print('PASS: pose store, on/off/fade, mixing, manual edits, update and deletion')
# Topology rejection does not partially add targets.
bad=mesh('browUp');bad.data.vertices.add(1);count=len(d.ffgn.targets)
try:P.import_meshes(d,[bad]);raise AssertionError('bad import accepted')
except ValueError:assert len(d.ffgn.targets)==count
print('ALL 2.2 PIPELINE CHECKS PASSED',bpy.app.version_string)

import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy,numpy as np
import faceforge_gn as F
from faceforge_gn import engine as E,authoring as A
F.register();bpy.ops.mesh.primitive_monkey_add();o=bpy.context.object;E.initialize(o);bpy.context.scene.ffgn_settings.owner=o
rest=E.coords(o.data);p=rest.copy();p[0,1]+=1
E.add(o,'jawOpen',p,ch='jawOpen');E.add(o,'jawOpen_50',rest+(p-rest)*.5,ch='jawOpen',weight=.5)
q=rest.copy();q[1,2]+=.2;E.add(o,'eyesClosed',q,ch='eyesClosed')
E.add(o,'jawOpen_20_eyesClosed_80',E.evaluate(o,{'jawOpen':.2,'eyesClosed':.8}),'COMBO',drivers=[('jawOpen',.2),('eyesClosed',.8)])
E.rebuild(o);r=o.ffgn;r.quickset=True
for i,expected in [(0,{'jawOpen':1,'eyesClosed':0}),(1,{'jawOpen':.5,'eyesClosed':0}),(3,{'jawOpen':.2,'eyesClosed':.8})]:
    r.active_target=i
    for n,v in expected.items():assert abs(r.channels[n].value-v)<1e-6
r.quickset=False;r.active_target=0;assert abs(r.channels['jawOpen'].value-.2)<1e-6
c=r.channels['jawOpen']
assert bpy.ops.ffgn.create_shape(kind='PRIMARY',shape_name='smile',mode='SCULPT')=={'FINISHED'}
s=bpy.context.scene.ffgn_settings;assert s.edit_object.mode=='SCULPT';assert bpy.context.object==s.edit_object
assert bpy.ops.ffgn.edit_shape(mode='EDIT')=={'FINISHED'};assert s.edit_object.mode=='EDIT'
assert bpy.ops.ffgn.edit_shape(mode='SCULPT')=={'FINISHED'};assert s.edit_object.mode=='SCULPT'
A.finish(bpy.context,False)
print('PASS new shape enters Sculpt; session switches Edit/Sculpt before Done')
r.quickset=True;r.active_target=1
p=r.poses.add();p.name='Old pose';p.values=json.dumps(E.values(o));p.weight=1;p.name='Renamed pose';assert p.name=='Renamed pose' and p.weight==1
print('PASS Quickset stages and combos, disabled selection, pose rename')

r.quickset=False;r.active_target=1
assert bpy.ops.ffgn.action(action='PREVIEW_ARC')=={'FINISHED'}
assert abs(c.value-.25)<1e-6
other=r.poses.add();other.name=p.name;assert other.name!=p.name
print('PASS curve preview and unique pose renaming')

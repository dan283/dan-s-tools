import sys,time,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy,numpy as np
import faceforge_gn as F
from faceforge_gn import engine as E
F.register()
bpy.ops.mesh.primitive_uv_sphere_add(segments=128,ring_count=128)
o=bpy.context.object; E.initialize(o); rest=E.coords(o.data); start=time.perf_counter()
for i in range(100):
    p=rest.copy(); p[:,2]+=.01*np.exp(-((rest[:,0]-(i/50-1))**2)*20)
    E.add(o,f'shape{i:03d}',p)
g=E.rebuild(o); build=time.perf_counter()-start
samples=[]
for frame in range(11):
    for i,c in enumerate(o.ffgn.channels): c.value=.5 if i%10==frame%10 else 0.
    start=time.perf_counter(); o.update_tag(); bpy.context.view_layer.update(); ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get()); me=ev.to_mesh()
    result=E.coords(me); ev.to_mesh_clear(); samples.append(time.perf_counter()-start)
np.testing.assert_allclose(result,E.evaluate(o),atol=1e-5,rtol=1e-5)
print(json.dumps({'blender':bpy.app.version_string,'vertices':len(rest),'targets':100,'nodes':len(g.nodes),'build_seconds':build,'median_evaluation_ms':1000*float(np.median(samples[1:])),'max_evaluation_ms':1000*max(samples[1:]),'agreement':'PASS'},indent=2),flush=True)

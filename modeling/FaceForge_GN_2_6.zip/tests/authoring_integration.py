"""Authoring regression: real Blender Edit/Sculpt modes, sessions and GN output."""
import sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy, bmesh
import numpy as np
import faceforge_gn as F
from faceforge_gn import engine as E, authoring as A
F.register()
s=bpy.context.scene.ffgn_settings
bpy.ops.mesh.primitive_monkey_add()
o=bpy.context.object; o.name='AuthoringFace'
assert bpy.ops.ffgn.action(action='INIT')=={'FINISHED'}
rest=E.coords(o.data).copy()
def close(a,b): np.testing.assert_allclose(a,b,atol=4e-5,rtol=4e-5)
def actual():
    o.update_tag(); bpy.context.view_layer.update()
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get()); me=ev.to_mesh()
    try: return E.coords(me)
    finally: ev.to_mesh_clear()
def move_edit(index,offset):
    bm=bmesh.from_edit_mesh(s.edit_object.data); bm.verts.ensure_lookup_table(); bm.verts[index].co+=__import__('mathutils').Vector(offset)
    bmesh.update_edit_mesh(s.edit_object.data)
def done(): assert bpy.ops.ffgn.action(action='COMMIT')=={'FINISHED'}
def create(**kw): assert bpy.ops.ffgn.create_shape('EXEC_DEFAULT',**kw)=={'FINISHED'}
def cancel(): assert bpy.ops.ffgn.action(action='CANCEL')=={'FINISHED'}
create(kind='PRIMARY',shape_name='jawOpen',mode='EDIT')
assert s.edit_object.mode=='EDIT' and o.hide_get()
move_edit(0,(0,0,-.25)); done()
jaw=rest.copy(); jaw[0,2]-=.25
close(actual(),jaw); close(E.coords(o.data),rest)
assert o.ffgn.channels['jawOpen'].value==1 and not s.edit_object and not o.hide_get()
print('PASS: new primary opens Edit Mode; Done flushes BMesh, protects neutral and previews 1.0')
create(kind='INBETWEEN',channel='jawOpen',weight=.5,mode='EDIT')
move_edit(0,(0,.1,0)); done()
half=rest+(jaw-rest)*.5; half[0,1]+=.1
close(actual(),half); assert o.ffgn.channels['jawOpen'].value==.5
print('PASS: interpolated in-between seed, edited stage at 0.5')
create(kind='PRIMARY',shape_name='lipFunneler',mode='SCULPT')
assert s.edit_object.mode=='SCULPT'
s.edit_object.data.vertices[1].co.y-=.2; done()
funnel=rest.copy(); funnel[1,1]-=.2
close(actual(),funnel)
A.pose(o,{'jawOpen':1,'lipFunneler':1})
uncorrected=E.evaluate(o).copy()
create(kind='COMBO',shape_name='jawOpen+lipFunneler',mode='EDIT')
move_edit(2,(0,.08,.04)); done()
corrected=uncorrected.copy(); corrected[2]+=[0,.08,.04]
close(actual(),corrected)
t=o.ffgn.targets[-1]; d=E.attr(o.data,t.attribute)
expected=np.zeros_like(d); expected[2]=[0,.08,.04]; close(d,expected)
A.pose(o,{'jawOpen':1}); close(actual(),jaw)
A.pose(o,{'jawOpen':1,'lipFunneler':1}); close(actual(),corrected)
print('PASS: corrective stores residual only and vanishes with missing driver')
# Cancel a newly created target removes its otherwise unused channel and restores mix.
prior=E.values(o); count=len(o.ffgn.targets)
create(kind='PRIMARY',shape_name='temporary',mode='EDIT'); move_edit(0,(0,0,5)); cancel()
assert len(o.ffgn.targets)==count and not o.ffgn.channels.get('temporary') and E.values(o)==prior
close(actual(),corrected)
# Cancel existing target never changes its geometry.
o.ffgn.active_target=0
assert bpy.ops.ffgn.edit_shape(mode='EDIT')=={'FINISHED'}
move_edit(0,(3,0,0)); cancel(); close(actual(),corrected)
print('PASS: cancel new / existing shape restores pose without leaking a channel')
# Mask/gain aware sculpt: visible target is edited and saved without double application.
t=o.ffgn.targets[0]; group=o.vertex_groups.new(name='partial'); group.add([0],.5,'REPLACE'); t.mask=group.name; t.gain=.5
assert bpy.ops.ffgn.edit_shape(mode='EDIT')=={'FINISHED'}
move_edit(0,(0,0,-.1)); done()
masked=rest.copy(); masked[0,2]-=.25*.25+.1
close(actual(),masked)
assert bpy.ops.ffgn.edit_shape(mode='EDIT')=={'FINISHED'}
move_edit(1,(.3,0,0))
try:
    A.finish(bpy.context,True); raise AssertionError('Expected masked edit rejection')
except ValueError as exc: assert 'outside' in str(exc)
assert s.edit_object is not None
cancel(); close(actual(),masked)
print('PASS: effective masked/gain editing, blocked-vertex rejection preserves working copy')
# Direct neutral edits can be rescued even though normal authoring rejects them.
A.pose(o,{})
o.data.vertices[3].co.z+=.2; o.data.update()
assert bpy.ops.ffgn.recover(shape_name='rescued')=={'FINISHED'}
rescued=rest.copy(); rescued[3,2]+=.2
close(E.coords(o.data),rest); close(actual(),rescued)
print('PASS: accidental neutral sculpt recovered as independent target')
# Save a live Edit Mode session and reload it; no in-memory global session state required.
create(kind='PRIMARY',shape_name='persistent',mode='EDIT'); move_edit(4,(.1,0,0))
# Flush mesh before save (Blender UI saves Edit Mode data itself).
bpy.ops.object.mode_set(mode='OBJECT')
path=str(Path(tempfile.mkdtemp())/'session.blend'); name=o.name
bpy.ops.wm.save_as_mainfile(filepath=path); bpy.ops.wm.open_mainfile(filepath=path)
o=bpy.data.objects[name]; s=bpy.context.scene.ffgn_settings
done(); persisted=rest.copy(); persisted[4,0]+=.1
close(actual(),persisted)
print('PASS: saved working session survives reopen and commits correctly')
# Reject changed topology on Done, but retain the working mesh so the artist can repair it.
assert bpy.ops.ffgn.edit_shape(mode='EDIT')=={'FINISHED'}
bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.subdivide(number_cuts=1)
try:
    A.finish(bpy.context,True); raise AssertionError('Expected topology rejection')
except ValueError as exc: assert 'Topology' in str(exc)
assert s.edit_object is not None
cancel(); close(actual(),persisted)
print('PASS: changed working topology rejected without losing sculpt or corrupting rig')
# Panel draws through the RNA-backed layout API via a strict proxy to validate references.
class Layout:
    def __getattr__(self,key):
        if key in ('row','column','box','split'): return lambda *a,**k:Layout()
        if key in ('label','separator'): return lambda *a,**k:None
        if key=='prop':
            def prop(obj,name,**kw):
                assert hasattr(obj,name),(type(obj),name)
                icon=kw.get('icon')
                if icon: assert icon in bpy.types.UILayout.bl_rna.functions['prop'].parameters['icon'].enum_items.keys(),icon
            return prop
        if key=='prop_search': return lambda obj,name,*a,**k:getattr(obj,name)
        if key=='template_list': return lambda name,*a,**k:getattr(bpy.types,name)
        if key=='operator':
            def op(name,**kw):
                ns,fn=name.split('.'); getattr(getattr(bpy.ops,ns),fn).get_rna_type()
                icon=kw.get('icon')
                if icon: assert icon in bpy.types.UILayout.bl_rna.functions['operator'].parameters['icon'].enum_items.keys(),icon
                return type('Op',(),{})()
            return op
        raise AttributeError(key)
panel=type('Panel',(),{'layout':Layout()})()
s.show_advanced=True; s.show_pipeline=True; s.show_poses=True; s.show_mixer_filters=True
F.FFGN_PT_panel.draw(panel,bpy.context)
assert bpy.ops.ffgn.edit_shape(mode='SCULPT')=={'FINISHED'}
F.FFGN_PT_panel.draw(panel,bpy.context); cancel()
print('PASS: panel property / operator / icon references')
print('ALL AUTHORING CHECKS PASSED',bpy.app.version_string)

import importlib.util
from pathlib import Path
import unittest
p=Path(__file__).resolve().parents[1]/'faceforge_gn/core.py'
spec=importlib.util.spec_from_file_location('core',p); C=importlib.util.module_from_spec(spec); spec.loader.exec_module(C)

class Interpolation(unittest.TestCase):
    def value(self,knots,w,mode='LINEAR',tension=0): return {u:e.evaluate({'w':w}) for u,e in C.basis(knots,mode,tension).items()}
    def test_single_signed(self):
        for w in [-2,-1,-.5,0,.5,1,2]:
            out=self.value([(-1,'neg'),(1,'pos')],w)
            self.assertAlmostEqual(out['pos'],max(0,min(1,w))); self.assertAlmostEqual(out['neg'],max(0,min(1,-w)))
    def test_cardinal_stages(self):
        knots=[(.25,'a'),(.65,'b'),(1.,'c'),(-.4,'d'),(-1.,'e')]
        for mode in ['LINEAR','CURVED']:
            for w,uid in knots:
                v=self.value(knots,w,mode)
                for k in v: self.assertAlmostEqual(v[k],float(k==uid),places=6)
            self.assertTrue(all(abs(v)<1e-8 for v in self.value(knots,0,mode).values()))
    def test_linear_midpoint(self):
        v=self.value([(.5,'a'),(1,'b')],.75)
        self.assertAlmostEqual(v['a'],.5); self.assertAlmostEqual(v['b'],.5)
    def test_spatial_arc(self):
        # Neutral=(0,0), half=(1,1), full=(2,0). Arc must differ from linear.
        v=self.value([(.5,'a'),(1,'b')],.25,'CURVED')
        self.assertAlmostEqual(v['a']+v['b']*2,.5)
        self.assertGreater(v['a'],.5)
    def test_c1_nonuniform(self):
        knots=[(.2,'a'),(.7,'b'),(1,'c')]; h=1e-5
        for w,_ in knots[:-1]:
            a=self.value(knots,w-h,'CURVED'); b=self.value(knots,w,'CURVED'); c=self.value(knots,w+h,'CURVED')
            for k in b: self.assertAlmostEqual((b[k]-a[k])/h,(c[k]-b[k])/h,delta=.003)
    def test_no_cross_signed_bleed(self):
        v=self.value([(-1,'n'),(-.5,'m'),(.5,'p'),(1,'q')],.4,'CURVED')
        self.assertEqual(v['n'],0); self.assertEqual(v['m'],0)
    def test_duplicate_stage(self):
        with self.assertRaises(ValueError): C.basis([(.5,'a'),(.5,'b')])
    def test_product(self):
        e=C.activation([('jaw',1),('smile',1)])
        self.assertEqual(e.evaluate({'jaw':.5,'smile':.4}),.2)
        self.assertEqual(e.evaluate({'jaw':-1,'smile':1}),0)
    def test_signed_peak_minimum(self):
        e=C.activation([('jaw',-.5),('smile',.8)],'MINIMUM')
        self.assertAlmostEqual(e.evaluate({'jaw':-.25,'smile':.8}),.5)
        self.assertEqual(e.evaluate({'jaw':.5,'smile':.8}),0)
    def test_zero_driver(self):
        with self.assertRaises(ValueError): C.activation([('x',0)])
    def test_user_pipeline_names(self):
        specs=C.parse_names(['jawOpen','lipFunneler','jawOpen_50','jawOpen_lipFunneler','jawOpen_N'])
        by={s['name']:s for s in specs}
        self.assertEqual(by['jawOpen_50']['weight'],.5)
        self.assertEqual(by['jawOpen_N']['weight'],-1)
        self.assertEqual(by['jawOpen_lipFunneler']['kind'],'COMBO')
    def test_plus_and_dash(self):
        specs=C.parse_names(['a','b','a-50','a+b']); self.assertEqual([s for s in specs if s['name']=='a+b'][0]['drivers'],[('a',1.),('b',1.)])
    def test_underscore_hero_preserved(self):
        specs=C.parse_names(['mouth_smile_L','mouth_smile_L_50']); self.assertEqual(specs[0]['channel'],'mouth_smile_L')
    def test_missing_dependency(self):
        with self.assertRaises(ValueError): C.parse_names(['a','a+b'])
    def test_duplicate_weight_names(self):
        with self.assertRaises(ValueError): C.parse_names(['a','a_50','a-50'])
    def test_invalid_stage(self):
        with self.assertRaises(ValueError): C.parse_names(['a','a_0'])
    def test_negative_hero_suffix_is_safe(self):
        specs=C.parse_names(['chinN']); self.assertEqual(specs[0]['kind'],'SHAPE')

if __name__=='__main__': unittest.main(verbosity=2)

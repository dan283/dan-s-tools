import sys,zipfile,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy,numpy as np
from _bpy_restrict_state import RestrictBlend
import _bpy_restrict_state as restrictions
# The bpy wheel exposes a wrapper module; point official restriction context at that wrapper.
restrictions._bpy=bpy
import faceforge_gn as F
from faceforge_gn import engine as E,pipeline as P
new=Path(F.__file__).read_text()
with zipfile.ZipFile(Path(__file__).resolve().parents[1]/'FaceForge_GN_2_5.zip') as z:old=z.read('faceforge_gn/__init__.py').decode()
exec(compile(old,F.__file__,'exec'),F.__dict__)
try:
 with RestrictBlend():F.register()
except AttributeError as ex:assert '_RestrictData' in str(ex);print('REPRODUCED old restricted registration crash')
else:raise AssertionError('Expected old bug')
exec(compile(new,F.__file__,'exec'),F.__dict__)
with RestrictBlend():F.register()
assert bpy.app.timers.is_registered(F.deferred_upgrade)
assert F.deferred_upgrade() is None
print('PASS recovered partial 2.5 registration and registered in RestrictBlend')
bpy.ops.mesh.primitive_monkey_add();o=bpy.context.object;E.initialize(o);bpy.context.scene.ffgn_settings.owner=o
rest=E.coords(o.data);p=rest.copy();p[0,2]+=.2
E.add(o,'jawOpen',p,ch='jawOpen');E.add(o,'jawOpen_50',rest+(p-rest)*.5,ch='jawOpen',weight=.5)
E.add(o,'eyesClosed',p,ch='eyesClosed');E.add(o,'jawOpen_eyesClosed',E.evaluate(o,{'jawOpen':1,'eyesClosed':1}),'COMBO',drivers=[('jawOpen',1),('eyesClosed',1)]);E.rebuild(o)
r=o.ffgn;r.active_target=0
assert bpy.ops.ffgn.assign_group(group='Mouth',scope='SELECTED')=={'FINISHED'}
assert [t.name for t in r.targets if F.target_visible(r,t)]==['jawOpen','jawOpen_50']
r.kind_filter='STAGE';assert sum(F.target_visible(r,t) for t in r.targets)==1
r.group_filter='';r.kind_filter='ALL';r.search='eyes';assert sum(F.target_visible(r,t) for t in r.targets)==2
assert bpy.ops.ffgn.assign_group(group='Eyes',scope='FILTERED')=={'FINISHED'}
assert r.targets[-1].group=='Eyes' and r.channels['eyesClosed'].group=='Eyes'
bpy.ops.ffgn.action(action='FILTER_CLEAR');r.sort_mode='NAME';assert [r.targets[i].name for i in F.target_order(r)]==sorted([t.name for t in r.targets],key=str.casefold)
r.sort_mode='MANUAL';r.active_target=0;uid=r.targets[0].uid;before=E.evaluate(o,{'jawOpen':.6,'eyesClosed':.4})
bpy.ops.ffgn.action(action='MOVE_DOWN');assert r.targets[1].uid==uid
np.testing.assert_allclose(before,E.evaluate(o,{'jawOpen':.6,'eyesClosed':.4}),atol=1e-6)
folder=Path(tempfile.mkdtemp());P.export_network(o,folder);copy=P.build_folder(bpy.context,folder);assert copy.ffgn.targets['jawOpen_eyesClosed'].group=='Eyes'
# Re-register while data exists: custom properties must survive cleanup.
r.channels['jawOpen'].value=.6
with RestrictBlend():F.register()
assert abs(o.ffgn.channels['jawOpen'].value-.6)<1e-6
assert o.ffgn.channels['jawOpen'].group=='Mouth'
assert len([f for f in bpy.app.handlers.load_post if f.__module__==F.__name__])==1
with RestrictBlend():F.unregister()
assert not bpy.app.timers.is_registered(F.deferred_upgrade)
with RestrictBlend():F.unregister()
print('PASS groups, search/type filters, ordering, roundtrip, re-enable data preservation and repeat cleanup')

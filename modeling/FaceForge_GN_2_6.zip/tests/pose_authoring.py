import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bpy,bmesh,numpy as np
import faceforge_gn as F
from faceforge_gn import engine as E,authoring as A
F.register(); bpy.ops.mesh.primitive_monkey_add();o=bpy.context.object
bpy.ops.ffgn.action(action='INIT');rest=E.coords(o.data)
p=rest.copy();p[0,2]-=.4;E.add(o,'jawOpen',p,ch='jawOpen')
p=rest.copy();p[1,1]-=.3;E.add(o,'lipFunneler',p,ch='lipFunneler');E.rebuild(o)
s=bpy.context.scene.ffgn_settings

def edit(offset):
    assert bpy.ops.ffgn.sculpt_pose(mode='EDIT')=={'FINISHED'}
    bm=bmesh.from_edit_mesh(s.edit_object.data);bm.verts.ensure_lookup_table();bm.verts[2].co.z+=offset;bmesh.update_edit_mesh(s.edit_object.data)
def done():assert bpy.ops.ffgn.action(action='COMMIT')=={'FINISHED'}
def actual():
    o.update_tag();bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh()
    try:return E.coords(m)
    finally:ev.to_mesh_clear()
def close(x,y):np.testing.assert_allclose(x,y,atol=3e-5)
A.pose(o,{'jawOpen':.5});before=E.evaluate(o);o.ffgn.active_target=1
edit(.1);done();t=o.ffgn.targets[-1]
assert t.channel=='jawOpen' and abs(t.weight-.5)<1e-5 and t.kind=='SHAPE'
expected=before.copy();expected[2,2]+=.1;close(actual(),expected)
count=len(o.ffgn.targets);edit(.03);done();assert len(o.ffgn.targets)==count
expected[2,2]+=.03;close(actual(),expected)
print('PASS: .5 auto in-between, ignores list selection, reuses existing stage')
A.pose(o,{'jawOpen':.2,'lipFunneler':.8});before=E.evaluate(o);edit(.07);done();t=o.ffgn.targets[-1]
assert t.kind=='COMBO';ds=dict(json.loads(t.drivers));assert abs(ds['jawOpen']-.2)<1e-5 and abs(ds['lipFunneler']-.8)<1e-5
expected=before.copy();expected[2,2]+=.07;close(actual(),expected)
count=len(o.ffgn.targets);edit(.01);done();assert len(o.ffgn.targets)==count;expected[2,2]+=.01;close(actual(),expected)
print('PASS: .2/.8 automatic corrective, exact peaks, residual, existing-pose reuse')
A.pose(o,{'jawOpen':.2,'lipFunneler':.7});edit(.02);done();assert len(o.ffgn.targets)==count+1
A.pose(o,{'jawOpen':.33});prior=E.values(o);count=len(o.ffgn.targets);edit(1)
assert bpy.ops.ffgn.action(action='CANCEL')=={'FINISHED'};assert len(o.ffgn.targets)==count and E.values(o)==prior
A.pose(o,{'jawOpen':-1});edit(.02);done();assert o.ffgn.targets[-1].weight==-1
A.pose(o,{})
try:A.begin_pose(bpy.context,o);raise AssertionError('Zero mix accepted')
except ValueError as exc:assert 'Dial' in str(exc)
print('PASS: distinct driver peaks, cancel, negative stage and zero-pose guard')
print('ALL AUTO-POSE TESTS PASSED',bpy.app.version_string)

"""Draw a precise workflow pamphlet. Diagrams are schematic, not UI screenshots."""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
W,H=1600,1840
im=Image.new('RGB',(W,H),'#eef2f5'); d=ImageDraw.Draw(im)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
INK='#132b3e'; MUTED='#496375'; TEAL='#007f86'; GOLD='#bf7723'; LINE='#d4e0e6'
def font(s,b=False):return ImageFont.truetype(BOLD if b else FONT,s)
def text(x,y,t,s=28,color=INK,b=False):d.text((x,y),t,font=font(s,b),fill=color)
def pill(x,y,t,width=None,color=INK):
    f=font(25,True); w=width or int(d.textlength(t,font=f))+38
    d.rounded_rectangle((x,y,x+w,y+52),radius=12,fill=color)
    d.text((x+w/2,y+26),t,font=f,fill='white',anchor='mm')
    return w

def face(cx,cy,opening=0,funnel=False,scale=1):
    rx,ry=70*scale,95*scale
    d.ellipse((cx-rx,cy-ry,cx+rx,cy+ry),outline=INK,width=4)
    for dx in [-25,25]:
        d.arc((cx+(dx-11)*scale,cy-24*scale,cx+(dx+11)*scale,cy-10*scale),180,355,fill=INK,width=4)
    d.line([(cx,cy-10*scale),(cx-6*scale,cy+17*scale),(cx+5*scale,cy+17*scale)],fill=MUTED,width=3)
    mw=(13 if funnel else 30)*scale; mh=(3+opening*20)*scale
    d.ellipse((cx-mw,cy+48*scale-mh,cx+mw,cy+48*scale+mh),outline=TEAL,width=5)
    d.arc((cx-rx+10,cy-ry+8,cx+rx-10,cy+ry-7),20,160,fill=LINE,width=3)

def arrow(x,y,x2,color=TEAL):
    d.line((x,y,x2-12,y),fill=color,width=5)
    d.polygon([(x2,y),(x2-17,y-10),(x2-17,y+10)],fill=color)
def card(y,h,n,title,tag):
    d.rounded_rectangle((60,y,1540,y+h),radius=24,fill='white',outline=LINE,width=2)
    d.ellipse((88,y+27,144,y+83),fill=TEAL)
    d.text((116,y+54),str(n),font=font(30,True),fill='white',anchor='mm')
    text(166,y+30,title,37,b=True)
    text(166,y+78,tag,24,color=MUTED)
    d.line((715,y+132,715,y+h-30),fill=LINE,width=2)
def line(x,y,n,t):
    text(x,y,str(n)+'.',29,color=TEAL,b=True);text(x+43,y,t,29)

d.rectangle((0,0,W,243),fill=INK)
text(65,40,'FACEFORGE GN 2.5',62,'white',True)
text(70,127,'Your neutral face → sculpted shapes → a controllable rig',30,'#b9e9eb')
text(70,187,'Open the 3D View sidebar: N → FaceForge',27,'white')
card(274,390,1,'Simple shape','Example: jawOpen')
face(232,486,0);face(536,486,1);arrow(335,483,430)
text(159,601,'Neutral · 0',26);text(452,601,'jawOpen · 1',26)
line(760,411,1,'Select face → Initialize Neutral.')
line(760,459,2,'New Shape → name jawOpen.')
line(760,507,3,'Choose Edit or Sculpt; confirm.')
line(760,555,4,'Shape the mesh → Done.')
text(802,605,'Done previews your shape at 1.0.',25,color=TEAL,b=True)
card(692,390,2,'In-between','One parent slider, an extra sculpted stage')
for cx,a in [(174,0),(380,.5),(586,1)]:face(cx,912,a,scale=.75)
arrow(250,916,294);arrow(458,916,500)
for x,t in [(151,'0'),(337,'0.5'),(563,'1')]:text(x,1010,t,28,color=TEAL,b=True)
line(760,830,1,'Zero the other shape channels.')
line(760,878,2,'Set jawOpen to 0.5.')
line(760,926,3,'Click Edit or Sculpt.')
line(760,974,4,'Shape it → Done (auto in-between).')
text(802,1024,'Scrub the same jawOpen slider.',25,color=TEAL,b=True)
card(1110,398,3,'Combination corrective','Fix a pose made from two or more shapes')
pill(109,1255,'jawOpen = .2',242)
pill(403,1255,'lipFunneler = .8',267)
text(365,1263,'+',30,TEAL,True)
face(272,1407,1,True,scale=.6)
arrow(365,1407,449)
text(465,1374,'Sculpt the fix',27,b=True)
text(465,1416,'Only the change',23,color=MUTED)
text(465,1446,'is stored.',23,color=MUTED)
line(760,1245,1,'Create both primary shapes first.')
line(760,1293,2,'Set jawOpen .2 / lipFunneler .8.')
line(760,1341,3,'Click Edit or Sculpt.')
line(760,1389,4,'Edit or sculpt the fix → Done.')
text(802,1442,'Corrective and drivers are automatic.',25,color=TEAL,b=True)
# Finish / cancel behavior is identical across the three workflows.
d.rounded_rectangle((60,1540,1540,1798),radius=24,fill=INK)
pill(92,1571,'Done',140,color=TEAL);text(257,1580,'Save this shape and preview its authoring pose.',27,'white')
pill(92,1639,'Cancel',140,color='#4d6272');text(257,1648,'Discard this session and restore the previous mix.',27,'white')
text(93,1717,'Keep topology unchanged: no Remesh, Dyntopo or added / deleted vertices.',25,'#b9e9eb')
text(93,1758,'Face drawings are schematic. You sculpt the actual anatomy on your own mesh.',21,'#c9d4dc')
root=Path(__file__).resolve().parents[1]
im.save(root/'FaceForge_Quickstart.png')
print(root/'FaceForge_Quickstart.png')

"""Attribute-backed GN deformer, authoring evaluator, mesh IO and transfer."""
import bpy
import numpy as np
import json, uuid, hashlib, re
from functools import wraps
from pathlib import Path
from mathutils import Vector
from mathutils.kdtree import KDTree
from mathutils.bvhtree import BVHTree
from .core import Expr, basis, activation, parse_names, arc_segments

PREFIX='FFGN_'
REST=PREFIX+'rest'
_BUSY=0

def batch(fn):
    @wraps(fn)
    def wrapped(*args,**kwargs):
        global _BUSY
        _BUSY+=1
        try: return fn(*args,**kwargs)
        finally: _BUSY-=1
    return wrapped

def uid(): return uuid.uuid4().hex[:12]

def coords(mesh):
    a=np.empty(len(mesh.vertices)*3,dtype=np.float32)
    mesh.vertices.foreach_get('co',a)
    return a.reshape(-1,3)

def put_coords(mesh,a):
    mesh.vertices.foreach_set('co',np.asarray(a,dtype=np.float32).ravel()); mesh.update()

def topo(mesh):
    e=np.empty(len(mesh.edges)*2,dtype=np.int32); mesh.edges.foreach_get('vertices',e)
    l=np.empty(len(mesh.loops),dtype=np.int32); mesh.loops.foreach_get('vertex_index',l)
    n=np.empty(len(mesh.polygons),dtype=np.int32); mesh.polygons.foreach_get('loop_total',n)
    counts=np.asarray([len(mesh.vertices),len(mesh.edges),len(mesh.polygons),len(mesh.loops)],dtype=np.int64)
    return hashlib.sha256(counts.tobytes()+e.tobytes()+l.tobytes()+n.tobytes()).hexdigest()

def compatible(base,mesh):
    if len(base.vertices)!=len(mesh.vertices) or topo(base)!=topo(mesh):
        raise ValueError('Topology/order mismatch. Use Transfer for a different topology; do not force indexed targets.')

def attr(mesh,name,value=None):
    a=mesh.attributes.get(name)
    if value is not None:
        if a and (a.data_type!='FLOAT_VECTOR' or a.domain!='POINT'): raise ValueError(f'Attribute collision: {name}')
        if not a: a=mesh.attributes.new(name,'FLOAT_VECTOR','POINT')
        a.data.foreach_set('vector',np.asarray(value,dtype=np.float32).ravel()); mesh.update()
    if not a: raise ValueError(f'Missing shape attribute: {name}')
    result=np.empty(len(mesh.vertices)*3,dtype=np.float32); a.data.foreach_get('vector',result)
    return result.reshape(-1,3)

def rig(context):
    o=context.scene.ffgn_settings.owner
    if not o: o=context.object
    if not o or o.type!='MESH': raise ValueError('Select a mesh or pin a facial rig')
    if not o.ffgn.enabled: raise ValueError('Initialize this mesh first')
    return o

@batch
def initialize(o):
    if o.type!='MESH': raise ValueError('Only mesh objects can be initialized')
    if o.ffgn.enabled: raise ValueError('Already initialized')
    if o.data.users>1: o.data=o.data.copy()
    if o.data.shape_keys: raise ValueError('Use Import Shape Keys on a copy instead of initializing a mesh with keys')
    if not len(o.data.vertices): raise ValueError('Mesh is empty')
    attr(o.data,REST,coords(o.data)); o.ffgn.signature=topo(o.data); o.ffgn.enabled=True
    o.ffgn.token=uid(); rebuild(o)

def check(o):
    if topo(o.data)!=o.ffgn.signature: raise ValueError('Rig topology changed after initialization. Restore topology before editing targets.')
    if not np.isfinite(coords(o.data)).all(): raise ValueError('Non-finite mesh positions')
    if not np.allclose(coords(o.data),attr(o.data,REST),rtol=1e-6,atol=1e-7):
        raise ValueError('Neutral was edited directly. Use Pipeline > Recover Edits to Neutral to save those edits as a shape.')

def channel(o,name):
    for c in o.ffgn.channels:
        if c.name==name: return c
    c=o.ffgn.channels.add(); c.name=name; c.uid=uid(); return c

def values(o): return {c.name:c.value for c in o.ffgn.channels}

def expressions(o):
    out={}
    known={c.name for c in o.ffgn.channels}
    for t in o.ffgn.targets:
        if t.kind=='SHAPE' and t.channel not in known: raise ValueError('Unknown channel '+t.channel)
        if t.kind=='SHAPE' and (not t.weight or not np.isfinite(t.weight)): raise ValueError('Invalid stage weight')
        if t.kind=='COMBO' and any(n not in known for n,_ in json.loads(t.drivers)): raise ValueError('Unknown corrective driver')
    for c in o.ffgn.channels:
        stages=[(t.weight,t.uid) for t in o.ffgn.targets if t.kind=='SHAPE' and t.channel==c.name]
        out.update({u:(e,c.name) for u,e in basis(stages,c.interpolation,extrapolate=True).items()})
    for t in o.ffgn.targets:
        if t.kind=='COMBO': out[t.uid]=(activation(json.loads(t.drivers),t.combo_mode),None)
    return out

def mask(o,t):
    if not t.mask: return np.ones(len(o.data.vertices),dtype=np.float32)
    g=o.vertex_groups.get(t.mask)
    if not g: raise ValueError(f'Missing mask vertex group: {t.mask}')
    w=np.zeros(len(o.data.vertices),dtype=np.float32)
    for v in o.data.vertices:
        for item in v.groups:
            if item.group==g.index: w[v.index]=item.weight; break
    if t.invert_mask: w=1-w
    return w

def live_delta(o,t):
    if not t.live or not t.source: return attr(o.data,t.attribute)
    src=t.source
    if src==o: raise ValueError('A target cannot reference its own rig')
    dg=bpy.context.evaluated_depsgraph_get(); ev=src.evaluated_get(dg); me=ev.to_mesh()
    try:
        compatible(o.data,me)
        return coords(me)-attr(o.data,t.reference)
    finally: ev.to_mesh_clear()

def evaluate(o,pose=None,exclude=None,envelope=True,allowed=None):
    check(o); v=values(o) if pose is None else {c.name:pose.get(c.name,0.) for c in o.ffgn.channels}
    out=attr(o.data,REST).copy(); ex=expressions(o)
    for t in o.ffgn.targets:
        if t.uid==exclude or t.mute or (allowed is not None and t.uid not in allowed): continue
        e,c=ex[t.uid]; w=e.evaluate({'w':v.get(c,0.)}) if c else e.evaluate(v)
        if w: out+=live_delta(o,t)*(w*t.gain)*mask(o,t)[:,None]
    if envelope: out=attr(o.data,REST)+(out-attr(o.data,REST))*o.ffgn.envelope
    return out

def target_pose(t):
    return {t.channel:t.weight} if t.kind=='SHAPE' else dict(json.loads(t.drivers))

@batch
def add(o,name,positions,kind='SHAPE',ch=None,weight=1.,drivers=None,mode='PRODUCT',source=None):
    check(o)
    if not name or any(t.name==name for t in o.ffgn.targets): raise ValueError(f'Empty or duplicate name: {name}')
    p=np.asarray(positions,dtype=np.float32)
    if p.shape!=(len(o.data.vertices),3) or not np.isfinite(p).all(): raise ValueError('Invalid target coordinates')
    if kind=='SHAPE':
        ch=ch or name
        if not weight or not np.isfinite(weight): raise ValueError('Stage must be finite and nonzero')
        if any(t.kind=='SHAPE' and t.channel==ch and abs(t.weight-weight)<1e-6 for t in o.ffgn.targets): raise ValueError('Duplicate channel stage')
        channel(o,ch); reference=attr(o.data,REST)
    else:
        if not drivers or len(drivers)<2 or len({n for n,_ in drivers})!=len(drivers): raise ValueError('A combo needs at least two channel drivers')
        known={c.name for c in o.ffgn.channels}
        if any(n not in known or not p or not np.isfinite(p) for n,p in drivers): raise ValueError('Missing driver channel or invalid activation peak')
        activation(drivers,mode)
        reference=evaluate(o,dict(drivers),envelope=False)
    t=o.ffgn.targets.add(); t.uid=uid(); t.name=name; t.kind=kind; t.channel=ch or ''; t.weight=weight
    t.drivers=json.dumps(drivers or []); t.combo_mode=mode
    t.attribute=PREFIX+'d_'+t.uid; t.reference=PREFIX+'r_'+t.uid
    attr(o.data,t.attribute,p-reference); attr(o.data,t.reference,reference)
    t.source=source; t.live=bool(source)
    o.ffgn.active_target=len(o.ffgn.targets)-1
    return t

class Graph:
    def __init__(self,g): self.g=g; self.cache={}; self.x=0; self.y=0
    def node(self,typ,label=''):
        n=self.g.nodes.new(typ); n.label=label; n.location=(self.x,self.y); self.y-=110; return n
    def wire(self,value,socket):
        if isinstance(value,bpy.types.NodeSocket): self.g.links.new(value,socket)
        else: socket.default_value=value
    def math(self,op,*args):
        n=self.node('ShaderNodeMath',op); n.operation=op
        for i,a in enumerate(args): self.wire(a,n.inputs[i])
        return n.outputs[0]
    def vector(self,op,*args):
        n=self.node('ShaderNodeVectorMath',op); n.operation=op
        for i,a in enumerate(args): self.wire(a,n.inputs['Scale'] if op=='SCALE' and i==1 else n.inputs[i])
        return n.outputs['Vector']
    def expression(self,e,variables):
        if not isinstance(e,Expr): return e
        if e.op=='VAR': return variables[e.args[0]]
        # Expression objects are shared inside the cardinal basis.
        key=(e,tuple((k,str(v)) for k,v in variables.items()))
        if key not in self.cache: self.cache[key]=self.math(e.op,*[self.expression(a,variables) for a in e.args])
        return self.cache[key]
    def named(self,name,typ='FLOAT_VECTOR'):
        n=self.node('GeometryNodeInputNamedAttribute',name); n.data_type=typ; n.inputs['Name'].default_value=name
        return n.outputs['Attribute']


def target_label(t):
    if t.kind=='COMBO': return 'Combo | '+' + '.join(f'{n} @ {v:g}' for n,v in json.loads(t.drivers))
    kind='Primary' if abs(t.weight)==1 else 'In-between'
    return f'{kind} | {t.channel} @ {t.weight:g}'

def rebuild(o):
    check(o)
    # Build off-line, attach only after every socket and driver is valid.
    g=bpy.data.node_groups.new('FaceForge • '+o.name,'GeometryNodeTree'); g.is_modifier=True; g['ffgn_token']=o.ffgn.token; g['ffgn_curve_version']=25
    try:
        g.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry')
        g.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
        env=g.interface.new_socket(name='Envelope',in_out='INPUT',socket_type='NodeSocketFloat'); env.default_value=1.; env.min_value=0.; env.max_value=1.
        sockets={}; target_sockets={}
        for c in o.ffgn.channels:
            s=g.interface.new_socket(name=c.name,in_out='INPUT',socket_type='NodeSocketFloat'); s.min_value=-1e6; s.max_value=1e6; sockets[c.name]=s
        for t in o.ffgn.targets:
            panel=g.interface.new_panel(name=target_label(t)+' | '+t.name,default_closed=True)
            gain=g.interface.new_socket(name='Gain',in_out='INPUT',socket_type='NodeSocketFloat',parent=panel)
            gain.default_value=1.
            enabled=g.interface.new_socket(name='Enabled',in_out='INPUT',socket_type='NodeSocketFloat',parent=panel)
            enabled.default_value=1.
            target_sockets[t.uid]=(gain,enabled)
        b=Graph(g); inp=b.node('NodeGroupInput'); inp.location=(-900,200); output=b.node('NodeGroupOutput'); output.location=(1400,200)
        def input_socket(s): return next(x for x in inp.outputs if x.identifier==s.identifier)
        ex=expressions(o); total=(0.,0.,0.); effective={None:(0.,0.,0.)}
        for i,t in enumerate(o.ffgn.targets):
            b.x=i*260; b.y=0
            frame=g.nodes.new('NodeFrame'); frame.label=f'{t.kind} • {t.name}'; frame.name=t.uid
            before=set(g.nodes)
            if t.live and t.source:
                if t.source==o: raise ValueError('Live target references its own rig')
                live_delta(o,t)  # Validate evaluated topology before connecting the source.
                info=b.node('GeometryNodeObjectInfo'); info.transform_space='ORIGINAL'; info.inputs['Object'].default_value=t.source
                sample=b.node('GeometryNodeSampleIndex'); sample.data_type='FLOAT_VECTOR'; sample.domain='POINT'; sample.clamp=False
                pos=b.node('GeometryNodeInputPosition'); idx=b.node('GeometryNodeInputIndex')
                b.wire(info.outputs['Geometry'],sample.inputs['Geometry']); b.wire(pos.outputs['Position'],sample.inputs['Value']); b.wire(idx.outputs['Index'],sample.inputs['Index'])
                d=b.vector('SUBTRACT',sample.outputs['Value'],b.named(t.reference))
            else: d=b.named(t.attribute)
            e,c=ex[t.uid]; v={'w':input_socket(sockets[c])} if c else {name:input_socket(sockets[name]) for name,_ in json.loads(t.drivers)}
            gain,enabled=target_sockets[t.uid]
            w=b.math('MULTIPLY',input_socket(gain),input_socket(enabled))
            if t.mask:
                mw=b.named(t.mask,'FLOAT')
                if t.invert_mask: mw=b.math('SUBTRACT',1.,mw)
                w=b.math('MULTIPLY',w,mw)
            effective[t.uid]=b.vector('SCALE',d,w)
            delta=b.vector('SCALE',effective[t.uid],b.expression(e,v))
            for n in set(g.nodes)-before: n.parent=frame
            total=b.vector('ADD',total,delta)
        b.x=1100; b.y=0
        total=b.vector('SCALE',total,inp.outputs['Envelope'])
        setpos=b.node('GeometryNodeSetPosition'); b.wire(inp.outputs['Geometry'],setpos.inputs['Geometry']); b.wire(total,setpos.inputs['Offset']); b.wire(setpos.outputs['Geometry'],output.inputs['Geometry'])
        mod=next((m for m in o.modifiers if m.type=='NODES' and m.node_group and m.node_group.get('ffgn_token')==o.ffgn.token),None)
        if not mod:
            mod=o.modifiers.new('FaceForge GN','NODES')
            index=o.modifiers.find(mod.name); o.modifiers.move(index,0)
        old=mod.node_group; oldkeys=json.loads(o.ffgn.socket_ids or '[]')
        for key in oldkeys:
            for path in [f'["{key}"]',f'properties.inputs.{key}.value']:
                try: o.driver_remove(mod.path_from_id()+('.' if not path.startswith('[') else '')+path)
                except (TypeError,RuntimeError,ValueError): pass
        mod.node_group=g
        keys=[]
        def drive(s,path,invert=False):
            key=s.identifier
            if hasattr(mod,'properties'):
                input_prop=getattr(mod.properties.inputs,key); input_prop.value=0.; f=input_prop.driver_add('value')
            else:
                mod[key]=0.; f=mod.driver_add(f'["{key}"]')
            f.driver.type='AVERAGE'
            var=f.driver.variables.new(); var.name='value'; var.type='SINGLE_PROP'; var.targets[0].id=o; var.targets[0].data_path=path; keys.append(key)
            if invert: f.driver.type='SCRIPTED'; f.driver.expression='1-value'
        drive(env,'ffgn.envelope')
        for c in o.ffgn.channels: drive(sockets[c.name],f'ffgn.channels["{bpy.utils.escape_identifier(c.name)}"].value')
        for i,t in enumerate(o.ffgn.targets):
            gain,enabled=target_sockets[t.uid]
            drive(gain,f'ffgn.targets[{i}].gain'); drive(enabled,f'ffgn.targets[{i}].mute',True)
        o.ffgn.socket_ids=json.dumps(keys)
        if old and old.users==0: bpy.data.node_groups.remove(old)
        o.ffgn.status=''; o.update_tag()
        return g
    except Exception:
        if g.users==0: bpy.data.node_groups.remove(g)
        raise

def mesh_object(o,name,positions):
    me=o.data.copy()
    # Working meshes must not accidentally carry the rig's shape archive.
    for a in list(me.attributes):
        if a.name.startswith(PREFIX): me.attributes.remove(a)
    put_coords(me,positions); ob=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(ob); ob.matrix_world=o.matrix_world.copy()
    return ob

def target_positions(o,t):
    # A stage is the requested absolute channel shape, not a corrective delta.
    return evaluate(o,target_pose(t),envelope=False)

@batch
def freeze(o,t):
    d=live_delta(o,t); attr(o.data,t.attribute,d); t.live=False; t.source=None

@batch
def remove(o,index):
    t=o.ffgn.targets[index]
    for name in [t.attribute,t.reference]:
        a=o.data.attributes.get(name)
        if a: o.data.attributes.remove(a)
    o.ffgn.targets.remove(index); o.ffgn.active_target=max(0,min(index,len(o.ffgn.targets)-1))
    rebuild(o)

def read_obj(path):
    v=[]; f=[]
    with open(path,encoding='utf8') as stream:
        for line in stream:
            parts=line.split()
            if not parts: continue
            if parts[0]=='v': v.append([float(x) for x in parts[1:4]])
            if parts[0]=='f':
                face=[]
                for s in parts[1:]:
                    n=int(s.split('/')[0]); face.append(n-1 if n>0 else len(v)+n)
                if len(face)<3 or any(i<0 or i>=len(v) for i in face): raise ValueError(f'Invalid OBJ face in {path}')
                f.append(face)
    a=np.asarray(v,dtype=np.float32)
    if a.ndim!=2 or a.shape[1]!=3 or not np.isfinite(a).all(): raise ValueError(f'Invalid OBJ vertices: {path}')
    return a,f

def check_obj(o,p,faces):
    if len(p)!=len(o.data.vertices): raise ValueError('OBJ vertex count mismatch')
    ours=[tuple(f.vertices) for f in o.data.polygons]
    if [tuple(f) for f in faces]!=ours: raise ValueError('OBJ face indices/order mismatch; vertex order must be preserved')

def write_obj(path,o,p):
    # Index-preserving writer: no selection context, axis conversion, or reordering.
    with open(path,'w',encoding='utf8',newline='\n') as out:
        out.write('# FaceForge GN local-space absolute target; Blender axes; units unchanged\n')
        for v in p: out.write('v %.9g %.9g %.9g\n'%tuple(v))
        uv=o.data.uv_layers.active
        if uv:
            for loop in uv.data: out.write('vt %.9g %.9g\n'%tuple(loop.uv))
        for face in o.data.polygons:
            out.write('f '+' '.join(f'{o.data.loops[i].vertex_index+1}/{i+1}' if uv else str(o.data.loops[i].vertex_index+1) for i in face.loop_indices)+'\n')

@batch
def export_package(o,directory):
    check(o); root=Path(directory); root.mkdir(parents=True,exist_ok=True)
    if (root/'faceforge.json').exists(): raise ValueError('Folder already contains a package. Choose a fresh folder to preserve the previous export.')
    manifest={'schema':1,'space':'LOCAL','axes':'BLENDER','topology':o.ffgn.signature,'neutral':'neutral.obj','channels':[], 'targets':[], 'poses':[]}
    planned=['neutral.obj']+['%04d_%s.obj'%(i,re.sub(r'[^\w.+-]','_',t.name)) for i,t in enumerate(o.ffgn.targets)]
    if any((root/x).exists() for x in planned): raise ValueError('Export would overwrite OBJ files. Choose an empty folder.')
    write_obj(root/'neutral.obj',o,attr(o.data,REST))
    for c in o.ffgn.channels: manifest['channels'].append({'name':c.name,'range_mode':c.range_mode,'arc_perpendicular':c.arc_perpendicular,'arc_strength':c.arc_strength,'arc_bulge':c.arc_bulge,'arc_axis':list(c.arc_axis),'interpolation':c.interpolation,'tension':c.tension,'group':c.group})
    # Export all enabled rig contributions; mute is an animator preview state.
    states=[t.mute for t in o.ffgn.targets]
    try:
        for t in o.ffgn.targets: t.mute=False
        for i,t in enumerate(o.ffgn.targets):
            filename=planned[i+1]
            ordered=sorted(o.ffgn.targets,key=lambda q:(q.kind=='COMBO',len(json.loads(q.drivers))))
            allowed={q.uid for q in ordered[:ordered.index(t)+1]} if t.kind=='COMBO' else {q.uid for q in o.ffgn.targets if q.kind=='SHAPE'}
            write_obj(root/filename,o,EVALUATE_PACKAGE(o,t,allowed))
            manifest['targets'].append({'name':t.name,'file':filename,'kind':t.kind,'channel':t.channel,'weight':t.weight,'drivers':json.loads(t.drivers),'mode':t.combo_mode,'group':t.group})
    finally:
        for t,state in zip(o.ffgn.targets,states): t.mute=state
    for p in o.ffgn.poses: manifest['poses'].append({'name':p.name,'values':json.loads(p.values)})
    (root/'faceforge.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    return len(o.ffgn.targets)

def EVALUATE_PACKAGE(o,t,allowed):
    return evaluate(o,target_pose(t),envelope=False,allowed=allowed)

@batch
def import_package(o,directory):
    check(o)
    if len(o.ffgn.targets): raise ValueError('Import into an empty initialized rig; merge ambiguity is deliberately rejected')
    root=Path(directory); mpath=root/'faceforge.json'; manifest=None
    if mpath.exists():
        manifest=json.loads(mpath.read_text(encoding='utf8'))
        if manifest.get('schema')==2:
            from .pipeline import import_folder
            return import_folder(o,directory)
        if manifest.get('schema')!=1 or manifest.get('space')!='LOCAL': raise ValueError('Unsupported package schema/space')
        def safe_file(name):
            p=(root/name).resolve()
            if p.parent!=root.resolve(): raise ValueError('Package paths must be filenames in the package folder')
            return p
        neutral,faces=read_obj(safe_file(manifest['neutral'])); check_obj(o,neutral,faces)
        if not np.allclose(neutral,attr(o.data,REST),rtol=1e-5,atol=1e-6): raise ValueError('Package neutral differs. Initialize the supplied neutral first, or use Transfer.')
        specs=manifest['targets']; payload=[]
        for s in specs:
            p,f=read_obj(safe_file(s['file'])); check_obj(o,p,f); payload.append((s,p))
    else:
        files=sorted(p for p in root.glob('*.obj') if p.stem.lower() not in {'neutral','basis','base'})
        if not files: raise ValueError('No OBJ shapes found')
        specs=parse_names([p.stem for p in files]); lookup={p.stem:p for p in files}; payload=[]
        for s in specs:
            p,f=read_obj(lookup[s['name']]); check_obj(o,p,f); payload.append((s,p))
    # Validate dependency order, uniqueness and channels before touching the rig.
    names=set(); stages=set(); heroes=set()
    for s,p in payload:
        if s['name'] in names: raise ValueError('Duplicate target in package')
        names.add(s['name'])
        if s['kind']=='SHAPE':
            key=(s['channel'],s['weight'])
            if key in stages or not s['weight'] or not np.isfinite(s['weight']): raise ValueError('Duplicate/invalid progressive stage')
            stages.add(key); heroes.add(s['channel'])
        elif s['kind']!='COMBO': raise ValueError('Unknown target type')
    for s,p in payload:
        if s['kind']=='COMBO':
            ds=s['drivers']
            if len(ds)<2 or any(n not in heroes or not w or not np.isfinite(w) for n,w in ds): raise ValueError('Unresolved corrective drivers')
    try:
        for name in sorted(heroes): channel(o,name)
        if manifest:
            for spec in manifest.get('channels',[]):
                c=channel(o,spec['name']); c.interpolation=spec['interpolation']; c.tension=spec['tension']; c.group=spec.get('group','Face'); c.range_mode=spec.get('range_mode','POSITIVE'); c.arc_perpendicular=spec.get('arc_perpendicular',True); c.arc_strength=spec.get('arc_strength',1.); c.arc_bulge=spec.get('arc_bulge',.25); c.arc_axis=spec.get('arc_axis',(0,1,0))
        payload.sort(key=lambda item:(item[0]['kind']=='COMBO',len(item[0].get('drivers',[]))))
        for s,p in payload: add(o,s['name'],p,s['kind'],s.get('channel'),s.get('weight',1.),s.get('drivers'),s.get('mode','PRODUCT')).group=s.get('group','')
        if manifest:
            for spec in manifest.get('poses',[]):
                pose=o.ffgn.poses.add(); pose.name=spec['name']; pose.values=json.dumps(spec['values'])
        rebuild(o)
    except Exception:
        for t in list(o.ffgn.targets):
            for name in [t.attribute,t.reference]:
                a=o.data.attributes.get(name)
                if a: o.data.attributes.remove(a)
        o.ffgn.targets.clear(); o.ffgn.channels.clear(); o.ffgn.poses.clear(); rebuild(o); raise
    return len(payload)

def mirror_map(o,tolerance):
    rest=attr(o.data,REST); tree=KDTree(len(rest))
    for i,p in enumerate(rest): tree.insert(Vector(p),i)
    tree.balance(); indexes=[]; distances=[]
    for p in rest:
        q=Vector((-p[0],p[1],p[2])); _,i,d=tree.find(q); indexes.append(i); distances.append(d)
    if max(distances)>tolerance or len(set(indexes))!=len(rest): raise ValueError(f'Neutral is not symmetric/bijective within tolerance ({max(distances):.6g}). Align local X symmetry first.')
    return np.asarray(indexes)

@batch
def split(o,t,width):
    if t.kind!='SHAPE': raise ValueError('Split primary/progressive targets; create split-channel combos separately')
    rest=attr(o.data,REST); d=live_delta(o,t)*mask(o,t)[:,None]*t.gain
    if width<=0: w=np.where(rest[:,0]>0,1.,np.where(rest[:,0]<0,0.,.5))
    else:
        w=np.clip(.5+rest[:,0]/width,0,1); w=w*w*(3-2*w)
    # Explicitly retain original channel; user can mute it to avoid double contribution.
    add(o,t.name+'_L',rest+d*w[:,None],ch=t.channel+'_L',weight=t.weight)
    add(o,t.name+'_R',rest+d*(1-w)[:,None],ch=t.channel+'_R',weight=t.weight)
    rebuild(o)

@batch
def transfer(source,dest,max_distance):
    """Closest-triangle barycentric displacement transfer in aligned world space.
    This is deliberately not advertised as the gradient-optimization paper solver.
    """
    check(source)
    if dest.ffgn.enabled or dest.data.shape_keys: raise ValueError('Destination must be a clean mesh without shape keys/FaceForge')
    rest=attr(source.data,REST); world=source.matrix_world
    verts=[world@Vector(p) for p in rest]; source.data.calc_loop_triangles()
    tris=[tuple(t.vertices) for t in source.data.loop_triangles]
    if not tris: raise ValueError('Source has no triangles')
    bvh=BVHTree.FromPolygons(verts,tris,all_triangles=True)
    mapping=[]
    for p in coords(dest.data):
        q=dest.matrix_world@Vector(p); hit,normal,index,dist=bvh.find_nearest(q)
        if hit is None or dist>max_distance: raise ValueError('Destination exceeds transfer distance. Align neutral surfaces and raise distance only after inspecting alignment.')
        ids=tris[index]; a,b,c=[np.asarray(verts[i],dtype=float) for i in ids]; v0=b-a; v1=c-a; v2=np.asarray(hit)-a
        dot00=np.dot(v0,v0); dot01=np.dot(v0,v1); dot11=np.dot(v1,v1); denom=dot00*dot11-dot01*dot01
        if abs(denom)<1e-20: raise ValueError('Degenerate source triangle')
        u=(dot11*np.dot(v2,v0)-dot01*np.dot(v2,v1))/denom; v=(dot00*np.dot(v2,v1)-dot01*np.dot(v2,v0))/denom
        mapping.append((ids,(1-u-v,u,v)))
    index=np.asarray([x[0] for x in mapping]); bary=np.asarray([x[1] for x in mapping])
    transform=np.asarray(dest.matrix_world.inverted().to_3x3()@source.matrix_world.to_3x3())
    deltas={t.uid:np.sum(live_delta(source,t)[index]*bary[:,:,None],axis=1)@transform.T for t in source.ffgn.targets}
    masks={t.uid:np.sum(mask(source,t)[index]*bary,axis=1) for t in source.ffgn.targets}
    initialize(dest)
    for c in source.ffgn.channels:
        n=channel(dest,c.name); n.group=c.group; n.interpolation=c.interpolation; n.tension=c.tension; n.range_mode=c.range_mode; n.arc_perpendicular=c.arc_perpendicular; n.arc_strength=c.arc_strength; n.arc_bulge=c.arc_bulge; n.arc_axis=c.arc_axis
    for t in source.ffgn.targets:
        n=dest.ffgn.targets.add()
        for field in ['name','kind','channel','weight','drivers','combo_mode','gain','mute','group']: setattr(n,field,getattr(t,field))
        n.uid=uid(); n.attribute=PREFIX+'d_'+n.uid; n.reference=PREFIX+'r_'+n.uid
        # Bake masks into transferred deltas, preserve gain as a channel property.
        attr(dest.data,n.attribute,deltas[t.uid]*masks[t.uid][:,None]); attr(dest.data,n.reference,attr(dest.data,REST))
    for p in source.ffgn.poses:
        q=dest.ffgn.poses.add(); q.name=p.name; q.values=p.values
    rebuild(dest)

@batch
def blur_mask(o,t,iterations):
    if not t.mask: raise ValueError('Create or select a vertex mask first')
    weights=mask(o,t)
    if t.invert_mask: weights=1-weights
    pairs=np.empty(len(o.data.edges)*2,dtype=np.int32); o.data.edges.foreach_get('vertices',pairs); pairs=pairs.reshape(-1,2)
    counts=np.ones(len(weights),dtype=np.float32)
    np.add.at(counts,pairs[:,0],1); np.add.at(counts,pairs[:,1],1)
    for _ in range(iterations):
        sums=weights.copy(); np.add.at(sums,pairs[:,0],weights[pairs[:,1]]); np.add.at(sums,pairs[:,1],weights[pairs[:,0]])
        weights=sums/counts
    group=o.vertex_groups[t.mask]
    for i,w in enumerate(weights): group.add([i],float(w),'REPLACE')
    o.data.update()

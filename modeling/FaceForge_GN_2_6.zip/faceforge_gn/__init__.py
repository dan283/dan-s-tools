bl_info={
    'name':'FaceForge GN — Facial Shape Studio', 'author':'Dan / OpenAI',
    'version':(2,6,0), 'blender':(4,5,0), 'location':'View3D > Sidebar > FaceForge',
    'description':'Geometry Nodes blendshape deformer with progressives, corrective residuals and pipeline packages',
    'category':'Animation'}
import bpy
import json
import numpy as np
from bpy.props import BoolProperty, StringProperty, FloatProperty, FloatVectorProperty, IntProperty, EnumProperty, PointerProperty, CollectionProperty
from bpy.types import PropertyGroup, Operator, Panel, UIList
from . import engine as E
from . import authoring as A

def structural_update(self,context):
    o=self.id_data
    if not isinstance(o,bpy.types.Object) or not o.ffgn.enabled or E._BUSY: return
    try: E.rebuild(o)
    except Exception as exc: o.ffgn.status=str(exc)

@E.batch
def apply_pose_mix(o):
    v={c.name:0. for c in o.ffgn.channels}
    for p in o.ffgn.poses:
        for name,value in json.loads(p.values).items():
            if name in v: v[name]+=p.weight*value
    for c in o.ffgn.channels: c.value=v[c.name]
    o.update_tag()

def pose_update(self,context):
    if E._BUSY:return
    apply_pose_mix(self.id_data)

def channel_update(self,context):
    if E._BUSY:return
    clear_pose_mix(self.id_data)

@E.batch
def clear_pose_mix(o):
    for p in o.ffgn.poses:p.weight=0.

@E.batch
def solo_pose(o,index):
    for i,p in enumerate(o.ffgn.poses):p.weight=1. if i==index else 0.
    apply_pose_mix(o)

def quickset_update(self,context):
    if E._BUSY or not self.quickset or not self.targets: return
    if context.scene.ffgn_settings.edit_object: return
    index=max(0,min(self.active_target,len(self.targets)-1))
    A.pose(self.id_data,E.target_pose(self.targets[index]))
    self.envelope=1.

def target_group(r,t):
    if t.kind=='SHAPE':
        c=r.channels.get(t.channel)
        return (c.group.strip() or 'Face') if c else 'Face'
    return t.group.strip() or 'Combinations'

def target_visible(r,t,expressions=None):
    search=r.search.casefold().strip()
    if search and search not in (' '.join([t.name,t.channel,target_group(r,t)]+list(E.target_pose(t)))).casefold():return False
    if r.group_filter and r.group_filter!=target_group(r,t):return False
    if r.kind_filter!='ALL':
        kind='COMBO' if t.kind=='COMBO' else 'PRIMARY' if abs(t.weight)==1 else 'STAGE'
        if kind!=r.kind_filter:return False
    if r.active_only:
        if t.mute or not t.gain:return False
        e,ch=(expressions if expressions is not None else E.expressions(r.id_data))[t.uid]
        if abs(e.evaluate({'w':r.channels[ch].value} if ch else E.values(r.id_data)))<1e-5:return False
    return True

def visible_targets(r):
    expressions=E.expressions(r.id_data) if r.active_only else None
    return [t for t in r.targets if target_visible(r,t,expressions)]

def target_order(r):
    indices=list(range(len(r.targets)))
    def key(i):
        t=r.targets[i]
        family=(t.kind=='COMBO',t.channel.casefold(),abs(t.weight)!=1,t.weight,t.name.casefold())
        if r.sort_mode=='NAME':return (t.name.casefold(),)
        if r.sort_mode=='GROUP':return (target_group(r,t).casefold(),)+family
        return family
    if r.sort_mode!='MANUAL':indices.sort(key=key,reverse=r.sort_reverse)
    return indices

class FFGN_Channel(PropertyGroup):
    uid: StringProperty()
    value: FloatProperty(name='Value',default=0.,soft_min=-1.,soft_max=1.,update=channel_update)
    value_positive: FloatProperty(name='Value',soft_min=0.,soft_max=1.,get=lambda self:self.value,set=lambda self,v:setattr(self,'value',v))
    range_mode: EnumProperty(name='Slider range',items=[('POSITIVE','0–1','Soft limits: type beyond either end'),('SIGNED','−1–1','Soft limits: type beyond either end')],default='POSITIVE')
    # Legacy 2.3/2.4 fields: retained for file compatibility, ignored by 2.5.
    arc_strength: FloatProperty(name='Tangent strength',default=1.,min=0.,soft_max=5.,update=structural_update)
    arc_bulge: FloatProperty(name='Arc bulge',default=.5,soft_min=-1.,soft_max=1.,update=structural_update,description='Bend distance as a fraction of each vertex segment length; zero disables the extra bulge')
    arc_perpendicular: BoolProperty(name='Perpendicular bend',default=True,update=structural_update,description='Project bend direction off each vertex motion; automatic fallback when parallel')
    arc_axis: FloatVectorProperty(name='Bend direction',default=(0.,1.,0.),size=3,update=structural_update,description='Object-local direction; normalized automatically')
    group: StringProperty(name='Group',default='Face')
    interpolation: EnumProperty(name='Vertex path',items=[('LINEAR','Linear','Straight segment vertex paths'),('CURVED','Curved','Automatic smooth spline through neutral and sculpted stages; continuous velocity and acceleration within each signed branch')],default='LINEAR',update=structural_update)
    tension: FloatProperty(name='Curve tension',min=0.,max=1.,default=0.,update=structural_update)

class FFGN_Target(PropertyGroup):
    name: StringProperty(name="Target name",update=structural_update)
    uid: StringProperty()
    attribute: StringProperty()
    reference: StringProperty()
    group: StringProperty(name='Group',default='')
    kind: EnumProperty(items=[('SHAPE','Stage','Primary/progressive/negative'),('COMBO','Corrective','Pose residual')])
    channel: StringProperty(name='Channel',update=structural_update)
    weight: FloatProperty(name='Stage weight',soft_min=-1.,soft_max=1.,default=1.,update=structural_update)
    drivers: StringProperty(default='[]',update=structural_update)
    combo_mode: EnumProperty(name='Activation',items=[('PRODUCT','Product','Product of normalized signed drivers'),('MINIMUM','Minimum','Minimum of normalized signed drivers')],update=structural_update)
    source: PointerProperty(type=bpy.types.Object,name='Live source',update=structural_update)
    live: BoolProperty(name='Live target',default=False,update=structural_update)
    mute: BoolProperty(name='Mute',default=False)
    gain: FloatProperty(name='Gain',default=1.,min=0.,soft_max=2.)
    mask: StringProperty(name='Vertex mask',update=structural_update)
    invert_mask: BoolProperty(name='Invert mask',update=structural_update)

def pose_name_update(self,context):
    name=self.name.strip() or 'Pose'
    used={p.name for p in self.id_data.ffgn.poses if p.as_pointer()!=self.as_pointer()}
    base=name;number=2
    while name in used:name=f'{base}.{number:03d}';number+=1
    if self.name!=name:self.name=name

class FFGN_Pose(PropertyGroup):
    name: StringProperty(name='Pose name',update=pose_name_update)
    values: StringProperty(default='{}')
    weight: FloatProperty(name='Pose weight',min=0.,max=1.,default=0.,update=pose_update)

class FFGN_Rig(PropertyGroup):
    enabled: BoolProperty()
    signature: StringProperty()
    status: StringProperty()
    token: StringProperty()
    socket_ids: StringProperty(default='[]')
    envelope: FloatProperty(name='Envelope',default=1.,min=0.,max=1.)
    channels: CollectionProperty(type=FFGN_Channel)
    targets: CollectionProperty(type=FFGN_Target)
    poses: CollectionProperty(type=FFGN_Pose)
    active_target: IntProperty(update=quickset_update)
    quickset: BoolProperty(name='Quickset',default=False,update=quickset_update,description='Selecting a target dials its stored stage or combo drivers and zeros all other channels')
    active_pose: IntProperty()
    search: StringProperty(name='Search')
    active_only: BoolProperty(name='Active only')
    group_filter: StringProperty(name='Group filter')
    kind_filter: EnumProperty(name='Type',items=[('ALL','All types',''),('PRIMARY','Primaries',''),('STAGE','Inbetweens / extended stages',''),('COMBO','Combinations','')])
    sort_mode: EnumProperty(name='Order',items=[('FAMILY','Channel families','Keep parent and stages together'),('NAME','Name','Alphabetical'),('GROUP','Group','Group then channel family'),('MANUAL','Custom','Use move arrows')])
    sort_reverse: BoolProperty(name='Reverse',default=False)
    mixer_page: IntProperty(name='Page',default=1,min=1)
    mixer_rows: IntProperty(name='Rows',default=16,min=4,max=64)

class FFGN_Settings(PropertyGroup):
    owner: PointerProperty(type=bpy.types.Object,name='Pinned rig')
    new_name: StringProperty(name='Shape / pose name',default='jawOpen')
    pose_name: StringProperty(name='Pose name',default='Pose')
    channel_name: StringProperty(name='Progressive channel',default='jawOpen')
    stage: FloatProperty(name='Stage',default=.5,min=-1.,max=1.)
    directory: StringProperty(name='OBJ package folder',subtype='DIR_PATH')
    edit_object: PointerProperty(type=bpy.types.Object)
    edit_owner: PointerProperty(type=bpy.types.Object)
    edit_uid: StringProperty()
    edit_hidden: BoolProperty()
    edit_state: StringProperty(default='{}')
    edit_created: BoolProperty()
    show_advanced: BoolProperty(name='Target tools & settings',default=False)
    show_mixer_filters: BoolProperty(name='Mixer display',default=False)
    mask_blur_steps: IntProperty(name='Mask blur steps',default=8,min=1,max=100)
    split_width: FloatProperty(name='Split transition width',default=.02,min=0.,subtype='DISTANCE')
    mirror_tolerance: FloatProperty(name='Mirror tolerance',default=.0001,min=.000001,subtype='DISTANCE')
    transfer_distance: FloatProperty(name='Transfer max distance',default=.05,min=.000001,subtype='DISTANCE')
    bake_start: IntProperty(name='First frame',default=1)
    bake_end: IntProperty(name='Last frame',default=100)
    show_shapes: BoolProperty(name='Shape editor',default=True)
    show_pipeline: BoolProperty(name='Import / Export & Pipeline',default=False)
    show_poses: BoolProperty(name='Pose library',default=False)


def active(o):
    if not len(o.ffgn.targets): raise ValueError('No target selected')
    return o.ffgn.targets[min(o.ffgn.active_target,len(o.ffgn.targets)-1)]

def select(context,o):
    if context.object and context.object.mode!='OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT'); o.hide_set(False); o.select_set(True); context.view_layer.objects.active=o

def finish_edit(context,commit):
    return A.finish(context,commit)

class FFGN_OT_action(Operator):
    bl_idname='ffgn.action'; bl_label='FaceForge'; bl_options={'REGISTER','UNDO'}
    action: StringProperty()
    index: IntProperty(default=-1)
    def execute(self,context):
        s=context.scene.ffgn_settings
        try:
            if self.action=='INIT':
                o=context.object
                if not o: raise ValueError('Select your neutral face mesh first.')
                if o.mode!='OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
                E.initialize(o); s.owner=o
            elif self.action=='KEYS':
                src=context.object
                if not src or src.type!='MESH' or not src.data.shape_keys: raise ValueError('Select a mesh with shape keys')
                keys=src.data.shape_keys.key_blocks
                neutral=np.array([tuple(v.co) for v in keys[0].data],dtype=np.float32)
                shapes={k.name:np.array([tuple(v.co) for v in k.data],dtype=np.float32) for k in list(keys)[1:]}
                specs=E.parse_names(shapes)
                me=src.data.copy(); o=bpy.data.objects.new(src.name+'_FaceForge',me); context.collection.objects.link(o); o.matrix_world=src.matrix_world.copy(); o.shape_key_clear(); E.put_coords(me,neutral); E.initialize(o)
                for sp in specs: E.add(o,sp['name'],shapes[sp['name']],sp['kind'],sp.get('channel'),sp.get('weight',1.),sp.get('drivers'),sp.get('mode','PRODUCT'))
                E.rebuild(o); select(context,o); s.owner=o
            elif self.action in {'COMMIT','CANCEL'}: finish_edit(context,self.action=='COMMIT')
            else:
                o=E.rig(context); r=o.ffgn; E.check(o)
                if s.edit_object and self.action not in {'VALIDATE'}: raise ValueError('Commit or cancel the active sculpt session first')
                if self.action=='FILTER_CLEAR':
                    r.search='';r.group_filter='';r.kind_filter='ALL';r.active_only=False;r.mixer_page=1
                elif self.action in {'MOVE_UP','MOVE_DOWN'}:
                    visible=[i for i in target_order(r) if target_visible(r,r.targets[i])]
                    if r.sort_mode!='MANUAL':raise ValueError('Choose Custom order to move shapes.')
                    if r.active_target not in visible:raise ValueError('Select a visible shape first.')
                    at=visible.index(r.active_target);dest=at+(-1 if self.action=='MOVE_UP' else 1)
                    if 0<=dest<len(visible):
                        E._BUSY+=1
                        try:r.targets.move(r.active_target,visible[dest]);r.active_target=visible[dest]
                        finally:E._BUSY-=1
                        E.rebuild(o)
                elif self.action=='REBUILD': E.rebuild(o)
                elif self.action=='ZERO':
                    for c in r.channels: c.value=0.
                elif self.action=='KEYFRAME':
                    for c in r.channels: c.keyframe_insert('value',group='FaceForge • '+c.group)
                elif self.action=='PREVIEW_ARC':
                    t=active(o)
                    if t.kind!='SHAPE':raise ValueError('Select a channel stage first.')
                    knots=[0.]+[x.weight for x in r.targets if x.kind=='SHAPE' and x.channel==t.channel and x.weight*t.weight>0 and abs(x.weight)<abs(t.weight)]
                    previous=max(knots,key=abs)
                    A.pose(o,{t.channel:(previous+t.weight)*.5});r.envelope=1.;E.rebuild(o)
                elif self.action=='SOLO':
                    t=active(o); pose=E.target_pose(t)
                    for c in r.channels: c.value=pose.get(c.name,0.)
                elif self.action in {'NEW','PROGRESSIVE','COMBO'}:
                    if self.action=='NEW': E.add(o,s.new_name,E.attr(o.data,E.REST),ch=s.new_name)
                    elif self.action=='PROGRESSIVE':
                        if not any(c.name==s.channel_name for c in r.channels): raise ValueError('Choose an existing progressive channel')
                        p=E.evaluate(o,{s.channel_name:s.stage},envelope=False)
                        E.add(o,s.new_name,p,ch=s.channel_name,weight=s.stage)
                    else:
                        ds=[(c.name,c.value) for c in r.channels if abs(c.value)>1e-5]
                        p=E.evaluate(o,envelope=False); E.add(o,s.new_name,p,'COMBO',drivers=ds)
                    E.rebuild(o)
                elif self.action=='SELECTED':
                    from .pipeline import import_meshes
                    import_meshes(o,context.selected_objects)
                elif self.action=='EDIT':
                    A.begin(context,o,active(o),'SCULPT')
                elif self.action=='EXTRACT':
                    t=active(o); ob=E.mesh_object(o,t.name,E.target_positions(o,t)); select(context,ob)
                elif self.action=='FREEZE': E.freeze(o,active(o)); E.rebuild(o)
                elif self.action=='DELETE': E.remove(o,r.active_target)
                elif self.action=='MASK':
                    t=active(o)
                    if not t.mask:
                        g=o.vertex_groups.new(name='FFGN mask • '+t.name); g.add(list(range(len(o.data.vertices))),1.,'REPLACE'); t.mask=g.name
                    select(context,o); o.vertex_groups.active_index=o.vertex_groups[t.mask].index
                    E.rebuild(o); bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
                elif self.action=='BLUR_MASK': E.blur_mask(o,active(o),s.mask_blur_steps)
                elif self.action=='BAKE_MASK':
                    t=active(o); E.freeze(o,t); E.attr(o.data,t.attribute,E.attr(o.data,t.attribute)*E.mask(o,t)[:,None]); t.mask=''; t.invert_mask=False; E.rebuild(o)
                elif self.action=='SPLIT': E.split(o,active(o),s.split_width)
                elif self.action=='MIRROR':
                    t=active(o)
                    if t.kind!='SHAPE': raise ValueError('Mirror shape stages; create opposite-side combo drivers explicitly')
                    indices=E.mirror_map(o,s.mirror_tolerance); d=E.live_delta(o,t)[indices]*E.mask(o,t)[indices,None]*t.gain; d[:,0]*=-1
                    E.add(o,s.new_name,E.attr(o.data,E.REST)+d,ch=s.channel_name,weight=t.weight); E.rebuild(o)
                elif self.action=='POSE_SAVE':
                    name=s.pose_name.strip()
                    if not name:raise ValueError('Enter a pose name.')
                    if any(p.name==name for p in r.poses): raise ValueError('Pose name exists; use Update Stored Pose to replace it.')
                    v=E.values(o);clear_pose_mix(o)
                    p=r.poses.add(); p.name=name; p.values=json.dumps(v); r.active_pose=len(r.poses)-1
                    solo_pose(o,r.active_pose)
                elif self.action=='POSE_UPDATE':
                    if not r.poses:raise ValueError('No pose selected')
                    v=E.values(o);clear_pose_mix(o);r.poses[r.active_pose].values=json.dumps(v);solo_pose(o,r.active_pose)
                elif self.action=='POSE_APPLY':
                    if not r.poses:raise ValueError('No pose selected')
                    solo_pose(o,r.active_pose)
                elif self.action=='POSE_OFF':
                    clear_pose_mix(o);apply_pose_mix(o)
                elif self.action=='POSE_DELETE':
                    if not r.poses:raise ValueError('No pose selected')
                    r.poses.remove(r.active_pose);r.active_pose=max(0,min(r.active_pose,len(r.poses)-1));apply_pose_mix(o)
                elif self.action in {'IMPORT','EXPORT'}:
                    if not s.directory: raise ValueError('Choose an OBJ package folder')
                    folder=bpy.path.abspath(s.directory)
                    count=E.import_package(o,folder) if self.action=='IMPORT' else E.export_package(o,folder)
                    self.report({'INFO'},f'{count} shapes '+('imported' if self.action=='IMPORT' else 'exported as absolute poses'))
                elif self.action=='UPDATE_BASE':
                    targets=[x for x in context.selected_objects if x!=o and x.type=='MESH']
                    if len(targets)!=1: raise ValueError('Select exactly one revised neutral mesh while the rig is pinned')
                    src=targets[0]; E.compatible(o.data,src.data); new=E.coords(src.data); delta=new-E.attr(o.data,E.REST)
                    for t in r.targets:
                        E.freeze(o,t); E.attr(o.data,t.reference,E.attr(o.data,t.reference)+delta)
                    E.put_coords(o.data,new); E.attr(o.data,E.REST,new); E.rebuild(o)
                elif self.action=='TRANSFER':
                    targets=[x for x in context.selected_objects if x!=o and x.type=='MESH']
                    if len(targets)!=1: raise ValueError('Select exactly one aligned destination mesh; pin the source rig')
                    dest=targets[0]; E.transfer(o,dest,s.transfer_distance); select(context,dest); s.owner=dest
                elif self.action=='BAKE':
                    if s.bake_end<s.bake_start or s.bake_end-s.bake_start>10000: raise ValueError('Invalid frame range (limit 10001 samples)')
                    positions=[]; frame=context.scene.frame_current
                    try:
                        for f in range(s.bake_start,s.bake_end+1):
                            context.scene.frame_set(f); positions.append(E.evaluate(o))
                    finally: context.scene.frame_set(frame)
                    ob=E.mesh_object(o,o.name+'_Baked',E.attr(o.data,E.REST)); ob.shape_key_add(name='Basis')
                    for i,p in enumerate(positions):
                        f=s.bake_start+i; key=ob.shape_key_add(name=f'frame_{f:04d}'); key.data.foreach_set('co',np.asarray(p,dtype=np.float32).ravel())
                        for fr,val in [(f-1,0.),(f,1.),(f+1,0.)]: key.value=val; key.keyframe_insert('value',frame=fr)
                    # Linear interpolation gives exact integer samples, no Bezier spill.
                    action=ob.data.shape_keys.animation_data.action
                    curves=[]
                    if hasattr(action,'fcurves'): curves=list(action.fcurves)
                    else:
                        for layer in action.layers:
                            for strip in layer.strips:
                                for bag in strip.channelbags: curves.extend(bag.fcurves)
                    for fc in curves:
                        for k in fc.keyframe_points: k.interpolation='LINEAR'
                    context.scene.frame_set(frame); select(context,ob)
                    self.report({'INFO'},'Baked new mesh with one shape key per sampled frame; source rig preserved')
                elif self.action=='VALIDATE':
                    issues=[]
                    known={c.name for c in r.channels}
                    E.expressions(o)
                    for t in r.targets:
                        E.live_delta(o,t); E.mask(o,t)
                        if t.kind=='SHAPE' and t.channel not in known: issues.append('Missing channel '+t.channel)
                        if not np.isfinite(E.attr(o.data,t.attribute)).all(): issues.append('Non-finite '+t.name)
                    managed=next((i for i,m in enumerate(o.modifiers) if m.type=='NODES' and m.node_group and m.node_group.get('ffgn_token')==r.token),None)
                    if managed is None: issues.append('Missing GN modifier: Rebuild')
                    elif managed>0: issues.append('Place FaceForge before armature / topology-changing modifiers')
                    if issues: raise ValueError('; '.join(issues))
                    self.report({'INFO'},f'Validated {len(r.channels)} channels / {len(r.targets)} targets')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}

class FFGN_UL_targets(UIList):
    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
        child=item.kind=='SHAPE' and abs(item.weight)<.99999
        row=layout.row(align=True)
        row.label(text=('    '+item.name) if child else item.name,icon='DRIVER' if item.kind=='COMBO' else ('IPO_EASE_IN_OUT' if child else 'SHAPEKEY_DATA'))
        row.label(text='Combo' if item.kind=='COMBO' else f'{item.weight:.2f}')
    def filter_items(self,context,data,propname):
        items=list(getattr(data,propname))
        visible={t.uid for t in visible_targets(data)}
        flags=[self.bitflag_filter_item if x.uid in visible else 0 for x in items]
        rank=[0]*len(items)
        for position,index in enumerate(target_order(data)):rank[index]=position
        return flags,rank

class FFGN_MT_groups(bpy.types.Menu):
    bl_label='Filter by group'
    def draw(self,context):
        r=E.rig(context).ffgn
        op=self.layout.operator('ffgn.group_filter',text='All groups');op.group=''
        for group in sorted({target_group(r,t) for t in r.targets},key=str.casefold):
            op=self.layout.operator('ffgn.group_filter',text=group);op.group=group

class FFGN_OT_group_filter(Operator):
    bl_idname='ffgn.group_filter';bl_label='Filter group'
    group:StringProperty()
    def execute(self,context):
        r=E.rig(context).ffgn;r.group_filter=self.group;r.mixer_page=1
        return {'FINISHED'}

class FFGN_OT_assign_group(Operator):
    bl_idname='ffgn.assign_group';bl_label='Assign Group';bl_options={'REGISTER','UNDO'}
    group:StringProperty(name='Group',default='Mouth')
    scope:EnumProperty(name='Apply to',items=[('SELECTED','Selected family','Primary and all its stages, or selected combo'),('FILTERED','All filtered shapes','Assign every currently visible shape and its channel family')])
    def invoke(self,context,event):return context.window_manager.invoke_props_dialog(self)
    def draw(self,context):
        self.layout.prop(self,'group');self.layout.prop(self,'scope')
        self.layout.label(text='Stages share their parent channel group.')
    def execute(self,context):
        try:
            o=E.rig(context);r=o.ffgn
            if context.scene.ffgn_settings.edit_object:raise ValueError('Finish the current shape first.')
            group=self.group.strip()
            if not group:raise ValueError('Enter a group name.')
            targets=[active(o)] if self.scope=='SELECTED' else visible_targets(r)
            if not targets:raise ValueError('No shapes match the filters.')
            for t in targets:
                if t.kind=='SHAPE':r.channels[t.channel].group=group
                else:t.group=group
            r.group_filter=group;r.mixer_page=1
            self.report({'INFO'},f'Assigned {len(targets)} targets to {group}')
            return {'FINISHED'}
        except Exception as exc:self.report({'ERROR'},str(exc));return {'CANCELLED'}

class FFGN_UL_poses(UIList):
    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index): layout.prop(item,'weight',text=item.name,slider=True)

def button(layout,label,action,icon='NONE'):
    op=layout.operator('ffgn.action',text=label,icon=icon); op.action=action; return op

def edit_buttons(layout):
    row=layout.row(align=True)
    for mode,icon in [('EDIT','EDITMODE_HLT'),('SCULPT','SCULPTMODE_HLT')]:
        cell=row.row(align=True)
        edit=bpy.context.scene.ffgn_settings.edit_object
        cell.enabled=not edit or edit.mode!=mode
        cell.operator('ffgn.edit_shape',text=mode.title(),icon=icon).mode=mode

def fold(layout,s,prop):
    layout.prop(s,prop,icon='TRIA_DOWN' if getattr(s,prop) else 'TRIA_RIGHT',emboss=False)
    return getattr(s,prop)

class FFGN_PT_panel(Panel):
    bl_label='FaceForge GN • Shape Authoring'; bl_idname='FFGN_PT_panel'; bl_space_type='VIEW_3D'; bl_region_type='UI'; bl_category='FaceForge'
    def draw(self,context):
        l=self.layout; s=context.scene.ffgn_settings
        if s.edit_object:
            box=l.box(); box.label(text='EDITING SHAPE',icon='SCULPTMODE_HLT')
            t=next((t for t in s.edit_owner.ffgn.targets if t.uid==s.edit_uid),None) if s.edit_owner else None
            box.label(text=t.name if t else s.edit_object.name)
            if t and t.kind=='COMBO':
                for name,value in json.loads(t.drivers): box.label(text=f'{name}: {value:.3f}')
            elif t: box.label(text=f'{t.channel} at {t.weight:.3f}')
            edit_buttons(box)
            row=box.row(align=True); row.scale_y=1.5
            button(row,'Done','COMMIT','CHECKMARK'); button(row,'Cancel','CANCEL','X')
            box.label(text='Move vertices or sculpt this working mesh.')
            box.label(text='Keep topology: no Remesh or Dyntopo.')
            if t and t.mask: box.label(text='Masked target: edit inside its mask.')
            box.label(text='Your neutral is saved separately.',icon='LOCKED')
            return
        l.prop(s,'owner',text='Rig')
        o=s.owner or context.object
        if not o or o.type!='MESH':
            l.label(text='Select your neutral face mesh.')
            l.operator('ffgn.pipeline',text='Build Network from OBJ Folder',icon='IMPORT').action='BUILD'
            return
        if not o.ffgn.enabled:
            l.label(text='1. Select a face in its neutral expression.')
            l.label(text='2. Initialize, then create your first shape.')
            row=l.row(); row.scale_y=1.5
            button(row,'Initialize Neutral','INIT','GEOMETRY_NODES')
            button(l,'Import Existing Shape Keys','KEYS','SHAPEKEY_DATA')
            l.operator('ffgn.pipeline',text='Build Network from OBJ Folder',icon='IMPORT').action='BUILD'
            return
        r=o.ffgn
        row=l.row(); row.scale_y=1.4
        row.operator('ffgn.create_shape',text='New Shape',icon='ADD').kind='PRIMARY'
        if not r.targets:
            box=l.box(); box.label(text='Neutral saved. Ready for your first shape.',icon='CHECKMARK')
            box.label(text='New Shape → jawOpen → Sculpt → Done')
        if r.status:
            box=l.box(); box.alert=True; box.label(text=r.status,icon='ERROR')
        if r.targets:
            box=l.box();row=box.row(align=True);row.prop(r,'search',text='',icon='VIEWZOOM');button(row,'','FILTER_CLEAR','X')
            row=box.row(align=True);row.menu('FFGN_MT_groups',text=r.group_filter or 'All groups');row.prop(r,'kind_filter',text='')
            row=box.row(align=True);row.prop(r,'sort_mode',text='');row.prop(r,'active_only',text='Active only')
            if r.sort_mode!='MANUAL':box.prop(r,'sort_reverse')
        if r.channels:
            box=l.box(); box.label(text='SHAPE MIXER',icon='GEOMETRY_NODES')
            row=box.row(align=True); button(row,'Neutral','ZERO','LOOP_BACK'); button(row,'Key Pose','KEYFRAME','KEY_HLT')
            if fold(box,s,'show_mixer_filters'):
                row=box.row(align=True); row.prop(r,'mixer_page'); row.prop(r,'mixer_rows')
            visible=visible_targets(r)
            names={name for t in visible for name in E.target_pose(t)}
            filtered=[c for c in r.channels if c.name in names]
            if r.sort_mode=='MANUAL':
                order={n:i for i,n in enumerate(dict.fromkeys(n for t in visible for n in E.target_pose(t)))}
                filtered.sort(key=lambda c:order[c.name])
            if r.sort_mode in {'NAME','FAMILY'}:filtered.sort(key=lambda c:c.name.casefold(),reverse=r.sort_reverse)
            elif r.sort_mode=='GROUP':filtered.sort(key=lambda c:(c.group.casefold(),c.name.casefold()),reverse=r.sort_reverse)
            if not filtered:box.label(text='No channels match these filters.')
            pages=max(1,(len(filtered)+r.mixer_rows-1)//r.mixer_rows); page=min(r.mixer_page,pages)
            for c in filtered[(page-1)*r.mixer_rows:page*r.mixer_rows]:
                row=box.row(align=True);row.prop(c,'value_positive' if c.range_mode=='POSITIVE' else 'value',text=c.name,slider=True);limits=row.row(align=True);limits.ui_units_x=3.3;limits.prop(c,'range_mode',text='')
            if pages>1:
                row=box.row(); row.prop(r,'mixer_page'); row.label(text=f'of {pages}')
        if r.channels:
            box=l.box(); box.label(text='EDIT CURRENT MIX')
            values=A.current_pose(o)
            if len(values)==1:
                name,value=next(iter(values.items())); box.label(text=f'{name} at {value:.4g}')
            elif values:
                box.label(text=f'Combination corrective: {len(values)} channels')
                for name,value in values.items(): box.label(text=f'{name}: {value:.4g}')
            else: box.label(text='Dial a shape, then Edit or Sculpt.')
            row=box.row(align=True); row.scale_y=1.4; row.enabled=bool(values)
            row.operator('ffgn.sculpt_pose',text='Edit',icon='EDITMODE_HLT').mode='EDIT'
            row.operator('ffgn.sculpt_pose',text='Sculpt',icon='SCULPTMODE_HLT').mode='SCULPT'
        if r.targets:
            box=l.box(); box.label(text='STORED SHAPES');box.prop(r,'quickset')
            box.template_list('FFGN_UL_targets','',r,'targets',r,'active_target',rows=7)
            box.label(text=f'{len(visible_targets(r))} / {len(r.targets)} shapes')
            row=box.row(align=True);row.operator('ffgn.assign_group',text='Assign Group',icon='FILE_FOLDER')
            if r.sort_mode=='MANUAL':
                button(row,'','MOVE_UP','TRIA_UP');button(row,'','MOVE_DOWN','TRIA_DOWN')
            t=active(o)
            if t.kind=='COMBO':
                for name,value in json.loads(t.drivers): box.label(text=f'{name} at {value:.3f}')
            else: box.label(text=f'Parent: {t.channel}  |  Weight: {t.weight:.3f}')
            if not r.quickset: button(box,'Preview Selected','SOLO','SOLO_ON')
            if t.kind=='SHAPE':
                c=r.channels.get(t.channel)
                if c:
                    box.prop(c,'interpolation',expand=True)
                    if c.interpolation=='CURVED':
                        box.label(text='Automatic path through sculpted stages')
                        if sum(t.kind=='SHAPE' and t.channel==c.name and t.weight*active(o).weight>0 for t in r.targets)<2:
                            box.label(text='Add an inbetween to define an arc.',icon='INFO')
                        button(box,'Preview Curve Between Stages','PREVIEW_ARC','PLAY')
            if fold(l,s,'show_advanced'):
                box=l.box(); box.prop(t,'name',text='Target name')
                box.label(text='Edit Selected Target (ignores mixer)')
                edit_buttons(box)
                row=box.row(align=True); row.prop(t,'mute'); row.prop(t,'gain')
                if t.kind=='SHAPE':
                    c=r.channels.get(t.channel)
                    if c:
                        box.prop(c,'group')
                else: box.prop(t,'combo_mode')
                box.prop(t,'source'); box.prop(t,'live')
                row=box.row(align=True); button(row,'Extract','EXTRACT','DUPLICATE'); button(row,'Freeze','FREEZE','FREEZE')
                box.prop_search(t,'mask',o,'vertex_groups'); box.prop(t,'invert_mask')
                row=box.row(align=True); button(row,'Paint Mask','MASK','WPAINT_HLT'); button(row,'Bake Mask','BAKE_MASK','CHECKMARK')
                row=box.row(align=True); row.prop(s,'mask_blur_steps'); button(row,'Blur','BLUR_MASK','MOD_SMOOTH')
                box.prop(s,'split_width'); button(box,'Split L / R','SPLIT','MOD_MIRROR')
                box.prop(s,'new_name',text='Mirror target name'); box.prop(s,'channel_name',text='Mirror channel')
                box.prop(s,'mirror_tolerance'); button(box,'Mirror to Named Channel','MIRROR','MOD_MIRROR')
                button(box,'Delete Selected Target','DELETE','TRASH')
        if fold(l,s,'show_poses'):
            box=l.box(); box.prop(s,'pose_name',text='New pose'); box.template_list('FFGN_UL_poses','',r,'poses',r,'active_pose',rows=3)
            if r.poses: box.prop(r.poses[r.active_pose],'name',text='Rename selected')
            row=box.row(align=True); button(row,'Store','POSE_SAVE','ADD'); button(row,'Apply','POSE_APPLY','POSE_HLT'); button(row,'Delete','POSE_DELETE','TRASH')
            row=box.row(align=True);button(row,'All Poses Off','POSE_OFF','LOOP_BACK');button(row,'Update Stored Pose','POSE_UPDATE','FILE_REFRESH')
            box.label(text='Pose sliders blend; manual channel edits detach.')
        if fold(l,s,'show_pipeline'):
            box=l.box(); box.prop(r,'envelope',slider=True)
            row=box.row(align=True); button(row,'Validate','VALIDATE','CHECKMARK'); button(row,'Rebuild','REBUILD','FILE_REFRESH')
            box.operator('ffgn.recover',text='Recover Edits to Neutral',icon='RECOVER_LAST')
            box.operator('ffgn.pipeline',text='Add Shapes from Selected Meshes',icon='OUTLINER_OB_MESH').action='MESHES'
            box.operator('ffgn.pipeline',text='Build Network from OBJ Folder',icon='IMPORT').action='BUILD'
            row=box.row(align=True)
            row.operator('ffgn.pipeline',text='Import OBJ Shapes',icon='IMPORT').action='IMPORT'
            row.operator('ffgn.pipeline',text='Export Shapes',icon='EXPORT').action='EXPORT'
            button(box,'Update Base from Selected Neutral','UPDATE_BASE','FILE_REFRESH')
            box.prop(s,'transfer_distance'); button(box,'Transfer to Selected Mesh','TRANSFER','MOD_DATA_TRANSFER')
            row=box.row(align=True); row.prop(s,'bake_start'); row.prop(s,'bake_end'); button(box,'Bake Animation to New Mesh','BAKE','SHAPEKEY_DATA')

from .operators import CLASSES as AUTHORING_CLASSES

CLASSES=[FFGN_MT_groups,FFGN_OT_group_filter,FFGN_OT_assign_group,FFGN_Channel,FFGN_Target,FFGN_Pose,FFGN_Rig,FFGN_Settings,FFGN_OT_action,FFGN_UL_targets,FFGN_UL_poses,FFGN_PT_panel]+AUTHORING_CLASSES
@bpy.app.handlers.persistent
def upgrade_curves(_=None):
    for o in bpy.data.objects:
        if not o.ffgn.enabled:continue
        mod=next((m for m in o.modifiers if m.type=='NODES' and m.node_group and m.node_group.get('ffgn_token')==o.ffgn.token),None)
        if mod and mod.node_group.get('ffgn_curve_version')==25:continue
        try:E.rebuild(o)
        except Exception as exc:o.ffgn.status='Rebuild needed: '+str(exc)

def deferred_upgrade():
    if not hasattr(bpy.types.Object,'ffgn'):return None
    if not hasattr(bpy.data,'objects'):return .1
    upgrade_curves()
    return None

def cleanup_registration():
    # Also recover partially registered classes left by a failed older enable.
    for fn in list(bpy.app.handlers.load_post):
        if getattr(fn,'__module__','')==__name__ and getattr(fn,'__name__','')=='upgrade_curves':
            old_timer=fn.__globals__.get('deferred_upgrade')
            if old_timer and bpy.app.timers.is_registered(old_timer):bpy.app.timers.unregister(old_timer)
            bpy.app.handlers.load_post.remove(fn)
    if bpy.app.timers.is_registered(deferred_upgrade):bpy.app.timers.unregister(deferred_upgrade)
    for owner,name in [(bpy.types.Scene,'ffgn_settings'),(bpy.types.Object,'ffgn')]:
        if hasattr(owner,name):delattr(owner,name)
    for cls in reversed(CLASSES):
        old=getattr(bpy.types,cls.__name__,None)
        if old is None:
            for base in cls.__bases__:
                if hasattr(base,'bl_rna_get_subclass_py'):
                    old=base.bl_rna_get_subclass_py(cls.__name__,None)
                    if old:break
        if old is not None:bpy.utils.unregister_class(old)

def register():
    cleanup_registration()
    try:
        for cls in CLASSES:bpy.utils.register_class(cls)
        bpy.types.Object.ffgn=PointerProperty(type=FFGN_Rig)
        bpy.types.Scene.ffgn_settings=PointerProperty(type=FFGN_Settings)
        bpy.app.handlers.load_post.append(upgrade_curves)
        bpy.app.timers.register(deferred_upgrade,first_interval=.1)
    except Exception:
        cleanup_registration()
        raise

def unregister():
    cleanup_registration()

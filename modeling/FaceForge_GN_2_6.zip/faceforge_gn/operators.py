"""Artist-facing authoring commands; no internal driver JSON in dialogs."""
import json
import bpy
from bpy.props import StringProperty, EnumProperty, FloatProperty
from bpy.types import Operator
from . import engine as E
from . import authoring as A

MODES=[('SCULPT','Sculpt','Start with sculpt brushes'),('EDIT','Edit','Start with vertex / proportional editing')]

def selected(obj):
    if not obj.ffgn.targets: raise ValueError('Create or select a shape first.')
    return obj.ffgn.targets[min(obj.ffgn.active_target,len(obj.ffgn.targets)-1)]

class FFGN_OT_create_shape(Operator):
    bl_idname='ffgn.create_shape'; bl_label='Create and Edit Shape'; bl_options={'REGISTER','UNDO'}
    kind: EnumProperty(items=[('PRIMARY','New Shape','New independent control'),('INBETWEEN','In-between','Intermediate pose on an existing control'),('COMBO','Combination Corrective','Correct the current combination')])
    shape_name: StringProperty(name='Name')
    channel: StringProperty(name='Parent shape')
    weight: FloatProperty(name='Weight',default=.5,min=-1.,max=1.)
    mode: EnumProperty(name='Start in',items=MODES,default='SCULPT')
    activation: EnumProperty(name='Activation',items=[('PRODUCT','Product','Multiply normalized driver values'),('MINIMUM','Minimum','Use the lowest normalized driver value')])
    driver_pose: StringProperty(default='[]',options={'HIDDEN'})

    def invoke(self,context,event):
        try:
            o=E.rig(context)
            if context.scene.ffgn_settings.edit_object: raise ValueError('Finish the current shape first.')
            if self.kind=='PRIMARY':
                self.shape_name='jawOpen' if not o.ffgn.channels.get('jawOpen') else ''
            elif self.kind=='INBETWEEN':
                t=selected(o)
                if t.kind!='SHAPE': raise ValueError('Select a primary shape or its in-between first.')
                self.channel=t.channel; v=o.ffgn.channels[self.channel].value
                self.weight=v if 1e-5<abs(v)<.99999 else .5
            else:
                ds=[(c.name,c.value) for c in o.ffgn.channels if abs(c.value)>1e-5]
                if len(ds)<2: raise ValueError('Raise at least two shape sliders, then create a corrective.')
                self.driver_pose=json.dumps(ds)
            return context.window_manager.invoke_props_dialog(self,width=390,confirm_text='Create & Sculpt')
        except Exception as exc:
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}

    def draw(self,context):
        l=self.layout
        if self.kind=='PRIMARY':
            l.label(text='Create a shape from your saved neutral.')
            l.prop(self,'shape_name')
            l.label(text='Example names: jawOpen, smile_L, browInnerUp')
        elif self.kind=='INBETWEEN':
            l.prop_search(self,'channel',E.rig(context).ffgn,'channels')
            l.prop(self,'weight'); l.prop(self,'shape_name',text='Name (optional)')
            l.label(text='Starts from the interpolated parent pose.')
        else:
            l.label(text='Correct this combined pose:')
            for n,v in json.loads(self.driver_pose): l.label(text=f'{n}  =  {v:.3f}')
            l.prop(self,'shape_name',text='Name (optional)'); l.prop(self,'activation')
            l.label(text='Only your sculpted correction is stored.')
        l.label(text='Create & Sculpt opens the working mesh in Sculpt Mode.')
        l.label(text='Finish with Done in the FaceForge sidebar.')

    def execute(self,context):
        t=None; o=None; prior=None
        try:
            s=context.scene.ffgn_settings
            if s.edit_object: raise ValueError('Finish the current shape first.')
            o=E.rig(context)
            if context.object and context.object.mode!='OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
            E.check(o); prior={'pose':E.values(o),'envelope':o.ffgn.envelope}
            if self.kind=='PRIMARY':
                name=self.shape_name.strip()
                if not name: raise ValueError('Enter a shape name, such as jawOpen.')
                if o.ffgn.channels.get(name): raise ValueError('This channel exists. Select it to edit or add an in-between.')
                t=E.add(o,name,E.attr(o.data,E.REST),ch=name)
            elif self.kind=='INBETWEEN':
                if not o.ffgn.channels.get(self.channel): raise ValueError('Choose an existing parent shape.')
                if not 1e-5<abs(self.weight)<.99999: raise ValueError('In-between weight must be between 0 and 1 (or -1 and 0).')
                name=self.shape_name.strip() or f'{self.channel}_{self.weight*100:g}'
                p=E.evaluate(o,{self.channel:self.weight},envelope=False)
                t=E.add(o,name,p,ch=self.channel,weight=self.weight)
            else:
                ds=json.loads(self.driver_pose) or [(c.name,c.value) for c in o.ffgn.channels if abs(c.value)>1e-5]
                name=self.shape_name.strip() or '+'.join(n for n,v in ds)
                p=E.evaluate(o,dict(ds),envelope=False)
                t=E.add(o,name,p,'COMBO',drivers=ds,mode=self.activation)
            E.rebuild(o)
            A.begin(context,o,t,self.mode,created=True,previous=prior)
            self.report({'INFO'},'Edit your shape, then click Done in FaceForge.')
            return {'FINISHED'}
        except Exception as exc:
            if t is not None and o is not None and not context.scene.ffgn_settings.edit_object:
                ch=t.channel
                E.remove(o,o.ffgn.active_target)
                if ch and prior and ch not in prior['pose']:
                    ci=next((i for i,c in enumerate(o.ffgn.channels) if c.name==ch),None)
                    if ci is not None: o.ffgn.channels.remove(ci)
                    E.rebuild(o)
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}

class FFGN_OT_edit_shape(Operator):
    bl_idname='ffgn.edit_shape'; bl_label='Edit Shape'; bl_options={'REGISTER','UNDO'}
    mode: EnumProperty(items=MODES,default='SCULPT')
    def execute(self,context):
        try:
            s=context.scene.ffgn_settings
            if s.edit_object:
                A.enter_mode(context,s.edit_object,self.mode)
            else:
                o=E.rig(context); A.begin(context,o,selected(o),self.mode)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}

class FFGN_OT_sculpt_pose(Operator):
    bl_idname='ffgn.sculpt_pose'; bl_label='Sculpt Current Pose'; bl_options={'REGISTER','UNDO'}
    bl_description='Edit the current mix: one channel creates an in-between; multiple channels create a corrective; existing matching targets are reused'
    mode: EnumProperty(items=MODES,default='SCULPT')
    def execute(self,context):
        try:
            A.begin_pose(context,E.rig(context),self.mode)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}

class FFGN_OT_recover(Operator):
    bl_idname='ffgn.recover'; bl_label='Recover Neutral Edits as Shape'; bl_options={'REGISTER','UNDO'}
    shape_name: StringProperty(name='Recovered shape name',default='recoveredShape')
    def invoke(self,context,event): return context.window_manager.invoke_props_dialog(self,width=380)
    def draw(self,context):
        self.layout.label(text='Save direct neutral edits as a new shape.')
        self.layout.label(text='Restore the saved neutral underneath it.')
        self.layout.prop(self,'shape_name')
    def execute(self,context):
        try:
            if context.scene.ffgn_settings.edit_object: raise ValueError('Finish the active shape session first.')
            A.recover_neutral(context,E.rig(context),self.shape_name.strip())
            self.report({'INFO'},'Recovered shape is now previewed at 1.0.'); return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}

CLASSES=[FFGN_OT_sculpt_pose,FFGN_OT_create_shape,FFGN_OT_edit_shape,FFGN_OT_recover]

class FFGN_OT_pipeline(Operator):
    bl_idname='ffgn.pipeline';bl_label='FaceForge Shape Pipeline';bl_options={'REGISTER','UNDO'}
    action: EnumProperty(items=[('MESHES','Add Selected Meshes','Import named target objects onto the pinned rig'),('BUILD','Build from OBJ Folder','Create a new network with an OBJ or selected mesh neutral'),('IMPORT','Import OBJ Shapes','Add named meshes from a folder'),('EXPORT','Export Shapes','Export all stored targets')])
    directory: StringProperty(name='OBJ folder',subtype='DIR_PATH')
    neutral_name: StringProperty(name='Neutral OBJ name',description='Blank auto-detects home, neutral, base or basis; otherwise enter a filename or stem')
    neutral_object: StringProperty(name='Use scene mesh as neutral')
    mode: EnumProperty(name='Mesh contents',items=[('COMBINED','Combined poses','Full evaluated poses including their channels and correctives'),('DIFFERENCE','Shape differences','Neutral plus target-only residual; stages exclude the scaled full primary')],default='COMBINED')
    def invoke(self,context,event):
        self.directory=context.scene.ffgn_settings.directory
        return context.window_manager.invoke_props_dialog(self,width=490)
    def draw(self,context):
        l=self.layout;l.label(text=dict((x[0],x[1]) for x in [('MESHES','Add selected meshes to Rig'),('BUILD','Build new facial network'),('IMPORT','Import shapes into Rig'),('EXPORT','Export every named target')])[self.action])
        if self.action!='MESHES':l.prop(self,'directory')
        if self.action in {'BUILD','IMPORT'}:l.prop(self,'neutral_name')
        if self.action=='BUILD':
            l.prop_search(self,'neutral_object',bpy.data,'objects');l.label(text='Blank neutral name: home / neutral / base / basis.')
        l.label(text='Create & Sculpt opens the working mesh in Sculpt Mode.')
        if self.action in {'MESHES','IMPORT','BUILD'}:
            l.label(text='Names: jawOpen_50, jawOpen_50_eyesClosed')
            l.label(text='Meshes must share indexed topology and local space.')
        else:
            l.label(text='Difference = neutral + just this target contribution.')
            l.label(text='Combined includes the fully evaluated corrective network.')
    def execute(self,context):
        from . import pipeline as P
        try:
            s=context.scene.ffgn_settings
            if s.edit_object:raise ValueError('Finish the current editing session first.')
            if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
            if self.action=='MESHES':count=P.import_meshes(E.rig(context),list(context.selected_objects),self.mode)
            else:
                if not self.directory:raise ValueError('Choose an OBJ folder.')
                folder=bpy.path.abspath(self.directory);s.directory=self.directory
                if self.action=='BUILD':
                    o=P.build_folder(context,folder,self.neutral_name,bpy.data.objects[self.neutral_object] if self.neutral_object else None,self.mode);s.owner=o;A.select(context,o);count=len(o.ffgn.targets)
                elif self.action=='IMPORT':count=P.import_folder(E.rig(context),folder,self.mode,self.neutral_name)
                else:count=P.export_network(E.rig(context),folder,self.mode)
            self.report({'INFO'},f'{count} shapes processed.');return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}

CLASSES.append(FFGN_OT_pipeline)

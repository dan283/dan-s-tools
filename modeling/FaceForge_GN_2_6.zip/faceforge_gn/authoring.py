"""Persistent, topology-safe Edit/Sculpt sessions. The runtime remains pure GN."""
import json
import bpy
import numpy as np
from . import engine as E

REFERENCE='FFGN_session_reference'
START='FFGN_session_start'
RAW='FFGN_session_raw'
FACTOR='FFGN_session_factor'

def select(context, obj):
    if context.object and context.object.mode!='OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    obj.hide_set(False); obj.select_set(True); context.view_layer.objects.active=obj

def enter_mode(context,obj,mode):
    select(context,obj)
    context.view_layer.update()
    area=context.area if context.area and context.area.type=='VIEW_3D' else next((a for a in context.screen.areas if a.type=='VIEW_3D'),None) if context.screen else None
    region=next((r for r in area.regions if r.type=='WINDOW'),None) if area else None
    if area and region:
        with context.temp_override(area=area,region=region,active_object=obj,object=obj):
            bpy.ops.object.mode_set(mode=mode)
    else:
        bpy.ops.object.mode_set(mode=mode)
    if obj.mode!=mode: raise RuntimeError('Could not enter '+mode+' mode; working mesh retained.')
    if area: area.tag_redraw()

@E.batch
def pose(obj, values):
    for stored in obj.ffgn.poses: stored.weight=0.
    for channel in obj.ffgn.channels: channel.value=values.get(channel.name,0.)
    obj.update_tag()

def begin(context, obj, target, mode='SCULPT', created=False, previous=None):
    s=context.scene.ffgn_settings
    if s.edit_object: raise ValueError('Finish the current shape with Done or Cancel first.')
    if context.object and context.object.mode!='OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    E.check(obj)
    if target.gain<1e-8: raise ValueError('Set this target Gain above zero before editing.')
    raw=E.live_delta(obj,target)
    factor=(E.mask(obj,target)*target.gain)[:,None]
    ref=E.attr(obj.data,E.REST) if target.kind=='SHAPE' else E.evaluate(obj,E.target_pose(target),exclude=target.uid,envelope=False)
    start=ref+raw*factor
    old=previous or {'pose':E.values(obj),'envelope':obj.ffgn.envelope,'mute':target.mute}
    old['pose_weights']={p.name:p.weight for p in obj.ffgn.poses}
    edit=E.mesh_object(obj,'EDIT • '+target.name,start)
    try:
        E.attr(edit.data,REFERENCE,ref); E.attr(edit.data,START,start)
        E.attr(edit.data,RAW,raw); E.attr(edit.data,FACTOR,np.repeat(factor,3,axis=1))
        s.edit_owner=obj; s.edit_object=edit; s.edit_uid=target.uid
        s.edit_hidden=obj.hide_get(); s.edit_state=json.dumps(old); s.edit_created=created
        s.owner=obj
        select(context,edit); obj.hide_set(True)
        enter_mode(context,edit,mode)
    except Exception:
        cleanup(context,obj,edit)
        raise
    return edit

def cleanup(context,obj,edit):
    s=context.scene.ffgn_settings; hidden=s.edit_hidden
    if context.object and context.object.mode!='OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    if edit:
        me=edit.data; bpy.data.objects.remove(edit,do_unlink=True)
        if me.users==0: bpy.data.meshes.remove(me)
    s.edit_object=None; s.edit_owner=None; s.edit_uid=''; s.edit_state='{}'; s.edit_created=False
    select(context,obj); obj.hide_set(hidden)

@E.batch
def finish(context,commit):
    s=context.scene.ffgn_settings; obj=s.edit_owner; edit=s.edit_object
    if not obj or not edit: raise ValueError('No active shape editing session.')
    select(context,edit)  # Flush the Edit Mode BMesh before reading positions.
    index=next((i for i,t in enumerate(obj.ffgn.targets) if t.uid==s.edit_uid),None)
    if index is None: raise ValueError('Edited target is missing; the working mesh has been kept.')
    t=obj.ffgn.targets[index]; state=json.loads(s.edit_state or '{}')
    if commit:
        E.check(obj); E.compatible(obj.data,edit.data)
        p=E.coords(edit.data)
        if not np.isfinite(p).all(): raise ValueError('Shape contains non-finite positions; working mesh kept.')
        # Old 1.0 sessions only stored their reference.
        if edit.data.attributes.get(START):
            change=p-E.attr(edit.data,START); factor=E.attr(edit.data,FACTOR)[:,0]
            blocked=factor<1e-8
            if np.any(np.linalg.norm(change[blocked],axis=1)>1e-6):
                raise ValueError('Edited vertices outside the target mask. Undo those edits or Cancel and adjust the mask.')
            delta=E.attr(edit.data,RAW)
            delta[~blocked]+=change[~blocked]/factor[~blocked,None]
        else: delta=p-E.attr(edit.data,REFERENCE)
        old_delta=E.attr(obj.data,t.attribute); old_ref=E.attr(obj.data,t.reference)
        old_source=t.source; old_live=t.live
        try:
            E.attr(obj.data,t.attribute,delta); E.attr(obj.data,t.reference,E.attr(edit.data,REFERENCE))
            t.source=None; t.live=False; E.rebuild(obj)
        except Exception:
            E.attr(obj.data,t.attribute,old_delta); E.attr(obj.data,t.reference,old_ref)
            t.source=old_source; t.live=old_live
            raise
        pose(obj,E.target_pose(t)); obj.ffgn.envelope=1.; t.mute=False
    else:
        if s.edit_created:
            ch=t.channel
            E.remove(obj,index)
            # Only remove a channel introduced by this cancelled operation.
            if ch and ch not in state.get('pose',{}) and not any(x.channel==ch for x in obj.ffgn.targets):
                ci=next((i for i,c in enumerate(obj.ffgn.channels) if c.name==ch),None)
                if ci is not None: obj.ffgn.channels.remove(ci)
                E.rebuild(obj)
        pose(obj,state.get('pose',{})); obj.ffgn.envelope=state.get('envelope',1.)
        for p in obj.ffgn.poses: p.weight=state.get('pose_weights',{}).get(p.name,0.)
    cleanup(context,obj,edit)

def recover_neutral(context,obj,name):
    """Recover same-topology accidental base edits as a new primary."""
    if context.object and context.object.mode!='OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    if E.topo(obj.data)!=obj.ffgn.signature: raise ValueError('Topology changed. Restore topology first; recovery requires the original vertex order.')
    if not name.strip() or any(t.name==name for t in obj.ffgn.targets): raise ValueError('Choose a unique shape name.')
    p=E.coords(obj.data); rest=E.attr(obj.data,E.REST)
    if not np.isfinite(p).all(): raise ValueError('Non-finite coordinates.')
    if np.allclose(p,rest): raise ValueError('The neutral has no direct edits to recover.')
    E.put_coords(obj.data,rest)
    try:
        t=E.add(obj,name,p,ch=name); E.rebuild(obj)
    except Exception:
        E.put_coords(obj.data,p)
        raise
    pose(obj,E.target_pose(t)); obj.ffgn.envelope=1.
    select(context,obj)
    return t

POSE_EPS=1e-5

def current_pose(obj):
    return {c.name:float(c.value) for c in obj.ffgn.channels if abs(c.value)>POSE_EPS}

def matching_target(obj,values):
    """Match channel identity AND activation values; list selection is irrelevant."""
    hits=[]
    for i,t in enumerate(obj.ffgn.targets):
        if (len(values)==1)!=(t.kind=='SHAPE'): continue
        other=E.target_pose(t)
        if other.keys()==values.keys() and all(abs(other[n]-v)<=POSE_EPS for n,v in values.items()): hits.append(i)
    if len(hits)>1: raise ValueError('Several stored targets match this pose. Use Target tools > Edit Selected Target to choose one.')
    return hits[0] if hits else None

def unique_name(obj,base):
    name=base; i=2
    while any(t.name==name for t in obj.ffgn.targets):
        name=f'{base}.{i:03d}'; i+=1
    return name

@E.batch
def begin_pose(context,obj,mode='SCULPT'):
    if context.scene.ffgn_settings.edit_object: raise ValueError('Finish the current shape first.')
    if context.object and context.object.mode!='OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    E.check(obj)
    values=current_pose(obj)
    if not values: raise ValueError('Dial a shape above zero, or use New Shape to create a primary.')
    index=matching_target(obj,values)
    previous={'pose':E.values(obj),'envelope':obj.ffgn.envelope,'active_target':obj.ffgn.active_target}
    created=index is None; target=None
    try:
        if created:
            p=E.evaluate(obj,values,envelope=False)
            if len(values)==1:
                name,weight=next(iter(values.items()))
                label=unique_name(obj,f'{name}_{weight*100:.5g}')
                target=E.add(obj,label,p,ch=name,weight=weight)
            else:
                label=unique_name(obj,'+'.join(f'{n}@{v:.5g}' for n,v in sorted(values.items())))
                target=E.add(obj,label,p,'COMBO',drivers=sorted(values.items()))
            E.rebuild(obj)
        else:
            obj.ffgn.active_target=index; target=obj.ffgn.targets[index]
        return begin(context,obj,target,mode,created=created,previous=previous)
    except Exception:
        if created and target is not None and not context.scene.ffgn_settings.edit_object:
            index=next((i for i,t in enumerate(obj.ffgn.targets) if t.uid==target.uid),None)
            if index is not None: E.remove(obj,index)
        obj.ffgn.active_target=previous['active_target']
        raise

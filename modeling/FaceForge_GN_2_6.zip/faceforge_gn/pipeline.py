"""Named mesh/OBJ networks and explicit full-pose versus residual handoff."""
import json,re
from pathlib import Path
import bpy
import numpy as np
from . import engine as E
from .core import parse_names,activation

NEUTRALS={'home','neutral','base','basis'}

def effective(o,t): return E.live_delta(o,t)*E.mask(o,t)[:,None]*t.gain

def primary_baseline(o,t):
    hero=next((x for x in o.ffgn.targets if x.kind=='SHAPE' and x.channel==t.channel and x.weight==(1 if t.weight>0 else -1)),None)
    return effective(o,hero)*abs(t.weight) if hero and hero.uid!=t.uid else np.zeros_like(E.attr(o.data,E.REST))

def difference(o,t):
    d=effective(o,t)
    if t.kind=='SHAPE' and abs(t.weight)!=1: d=d-primary_baseline(o,t)
    return E.attr(o.data,E.REST)+d

def combo_matrix(specs):
    return np.asarray([[activation(b['drivers'],b.get('mode','PRODUCT')).evaluate({n:dict(a['drivers']).get(n,0.) for n,_ in b['drivers']}) for b in specs] for a in specs],dtype=np.float64)

@E.batch
def import_payload(o,payload,mode='COMBINED',channel_specs=(),pose_specs=()):
    E.check(o);rest=E.attr(o.data,E.REST)
    requested_order=[s['name'] for s,p in payload]
    payload=sorted(payload,key=lambda item:(item[0]['kind']=='COMBO',0 if abs(item[0].get('weight',1))==1 else 1,item[0]['name']))
    existing_names={t.name for t in o.ffgn.targets}; stages={(t.channel,round(t.weight,6)) for t in o.ffgn.targets if t.kind=='SHAPE'}
    known={c.name for c in o.ffgn.channels}|{s['channel'] for s,p in payload if s['kind']=='SHAPE'}
    seen=set()
    for s,p in payload:
        if s['name'] in existing_names or s['name'] in seen: raise ValueError('Target already exists: '+s['name'])
        seen.add(s['name'])
        if p.shape!=rest.shape or not np.isfinite(p).all(): raise ValueError('Invalid coordinates: '+s['name'])
        if s['kind']=='SHAPE':
            key=(s['channel'],round(s['weight'],6))
            if key in stages or not (abs(s['weight'])>0 and np.isfinite(s['weight'])): raise ValueError('Duplicate or invalid stage: '+s['name'])
            stages.add(key)
        elif s['kind']=='COMBO':
            ds=s['drivers']
            if len(ds)<2 or len({n for n,w in ds})!=len(ds) or any(n not in known or not (abs(w)>0 and np.isfinite(w)) for n,w in ds): raise ValueError('Invalid corrective drivers: '+s['name'])
        else: raise ValueError('Invalid target kind')
    combos=[(s,p) for s,p in payload if s['kind']=='COMBO']; matrix=None
    if combos and mode=='COMBINED':
        matrix=combo_matrix([s for s,p in combos])
        if np.linalg.matrix_rank(matrix)!=len(combos): raise ValueError('Corrective poses do not uniquely define their differences. Import Difference meshes instead, or remove duplicate/dependent poses.')
    n_targets=len(o.ffgn.targets);n_channels=len(o.ffgn.channels);n_poses=len(o.ffgn.poses)
    try:
        for s,p in payload:
            if s['kind']!='SHAPE': continue
            if mode=='DIFFERENCE' and abs(s['weight'])!=1:
                hero=next((t for t in o.ffgn.targets if t.kind=='SHAPE' and t.channel==s['channel'] and t.weight==(1 if s['weight']>0 else -1)),None)
                if hero: p=p+effective(o,hero)*abs(s['weight'])
            E.add(o,s['name'],p,ch=s['channel'],weight=s['weight'])
        for spec in channel_specs:
            c=E.channel(o,spec['name']);c.interpolation=spec.get('interpolation','LINEAR');c.tension=spec.get('tension',0.);c.group=spec.get('group','Face');c.range_mode=spec.get('range_mode','POSITIVE');c.arc_perpendicular=spec.get('arc_perpendicular',True);c.arc_strength=spec.get('arc_strength',1.);c.arc_bulge=spec.get('arc_bulge',.25);c.arc_axis=spec.get('arc_axis',(0,1,0))
        if combos:
            if mode=='COMBINED':
                # Simultaneously recover all new residuals: full poses may contain each other.
                rhs=np.asarray([p-E.evaluate(o,dict(s['drivers']),envelope=False) for s,p in combos])
                ds=np.linalg.solve(matrix,rhs.reshape(len(combos),-1)).reshape(rhs.shape)
            else: ds=np.asarray([p-rest for s,p in combos])
            for (s,p),d in zip(combos,ds):
                reference=E.evaluate(o,dict(s['drivers']),envelope=False)
                E.add(o,s['name'],reference+d,'COMBO',drivers=s['drivers'],mode=s.get('mode','PRODUCT')).group=s.get('group','')
        for offset,name in enumerate(requested_order):
            index=next(i for i,t in enumerate(o.ffgn.targets) if t.name==name)
            o.ffgn.targets.move(index,n_targets+offset)
        for spec in pose_specs:
            p=o.ffgn.poses.add();p.name=spec['name'];p.values=json.dumps(spec['values'])
        E.rebuild(o)
    except Exception:
        for t in list(o.ffgn.targets)[n_targets:]:
            for name in [t.attribute,t.reference]:
                a=o.data.attributes.get(name)
                if a:o.data.attributes.remove(a)
        while len(o.ffgn.targets)>n_targets:o.ffgn.targets.remove(len(o.ffgn.targets)-1)
        while len(o.ffgn.channels)>n_channels:o.ffgn.channels.remove(len(o.ffgn.channels)-1)
        while len(o.ffgn.poses)>n_poses:o.ffgn.poses.remove(len(o.ffgn.poses)-1)
        E.rebuild(o);raise
    return len(payload)

@E.batch
def import_meshes(o,objects,mode='COMBINED'):
    objects=[x for x in objects if x!=o and x.type=='MESH']
    if not objects: raise ValueError('Select target meshes; set Rig to your neutral.')
    specs=parse_names([x.name for x in objects],[c.name for c in o.ffgn.channels]);lookup={x.name:x for x in objects};payload=[]
    for s in specs:
        src=lookup[s['name']];E.compatible(o.data,src.data);payload.append((s,E.coords(src.data)))
    return import_payload(o,payload,mode)

@E.batch
def export_network(o,directory,mode='COMBINED'):
    E.check(o)
    if not o.ffgn.targets: raise ValueError('No shapes to export.')
    root=Path(directory);root.mkdir(parents=True,exist_ok=True)
    files=[re.sub(r'[^\w.+@-]','_',t.name)+'.obj' for t in o.ffgn.targets]
    if len({x.casefold() for x in files})!=len(files) or any(Path(x).stem.casefold() in NEUTRALS for x in files): raise ValueError('Shape filenames collide after sanitizing; rename them before export.')
    if any((root/f).exists() for f in files+['neutral.obj','faceforge.json']): raise ValueError('Use a fresh export folder; existing files are preserved.')
    manifest={'schema':2,'space':'LOCAL','mode':mode,'neutral':'neutral.obj','targets':[],'channels':[],'poses':[],'difference_baseline':'NEUTRAL_PLUS_RESIDUAL; stages subtract signed full primary scaled by abs(weight)'}
    states=[t.mute for t in o.ffgn.targets];written=[]
    try:
        for t in o.ffgn.targets:t.mute=False
        E.write_obj(root/'neutral.obj',o,E.attr(o.data,E.REST));written.append(root/'neutral.obj')
        for t,file in zip(o.ffgn.targets,files):
            p=E.evaluate(o,E.target_pose(t),envelope=False) if mode=='COMBINED' else difference(o,t)
            E.write_obj(root/file,o,p);written.append(root/file)
            manifest['targets'].append(dict(name=t.name,file=file,kind=t.kind,channel=t.channel,weight=t.weight,drivers=json.loads(t.drivers),mode=t.combo_mode,group=t.group))
        manifest['channels']=[dict(name=c.name,range_mode=c.range_mode,arc_perpendicular=c.arc_perpendicular,arc_strength=c.arc_strength,arc_bulge=c.arc_bulge,arc_axis=list(c.arc_axis),interpolation=c.interpolation,tension=c.tension,group=c.group) for c in o.ffgn.channels]
        manifest['poses']=[dict(name=p.name,values=json.loads(p.values)) for p in o.ffgn.poses]
        (root/'faceforge.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    except Exception:
        for path in written:path.unlink(missing_ok=True)
        raise
    finally:
        for t,state in zip(o.ffgn.targets,states):t.mute=state
    return len(files)

def import_folder(o,directory,mode='COMBINED',neutral_name=''):
    root=Path(directory);manifest=None
    if (root/'faceforge.json').exists():
        manifest=json.loads((root/'faceforge.json').read_text(encoding='utf8'))
        if manifest.get('schema')==1:return E.import_package(o,directory)
        if manifest.get('schema')!=2 or manifest.get('space')!='LOCAL':raise ValueError('Unsupported package schema/space')
        specs=manifest['targets'];mode=manifest['mode']
        if mode not in {'COMBINED','DIFFERENCE'}:raise ValueError('Unknown package mode')
        def safe(name):
            p=(root/name).resolve()
            if p.parent!=root.resolve():raise ValueError('Package paths must be filenames')
            return p
        neutral,faces=E.read_obj(safe(manifest['neutral']));E.check_obj(o,neutral,faces)
        if not np.allclose(neutral,E.attr(o.data,E.REST),atol=1e-6):raise ValueError('Package neutral does not match this rig.')
        lookup={s['name']:safe(s['file']) for s in specs}
    else:
        excluded=NEUTRALS|{Path(neutral_name).stem.casefold()}
        files=[p for p in root.iterdir() if p.suffix.lower()=='.obj' and p.stem.casefold() not in excluded]
        specs=parse_names([p.stem for p in files],[c.name for c in o.ffgn.channels]);lookup={p.stem:p for p in files}
    payload=[]
    for s in specs:
        p,f=E.read_obj(lookup[s['name']]);E.check_obj(o,p,f);payload.append((s,p))
    if not payload:raise ValueError('No target OBJ files found.')
    return import_payload(o,payload,mode,manifest.get('channels',[]) if manifest else [],manifest.get('poses',[]) if manifest else [])

def build_folder(context,directory,neutral_name='',neutral_object=None,mode='COMBINED'):
    root=Path(directory)
    if not root.is_dir():raise ValueError('Choose an OBJ folder.')
    if neutral_object:
        if neutral_object.type!='MESH':raise ValueError('Neutral must be a mesh.')
        obj=E.mesh_object(neutral_object,neutral_object.name+'_FaceForge',E.coords(neutral_object.data))
        obj.shape_key_clear()
    else:
        files=[p for p in root.iterdir() if p.suffix.lower()=='.obj']
        if (root/'faceforge.json').exists():
            name=json.loads((root/'faceforge.json').read_text())['neutral'];path=(root/name).resolve()
            if path.parent!=root.resolve():raise ValueError('Invalid neutral path')
        else:
            matches=[p for p in files if p.stem.casefold()==Path(neutral_name).stem.casefold()] if neutral_name else [p for p in files if p.stem.casefold() in NEUTRALS]
            if len(matches)!=1:raise ValueError('Choose the neutral filename: found zero or multiple home/neutral/base/basis OBJs.')
            path=matches[0]
        p,faces=E.read_obj(path);mesh=bpy.data.meshes.new(path.stem+'_FaceForge');mesh.from_pydata(p.tolist(),[],faces);mesh.update()
        obj=bpy.data.objects.new(mesh.name,mesh);context.collection.objects.link(obj);neutral_name=path.stem
    try:
        E.initialize(obj);import_folder(obj,root,mode,neutral_name)
    except Exception:
        mesh=obj.data;groups=[m.node_group for m in obj.modifiers if m.type=='NODES'];bpy.data.objects.remove(obj,do_unlink=True)
        if mesh.users==0:bpy.data.meshes.remove(mesh)
        for g in groups:
            if g and g.users==0:bpy.data.node_groups.remove(g)
        raise
    return obj

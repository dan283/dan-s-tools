"""Pure interpolation and production naming rules. No Blender dependencies."""
import re
import math

class Expr:
    def __init__(self, op, *args): self.op, self.args = op, args
    def __add__(self, b): return Expr('ADD', self, b)
    def __sub__(self, b): return Expr('SUBTRACT', self, b)
    def __mul__(self, b): return Expr('MULTIPLY', self, b)
    def __truediv__(self, b): return Expr('DIVIDE', self, b)
    def evaluate(self, values):
        a = [x.evaluate(values) if isinstance(x, Expr) else x for x in self.args]
        if self.op == 'VAR': return values[a[0]]
        if self.op == 'ADD': return a[0]+a[1]
        if self.op == 'SUBTRACT': return a[0]-a[1]
        if self.op == 'MULTIPLY': return a[0]*a[1]
        if self.op == 'DIVIDE': return a[0]/a[1]
        if self.op == 'MINIMUM': return min(a)
        if self.op == 'MAXIMUM': return max(a)
        if self.op == 'LESS_THAN': return float(a[0]<a[1])
        if self.op == 'GREATER_THAN': return float(a[0]>a[1])
        raise ValueError(self.op)

def clamp(v, lo=0., hi=1.): return Expr('MINIMUM', Expr('MAXIMUM',v,lo),hi)

def basis(knots, mode='LINEAR', tension=0., strength=1., extrapolate=False):
    """Scalar cardinal basis of a nonuniform cubic Hermite spline.
    Includes neutral at 0; negative and positive branches remain separate.
    Returns expressions keyed by target IDs. Curved means a spatial vertex path.
    """
    if mode=='CURVED':return natural_basis(knots,extrapolate)
    result = {}
    for sign in (-1, 1):
        k = sorted([(0., None)]+[(abs(x), uid) for x,uid in knots if x*sign>0])
        if len(k)==1: continue
        if len({x for x,_ in k}) != len(k): raise ValueError('Duplicate progressive weights')
        if any(not math.isfinite(x) for x,_ in k): raise ValueError('Weights must be finite')
        w = clamp(Expr('VAR','w')*sign,0,k[-1][0])
        for j in range(len(k)-1):
            x0,id0=k[j]; x1,id1=k[j+1]; h=x1-x0
            t=(w-x0)/h
            # At an interior knot use the segment on its left, inclusive upper bound.
            gate = Expr('SUBTRACT',1.,Expr('GREATER_THAN',w,x1))
            if j: gate=gate*Expr('GREATER_THAN',w,x0)
            coeff={}
            def add(uid,v):
                if uid is not None: coeff[uid]=Expr('ADD',coeff.get(uid,0.),v)
            if mode=='LINEAR': add(id0,Expr('SUBTRACT',1.,t)); add(id1,t)
            else:
                t2=t*t; t3=t2*t
                h00=t3*2-t2*3+1; h01=t2*3-t3*2
                h10=t3-t2*2+t; h11=t3-t2
                add(id0,h00); add(id1,h01)
                for idx,H in [(j,h10),(j+1,h11)]:
                    a=max(0,idx-1); b=min(len(k)-1,idx+1)
                    factor=h*(1-tension)*strength/(k[b][0]-k[a][0])
                    add(k[b][1],H*factor); add(k[a][1],H*(-factor))
            for uid,c in coeff.items(): result[uid]=Expr('ADD',result.get(uid,0.),c*gate)
        if extrapolate:
            # Stable linear secant continuation beyond the last authored sample.
            extra=Expr('MAXIMUM',Expr('VAR','w')*sign-k[-1][0],0.)/(k[-1][0]-k[-2][0])
            result[k[-1][1]]=result[k[-1][1]]+extra
            if k[-2][1] is not None: result[k[-2][1]]=result[k[-2][1]]-extra
    if extrapolate:
        for sign in (-1,1):
            if any(x*sign>0 for x,uid in knots): continue
            opposite=sorted((abs(x),uid) for x,uid in knots if x*sign<0)
            if opposite:
                x,uid=opposite[0]
                result[uid]=result[uid]-Expr('MAXIMUM',Expr('VAR','w')*sign,0.)/x
    return result

def natural_basis(knots,extrapolate=False):
    """Natural C2 cubic interpolant in channel weight. Coordinates never set scale.
    Each signed branch is independent; end tangents continue outside its samples.
    """
    result={}
    starts={}
    for sign in (-1,1):
        k=sorted([(0.,None)]+[(abs(w),uid) for w,uid in knots if w*sign>0])
        n=len(k)
        if n<2:continue
        x=[v for v,u in k];ids=[u for v,u in k]
        h=[x[i+1]-x[i] for i in range(n-1)]
        if any(v<=0 or not math.isfinite(v) for v in h):raise ValueError('Duplicate or invalid progressive weights')
        # Solve second derivatives for every cardinal column at once (Thomas).
        M=[[0.]*n for _ in range(n)];diag=[1.]*n;upper=[0.]*n;lower=[0.]*n
        for i in range(1,n-1):
            lower[i]=h[i-1];diag[i]=2*(h[i-1]+h[i]);upper[i]=h[i]
            M[i][i-1]=6/h[i-1];M[i][i]=-6*(1/h[i-1]+1/h[i]);M[i][i+1]=6/h[i]
        for i in range(1,n):
            f=lower[i]/diag[i-1];diag[i]-=f*upper[i-1]
            M[i]=[v-f*u for v,u in zip(M[i],M[i-1])]
        for i in range(n-1,-1,-1):
            M[i]=[(v-(upper[i]*M[i+1][j] if i<n-1 else 0))/diag[i] for j,v in enumerate(M[i])]
        w=clamp(Expr('VAR','w')*sign,0,x[-1])
        for j in range(n-1):
            t=(w-x[j])/h[j];a=Expr('SUBTRACT',1.,t)
            gate=Expr('SUBTRACT',1.,Expr('GREATER_THAN',w,x[j+1]))
            if j:gate=gate*Expr('GREATER_THAN',w,x[j])
            for col in range(1,n):
                c=(a*a*a-a)*(h[j]**2*M[j][col]/6)+(t*t*t-t)*(h[j]**2*M[j+1][col]/6)
                if col==j:c=c+a
                if col==j+1:c=c+t
                uid=ids[col];result[uid]=Expr('ADD',result.get(uid,0.),c*gate)
        start={};end={}
        for col in range(1,n):
            start[ids[col]]=(float(col==1)-float(col==0))/h[0]-h[0]*(2*M[0][col]+M[1][col])/6
            end[ids[col]]=(float(col==n-1)-float(col==n-2))/h[-1]+h[-1]*(M[-2][col]+2*M[-1][col])/6
        starts[sign]=start
        if extrapolate:
            extra=Expr('MAXIMUM',Expr('VAR','w')*sign-x[-1],0.)
            for uid,slope in end.items():result[uid]=result[uid]+extra*slope
    if extrapolate:
        for sign in (-1,1):
            if sign not in starts and -sign in starts:
                extra=Expr('MAXIMUM',Expr('VAR','w')*sign,0.)
                for uid,slope in starts[-sign].items():result[uid]=result[uid]-extra*slope
    return result

def arc_segments(knots):
    """Smooth endpoint-zero bulges; coefficient and derivative vanish at stages."""
    for sign in (-1,1):
        k=sorted([(0.,None)]+[(abs(w),uid) for w,uid in knots if w*sign>0])
        for (x,a),(y,b) in zip(k,k[1:]):
            t=clamp((Expr('VAR','w')*sign-x)/(y-x))
            bump=t*t*(Expr('SUBTRACT',1.,t))*(Expr('SUBTRACT',1.,t))*16.
            yield a,b,bump

def activation(drivers, mode='PRODUCT'):
    if not drivers: raise ValueError('A corrective needs drivers')
    out=None
    for name,peak in drivers:
        if not peak or not math.isfinite(peak): raise ValueError('Corrective driver peak cannot be zero')
        x=clamp(Expr('VAR',name)/peak)
        out=x if out is None else Expr('MINIMUM',out,x) if mode=='MINIMUM' else out*x
    return out

def parse_names(names, known_channels=()):
    """Resolve full channel names plus optional percentage tokens; ignore case only when unique."""
    names=list(names)
    if len(set(names))!=len(names): raise ValueError('Duplicate shape names')
    heroes=set(known_channels)
    candidates={n for n in names if '+' not in n and not re.search(r'(?:_|-)(?:-?\d+(?:\.\d+)?|N)$',n,re.I)}
    heroes.update(candidates)
    def decode(text, pool):
        results=[]
        def walk(t,parts):
            for h in sorted(pool,key=lambda x:(-len(x),x)):
                if not t.casefold().startswith(h.casefold()): continue
                tail=t[len(h):]; options=[]
                if not tail: options.append((1.,''))
                elif tail[0] in '_+': options.append((1.,tail[1:]))
                m=re.match(r'^[_-](-?\d+(?:\.\d+)?|N)(?=$|[_+])',tail,re.I)
                if m:
                    weight=-1. if m[1].upper()=='N' else float(m[1])/100.
                    if not weight or not math.isfinite(weight): continue
                    rest=tail[m.end():]; options.append((weight,rest[1:] if rest else ''))
                for weight,rest in options:
                    if h in [n for n,_ in parts]: continue
                    seq=parts+[(h,weight)]
                    if not rest: results.append(seq)
                    else: walk(rest,seq)
        walk(text,[])
        return list({tuple(x):x for x in results}.values())
    # Remove names which can be decomposed using other complete channel names.
    for n in sorted(candidates,key=lambda x:(len(x),x)):
        if n in known_channels: continue
        ways=decode(n,heroes-{n})
        if ways: heroes.discard(n)
    folded={}
    for h in heroes:
        if h.casefold() in folded and folded[h.casefold()]!=h: raise ValueError('Channels differ only by case: '+h)
        folded[h.casefold()]=h
    specs=[];stages=set()
    for n in names:
        ways=decode(n,heroes)
        if len(ways)!=1: raise ValueError(f'Ambiguous/unresolved name {n}; include its primary meshes or use a manifest')
        parts=ways[0]
        if len(parts)==1:
            h,w=parts[0]; key=(h,w)
            if key in stages: raise ValueError(f'Duplicate stage {key}')
            stages.add(key);specs.append(dict(name=n,kind='SHAPE',channel=h,weight=w))
        else: specs.append(dict(name=n,kind='COMBO',drivers=parts,mode='PRODUCT'))
    return sorted(specs,key=lambda s:(s['kind']=='COMBO',len(s.get('drivers',[])),0 if abs(s.get('weight',1))==1 else 1,s['name']))

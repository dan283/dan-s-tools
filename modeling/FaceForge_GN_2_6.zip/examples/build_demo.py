"""Creates a mathematical interpolation lab, not an authored facial asset.
Run inside Blender after installing the addon, or with the official bpy runtime.
"""
import bpy,json,numpy as np
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import faceforge_gn as F
from faceforge_gn import engine as E
try: F.register()
except ValueError: pass
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
N=41
v=[(2*x/(N-1)-1,2*y/(N-1)-1,0.) for y in range(N) for x in range(N)]
f=[(y*N+x,y*N+x+1,(y+1)*N+x+1,(y+1)*N+x) for y in range(N-1) for x in range(N-1)]
me=bpy.data.meshes.new('Interpolation Lab'); me.from_pydata(v,[],f); me.update()
o=bpy.data.objects.new('FaceForge • INTERPOLATION LAB',me); bpy.context.collection.objects.link(o)
bpy.context.view_layer.objects.active=o; o.select_set(True); E.initialize(o); rest=E.coords(me)
x=rest[:,0]; y=rest[:,1]; profile=np.exp(-3*(x*x+y*y))
p=rest.copy(); p[:,2]=.8*profile
E.add(o,'bend',p,ch='bend')
p=rest.copy(); p[:,2]=.5*profile; p[:,0]+=.22*profile
E.add(o,'bend_50',p,ch='bend',weight=.5)
p=rest.copy(); p[:,2]=-.5*profile
E.add(o,'bend_N',p,ch='bend',weight=-1)
p=rest.copy(); p[:,0]+=.35*profile; p[:,2]+=.2*y
E.add(o,'pull',p,ch='pull')
p=E.evaluate(o,{'bend':1.,'pull':1.},envelope=False); p[:,2]+=.25*profile
E.add(o,'bend+pull',p,'COMBO',drivers=[('bend',1.),('pull',1.)])
c=o.ffgn.channels['bend']; c.interpolation='CURVED'; c.group='Progressives'
o.ffgn.channels['pull'].group='Primary'; E.rebuild(o)
for name,vals in [('Neutral',{}),('Half bend',{'bend':.5}),('Curved quarter',{'bend':.25}),('Full bend',{'bend':1}),('Negative',{'bend':-1}),('Combination',{'bend':1,'pull':1})]:
 p=o.ffgn.poses.add();p.name=name;p.values=json.dumps(vals)
o.ffgn.channels['bend'].value=.65;o.ffgn.channels['pull'].value=.4
bpy.context.scene.ffgn_settings.owner=o
mat=bpy.data.materials.new('Lab • slate blue');mat.diffuse_color=(.08,.27,.42,1);o.data.materials.append(mat)
o.show_wire=True;o.show_all_edges=True
for poly in me.polygons: poly.use_smooth=True
# Embedded startup instructions are readable without the addon.
txt=bpy.data.texts.new('START HERE');txt.write('FACEFORGE GN — INTERPOLATION LAB\n\nInstall the addon first. Open N → FaceForge.\nMove bend from -1 to +1; the 0.5 stage introduces a curved vertex path.\nSwitch Linear/Curved to compare trajectories.\nEnable pull with bend to activate the corrective.\nTry stored poses, Sculpt/Commit, Extract, masks and package export.\n\nThis sheet is a deliberately simple mathematical test mesh, not a facial model.\nUse an artist-authored neutral and target set for a production face.\n')
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':
   area.spaces.active.region_3d.view_distance=5;area.spaces.active.show_region_ui=True
   area.spaces.active.region_3d.view_rotation=(.883,.27,.364,.11)
bpy.ops.wm.save_as_mainfile(filepath=str(Path(__file__).parent/'FaceForge_Interpolation_Lab.blend'))
print('DEMO SAVED')

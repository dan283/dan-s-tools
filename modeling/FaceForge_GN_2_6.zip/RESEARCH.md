# Research and design record

## Sources reviewed

1. **BBlendShapes V.0.1**, https://www.youtube.com/watch?v=NSpAub680QI
   The YouTube page could not be fetched directly. The complete uploaded auto-generated subtitle transcript was read. It describes a modifier workflow with live objects, stored targets, progressives, curved vertex paths, combinations, sculpt access, masks, splitting and neutral revision. The transcript is not proof of unshown implementation details.

2. **Blender Artists discussion**, https://blenderartists.org/t/blendshapes-for-blender-add-on/1624575
   Alex/metamesh confirms the Geometry Nodes basis. Dan's comments emphasize meaningful absolute OBJ handoffs, naming-based network construction and pose recall. FaceForge uses a manifest so file names need not encode every rig relationship.

3. **ShapeUp**, https://github.com/dan283/ShapeUp
   The public README describes primary/hero, progressive, negative and combination shape terminology. It is a workflow reference; repository implementation code was not copied.

4. **Lewis, Anjyo, Rhee, Zhang, Pighin and Deng — Practice and Theory of Blendshape Facial Models**, Eurographics 2014 survey/adapted notes.
   https://www.scribblethink.org/Work/Pdfs/blendshapes_MAIN.pdf
   Sections 3.1–3.3 describe neutral-relative deltas, intermediate stages and combination terms. The additive neutral-plus-displacement formulation informs the runtime architecture. Product activation is a deliberate artist-facing choice; higher-order products can activate late.

5. **Sumner and Popović — Deformation Transfer for Triangle Meshes**, SIGGRAPH 2004.
   https://people.csail.mit.edu/sumner/research/deftransfer/
   Their method transfers triangle transformations and solves a global optimization. This release does not implement that algorithm. The included closest-triangle displacement transfer is simpler and has different limitations.

6. **Blender Python API and Geometry Nodes documentation**.
   https://developer.blender.org/docs/release_notes/5.2/python_api/
   https://docs.blender.org/api/5.2/bpy.types.NodesModifier.html
   https://docs.blender.org/api/5.3/bpy.types.NodesModifier.html
   https://docs.blender.org/api/current/bpy.types.NodeTreeInterface.html
   https://docs.blender.org/manual/en/latest/modeling/geometry_nodes/geometry/sample/sample_index.html
   Some documentation pages could not be retrieved fully by search. The actual official 4.5 and 5.2 Python runtimes were also inspected directly. In 5.2 GN input values moved from modifier ID properties to `modifier.properties.inputs.<identifier>.value`. FaceForge supports both interfaces and attaches drivers to the actual socket property in the new API.

## Implementation choices

The GN graph reads per-point delta attributes, constructs scalar stage basis functions, computes signed combination activations, multiplies target gains/masks, sums displacements and applies one Set Position offset. There is no Python frame handler and no runtime driver-namespace function.

Authoring/IO operations use a separate numeric evaluator built from the same expression representation. Numerical/cardinal tests provide independent expected values; Blender integration compares the compiled graph with the evaluator across poses. Spatial interpolation uses nonuniform Hermite basis weights, rather than merely smoothstepping a channel slider.

Packages distinguish a complete sculpted pose from the residual consumed by a corrective. Import subtracts the preceding network; export reconstructs the matching absolute hierarchical pose. Masks and gains are flattened into exported geometry. Neutral revisions preserve deltas rather than attempting unsupported anatomical adaptation.

This is an independent implementation, not a Wētā tool, certification or claim to reproduce its proprietary facial pipeline. No claim is made that a first release is objectively the best VFX addon. The included validation records describe what has actually been checked.

# 2.0 research review and authoring redesign

Reviewed 13 October 2026. The observations below distinguish published features from the design choices made for this addon. Public documentation cannot establish the full current internal implementation of a studio pipeline.

## Maya: the closest match to the requested artist experience

Autodesk's Shape Editor organizes targets, their weights, editing operations and combinations in one place. Its combination documentation describes driven correction targets: they respond to other shapes and do not need an independent animator weight. Its in-between documentation places intermediate targets beneath their parent and distinguishes absolute from relative in-betweens. Editing an in-between selects its corresponding weight.

**Decision for FaceForge:** creation immediately enters Edit/Sculpt; Done previews the authored weight; in-betweens share their parent's slider; combo drivers are readable names and peaks. The implementation supports absolute in-betweens. Relative in-betweens and arbitrary driver remapping remain unimplemented.

Sources:
- [Maya Shape Editor](https://help.autodesk.com/cloudhelp/2025/ENU/Maya-CharacterAnimation/files/GUID-3C92402C-B24E-4874-AC8D-EADF976A19DC.htm)
- [Create combination target shapes](https://help.autodesk.com/cloudhelp/2022/ENU/Maya-CharacterAnimation/files/GUID-7B04F045-71F2-491D-8C2A-18B3DB1AA1F4.htm)
- [Add in-between target shapes](https://help.autodesk.com/cloudhelp/2017/ENU/MayaLT/files/GUID-FF40A342-2F43-42C5-A8C9-8C5E3D91B565.htm)

## Wētā: artist control extends beyond a FACS shape list

Wētā's published **Animatomy** work describes a facial representation based on contractile muscle-fibre curves. It fits actor scans, learns a manifold of plausible strains, deforms skin and transfers expression between actors and characters. The paper discusses limits of FACS-based parameterizations, including separation, coverage, opposition and redundancy. Its contribution is a deeper representation and deformation architecture than a conventional blendshape browser.

**Decision for FaceForge:** keep authoring controls understandable and data relationships explicit, while acknowledging that arbitrary named FACS-style controls are only one representation. A `jawOpen` label does not supply jaw anatomy, muscle contraction or a solve. FaceForge does not implement Animatomy's muscle curves, learned manifold or actor-to-character system.

Source: [Choi et al., Animatomy, SIGGRAPH 2022](https://www.wetafx.co.nz/assets/Uploads/PDFs/animatomy.pdf).

Wētā's **FACETS** description covers performance capture, muscle-motion interpretation, character mapping and editable solves. This places capture and animator adjustment in the same wider pipeline, but it does not publish a complete shape-authoring implementation.

**Decision for FaceForge:** exported geometry, named controls and saved poses should remain inspectable. Capture solving can be connected later through channel values without changing the storage of authored targets. FACETS itself is not implemented.

Source: [Wētā FACETS](https://www.wetafx.co.nz/research-and-tech/technology/facets).

## ILM, Zeno and reusable production systems

ILM's public facial-capture overview distinguishes systems including MEDUSA, Anyma and Flux. These address acquisition and reconstruction of performance, not just target sculpting. Its publication **BlockParty 2** describes a Maya-based modular rig-building system with reusable components, connection contracts and an approachable visual interface.

**Decision for FaceForge:** enforce explicit topology/space contracts and make authoring operations visible in the UI. Retain a separate numeric authoring evaluator and GN runtime so a mesh handoff can be checked independently of the editor. This is an engineering inference from the published modularity principles, not a claim that FaceForge shares ILM internals.

**Zeno evidence limit:** the reviewed public primary material did not establish enough detail to reproduce Zeno's internal facial editor, dependencies or correction mathematics. There is no verified basis here for advertising a “Zeno clone.” The requested artist operations are implemented directly, with their evaluation rules documented.

Sources:
- [ILM facial capture](https://www.ilm.com/facial-capture/)
- [Rose, Jutan & Doublestein, BlockParty 2, SIGGRAPH 2013](https://mikejutan.com/work/publications/index_files/BlockParty2_Siggraph2013.pdf)

## Disney: facial rigs can combine representations

Disney Animation's published deformer-based facial rigging approach uses skin clusters, wires and pose-space deformation. Its abstract contrasts the tunability and cost of blendshapes with other deformers. This supports treating shape libraries as one component of a facial rig, rather than assuming every useful motion must be a single additive target.

**Decision for FaceForge:** support the sculpted shape layer well and leave jaw joints, eye aiming, skinning and secondary deformation to explicit downstream systems. Sculpt sessions operate on the base cage before downstream armature/subdivision; they do not invert a posed skinning deformation.

Source: [Kahwaty et al., A Deformer Based Approach to Facial Rigging, SIGGRAPH 2013](https://www.disneyanimation.com/publications/a-deformer-based-approach-to-facial-rigging/).

## What the user's references required

The supplied BBlendShapes transcript describes direct sculpt access, persistent targets, live objects with modifiers, progressive shapes, curved paths, combinations, masks and neutral changes. Dan's forum requirements add useful absolute-geometry handoff and naming conventions. Those requirements are represented in the existing evaluator, live-source connections, OBJ packages and authoring operations.

The supplied screenshot showed an initialized mesh with zero channels and zero targets. It did not provide an exact exception traceback. The strongest actionable finding was a workflow gap: creating a blank primary did not enter sculpting, and committing did not set its channel weight. An artist could complete an operation and still see no change.

**2.0 fixes that transition:** Initialize → New Shape → Edit/Sculpt → Done. In-betweens and combos follow the same editing-session model. Cancel restores the previous pose. A direct neutral edit can be recovered when topology is still valid. None of those repairs depends on guessing the unknown earlier exception.

## Evaluation rules you can inspect

The following is this addon's design, not an attributed studio algorithm:

1. Save neutral positions and indexed topology.
2. Store each primary/in-between as a neutral-relative displacement.
3. Evaluate one cardinal stage basis per channel, with separate positive/negative branches.
4. Compute combo activations from signed normalized channel peaks using Product or Minimum.
5. Sum masked, gain-scaled displacements and apply the master envelope in Geometry Nodes.
6. Author a combo in the full activating pose, then store only its residual correction.
7. Export complete absolute meshes plus a manifest; reconstruct residuals on import.

Example: if the combined jaw/lip pose is `B` and the artist's sculpted result is `S`, the corrective stores `S − B`. At its driver peaks the result is `B + (S − B) = S`. It does not add `S` directly onto `B`.

In-betweens are different: 0, 0.5 and 1 are samples of one channel's path. A half-open jaw is not a second primary channel. This distinction determines both the UI and the GN basis functions.

## Practical facial-authoring sequence

This is a proposed review workflow for your mesh, not a complete studio standard:

1. Finalize neutral expression, scale, topology and vertex correspondence. Check lips, eyelids and mouth interior before accumulating shapes.
2. Author a small, reviewable set of primary motions. Start with jaw and a few mouth/eye actions rather than mass-generating empty channels.
3. Review each primary at 0, 0.25, 0.5, 0.75 and 1. Add intermediate sculpts where the path, silhouette or contact is wrong.
4. Inspect meaningful pairs such as jaw opening plus lip funneling, or a smile plus cheek/eye compression. Add only the missing deformation as a corrective.
5. Review those combinations at partial activation, both with and without the corrective. Product and Minimum feel different; neither is an anatomical solver.
6. Revisit affected correctives after changing a primary or the neutral. Preserving residuals does not guarantee unchanged anatomy.
7. Save named review poses and pass absolute meshes plus metadata between applications. Check the returned shapes before replacing working production assets.

## Current coverage and next priorities

| Area | Implemented now | Boundary / future work |
|---|---|---|
| Primary authoring | Named controls, Edit/Sculpt, protected neutral, automatic preview | Artist supplies the actual anatomy |
| In-betweens | Absolute stages, parent grouping, linear/curved trajectories | Relative stages; corrective in-between interpolation |
| Combinations | Signed peaks, Product/Minimum, residual authoring | RBF/PSD neighbourhoods; driver editing UI |
| Interchange | Absolute OBJ meshes, manifest, naming import | Native Maya plugin, USD rig schema, action exchange |
| Shape reuse | Live sources, mirror, split, masks, neutral revision | Robust landmark/gradient-based facial transfer |
| Layering | One GN facial network per mesh; downstream modifiers | Multiple managed facial layers and posed-skin inverse editing |
| Diagnostics | Topology guards, Validate, recover neutral sculpt, retained failed sessions | Full change-dependency audit and show-scale asset validation |
| Performance | GN evaluation; reusable stored attributes | Sparse/compressed targets and larger real-face benchmarks |
| Capture/anatomy | Channel inputs can be animated | Facial solve, muscle model, jaw articulation, collision, wrinkles |

The most useful next production extensions are dependency-aware revision review, relative in-betweens, explicit jaw/eye integration, and stronger transfer correspondence. They should be evaluated against your actual facial mesh and show requirements before adding more UI or claiming studio equivalence.

## 2.1 workflow revision

The user requested that authoring infer target type from the current mix. Dedicated In-between/Corrective creation buttons have therefore been removed from the main panel. One nonzero channel identifies a stage; multiple nonzero channels identify a combination with those exact activation peaks. Stored matching targets are reopened. Earlier descriptions of the 2.0 buttons are historical design notes. The combination activation mathematics remains Product/Minimum with saturation, not an RBF neighbourhood solver.

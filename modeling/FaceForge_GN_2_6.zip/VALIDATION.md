# Validation — FaceForge GN 2.3

## Runtime coverage

The official Blender Python runtimes were used headlessly:

- Blender **4.5.0** / Python 3.11.
- Blender **5.2.2 LTS** / Python 3.13.

Both passed the deformation/IO integration assertions in `tests/blender_integration.py` and the new authoring assertions in `tests/authoring_integration.py` on 13 October 2026. The 4.5 wheel emitted C++ memory-cleanup warnings and stalled during interpreter shutdown after the final success message; a bounded follow-up was stopped by a 20-second timeout. Thus 4.5 has passing addon assertions but an unresolved runtime-exit issue in this environment, not a clean end-to-end process result. The 5.2 runs exited normally. Desktop UI operation has not been manually verified. **Blender 5.3 was not executed in this environment.** Its GN modifier-input API was checked through public documentation/search, and the addon uses the tested 5.2 interface where available. No 5.3 compatibility guarantee is implied.

## New 2.0 authoring checks

The authoring fixture uses Blender’s Suzanne mesh and real Edit/Sculpt modes:

- Initialize, create a named primary, enter Edit Mode, modify BMesh, commit and verify GN output at 1.0.
- Seed an in-between from current interpolation, edit it and verify its 0.5 output.
- Create in Sculpt Mode; switch/open sessions through public operators.
- Sculpt a combo and verify only its residual is stored; disabling one driver removes it.
- Cancel a new shape without leaking its channel; cancel an existing shape without changing its geometry.
- Edit a target through partial mask weights and gain; reject changes outside a zero-weight mask while retaining the working copy.
- Recover direct neutral edits as a new independent shape.
- Save/reopen an unfinished session and successfully commit.
- Reject changed working topology while preserving the working mesh for repair or cancellation.
- Resolve panel operator/property/icon references against the Blender runtime. This is a structural UI check, not a screenshot-based desktop interaction test.

## Deformation and pipeline checks that passed

- 17 pure tests: cardinal stage matching, signed branches, nonuniform C1 curve continuity, spatial arc behaviour, stage rejection, product/minimum activations, signed peaks, naming and ambiguous/dependency rejection.
- 42 GN/evaluator pose comparisons: linear/curved, signed primary/progressive channels, combination residuals.
- Immediate gain/mute drivers and vertex masks/inversion.
- Live sculpt updates, target-object transform independence, freezing and source deletion.
- Absolute OBJ + manifest import/export round-trip.
- Mask/gain flattening into portable shapes.
- Signed partial-peak minimum corrective round-trip.
- Mirroring bijection and complementary split displacement sum.
- Different-vertex-count barycentric transfer on aligned planar geometry.
- Topology-change rejection, including isolated added vertices.
- Sampled native shape-key animation reconstruction at integer frames.
- Public operators: sculpt/commit, pose storage/recall, Validate.
- Revised-neutral propagation with unchanged shape deltas.
- .blend save/reopen: attributes, one deformer and functioning driver paths persist.
- UI icon identifiers checked against actual Blender RNA; Python syntax compiled on the applicable runtimes.

These checks use synthetic fixtures. A complex facial production asset, Windows UI interactions, rendering evaluation at fractional bake frames, anatomical transfer accuracy and a complete show pipeline were not validated here.

## Performance sample

Retained 1.0 evaluator benchmark in official Blender 4.5.0, headless in this environment (not remeasured for the 2.0 authoring UI):

| Metric | Result |
|---|---:|
| Vertices | 16,258 |
| Targets / channels | 100 / 100 |
| Generated GN nodes | 1,604 |
| Create 100 targets + build graph | 16.94 s |
| Median update + evaluated mesh readback | 17.29 ms |
| Largest measured update after warmup | 18.35 ms |
| GN output / authoring evaluator agreement | Pass |

Ten updates after one warmup were measured. This is not a viewport FPS guarantee; hardware, live source modifiers, topology, graph complexity and UI overhead change performance. Target archive memory scales with vertices × targets; this release does not provide sparse/compressed delta storage.

## Reproduce

From the extracted package root with a supported Blender executable:

```sh
blender --background --factory-startup --python tests/blender_integration.py
blender --background --factory-startup --python tests/authoring_integration.py
blender --background --factory-startup --python tests/benchmark.py
```

Pure math/naming tests need standard Python only:

```sh
python tests/test_core.py
```

The shipped interpolation lab is a mathematical sheet mesh for experimentation, not a facial sculpt or benchmark-quality character asset. Install the addon before opening it, then use N → FaceForge and the stored poses.

## 2.1 auto-pose authoring

Blender 5.2.2: `tests/pose_authoring.py` verifies automatic 0.5 stages, wrong list-selection independence, same-pose reuse, 0.2/0.8 corrective driver peaks and residual output, distinct combination peaks, cancel, negative stages and a zero-mix guard. A regression fix zero-fills unspecified channel values during numeric pose evaluation, so a new in-between can be authored after combos exist. 2.1 was not rerun on 4.5.

## 2.2 pipeline and pose checks

Executed in official bpy 5.2.2 headlessly. `tests/pipeline_v22.py` covers the user's exact naming examples, case-insensitive channel references, readable GN modifier panels with working drivers, selected-mesh import, home/custom/scene-neutral OBJ network construction, both export modes and numerical reimport equivalence over five poses, plus pose storage, fade, off, mix, update, deletion and sculpt-session interactions. Authoring and extended deformation/IO regression scripts also pass. Desktop UI has not been manually exercised. Blender 4.5/5.3 have not been rerun for 2.2.

## 2.3 range and arc checks

`tests/curves_v23.py` passes in official bpy 5.2.2: both soft range metadata, typed values -1.5 through 2, evaluated GN extrapolation, inverted missing branch, visible spatial bends with collinear stages at tensions 0 and 1, exact authored endpoints, numeric/GN equivalence, curve/range package roundtrip, and authoring at weight 1.5. The deformation/IO and 2.2 pipeline regression suites also pass. Desktop UI and other Blender versions were not executed for 2.3.

## 2.4 validation

Blender 5.2.2 headless: parallel-direction perpendicular arc, evaluator/GN agreement, Quickset primary/stage/weighted combo and disabled selection, new-shape Sculpt Mode and Edit/Sculpt session switching before Done, unique pose rename, curve midpoint preview. All passed. 2.3 curve regression, 2.2 pipeline regression and 17 core tests passed. No interactive desktop UI or other Blender version verification.

## 2.5 curve rewrite
Blender 5.2.2 headless: exact authored stage interpolation; C2 continuity across nonuniform weights; smooth tangent extrapolation; actual GN versus numeric evaluator; scale equivalence at 1e-6, 1, and 1e6 (12 orders of magnitude); old directional controls do not affect deformation; OBJ roundtrip; old graph migration. All passed. Interactive desktop UI and other Blender versions remain unverified.

## 2.6 startup and organization
Reproduced the 2.5 `_RestrictData` crash with Blender's official RestrictBlend context (bpy wheel wrapper bound to the restriction module). New registration succeeds in that context after the failed old registration. Re-register/unregister is repeatable, timers/handlers are cleaned, rig data is preserved. Group assignment, family inheritance, combo groups, filters, sorting, custom reorder and OBJ group roundtrip passed. Curves and pipeline regressions passed on Blender 5.2.2. Exact 5.4 alpha and desktop UI not tested.

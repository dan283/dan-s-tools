# 2.6 installation recovery and shape organization

This version fixes the `_RestrictData` startup crash. Migration is deferred until Blender permits scene access. It also cleans up FaceForge registrations left by a failed older enable without deleting saved rig data. Save your scene, restart Blender, install this ZIP, and enable FaceForge GN. Restarting clears any remaining failed-addon state from earlier attempts; no need to rebuild the face from scratch.

Above the mixer, use shared **Search**, **All groups**, **Type**, **Order**, and **Active only** controls. Search matches target names, parent channels, groups and combination drivers. Filters apply to both the stored list and relevant mixer controls. The X resets filters. Choose channel-family, alphabetical, group or custom order; reverse is available for sorted modes.

Select a shape and choose **Assign Group** (e.g. Mouth, Eyes, Brows). Selected family assigns its primary and all stages together. All filtered shapes assigns the current filtered set; stages always share their parent channel group. Combinations may have independent groups. Choose **Custom** order and use the up/down arrows to reorder visible shapes. Group names and target order survive .blend saves and current OBJ package export/import.

The 2.5 automatic scale-independent curved solver is retained. Registration recovery and grouping were tested with Blender 5.2.2 including Blender's restricted registration context; the user's exact 5.4 alpha build was unavailable for testing.

# FaceForge GN 2.6 — Facial Shape Authoring

Build a facial shape library from your own neutral mesh. Create `jawOpen`, edit or sculpt it, add in-betweens, then sculpt automatic combination correctives. Geometry Nodes evaluates the deformation; no Python frame handler is needed.

## Install / replace 1.0

1. Save your .blend. Disable the old FaceForge addon and restart Blender when replacing an already loaded version.
2. **Edit → Preferences → Add-ons → Install from Disk** (the dropdown menu location varies by Blender version).
3. Choose `FaceForge_GN_2_3.zip` without extracting it. Enable **FaceForge GN — Facial Shape Studio**.
4. Select your neutral face. Open **N → FaceForge**.

The saved rig data from 1.0 is retained. The new files replace the `faceforge_gn` addon folder. No extra Python packages are needed inside Blender.

## Your first shape

1. **Initialize Neutral** — stores your neutral and creates the GN modifier.
2. **New Shape** — name it `jawOpen`; choose **Sculpt** or **Edit**, then confirm.
3. Shape the working mesh with your usual Blender tools.
4. **Done** — saves the shape and shows `jawOpen` at **1.0**.
5. Move `jawOpen` between **0** and **1** in the Shape Mixer. **Neutral** zeros all channels.

**Cancel** discards this editing session and restores your previous mix. A newly created, cancelled target is removed. Select a saved target and click **Edit** or **Sculpt** to revise it. Keep the vertex count/order/connectivity intact: no Remesh, Dyntopo, extrusion, deletion or applied subdivision.

## One Edit / Sculpt workflow for every pose

Set the Shape Mixer, then click **Edit** or **Sculpt** under **EDIT CURRENT MIX**:

- One active channel at 1.0: edit its primary.
- One active channel at 0.5: automatically create or edit its 0.5 in-between.
- `jawOpen = 0.2` and `lipFunneler = 0.8`: automatically create or edit the corrective with those driver peaks.
- All channels at zero: use New Shape to create a primary, or dial an existing channel first.

No separate In-between or Corrective buttons. Matching is based on channel identities and slider values, never the selected target row. Returning to a stored pose reuses its target. Done previews the authored pose; Cancel removes a newly inferred target and restores your previous mix. Automatic target names include their stage/driver weights.

Corrective activation still uses normalized Product/Minimum with saturation at its captured peaks. A 0.2/0.8 corrective is fully active at that pose and stays active beyond those peaks; multiple different corrective poses are additive, not local RBF interpolation.

## Soft ranges and automatic curved paths — 2.5

Each channel row has a **0 to 1 / -1 to 1** range selector. These are slider ranges, not hard clamps: click the numeric value and type **1.5**, **2**, **-1.5**, etc. The deformation extrapolates past the last stage using the final segment slope. If there is no authored negative branch, negative values invert the first positive segment; an authored negative branch takes precedence. The same principle applies to a missing positive branch. Automatic Edit/Sculpt can also create stages beyond ±1.

Select a stored target and choose **Curved**. The vertex trajectory is a natural cubic spline through the neutral and all authored stages on that signed channel branch. It passes exactly through every stored stage, with matching velocity and acceleration across inbetweens. No direction, bulge, tension or scale setting is needed.

**Preview Curve Between Stages** solos the midpoint of the selected segment. For stages at 0, 0.5 and 1, inspect 0.25 and 0.75. A neutral and one target define a straight line; sculpt an inbetween off that line to define a curved trajectory. Collinear stages stay on their line. The same channel weights and sculpt proportions yield the same result for a mouse or Godzilla: no world-distance threshold is involved.

Beyond the last stored stage, the end tangent continues smoothly for exaggeration. Positive/negative branches stay independent; there is no promise of smoothness across zero when both are authored independently. Cubic interpolation can overshoot; it does not enforce collisions or volume.

Existing rigs rebuild automatically when opening a file or enabling the addon. Old bulge/direction settings are ignored. The changed interpolation intentionally changes intermediate results in existing Curved channels, while authored channel stages remain exact; review existing corrective combinations, since their stored residuals may have been sculpted against the old interpolation.

## Import / Export & Pipeline — new in 2.4

Expand **Import / Export & Pipeline** in the sidebar.

- **Add Shapes from Selected Meshes:** set Rig to your initialized neutral, select the source meshes, then import. Their names build the relationships automatically. They become stored targets; their scene placement does not alter local-space shape coordinates.
- **Build Network from OBJ Folder:** select a folder. It detects `home.obj`, `neutral.obj`, `base.obj` or `basis.obj`; enter a custom neutral name when needed. Alternatively pick a scene mesh as the neutral. A new rig is created, preserving the scene source.
- **Import OBJ Shapes:** add shapes to an existing initialized rig. Existing target names/stages are protected from overwrite.
- **Export Shapes:** choose **Combined poses** or **Shape differences** and a fresh folder. Files use the target names plus `.obj` and include `neutral.obj` and `faceforge.json`.

| Name | Imported meaning |
|---|---|
| `jawOpen` | Primary channel |
| `jawOpen_50` | `jawOpen` at 0.5 |
| `jawopen_eyesClosed` | `jawOpen` at 1 + `eyesClosed` at 1 |
| `jawOpen_50_eyesClosed` | `jawOpen` at 0.5 + `eyesClosed` at 1 |
| `jawOpen_20_eyesClosed_80` | Combo with driver peaks 0.2 and 0.8 |

Include the primary meshes, or import into a rig where those channels already exist. Channel references match case-insensitively when unambiguous. Full names containing underscores, such as `mouth_smile_L`, remain supported.

**Combined poses** export the evaluated face at that target's weights, including every active corrective. **Shape differences** export neutral + only the target contribution. For an in-between this subtracts the full primary scaled to the stage weight; for a combo it exports only its residual. Thus a difference OBJ is still a usable mesh, not vectors positioned around the origin. Keep the manifest when reimporting to preserve interpolation and driver settings.

## Pose library

Dial your shapes, expand **Pose library**, enter a name and click **Store**. Each pose has a **0–1 weight slider**. Zero switches it off; one recalls its full channel values. Several poses can blend additively, without clamping the resulting channel values. **Apply** solos the selected pose; **All Poses Off** returns to neutral. **Update Stored Pose** replaces the selected pose with your current mix.

Manually editing a shape channel detaches the pose sliders while keeping that current mix. Use **Key Pose** to key the resulting shape channels; pose sliders are an authoring mixer, not a separate animation rig.

## Modifier labels and existing rigs

The GN modifier now groups target controls under readable sections such as **In-between | jawOpen @ 0.5** and **Combo | jawOpen @ 0.5 + eyesClosed @ 1**, including the target name. Opaque IDs are no longer used as user-facing labels. For a previously saved rig, click **Rebuild** once to regenerate its modifier labels.

## Scope and verification

2.5 was tested headlessly in Blender 5.2.2. See `VALIDATION.md` for exact checks and older-version limitations. The manual, research, source code, tests and authoring quick-start image are included.

Keep topology and vertex order unchanged. Raw OBJ network construction imports geometry; it does not reconstruct OBJ materials/UVs. Use an existing scene mesh as neutral when you need to retain its materials/UVs. No automatic anatomical shape generation, muscle simulation or performance solving is included.

Quickset above the shape list solos the selected stage or combination at its stored driver values. Pose library offers Rename selected. New Shape confirms with Create & Sculpt; Edit/Sculpt buttons switch modes during a working session before Done.

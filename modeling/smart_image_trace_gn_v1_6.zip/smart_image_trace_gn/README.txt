Smart Image Trace GN v1.6

Blender 5.2/5.3 add-on.

IMPORTANT: v1.6 is rebuilt directly from the last known-working v1.2 tracing/object pipeline.
The experimental v1.3-v1.5 construction was removed.

Changes:
- Repairs/relinks a stale output object pointer so a successful trace cannot remain invisible.
- Top Width island scaling replaced by a true-distance top-perimeter inset/chamfer.
- Inset Segments/Profile allow a straight or rounded shoulder.
- Edge Round only targets final top/bottom rim edges; vertical silhouette edges are excluded.
- Flat Height=0 path remains the simple v1.2 Fill Curve result.

Install the ZIP from Blender Preferences. Disable/remove older Smart Image Trace GN versions first.

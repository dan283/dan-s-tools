bl_info = {
    "name": "Smart Image Trace GN",
    "author": "OpenAI",
    "version": (1, 6, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Image Trace",
    "description": "Live raster-to-curve tracing with Geometry Nodes fill, height, true top inset/chamfer and artifact-safe rim rounding",
    "category": "Object",
}

import bpy
import math
from bpy.props import (
    PointerProperty,
    FloatProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup
from bpy_extras.io_utils import ImportHelper

try:
    import numpy as np
except Exception:
    np = None


ADDON_PREFIX = "SITGN_"
NODE_GROUP_NAME = "SITGN_Fill_White_Regions_v16"

# Live-preview state. Property updates can fire many times while a slider is
# dragged, so we debounce them through bpy.app.timers instead of retracing on
# every mouse event.
_LIVE_PENDING_SCENES = set()
_LIVE_TIMER_RUNNING = False
_LIVE_TRACE_RUNNING = False



# -----------------------------------------------------------------------------
# Geometry / tracing helpers
# -----------------------------------------------------------------------------

def _box_blur(a, radius):
    """Fast box blur, numpy only, preserving image dimensions."""
    if radius <= 0:
        return a
    r = int(radius)
    p = np.pad(a, ((r, r), (r, r)), mode='edge')
    # Integral image with a 1-cell zero border.
    ii = np.pad(p, ((1, 0), (1, 0)), mode='constant').cumsum(0).cumsum(1)
    k = 2 * r + 1
    return (ii[k:, k:] - ii[:-k, k:] - ii[k:, :-k] + ii[:-k, :-k]) / float(k * k)


def _resize_nearest(a, max_dim):
    """Downsample only when necessary. Returns array and source->trace scale."""
    h, w = a.shape
    m = max(h, w)
    if m <= max_dim:
        return a, 1.0
    s = float(max_dim) / float(m)
    nw = max(2, int(round(w * s)))
    nh = max(2, int(round(h * s)))
    xs = np.linspace(0, w - 1, nw).astype(np.int32)
    ys = np.linspace(0, h - 1, nh).astype(np.int32)
    return a[np.ix_(ys, xs)], s


def _image_field(image, settings):
    if np is None:
        raise RuntimeError("NumPy is unavailable. Blender normally ships with NumPy; reinstall/repair Blender if it is missing.")

    w, h = int(image.size[0]), int(image.size[1])
    if w < 2 or h < 2:
        raise RuntimeError("The selected image has no readable pixel data.")

    pixels = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    rgba = pixels.reshape((h, w, 4))

    rgb = rgba[:, :, :3]
    alpha = rgba[:, :, 3]

    if settings.detection_mode == 'MIN_RGB':
        # More literal white detector: a saturated bright colour will not be
        # treated as white as readily as with plain luminance.
        field = np.minimum(np.minimum(rgb[:, :, 0], rgb[:, :, 1]), rgb[:, :, 2])
    else:
        # Rec.709 luma. Multiplying by alpha makes transparent pixels empty.
        field = (
            rgb[:, :, 0] * 0.2126
            + rgb[:, :, 1] * 0.7152
            + rgb[:, :, 2] * 0.0722
        )

    field = field * alpha
    if settings.invert:
        field = 1.0 - field

    field, scale = _resize_nearest(field, settings.max_trace_resolution)
    if settings.blur_radius > 0:
        field = _box_blur(field, settings.blur_radius)

    return field.astype(np.float32, copy=False), w, h, scale


def _edge_interp(a, b, threshold):
    d = b - a
    if abs(d) < 1e-12:
        return 0.5
    t = (threshold - a) / d
    if t < 0.0:
        return 0.0
    if t > 1.0:
        return 1.0
    return float(t)


def _marching_squares(field, threshold):
    """
    Sub-pixel iso-contours from a grayscale field.

    This uses the real grey values, not a pre-binarized bitmap, so anti-aliased
    source edges produce cleaner vector paths. A black one-pixel border closes
    shapes that touch the image boundary.
    """
    f = np.pad(field, 1, mode='constant', constant_values=0.0)

    bl = f[:-1, :-1]
    br = f[:-1, 1:]
    tr = f[1:, 1:]
    tl = f[1:, :-1]

    bits = (
        (bl >= threshold).astype(np.uint8)
        | ((br >= threshold).astype(np.uint8) << 1)
        | ((tr >= threshold).astype(np.uint8) << 2)
        | ((tl >= threshold).astype(np.uint8) << 3)
    )

    mask = (bits != 0) & (bits != 15)
    ys, xs = np.nonzero(mask)
    segments = []

    for y, x in zip(ys.tolist(), xs.tolist()):
        v_bl = float(f[y, x])
        v_br = float(f[y, x + 1])
        v_tr = float(f[y + 1, x + 1])
        v_tl = float(f[y + 1, x])
        case = int(bits[y, x])

        points = {}
        if (v_bl >= threshold) != (v_br >= threshold):
            t = _edge_interp(v_bl, v_br, threshold)
            points['b'] = (x + t, y)
        if (v_br >= threshold) != (v_tr >= threshold):
            t = _edge_interp(v_br, v_tr, threshold)
            points['r'] = (x + 1, y + t)
        if (v_tl >= threshold) != (v_tr >= threshold):
            t = _edge_interp(v_tl, v_tr, threshold)
            points['t'] = (x + t, y + 1)
        if (v_bl >= threshold) != (v_tl >= threshold):
            t = _edge_interp(v_bl, v_tl, threshold)
            points['l'] = (x, y + t)

        if len(points) == 2:
            vals = list(points.values())
            segments.append((vals[0], vals[1]))
        elif len(points) == 4:
            # Resolve saddle cells using their centre value. This avoids random
            # topology changes at X-shaped / diagonal anti-aliased pixels.
            centre = (v_bl + v_br + v_tr + v_tl) * 0.25
            if case == 5:  # BL + TR are foreground
                pairs = [('b', 'r'), ('t', 'l')] if centre >= threshold else [('l', 'b'), ('r', 't')]
            elif case == 10:  # BR + TL are foreground
                pairs = [('l', 'b'), ('r', 't')] if centre >= threshold else [('b', 'r'), ('t', 'l')]
            else:
                pairs = [('b', 'r'), ('t', 'l')]
            for a, b in pairs:
                segments.append((points[a], points[b]))

    def key(p):
        # Adjacent cells calculate the same crossing independently. Quantizing
        # makes the stitch robust to tiny float differences.
        return (round(p[0], 6), round(p[1], 6))

    adjacency = {}
    coords = {}
    unused = set()

    for a, b in segments:
        ka, kb = key(a), key(b)
        if ka == kb:
            continue
        coords[ka] = a
        coords[kb] = b
        adjacency.setdefault(ka, []).append(kb)
        adjacency.setdefault(kb, []).append(ka)
        unused.add(tuple(sorted((ka, kb))))

    loops = []
    safety_limit = len(unused) + 16

    while unused:
        edge = next(iter(unused))
        unused.remove(edge)
        start, current = edge[0], edge[1]
        loop = [coords[start], coords[current]]

        steps = 0
        while current != start and steps < safety_limit:
            steps += 1
            nxt = None
            for candidate in adjacency.get(current, ()):
                e = tuple(sorted((current, candidate)))
                if e in unused:
                    nxt = candidate
                    unused.remove(e)
                    break
            if nxt is None:
                break
            current = nxt
            if current != start:
                loop.append(coords[current])

        if current == start and len(loop) >= 3:
            # Remove the artificial one-pixel pad from coordinates.
            loops.append([(p[0] - 1.0, p[1] - 1.0) for p in loop])

    return loops


def _poly_area(points):
    area = 0.0
    n = len(points)
    for i in range(n):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return 0.5 * area


def _point_in_poly(point, poly):
    x, y = point
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            x_intersect = (xj - xi) * (y - yi) / ((yj - yi) if abs(yj - yi) > 1e-30 else 1e-30) + xi
            if x < x_intersect:
                inside = not inside
        j = i
    return inside


def _point_segment_distance(p, a, b):
    px, py = p
    ax, ay = a
    bx, by = b
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    vv = vx * vx + vy * vy
    if vv <= 1e-20:
        return math.hypot(wx, wy)
    t = (wx * vx + wy * vy) / vv
    t = max(0.0, min(1.0, t))
    qx, qy = ax + t * vx, ay + t * vy
    return math.hypot(px - qx, py - qy)


def _rdp_open(points, epsilon):
    """Iterative Ramer-Douglas-Peucker simplification."""
    if len(points) <= 2:
        return list(points)
    keep = [False] * len(points)
    keep[0] = True
    keep[-1] = True
    stack = [(0, len(points) - 1)]

    while stack:
        start, end = stack.pop()
        a, b = points[start], points[end]
        best_i = -1
        best_d = -1.0
        for i in range(start + 1, end):
            d = _point_segment_distance(points[i], a, b)
            if d > best_d:
                best_d = d
                best_i = i
        if best_i >= 0 and best_d > epsilon:
            keep[best_i] = True
            stack.append((start, best_i))
            stack.append((best_i, end))

    return [p for i, p in enumerate(points) if keep[i]]


def _simplify_closed(points, epsilon):
    if epsilon <= 0.0 or len(points) < 6:
        return list(points)

    # Split the ring across a long chord, simplify the two arcs separately,
    # then join. This avoids the usual closed-loop RDP seam artefact.
    i0 = min(range(len(points)), key=lambda i: (points[i][0], points[i][1]))
    p0 = points[i0]
    i1 = max(
        range(len(points)),
        key=lambda i: (points[i][0] - p0[0]) ** 2 + (points[i][1] - p0[1]) ** 2,
    )

    def arc(a, b):
        out = [points[a]]
        i = a
        while i != b:
            i = (i + 1) % len(points)
            out.append(points[i])
        return out

    a = _rdp_open(arc(i0, i1), epsilon)
    b = _rdp_open(arc(i1, i0), epsilon)
    merged = a[:-1] + b[:-1]
    return merged if len(merged) >= 3 else list(points)


def _orient_by_nesting(loops):
    """Outer contours CCW, holes CW, nested islands alternating."""
    if not loops:
        return loops

    areas = [abs(_poly_area(p)) for p in loops]
    oriented = []
    for i, poly in enumerate(loops):
        test = poly[0]
        depth = 0
        for j, other in enumerate(loops):
            if i == j or areas[j] <= areas[i]:
                continue
            if _point_in_poly(test, other):
                depth += 1
        want_ccw = (depth % 2 == 0)
        is_ccw = _poly_area(poly) > 0.0
        if is_ccw != want_ccw:
            poly = list(reversed(poly))
        oriented.append(poly)
    return oriented


def _trace_image(image, settings):
    field, src_w, src_h, downsample_scale = _image_field(image, settings)
    trace_h, trace_w = field.shape

    loops = _marching_squares(field, settings.threshold)

    # Area and simplification are specified in source-image pixels. Convert
    # them to the possibly downsampled trace pixel space.
    min_area_trace = settings.min_area_px * downsample_scale * downsample_scale
    simplify_trace = settings.simplify_px * downsample_scale

    loops = [p for p in loops if abs(_poly_area(p)) >= min_area_trace]
    loops = [_simplify_closed(p, simplify_trace) for p in loops]
    loops = [p for p in loops if len(p) >= 3]
    loops = _orient_by_nesting(loops)

    if not loops:
        raise RuntimeError("No closed white regions were found. Try lowering Threshold, reducing Min Area, or toggling Invert.")

    # Fit the traced image width to the requested Blender-unit width.
    unit_per_trace_px = settings.output_width / max(1.0, float(trace_w - 1))
    cx = (trace_w - 1) * 0.5
    cy = (trace_h - 1) * 0.5

    result = []
    for poly in loops:
        converted = []
        for x, y in poly:
            xx = (x - cx) * unit_per_trace_px
            yy = (y - cy) * unit_per_trace_px
            if settings.flip_y:
                yy = -yy
            converted.append((xx, yy))
        result.append(converted)

    return result, src_w, src_h


# -----------------------------------------------------------------------------
# Blender data / Geometry Nodes
# -----------------------------------------------------------------------------

def _new_interface_socket(node_group, name, in_out, socket_type):
    # Blender 4.x/5.x API.
    if hasattr(node_group, "interface"):
        return node_group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    # Older fallback (not the primary supported target).
    collection = node_group.inputs if in_out == 'INPUT' else node_group.outputs
    return collection.new(socket_type, name)


def _ensure_fill_node_group(settings=None):
    """Build the procedural 2D -> 3D Geometry Nodes stack.

    v1.6 intentionally starts from the known-working v1.2 tree and changes only
    the 3D shaping stage:

      Fill Curve -> Extrude Mesh -> bevel TOP PERIMETER only (true-distance
      inset/chamfer) -> bevel TOP/BOTTOM RIMS only (rounding) -> output.

    The old Top Width island scaling is gone. Top Inset is a real distance into
    the top face, so long strokes, letters, holes and separate islands do not
    collapse toward arbitrary object centres.

    The bevel selections are tightly restricted. Internal triangulation edges
    are rejected with Edge Angle, and vertical silhouette edges are never sent
    to the rounding bevel. This is specifically to avoid the spikes/bow-ties
    that v1.2 could create on acute traced corners.
    """
    ng = bpy.data.node_groups.get(NODE_GROUP_NAME)
    if ng and ng.bl_idname != 'GeometryNodeTree':
        bpy.data.node_groups.remove(ng)
        ng = None

    if ng is None:
        ng = bpy.data.node_groups.new(NODE_GROUP_NAME, 'GeometryNodeTree')
        _new_interface_socket(ng, "Geometry", 'INPUT', 'NodeSocketGeometry')
        _new_interface_socket(ng, "Geometry", 'OUTPUT', 'NodeSocketGeometry')
    else:
        ng.nodes.clear()

    nodes = ng.nodes
    links = ng.links

    def value_node(name, label, value, location):
        n = nodes.new('ShaderNodeValue')
        n.name = ADDON_PREFIX + name
        n.label = label
        n.location = location
        n.outputs[0].default_value = float(value)
        return n

    def compare_node(operation, location, label, b=None):
        n = nodes.new('FunctionNodeCompare')
        n.data_type = 'FLOAT'
        n.operation = operation
        n.location = location
        n.label = label
        if b is not None:
            try:
                n.inputs['B'].default_value = float(b)
            except Exception:
                pass
        return n

    def bool_node(operation, location, label):
        n = nodes.new('FunctionNodeBooleanMath')
        n.operation = operation
        n.location = location
        n.label = label
        return n

    def math_node(operation, location, label, b=None):
        n = nodes.new('ShaderNodeMath')
        n.operation = operation
        n.location = location
        n.label = label
        if b is not None:
            n.inputs[1].default_value = float(b)
        return n

    def set_bevel_offsets(node, socket=None, value=0.0):
        found = 0
        for sock_name in ('Start Left Offset', 'Start Right Offset', 'End Left Offset', 'End Right Offset'):
            s = node.inputs.get(sock_name)
            if s is None:
                continue
            found += 1
            if socket is None:
                s.default_value = float(value)
            else:
                links.new(socket, s)
        if found == 0:
            raise RuntimeError("Mesh Bevel offset sockets were not found in this Blender build")

    # ------------------------------------------------------------------
    # Known-good v1.2 base: Group Input -> Fill Curve -> Extrude Mesh.
    # ------------------------------------------------------------------
    n_in = nodes.new('NodeGroupInput')
    n_in.label = "Traced closed curves"
    n_in.location = (-1500, 120)

    n_fill = nodes.new('GeometryNodeFillCurve')
    n_fill.label = "Fill white regions / preserve holes"
    n_fill.location = (-1280, 120)
    try:
        n_fill.mode = 'NGONS'
    except Exception:
        pass

    height = float(getattr(settings, 'height', 0.0) if settings else 0.0)
    inset = float(getattr(settings, 'top_inset', 0.0) if settings else 0.0)
    inset_segments = int(getattr(settings, 'top_segments', 1) if settings else 1)
    inset_profile = float(getattr(settings, 'top_profile', 0.5) if settings else 0.5)
    inset_miter = bool(getattr(settings, 'top_miter', False) if settings else False)
    round_width = float(getattr(settings, 'bevel_width', 0.0) if settings else 0.0)
    round_segments = int(getattr(settings, 'bevel_segments', 3) if settings else 3)
    round_shape = float(getattr(settings, 'bevel_shape', 0.5) if settings else 0.5)

    n_height = value_node("Height", "Height", height, (-1280, -140))
    n_inset = value_node("TopInset", "Top Inset", inset, (-940, -390))
    n_round = value_node("RoundWidth", "Edge Round", round_width, (420, -470))

    n_offset = nodes.new('ShaderNodeCombineXYZ')
    n_offset.location = (-1080, -120)

    n_extrude = nodes.new('GeometryNodeExtrudeMesh')
    n_extrude.name = ADDON_PREFIX + "Extrude"
    n_extrude.label = "Height"
    n_extrude.location = (-1030, 120)
    n_extrude.mode = 'FACES'
    if n_extrude.inputs.get('Selection'):
        n_extrude.inputs['Selection'].default_value = True
    if n_extrude.inputs.get('Individual'):
        n_extrude.inputs['Individual'].default_value = False

    # Critical links kept exactly in the simple v1.2 style.
    links.new(n_in.outputs.get('Geometry'), n_fill.inputs.get('Curve'))
    links.new(n_height.outputs[0], n_offset.inputs.get('Z'))
    links.new(n_fill.outputs.get('Mesh'), n_extrude.inputs.get('Mesh'))
    links.new(n_offset.outputs.get('Vector'), n_extrude.inputs.get('Offset'))

    # ------------------------------------------------------------------
    # Top Inset / shoulder
    # ------------------------------------------------------------------
    # Select only perimeter edges on the top plane. Position excludes vertical
    # edges; Edge Angle excludes coplanar triangulation/internal edges.
    n_pos_top = nodes.new('GeometryNodeInputPosition')
    n_pos_top.location = (-830, -20)
    n_sep_top = nodes.new('ShaderNodeSeparateXYZ')
    n_sep_top.location = (-650, -20)
    links.new(n_pos_top.outputs.get('Position'), n_sep_top.inputs.get('Vector'))

    n_top_z = math_node('MULTIPLY', (-830, -150), "Top Z threshold", 0.9995)
    links.new(n_height.outputs[0], n_top_z.inputs[0])

    n_is_top = compare_node('GREATER_THAN', (-460, -20), "Top plane")
    links.new(n_sep_top.outputs.get('Z'), n_is_top.inputs.get('A'))
    links.new(n_top_z.outputs[0], n_is_top.inputs.get('B'))

    n_angle_top = nodes.new('GeometryNodeInputMeshEdgeAngle')
    n_angle_top.location = (-650, -170)
    n_has_angle_top = compare_node('GREATER_THAN', (-460, -170), "Boundary edge", 0.001)
    links.new(n_angle_top.outputs.get('Unsigned Angle'), n_has_angle_top.inputs.get('A'))

    n_top_boundary = bool_node('AND', (-250, -60), "Top perimeter only")
    links.new(n_is_top.outputs.get('Result'), n_top_boundary.inputs[0])
    links.new(n_has_angle_top.outputs.get('Result'), n_top_boundary.inputs[1])

    # A stock bevel shoulder cannot travel farther down the side than the
    # object is tall. Keep a safety margin so aggressive values do not invert.
    n_hcap = math_node('MULTIPLY', (-700, -330), "Inset height safety", 0.45)
    links.new(n_height.outputs[0], n_hcap.inputs[0])
    n_inset_safe = math_node('MINIMUM', (-480, -330), "Safe inset")
    links.new(n_inset.outputs[0], n_inset_safe.inputs[0])
    links.new(n_hcap.outputs[0], n_inset_safe.inputs[1])

    n_inset_bevel = nodes.new('GeometryNodeMeshBevel')
    n_inset_bevel.name = ADDON_PREFIX + "InsetBevel"
    n_inset_bevel.label = "Top Inset / Shoulder"
    n_inset_bevel.location = (0, 120)
    if n_inset_bevel.inputs.get('Segments'):
        n_inset_bevel.inputs['Segments'].default_value = max(1, inset_segments)
    if n_inset_bevel.inputs.get('Shape'):
        n_inset_bevel.inputs['Shape'].default_value = inset_profile
    if n_inset_bevel.inputs.get('Miter'):
        n_inset_bevel.inputs['Miter'].default_value = inset_miter
    links.new(n_extrude.outputs.get('Mesh'), n_inset_bevel.inputs.get('Mesh'))
    links.new(n_top_boundary.outputs[0], n_inset_bevel.inputs.get('Selection'))
    set_bevel_offsets(n_inset_bevel, n_inset_safe.outputs[0])

    # ------------------------------------------------------------------
    # Artifact-safe edge rounding
    # ------------------------------------------------------------------
    # Round only the final top and bottom horizontal perimeter rings. The
    # vertical contour corners are intentionally NOT selected; that was the
    # main source of the exploding triangular patches in v1.2.
    n_pos_round = nodes.new('GeometryNodeInputPosition')
    n_pos_round.location = (180, -30)
    n_sep_round = nodes.new('ShaderNodeSeparateXYZ')
    n_sep_round.location = (370, -30)
    links.new(n_pos_round.outputs.get('Position'), n_sep_round.inputs.get('Vector'))

    n_is_top2 = compare_node('GREATER_THAN', (560, -20), "Top rim")
    links.new(n_sep_round.outputs.get('Z'), n_is_top2.inputs.get('A'))
    links.new(n_top_z.outputs[0], n_is_top2.inputs.get('B'))

    n_bottom_eps = math_node('MULTIPLY', (360, -150), "Bottom epsilon", 0.0005)
    links.new(n_height.outputs[0], n_bottom_eps.inputs[0])
    n_is_bottom = compare_node('LESS_THAN', (560, -150), "Bottom rim")
    links.new(n_sep_round.outputs.get('Z'), n_is_bottom.inputs.get('A'))
    links.new(n_bottom_eps.outputs[0], n_is_bottom.inputs.get('B'))

    n_rims = bool_node('OR', (750, -70), "Top or bottom rim")
    links.new(n_is_top2.outputs.get('Result'), n_rims.inputs[0])
    links.new(n_is_bottom.outputs.get('Result'), n_rims.inputs[1])

    n_angle_round = nodes.new('GeometryNodeInputMeshEdgeAngle')
    n_angle_round.location = (370, -270)
    n_has_angle_round = compare_node('GREATER_THAN', (560, -270), "Non-flat rim", 0.001)
    links.new(n_angle_round.outputs.get('Unsigned Angle'), n_has_angle_round.inputs.get('A'))

    n_round_sel = bool_node('AND', (930, -80), "Safe rim selection")
    links.new(n_rims.outputs[0], n_round_sel.inputs[0])
    links.new(n_has_angle_round.outputs.get('Result'), n_round_sel.inputs[1])

    # Global height cap. Because vertical corners are excluded, this does not
    # need the aggressive per-edge varying width used in the broken revisions.
    n_round_hcap = math_node('MULTIPLY', (620, -410), "Round height safety", 0.20)
    links.new(n_height.outputs[0], n_round_hcap.inputs[0])
    n_round_safe = math_node('MINIMUM', (820, -410), "Safe round width")
    links.new(n_round.outputs[0], n_round_safe.inputs[0])
    links.new(n_round_hcap.outputs[0], n_round_safe.inputs[1])

    n_bevel = nodes.new('GeometryNodeMeshBevel')
    n_bevel.name = ADDON_PREFIX + "Bevel"
    n_bevel.label = "Top / Bottom Rim Round"
    n_bevel.location = (1140, 120)
    if n_bevel.inputs.get('Segments'):
        n_bevel.inputs['Segments'].default_value = max(1, round_segments)
    if n_bevel.inputs.get('Shape'):
        n_bevel.inputs['Shape'].default_value = round_shape
    if n_bevel.inputs.get('Miter'):
        n_bevel.inputs['Miter'].default_value = False
    links.new(n_inset_bevel.outputs.get('Mesh'), n_bevel.inputs.get('Mesh'))
    links.new(n_round_sel.outputs[0], n_bevel.inputs.get('Selection'))
    set_bevel_offsets(n_bevel, n_round_safe.outputs[0])

    # Height 0 returns the exact flat fill, exactly as v1.2 did.
    n_has_height = nodes.new('ShaderNodeMath')
    n_has_height.name = ADDON_PREFIX + "HasHeight"
    n_has_height.label = "Height > 0"
    n_has_height.operation = 'GREATER_THAN'
    n_has_height.location = (1140, -190)
    n_has_height.inputs[1].default_value = 0.000001

    n_switch = nodes.new('GeometryNodeSwitch')
    n_switch.label = "Flat / 3D"
    n_switch.location = (1390, 120)
    n_switch.input_type = 'GEOMETRY'

    n_out = nodes.new('NodeGroupOutput')
    n_out.location = (1630, 120)

    links.new(n_height.outputs[0], n_has_height.inputs[0])
    links.new(n_has_height.outputs[0], n_switch.inputs.get('Switch'))
    links.new(n_fill.outputs.get('Mesh'), n_switch.inputs.get('False'))
    links.new(n_bevel.outputs.get('Mesh'), n_switch.inputs.get('True'))
    links.new(n_switch.outputs.get('Output'), n_out.inputs.get('Geometry'))

    return ng


def _update_geometry_nodes(settings):
    """Update 3D shaping controls without retracing the raster image."""
    ng = bpy.data.node_groups.get(NODE_GROUP_NAME)
    if ng is None or not ng.nodes:
        ng = _ensure_fill_node_group(settings)

    n_height = ng.nodes.get(ADDON_PREFIX + "Height")
    if n_height:
        n_height.outputs[0].default_value = float(settings.height)

    n_inset = ng.nodes.get(ADDON_PREFIX + "TopInset")
    if n_inset:
        n_inset.outputs[0].default_value = float(settings.top_inset)

    n_inset_bevel = ng.nodes.get(ADDON_PREFIX + "InsetBevel")
    if n_inset_bevel:
        if n_inset_bevel.inputs.get('Segments'):
            n_inset_bevel.inputs['Segments'].default_value = max(1, int(settings.top_segments))
        if n_inset_bevel.inputs.get('Shape'):
            n_inset_bevel.inputs['Shape'].default_value = float(settings.top_profile)
        if n_inset_bevel.inputs.get('Miter'):
            n_inset_bevel.inputs['Miter'].default_value = bool(settings.top_miter)

    n_round = ng.nodes.get(ADDON_PREFIX + "RoundWidth")
    if n_round:
        n_round.outputs[0].default_value = float(settings.bevel_width)

    n_bevel = ng.nodes.get(ADDON_PREFIX + "Bevel")
    if n_bevel:
        if n_bevel.inputs.get('Segments'):
            n_bevel.inputs['Segments'].default_value = max(1, int(settings.bevel_segments))
        if n_bevel.inputs.get('Shape'):
            n_bevel.inputs['Shape'].default_value = float(settings.bevel_shape)

    # Force viewport reevaluation of any object using the group.
    for obj in bpy.data.objects:
        for mod in obj.modifiers:
            if mod.type == 'NODES' and mod.node_group == ng:
                try:
                    obj.update_tag()
                except Exception:
                    pass
                break


def _request_geometry_update(self, context):
    try:
        _update_geometry_nodes(self)
        self.status = "3D shape updated"
    except Exception as exc:
        self.status = f"3D update failed: {exc}"

def _curve_object_from_loops(context, loops, settings, image, select_result=True):
    props = settings
    obj = props.output_object

    if obj and obj.name not in bpy.data.objects:
        obj = None

    target_collection = getattr(context, "collection", None) or context.scene.collection

    if obj is None or obj.type != 'CURVE':
        curve = bpy.data.curves.new(ADDON_PREFIX + "Curves", type='CURVE')
        obj = bpy.data.objects.new(ADDON_PREFIX + "Trace", curve)
        target_collection.objects.link(obj)
        props.output_object = obj
    else:
        curve = obj.data
        curve.splines.clear()
        # A Scene pointer can survive after an object was unlinked from the
        # current Scene/Collection. That produces a perfectly successful trace
        # status but nothing visible in the viewport. Always repair the link.
        try:
            if obj.name not in context.scene.objects:
                target_collection.objects.link(obj)
        except Exception:
            try:
                if not obj.users_collection:
                    context.scene.collection.objects.link(obj)
            except Exception:
                pass

    # Explicitly make the trace visible again in case the previous source was
    # hidden after Bake Mesh or by the user.
    try:
        obj.hide_viewport = False
        obj.hide_render = False
        obj.hide_set(False)
    except Exception:
        pass

    curve.name = ADDON_PREFIX + "Curves"
    curve.dimensions = '2D'
    curve.resolution_u = 1
    try:
        curve.fill_mode = 'NONE'
    except Exception:
        pass

    total_points = 0
    for poly in loops:
        spline = curve.splines.new('POLY')
        spline.points.add(len(poly) - 1)
        for i, (x, y) in enumerate(poly):
            spline.points[i].co = (x, y, 0.0, 1.0)
        spline.use_cyclic_u = True
        total_points += len(poly)

    # Dedicated Geometry Nodes modifier: closed curve regions -> mesh faces.
    mod = None
    for m in obj.modifiers:
        if m.type == 'NODES' and m.name.startswith(ADDON_PREFIX):
            mod = m
            break
    if mod is None:
        mod = obj.modifiers.new(ADDON_PREFIX + "Fill", 'NODES')
    mod.node_group = _ensure_fill_node_group(settings)

    obj["sitgn_source_image"] = image.name
    obj["sitgn_contour_count"] = len(loops)
    obj["sitgn_point_count"] = total_points

    # Select result for immediate inspection only for explicit traces/load.
    # Live slider updates should not steal the user's selection every time.
    if select_result:
        try:
            for other in context.selected_objects:
                other.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
        except Exception:
            pass

    return obj, total_points


# -----------------------------------------------------------------------------
# Live preview / trace execution
# -----------------------------------------------------------------------------

def _frame_result_in_view3d(context, obj):
    """Best-effort viewport framing after the first image load."""
    try:
        screen = context.screen
        if screen is None:
            return
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region is None:
                continue
            with context.temp_override(area=area, region=region, active_object=obj, object=obj):
                bpy.ops.view3d.view_selected(use_all_regions=False)
            break
    except Exception:
        # Framing is convenience only; trace creation must never fail because
        # the current editor/context cannot run a View3D operator.
        pass


def _perform_trace(context, settings, *, select_result=False, frame_result=False):
    image = settings.image
    if image is None:
        settings.status = "Choose or load an image"
        return None

    settings.status = "Tracing..."
    loops, src_w, src_h = _trace_image(image, settings)
    obj, total_points = _curve_object_from_loops(
        context, loops, settings, image, select_result=select_result
    )
    try:
        linked = obj.name in context.scene.objects
    except Exception:
        linked = bool(obj)
    settings.status = f"{len(loops)} contours • {total_points} points • {'visible' if linked else 'UNLINKED'}"
    if frame_result:
        _frame_result_in_view3d(context, obj)
    return obj


def _run_live_timer():
    global _LIVE_TIMER_RUNNING, _LIVE_TRACE_RUNNING

    if _LIVE_TRACE_RUNNING:
        return 0.10

    if not _LIVE_PENDING_SCENES:
        _LIVE_TIMER_RUNNING = False
        return None

    pending = list(_LIVE_PENDING_SCENES)
    _LIVE_PENDING_SCENES.clear()
    _LIVE_TRACE_RUNNING = True
    try:
        context = bpy.context
        for scene_name in pending:
            scene = bpy.data.scenes.get(scene_name)
            if scene is None or not hasattr(scene, "sitgn_settings"):
                continue
            settings = scene.sitgn_settings
            if not settings.live_update or settings.image is None:
                continue
            # The current active scene is the normal UI case. If the queued
            # scene is not active, defer it until it becomes active rather than
            # creating objects into the wrong collection/view layer.
            if context.scene != scene:
                _LIVE_PENDING_SCENES.add(scene_name)
                continue
            try:
                _perform_trace(context, settings, select_result=False, frame_result=False)
            except Exception as exc:
                settings.status = f"Live update failed: {exc}"
    finally:
        _LIVE_TRACE_RUNNING = False

    if _LIVE_PENDING_SCENES:
        return 0.12
    _LIVE_TIMER_RUNNING = False
    return None


def _request_live_update(self, context):
    """Property update callback used by all settings that affect the trace."""
    global _LIVE_TIMER_RUNNING
    try:
        if not self.live_update or self.image is None:
            return
        scene = context.scene if context and context.scene else None
        if scene is None:
            return
        _LIVE_PENDING_SCENES.add(scene.name)
        self.status = "Live update queued..."
        if not _LIVE_TIMER_RUNNING:
            _LIVE_TIMER_RUNNING = True
            bpy.app.timers.register(_run_live_timer, first_interval=0.10)
    except Exception:
        # Blender can call property updates during registration/file loading
        # where no useful context exists. Silently skip those cases.
        pass


# -----------------------------------------------------------------------------
# Properties
# -----------------------------------------------------------------------------

class SITGN_Settings(PropertyGroup):
    image: PointerProperty(
        name="Image",
        type=bpy.types.Image,
        description="Raster image to trace",
        update=_request_live_update,
    )

    detection_mode: EnumProperty(
        name="White Detection",
        items=(
            ('LUMA', "Luminance", "Use perceived brightness; best for black/white artwork"),
            ('MIN_RGB', "Strict White", "Requires all RGB channels to be bright; useful if the image contains colours"),
        ),
        default='LUMA',
        update=_request_live_update,
    )

    threshold: FloatProperty(
        name="Threshold",
        description="Iso-value used to trace the edge between black and white",
        default=0.50,
        min=0.01,
        max=0.99,
        precision=3,
        update=_request_live_update,
    )

    invert: BoolProperty(
        name="Invert",
        description="Trace dark areas instead of bright/white areas",
        default=False,
        update=_request_live_update,
    )

    blur_radius: IntProperty(
        name="Pre-Blur",
        description="Small source-space cleanup before tracing; useful for JPEG noise and rough scans",
        default=0,
        min=0,
        max=12,
        update=_request_live_update,
    )

    simplify_px: FloatProperty(
        name="Simplify",
        description="RDP contour simplification in source-image pixels. Higher values create cleaner/lighter curves",
        default=1.0,
        min=0.0,
        max=20.0,
        precision=2,
        subtype='PIXEL',
        update=_request_live_update,
    )

    min_area_px: FloatProperty(
        name="Min Island Area",
        description="Ignore tiny foreground islands / holes below this approximate pixel area",
        default=12.0,
        min=0.0,
        max=1000000.0,
        precision=1,
        update=_request_live_update,
    )

    max_trace_resolution: IntProperty(
        name="Max Trace Resolution",
        description="Images larger than this are downsampled for contour extraction. 2048 is fast and usually very accurate",
        default=2048,
        min=256,
        max=8192,
        update=_request_live_update,
    )

    output_width: FloatProperty(
        name="Width",
        description="Final traced image width in Blender units",
        default=2.0,
        min=0.0001,
        max=100000.0,
        precision=4,
        update=_request_live_update,
    )

    height: FloatProperty(
        name="Height",
        description="Extrude the filled white regions upward in Z. Zero keeps the result flat",
        default=0.20,
        min=0.0,
        max=1000.0,
        precision=4,
        subtype='DISTANCE',
        update=_request_geometry_update,
    )

    top_inset: FloatProperty(
        name="Top Inset",
        description="Constant-distance top shoulder. Shrinks the top boundary inward instead of scaling each island",
        default=0.0,
        min=0.0,
        max=100.0,
        precision=4,
        subtype='DISTANCE',
        update=_request_geometry_update,
    )

    top_segments: IntProperty(
        name="Inset Segments",
        description="1 gives a straight chamfer; higher values round the shoulder profile",
        default=1,
        min=1,
        max=12,
        update=_request_geometry_update,
    )

    top_profile: FloatProperty(
        name="Inset Profile",
        description="Cross-section shape of the inset shoulder when Inset Segments is above 1",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
        update=_request_geometry_update,
    )

    top_miter: BoolProperty(
        name="Smooth Inset Corners",
        description="Use Blender's Arc/Patch miter treatment on inset corners. Leave off for the most conservative topology",
        default=False,
        update=_request_geometry_update,
    )

    bevel_width: FloatProperty(
        name="Edge Round",
        description="Geometry Nodes bevel width for non-flat 3D edges. Set to zero for sharp edges",
        default=0.0,
        min=0.0,
        max=100.0,
        precision=4,
        subtype='DISTANCE',
        update=_request_geometry_update,
    )

    bevel_segments: IntProperty(
        name="Round Segments",
        description="Number of segments used by the Geometry Nodes edge bevel",
        default=3,
        min=1,
        max=16,
        update=_request_geometry_update,
    )

    bevel_shape: FloatProperty(
        name="Round Profile",
        description="Shape of the rounded edge; 0.5 gives a circular-style profile",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
        update=_request_geometry_update,
    )

    flip_y: BoolProperty(
        name="Flip Y",
        description="Vertically flip the traced result if the source orientation requires it",
        default=False,
        update=_request_live_update,
    )

    live_update: BoolProperty(
        name="Live Preview",
        description="Automatically retrace after loading an image or changing trace settings",
        default=True,
        update=_request_live_update,
    )

    hide_source_after_bake: BoolProperty(
        name="Hide Curves After Bake",
        default=True,
    )

    output_object: PointerProperty(
        name="Trace Object",
        type=bpy.types.Object,
    )

    status: StringProperty(
        name="Status",
        default="Ready",
        options={'SKIP_SAVE'},
    )


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------

class SITGN_OT_load_image(Operator, ImportHelper):
    bl_idname = "sitgn.load_image"
    bl_label = "Load Image"
    bl_description = "Load a raster image into Blender and use it as the trace source"

    filename_ext = ".png"
    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.tga;*.webp",
        options={'HIDDEN'},
    )

    def execute(self, context):
        try:
            image = bpy.data.images.load(self.filepath, check_existing=True)
            settings = context.scene.sitgn_settings
            settings.image = image

            # Loading is an explicit action: always create a visible result
            # immediately. This fixes the old two-step "load, then trace"
            # behaviour that looked like the add-on did nothing.
            _LIVE_PENDING_SCENES.discard(context.scene.name)
            obj = _perform_trace(
                context, settings, select_result=True, frame_result=True
            )
            if obj:
                self.report({'INFO'}, settings.status)
            return {'FINISHED'}
        except Exception as exc:
            context.scene.sitgn_settings.status = f"Load/trace failed: {exc}"
            self.report({'ERROR'}, f"Smart Image Trace: {exc}")
            return {'CANCELLED'}


class SITGN_OT_use_selected_image(Operator):
    bl_idname = "sitgn.use_selected_image"
    bl_label = "Use Selected Image Empty"
    bl_description = "Use the image assigned to the selected Image Empty"

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def execute(self, context):
        obj = context.object
        image = getattr(obj, "data", None)
        if not isinstance(image, bpy.types.Image):
            # Some Blender builds expose an image empty through a data-like
            # property only when its display type is IMAGE; keep the message
            # explicit rather than silently picking an unrelated image.
            self.report({'ERROR'}, "Selected object does not expose a Blender Image datablock. Use Load Image instead.")
            return {'CANCELLED'}
        settings = context.scene.sitgn_settings
        settings.image = image
        try:
            _LIVE_PENDING_SCENES.discard(context.scene.name)
            _perform_trace(context, settings, select_result=True, frame_result=True)
            self.report({'INFO'}, settings.status)
            return {'FINISHED'}
        except Exception as exc:
            settings.status = f"Trace failed: {exc}"
            self.report({'ERROR'}, f"Smart Image Trace: {exc}")
            return {'CANCELLED'}


class SITGN_OT_trace(Operator):
    bl_idname = "sitgn.trace"
    bl_label = "Trace / Update"
    bl_description = "Trace the white raster regions to closed curves and fill them with Geometry Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.sitgn_settings
        image = settings.image
        if image is None:
            self.report({'ERROR'}, "Choose or load an image first.")
            return {'CANCELLED'}

        try:
            _LIVE_PENDING_SCENES.discard(context.scene.name)
            _perform_trace(context, settings, select_result=True, frame_result=True)
            self.report({'INFO'}, settings.status)
            return {'FINISHED'}
        except Exception as exc:
            settings.status = "Trace failed"
            self.report({'ERROR'}, f"Smart Image Trace: {exc}")
            return {'CANCELLED'}


class SITGN_OT_bake_mesh(Operator):
    bl_idname = "sitgn.bake_mesh"
    bl_label = "Bake Filled Mesh"
    bl_description = "Create a real mesh from the evaluated Geometry Nodes result while keeping the editable trace curves"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        s = getattr(context.scene, "sitgn_settings", None)
        return bool(s and s.output_object and s.output_object.name in bpy.data.objects)

    def execute(self, context):
        settings = context.scene.sitgn_settings
        source = settings.output_object
        if source is None:
            return {'CANCELLED'}

        try:
            depsgraph = context.evaluated_depsgraph_get()
            evaluated = source.evaluated_get(depsgraph)
            mesh = bpy.data.meshes.new_from_object(evaluated, depsgraph=depsgraph)
            if mesh is None:
                raise RuntimeError("The evaluated Geometry Nodes output did not produce a mesh.")

            mesh.name = source.name + "_Mesh"
            baked = bpy.data.objects.new(source.name + "_Mesh", mesh)
            # Link to the same collection as source where possible.
            if source.users_collection:
                source.users_collection[0].objects.link(baked)
            else:
                context.collection.objects.link(baked)
            baked.matrix_world = source.matrix_world.copy()

            for obj in context.selected_objects:
                obj.select_set(False)
            baked.select_set(True)
            context.view_layer.objects.active = baked

            if settings.hide_source_after_bake:
                source.hide_set(True)

            settings.status = f"Baked mesh: {len(mesh.polygons)} faces"
            self.report({'INFO'}, settings.status)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, f"Bake failed: {exc}")
            return {'CANCELLED'}


class SITGN_OT_clear(Operator):
    bl_idname = "sitgn.clear"
    bl_label = "Remove Trace"
    bl_description = "Remove the current editable traced curve object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.sitgn_settings
        obj = settings.output_object
        if obj and obj.name in bpy.data.objects:
            data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if data and data.users == 0:
                try:
                    bpy.data.curves.remove(data)
                except Exception:
                    pass
        settings.output_object = None
        settings.status = "Ready"
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# UI
# -----------------------------------------------------------------------------

class SITGN_PT_panel(Panel):
    bl_label = "Smart Image Trace"
    bl_idname = "SITGN_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Image Trace"

    def draw(self, context):
        layout = self.layout
        s = context.scene.sitgn_settings

        box = layout.box()
        box.label(text="Source", icon='IMAGE_DATA')
        box.prop(s, "image")
        row = box.row(align=True)
        row.operator("sitgn.load_image", icon='FILE_FOLDER')
        row.operator("sitgn.use_selected_image", icon='EYEDROPPER')
        box.prop(s, "live_update", toggle=True, icon='REC')
        if s.live_update:
            box.label(text="Loading or changing a setting retraces automatically.", icon='CHECKMARK')

        box = layout.box()
        box.label(text="White-region extraction", icon='MOD_MASK')
        box.prop(s, "detection_mode")
        row = box.row(align=True)
        row.prop(s, "threshold")
        row.prop(s, "invert", toggle=True)
        box.prop(s, "blur_radius")
        box.prop(s, "min_area_px")
        box.prop(s, "simplify_px")
        box.prop(s, "max_trace_resolution")

        box = layout.box()
        box.label(text="Output Size", icon='CURVE_DATA')
        box.prop(s, "output_width")
        box.prop(s, "flip_y")

        box = layout.box()
        box.label(text="3D Shape", icon='MOD_SOLIDIFY')
        box.prop(s, "height")

        box.separator()
        box.label(text="Top Shoulder", icon='MOD_BEVEL')
        box.prop(s, "top_inset")
        row = box.row(align=True)
        row.enabled = s.top_inset > 0.0
        row.prop(s, "top_segments")
        row.prop(s, "top_profile", text="Profile")
        row = box.row()
        row.enabled = s.top_inset > 0.0
        row.prop(s, "top_miter")

        box.separator()
        box.label(text="Rim Rounding", icon='MOD_BEVEL')
        box.prop(s, "bevel_width")
        row = box.row(align=True)
        row.enabled = s.bevel_width > 0.0
        row.prop(s, "bevel_segments")
        row.prop(s, "bevel_shape", text="Profile")

        col = layout.column(align=True)
        col.scale_y = 1.25
        col.operator("sitgn.trace", text="Rebuild Now", icon='FILE_REFRESH')

        if s.output_object:
            row = layout.row(align=True)
            row.operator("sitgn.bake_mesh", text="Bake Mesh", icon='MESH_DATA')
            row.operator("sitgn.clear", text="Remove", icon='TRASH')
            layout.prop(s, "hide_source_after_bake")

        layout.separator()
        status = layout.row()
        status.label(text=s.status, icon='INFO')
        hint = layout.column(align=True)
        hint.scale_y = 0.85
        hint.label(text="Tracing uses sub-pixel marching squares.")
        hint.label(text="GN: Fill → Extrude → top-perimeter inset → rim round.")
        hint.label(text="Top Inset is a distance, not an island scale.")
        hint.label(text="Rounding excludes vertical contour edges to avoid spikes.")


classes = (
    SITGN_Settings,
    SITGN_OT_load_image,
    SITGN_OT_use_selected_image,
    SITGN_OT_trace,
    SITGN_OT_bake_mesh,
    SITGN_OT_clear,
    SITGN_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sitgn_settings = PointerProperty(type=SITGN_Settings)


def unregister():
    if hasattr(bpy.types.Scene, "sitgn_settings"):
        del bpy.types.Scene.sitgn_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

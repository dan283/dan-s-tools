bl_info = {
    'name': 'Mesh Simplification',
    'author': 'OpenAI; meshoptimizer by Arseny Kapoulkine; Fast Quadric by Sven Forstmann',
    'version': (2, 3, 0),
    'blender': (4, 3, 0),
    'location': 'View3D > Sidebar > Mesh Simplification',
    'description': 'Native mesh reduction with fast, standard, and quadric methods',
    'category': 'Mesh',
}

import bpy
import ctypes as C
from array import array
from pathlib import Path
from time import perf_counter
from bpy.props import IntProperty, PointerProperty, FloatProperty

_NATIVE = None
_QUADRIC = None


def backend():
    global _NATIVE
    if _NATIVE is None:
        dll = Path(__file__).with_name('meshopt_backend.dll')
        if not dll.exists():
            raise RuntimeError('Windows backend DLL is missing')
        lib = C.CDLL(str(dll))
        lib.meshopt_reduce.argtypes = [C.POINTER(C.c_uint32), C.POINTER(C.c_uint32), C.c_uint64,
            C.POINTER(C.c_float), C.c_uint64, C.c_uint64, C.c_int,
            C.POINTER(C.c_float), C.c_float, C.c_float, C.POINTER(C.c_float)]
        lib.meshopt_reduce.restype = C.c_uint64
        _NATIVE = lib
    return _NATIVE


def quadric_backend():
    global _QUADRIC
    if _QUADRIC is None:
        dll = Path(__file__).with_name('quadric_backend.dll')
        if not dll.exists():
            raise RuntimeError('Quadric quality DLL is missing')
        lib = C.CDLL(str(dll))
        lib.quadric_reduce.argtypes = [C.POINTER(C.c_float), C.POINTER(C.c_uint32),
            C.POINTER(C.c_uint64), C.POINTER(C.c_float), C.c_uint64,
            C.POINTER(C.c_uint32), C.c_uint64, C.c_uint64, C.c_double]
        lib.quadric_reduce.restype = C.c_uint64
        _QUADRIC = lib
    return _QUADRIC


def triangulated_input(obj):
    dg = bpy.context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(dg)
    mesh = evaluated.to_mesh()
    if mesh is None:
        raise RuntimeError('No evaluated mesh')
    try:
        mesh.calc_loop_triangles()
        vertex_count = len(mesh.vertices)
        triangle_count = len(mesh.loop_triangles)
        if vertex_count == 0 or triangle_count == 0 or vertex_count >= 2**32:
            raise RuntimeError('Mesh has no triangles or exceeds 32-bit vertex indexing')
        positions = array('f', [0.0]) * (vertex_count * 3)
        indices = array('I', [0]) * (triangle_count * 3)
        mesh.vertices.foreach_get('co', positions)
        mesh.loop_triangles.foreach_get('vertices', indices)
        return positions, indices, vertex_count, triangle_count
    finally:
        evaluated.to_mesh_clear()


def build_result(obj, settings, mode):
    started = perf_counter()
    pos, idx, vertex_count, input_tris = triangulated_input(obj)
    desired = min(input_tris, max(4, settings.target_tris))
    output = array('I', [0]) * len(idx)
    if mode == 2:
        out_positions = array('f', [0.0]) * len(pos)
        out_vertices = C.c_uint64(0)
        count = quadric_backend().quadric_reduce(
            (C.c_float * len(out_positions)).from_buffer(out_positions),
            (C.c_uint32 * len(output)).from_buffer(output), C.byref(out_vertices),
            (C.c_float * len(pos)).from_buffer(pos), vertex_count,
            (C.c_uint32 * len(idx)).from_buffer(idx), len(idx),
            desired, settings.quality_thoroughness)
        pos = out_positions
        vertex_count = out_vertices.value
    else:
        err = C.c_float(0)
        count = backend().meshopt_reduce(
            (C.c_uint32 * len(output)).from_buffer(output),
            (C.c_uint32 * len(idx)).from_buffer(idx), len(idx),
            (C.c_float * len(pos)).from_buffer(pos), vertex_count, desired * 3,
            mode, None, 0.0, 3.402823466e+38, C.byref(err))
    if count < 3 or count % 3:
        raise RuntimeError('Native simplifier returned an empty or invalid result')
    used = set(output[:count])
    if max(used) >= vertex_count:
        raise RuntimeError('Native simplifier returned an invalid vertex index')
    remap = {old: new for new, old in enumerate(sorted(used))}
    verts = [(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]) for i in sorted(used)]
    faces = [(remap[output[i]], remap[output[i + 1]], remap[output[i + 2]])
             for i in range(0, count, 3)]
    mesh = bpy.data.meshes.new(obj.name + ('_simplified_fast' if mode == 1 else '_simplified_qem' if mode == 2 else '_simplified_standard'))
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    result = bpy.data.objects.new(mesh.name, mesh)
    result.matrix_world = obj.matrix_world.copy()
    (obj.users_collection[0] if obj.users_collection else bpy.context.collection).objects.link(result)
    result['simplify_source'] = obj.name
    result['simplify_input_tris'] = input_tris
    result['simplify_output_tris'] = count // 3
    result['simplify_seconds'] = round(perf_counter() - started, 3)
    result['simplify_method'] = ('Standard', 'Fast', 'Quadric')[mode]
    return result


class SimplificationSettings(bpy.types.PropertyGroup):
    target_tris: IntProperty(name='Target Triangles', default=50000, min=4)
    quality_thoroughness: FloatProperty(name='Quadric Thoroughness', default=6.0, min=5.0, max=8.0,
        description='Lower values use more conservative collapse thresholds and can take longer')


class MESH_SIMPLIFY_OT_run(bpy.types.Operator):
    bl_idname = 'mesh_simplification.run'
    bl_label = 'Simplify'
    bl_options = {'REGISTER', 'UNDO'}
    mode: IntProperty(default=1, min=0, max=2)

    def execute(self, context):
        source = context.active_object
        if not source or source.type != 'MESH':
            self.report({'ERROR'}, 'Select an original mesh object')
            return {'CANCELLED'}
        try:
            result = build_result(source, context.scene.mesh_simplification, self.mode)
        except Exception as exc:
            self.report({'ERROR'}, f'{type(exc).__name__}: {exc}')
            return {'CANCELLED'}
        for obj in context.selected_objects:
            obj.select_set(False)
        result.select_set(True)
        context.view_layer.objects.active = result
        self.report({'INFO'}, f'{result["simplify_output_tris"]:,} triangles in {result["simplify_seconds"]:.1f}s (target may be limited by topology)')
        return {'FINISHED'}


class MESH_SIMPLIFY_PT_panel(bpy.types.Panel):
    bl_label = 'Mesh Simplification'
    bl_idname = 'MESH_SIMPLIFY_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Mesh Simplification'

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene.mesh_simplification, 'target_tris')
        row = layout.row(align=True)
        row.operator('mesh_simplification.run', text='Fast').mode = 1
        row.operator('mesh_simplification.run', text='Standard').mode = 0
        layout.prop(context.scene.mesh_simplification, 'quality_thoroughness')
        layout.operator('mesh_simplification.run', text='Quadric (QEM)').mode = 2
        layout.label(text='Output: new mesh object')
        layout.label(text='Geometry only; no UV or material transfer')
        obj = context.active_object
        if obj and 'simplify_seconds' in obj:
            layout.label(text=f'{obj["simplify_output_tris"]:,} tris in {obj["simplify_seconds"]:.1f}s')


CLASSES = (SimplificationSettings, MESH_SIMPLIFY_OT_run, MESH_SIMPLIFY_PT_panel)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mesh_simplification = PointerProperty(type=SimplificationSettings)


def unregister():
    del bpy.types.Scene.mesh_simplification
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
